package com.citizencalc.gstcalculator

var PURCHASE = ""
