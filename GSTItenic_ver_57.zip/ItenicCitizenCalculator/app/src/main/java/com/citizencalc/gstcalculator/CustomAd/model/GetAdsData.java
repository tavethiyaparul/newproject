package com.citizencalc.gstcalculator.CustomAd.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class GetAdsData implements Serializable {
    @SerializedName("data")
    private ArrayList<Data> data;
    @SerializedName("splash")
    private ArrayList<Data> splash;

    public ArrayList<Data> getData() {
        return data;
    }

    public void setData(ArrayList<Data> data) {
        this.data = data;
    }

    public ArrayList<Data> getSplash() {
        return splash;
    }

    public void setSplash(ArrayList<Data> splash) {
        this.splash = splash;
    }
}