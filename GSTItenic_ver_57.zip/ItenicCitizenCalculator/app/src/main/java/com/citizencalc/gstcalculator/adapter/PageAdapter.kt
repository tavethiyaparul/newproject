package com.citizencalc.gstcalculator.adapter

import android.graphics.pdf.PdfRenderer
import android.os.Parcel
import android.os.ParcelFileDescriptor
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.citizencalc.gstcalculator.databinding.PageBinding

class PageAdapter() : RecyclerView.Adapter<PageController>(), Parcelable {

    private var renderer: PdfRenderer? = null

    constructor(parcel: Parcel) : this()

    constructor(pfd:ParcelFileDescriptor) : this() {
        renderer = PdfRenderer(pfd)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageController {
        val binding = PageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PageController(binding)
    }

    override fun getItemCount(): Int {
        return(renderer!!.pageCount)
    }

    override fun onBindViewHolder(holder: PageController, position: Int) {
        val page = renderer!!.openPage(position)
        holder.setPage(page)
        page.close()
    }

    fun close() {
        renderer?.close()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<PageAdapter> {
        override fun createFromParcel(parcel: Parcel): PageAdapter {
            return PageAdapter(parcel)
        }

        override fun newArray(size: Int): Array<PageAdapter?> {
            return arrayOfNulls(size)
        }
    }
}