package com.citizencalc.gstcalculator.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.citizencalc.gstcalculator.R;

public class SearchHolder extends RecyclerView.ViewHolder {
    public ImageView search_unit_icon;
    public TextView search_unit_name,search_unit_code,search_unit_parent_name;
    public RelativeLayout search_layout,search_icon_bg;
    public SearchHolder(@NonNull View itemView) {
        super(itemView);
        search_unit_icon = itemView.findViewById(R.id.search_unit_icon);
        search_unit_name = itemView.findViewById(R.id.search_unit_name);
        search_unit_code = itemView.findViewById(R.id.search_unit_code);
        search_unit_parent_name = itemView.findViewById(R.id.search_unit_parent_name);
        search_layout = itemView.findViewById(R.id.search_layout);
        search_icon_bg = itemView.findViewById(R.id.search_icon_bg);
    }
}
