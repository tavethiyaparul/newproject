package com.citizencalc.gstcalculator.model

class HistoryData() {
    var first_oprand: String? = null
    var second_oprand: String? = null
    var result_total: String? = null
    var oprator: String? = null
}