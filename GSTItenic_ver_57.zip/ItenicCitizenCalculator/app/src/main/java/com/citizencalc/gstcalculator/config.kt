package com.citizencalc.gstcalculator

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import androidx.annotation.Keep
import androidx.room.*
import com.citizencalc.gstcalculator.Classes.common.AppKey
import com.citizencalc.gstcalculator.Classes.common.Custom_Ad_Path
import com.citizencalc.gstcalculator.Classes.common.GAME_PAGE_URL
import com.citizencalc.gstcalculator.Classes.common.GstApp
import com.citizencalc.gstcalculator.Classes.common.NodeConnection
import com.citizencalc.gstcalculator.Classes.common.PRO_DIALOG_DAYS
import com.citizencalc.gstcalculator.Classes.common.config_tag
import com.citizencalc.gstcalculator.RoomDb.Companion.caAdsDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbAppConfigDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbSkuDao
import com.citizencalc.gstcalculator.database.dao.*
import com.citizencalc.gstcalculator.database.table.*
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import com.ihsanbal.logging.Level
import com.ihsanbal.logging.LoggingInterceptor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.internal.platform.Platform
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import javax.net.ssl.SSLHandshakeException

const val dbName = "gst_calculator.db"

@Keep
class Converters {
    @TypeConverter
    fun fromString(value: String): ArrayList<TbAdsPublisherId> {
        val listType = object : TypeToken<ArrayList<TbAdsPublisherId>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromArrayList(list: ArrayList<TbAdsPublisherId>): String {
        val gson = Gson()
        return gson.toJson(list)
    }

    @TypeConverter
    fun fromColorString(value: String): ArrayList<String> {
        val listType = object : TypeToken<ArrayList<String>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromColorArrayList(list: ArrayList<String>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}

/*@Volatile
@JvmField
var instances: RoomDb? = null*/

@Database(
    entities = [CaAds::class, CaTags::class, TbAdsName::class, TbAdsPublisherId::class, TbAppConfig::class, TbSku::class, RoomOrder::class],
    exportSchema = false,
    version = 3
)
@TypeConverters(Converters::class)
abstract class RoomDb : RoomDatabase() {
    companion object {
        /*fun getInstance(context: Context): RoomDb? {
            if (instances == null) {
                instances = Room.databaseBuilder(context, RoomDb::class.java, dbName)
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build()
            }
            return instances
        }*/
        private val instance by lazy {
            Room.databaseBuilder(GstApp.appInstance, RoomDb::class.java, dbName)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build()
        }
        val caAdsDao get() = instance.caAdsDao()
        val caTagsDao get() = instance.caTagsDao()
        val tbAdsNameDao get() = instance.tbAdsNameDao()
        val tbAppConfigDao get() = instance.tbAppConfigDao()
        val tbSkuDao get() = instance.tbSkuDao()
        val roomOrderDao get() = instance.roomOrderDao()
    }

    abstract fun caAdsDao(): CaAdsDao
    abstract fun caTagsDao(): CaTagsDao
    abstract fun tbAdsNameDao(): TbAdsNameDao
    abstract fun tbAppConfigDao(): TbAppConfigDao
    abstract fun tbSkuDao(): TbSkuDao
    abstract fun roomOrderDao(): RoomOrderDao
}

fun Context.getAPIService(url: String): ApiClient? {
    return if (isNetworkConnected() && url.contains("http")) try {
        getClient(url)?.create(ApiClient::class.java)
    } catch (e: NullPointerException) {
        null
    } catch (e: Exception) {
        null
    } else null
}

fun getClient(baseUrl: String): Retrofit? {
    try {
        val interceptor = Interceptor { chain ->
            try {
                val original = chain.request()
                val builder = original.newBuilder()
                builder.header("app_secret", AppKey)
                builder.method(original.method, original.body)
                val request = builder.build()
                chain.proceed(request)
            } catch (e: TimeoutException) {
                throw e
            } catch (e: IOException) {
                throw e
            } catch (e: SocketTimeoutException) {
                throw e
            } catch (e: SocketException) {
                throw e
            } catch (e: SSLHandshakeException) {
                throw e
            } catch (e: UnknownHostException) {
                throw e
            } catch (e: ConnectException) {
                throw e
            } catch (e: Exception) {
                throw e
            }
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(
                LoggingInterceptor.Builder()
                    .setLevel(if (BuildConfig.DEBUG) Level.BASIC else Level.NONE)
                    .log(Platform.INFO)
                    .log(1)
                    .request("Request")
                    .response("Response")
                    .build()
            )
            .addInterceptor(interceptor)
            .connectTimeout(1, TimeUnit.MINUTES)
            .readTimeout(1, TimeUnit.MINUTES)
            .build()
        return Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(baseUrl)
            .client(client)
            .build()
    } catch (e: TimeoutException) {
        return null
    } catch (e: IOException) {
        return null
    } catch (e: SocketTimeoutException) {
        return null
    } catch (e: SocketException) {
        return null
    } catch (e: SSLHandshakeException) {
        return null
    } catch (e: UnknownHostException) {
        return null
    } catch (e: ConnectException) {
        return null
    } catch (e: Exception) {
        return null
    }
}


interface ApiClient {
    @POST(".")
    fun getData(@Body jsonObject: JsonObject): Call<JsonObject>

    @GET("subscriptions/")
    fun getVerificationData(
        @Query("packageName") packageName: String,
        @Query("sku") sku: String,
        @Query("token") token: String
    ): Response<JsonObject>
}

data class VerificationRequest(
    @SerializedName("packageName") val packageName: String,
    @SerializedName("sku") val sku: String,
    @SerializedName("token") val token: String
)

fun Context.isNetworkConnected(): Boolean {
    return run {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val capabilities = connectivityManager
            .getNetworkCapabilities(network)
        (capabilities != null
                && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
    }
}


fun fetchRemoteData(call: () -> Unit) {
    val firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
    firebaseRemoteConfig.setConfigSettingsAsync(
        FirebaseRemoteConfigSettings.Builder()
            .setMinimumFetchIntervalInSeconds(600)
            .build()
    )
    firebaseRemoteConfig.fetchAndActivate()
        .addOnCompleteListener {
            val response = firebaseRemoteConfig.getString(config_tag)
            try {
                val jsonObject = JSONObject(response)

                val jsonArray = jsonObject.getJSONArray("live")

                val liveJsonObject = jsonArray.getJSONObject(0)
                liveJsonObject.getString("custom_ads_path")
                NodeConnection = liveJsonObject.getString("node_connection")
                Custom_Ad_Path = liveJsonObject.getString("custom_ads_path")
                GAME_PAGE_URL = liveJsonObject.getString("game_url")
                PRO_DIALOG_DAYS = liveJsonObject.getInt("pro_dialog_days")
                AppKey = liveJsonObject.getString("app_key")
                call.invoke()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
}


fun Context.jobSKU(callback: () -> Unit) {
    val jsonObject = JsonObject()
    jsonObject.addProperty("event_name", "sku")

    val api = getAPIService(NodeConnection)
    if (api != null) {
        val call = api.getData(jsonObject)
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if (response.isSuccessful) {
                    val jsonObjectMain = JSONObject(response.body().toString())
                    val code = jsonObjectMain.getInt("code")
                    if (code == 200) {
                        val data = jsonObjectMain.getJSONArray("data")
                        if (data.length() > 0) {
                            for (i in 0 until data.length()) {
                                try {
                                    val dataObj = data.getJSONObject(i)
                                    val tbSku = TbSku()
                                    tbSku.id = dataObj.getString("_id")
                                    tbSku.sku = dataObj.getString("sku")
                                    tbSku.title = dataObj.getString("title")
                                    tbSku.content = dataObj.getString("content")
                                    tbSku.defaultValue = dataObj.getString("default_value")
                                    tbSku.validity = dataObj.getString("validity")
                                    val color = dataObj.getJSONArray("color")
                                    if (color.length() > 0) {
                                        for (j in 0 until color.length()) {
                                            tbSku.color.add(color.getString(j))
                                        }
                                    }
                                    tbSkuDao.insert(tbSku)
                                } catch (_: java.lang.NullPointerException) {
                                }
                            }
                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            callback.invoke()
                        }
                    } else CoroutineScope(Dispatchers.Main).launch {
                        callback.invoke()
                    }
                } else CoroutineScope(Dispatchers.Main).launch {
                    callback.invoke()
                }

            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                CoroutineScope(Dispatchers.Main).launch {
                    callback.invoke()
                }
            }
        })
    }
}

fun Context.installTrackJob(callback: () -> Unit) {
    CoroutineScope(Dispatchers.Main).launch {

        val oldVer = tbAppConfigDao.getData(AC_ID_INSTALL_TRACK)
        if (oldVer != null && oldVer == BuildConfig.VERSION_CODE.toString()) {
            CoroutineScope(Dispatchers.Main).launch {
                callback.invoke()
            }
        } else {
            val jsonObject = JsonObject()
            jsonObject.addProperty("event_name", "installtrack_new")
            jsonObject.addProperty(
                "app_old_version", oldVer ?: ""
            )
            jsonObject.addProperty("app_version", BuildConfig.VERSION_CODE.toString())

            val api = getAPIService(NodeConnection)
            if (api != null) {
                val call = api.getData(jsonObject)
                call.enqueue(object : Callback<JsonObject> {
                    override fun onResponse(
                        call: Call<JsonObject>,
                        response: Response<JsonObject>
                    ) {
                        if (response.isSuccessful) {
                            val jsonObjectMain = JSONObject(response.body().toString())
                            val code = jsonObjectMain.getInt("code")
                            if (code == 200) {
                                tbAppConfigDao.insert(
                                    addInTable(
                                        AC_ID_INSTALL_TRACK,
                                        BuildConfig.VERSION_CODE.toString()
                                    )
                                )
                            }
                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            callback.invoke()
                        }
                    }

                    override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                        CoroutineScope(Dispatchers.Main).launch {
                            callback.invoke()
                        }
                    }
                })
            }
        }

    }
}

fun Context.customAdsTags() {
    CoroutineScope(Dispatchers.Main).launch {
        val jsonObject = JsonObject()
        jsonObject.addProperty("event_name", "customAds")
        val api = getAPIService(NodeConnection)
        if (api != null) {
            val call = api.getData(jsonObject)
            call.enqueue(object : Callback<JsonObject> {
                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    if (response.isSuccessful) {
                        val jsonObjectMain = JSONObject(response.body().toString())
                        val code = jsonObjectMain.getInt("code")
                        if (code == 200) {
                            val data = jsonObjectMain.getJSONArray("data")
                            for (i in 0 until data.length()) {
                                val arrayObject = data.getJSONObject(i)
                                val caAds = CaAds()
                                caAds.id = arrayObject.getString("_id")
                                caAds.adsTitle = arrayObject.getString("add_title")
                                caAds.adsDesc = arrayObject.getString("add_desc")
                                caAds.icon = arrayObject.getString("icon")
                                caAds.banner = arrayObject.getString("banner")
                                caAds.install = arrayObject.getString("install")
                                caAds.color = arrayObject.getString("color")
                                caAds.rating = arrayObject.getString("rating")
                                caAds.download = arrayObject.getString("download")
                                caAds.review = arrayObject.getString("review")
                                if (arrayObject.has("design_page")) caAds.designPage =
                                    arrayObject.getString("design_page")
                                else caAds.designPage = ""
                                caAds.advertisementCustomMulti =
                                    arrayObject.getString("advertisement_custom_multi")
                                caAds.enable = arrayObject.getInt("enable")
                                caAds.date = arrayObject.getString("date")
                                caAdsDao.insert(caAds)
                            }
                        }
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {

                }
            })
        }
    }
}