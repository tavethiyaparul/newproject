package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
@Keep
public class Ad_chield implements Serializable {

    @SerializedName("enable")
    private String enable;

    @SerializedName("adc_date")
    private String adc_date;

    @SerializedName("ad_token")
    private String ad_token;

    @SerializedName("version_Id")
    private String version_Id;

    @SerializedName("ad_keyword")
    private String ad_keyword;

    public String getEnable() {
        return enable;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public String getAdc_date() {
        return adc_date;
    }

    public void setAdc_date(String adc_date) {
        this.adc_date = adc_date;
    }

    public String getAd_token() {
        return ad_token;
    }

    public void setAd_token(String ad_token) {
        this.ad_token = ad_token;
    }

    public String getVersion_Id() {
        return version_Id;
    }

    public void setVersion_Id(String version_Id) {
        this.version_Id = version_Id;
    }

    public String getAd_keyword() {
        return ad_keyword;
    }

    public void setAd_keyword(String ad_keyword) {
        this.ad_keyword = ad_keyword;
    }


}