package com.citizencalc.gstcalculator.Classes.common

import androidx.core.content.FileProvider

class GenericFileProvider:FileProvider() {
}