package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
@Keep
public class Getversion implements Serializable {

    @SerializedName("enable")
    private String enable;

   @SerializedName("count")
    private String count;

    @SerializedName("adm_date")
    private String adm_date;

    @SerializedName("version_Id")
    private String version_Id;


    @SerializedName("ad_chield")
    private ArrayList<Ad_chield> ad_chield;

    @SerializedName("adm_name")
    private String adm_name;


    public String getEnable() {
        return enable;
    }

    public ArrayList<Ad_chield> getAd_chield() {
        return ad_chield;
    }

    public void setAd_chield(ArrayList<Ad_chield> ad_chield) {
        this.ad_chield = ad_chield;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getAdm_date() {
        return adm_date;
    }

    public void setAdm_date(String adm_date) {
        this.adm_date = adm_date;
    }

    public String getVersion_Id() {
        return version_Id;
    }

    public void setVersion_Id(String version_Id) {
        this.version_Id = version_Id;
    }


    public String getAdm_name() {
        return adm_name;
    }

    public void setAdm_name(String adm_name) {
        this.adm_name = adm_name;
    }
}