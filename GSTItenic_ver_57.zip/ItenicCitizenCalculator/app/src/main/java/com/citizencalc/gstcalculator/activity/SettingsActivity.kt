package com.citizencalc.gstcalculator.activity

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Last_Unit_Tag
import com.citizencalc.gstcalculator.Classes.common.AppUtility.NumberFormat
import com.citizencalc.gstcalculator.Classes.common.AppUtility.NumberFormatID
import com.citizencalc.gstcalculator.Classes.common.AppUtility.PREF_TAG
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Play_Store_Url
import com.citizencalc.gstcalculator.Classes.common.AppUtility.RATE_US_COM
import com.citizencalc.gstcalculator.databinding.DialogRateUsBinding
import com.citizencalc.gstcalculator.databinding.UnitSettingActivityNewBinding
import kotlin.system.exitProcess

class SettingsActivity : AppCompatActivity() {
    
    lateinit var binding : UnitSettingActivityNewBinding
    lateinit var ActionBarTitle: TextView
    lateinit var suggestion_text: TextView
    lateinit var round_text: TextView
    lateinit var shareText: TextView
    lateinit var rateText: TextView
    lateinit var Unit_preferences: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    private var radioGroup: RadioGroup? = null

    //SwitchCompat switch_sound, switch_vibration;
    lateinit var rate: RelativeLayout
    lateinit var shareApp: RelativeLayout
    lateinit var mail: RelativeLayout
    internal var suggest: TextView? = null
    lateinit var version: TextView
    lateinit var roundOffText: TextView
    private val mRateValue = 0f
    lateinit var seekbar: SeekBar

    var myLanStringValue: String? = null

    internal var states = arrayOf(intArrayOf(-android.R.attr.state_checked), intArrayOf(android.R.attr.state_checked))
    internal var thumbColors = intArrayOf(Color.WHITE, Color.rgb(255, 136, 0))
    internal var trackColors = intArrayOf(Color.rgb(30, 28, 31), Color.rgb(122, 88, 49))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = UnitSettingActivityNewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }

        val sp = getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        myLanStringValue = sp.getString("is_radio_name", "")

        val toolbar = findViewById<Toolbar>(R.id.toolbar_setting)
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayShowCustomEnabled(true)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        val inflator = LayoutInflater.from(this)
        val v = inflator.inflate(R.layout.custom_actionbar, null)
        ActionBarTitle = v.findViewById(R.id.action_bar_title)
        ActionBarTitle.setTextColor(resources.getColor(R.color.white))
        supportActionBar!!.customView = v

        supportActionBar!!.setBackgroundDrawable(ColorDrawable(resources.getColor(R.color.colorPrimaryAppThemeDark)))

        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        init()

        if (myLanStringValue == "Gujarati") {
            ActionBarTitle.text = resources.getString(R.string.Gujarati_title_setting_unit)
            binding.txtDecimalPlace.text = resources.getString(R.string.Gujarati_decimal_palce)
            binding.txtAnsDecimal.text = resources.getString(R.string.Gujarati_decimal_palce_)
            binding.txtNumberFormat.text = resources.getString(R.string.Gujarati_NumberFormat)
            binding.txtgenralDecimal.text = resources.getString(R.string.Gujarati_title_genral_decimal)
            binding.txtScientific.text = resources.getString(R.string.Gujarati_title_Scienitifc_decimal)
            binding.txtthousandsSeperator.text = resources.getString(R.string.Gujarati_title_Thousand_seprator)
            round_text.text = resources.getString(R.string.Gujarati_title_round)

        } else if (myLanStringValue == "Hindi") {
            ActionBarTitle.text = resources.getString(R.string.Hindi_title_setting_unit)
            binding.txtDecimalPlace.text = resources.getString(R.string.Hindi_decimal_palce)
            binding.txtAnsDecimal.text = resources.getString(R.string.Hindi_decimal_palce_)
            binding.txtNumberFormat.text = resources.getString(R.string.Hindi_NumberFormat)
            binding.txtgenralDecimal.text = resources.getString(R.string.Hindi_title_genral_decimal)
            binding.txtScientific.text = resources.getString(R.string.Hindi_title_Scienitifc_decimal)
            binding.txtthousandsSeperator.text =
                resources.getString(R.string.Hindi_title_Thousand_seprator)
            round_text.text = resources.getString(R.string.Hindi_title_round)

        } else {
            ActionBarTitle.text = resources.getString(R.string.English_title_setting_unit)
            binding.txtDecimalPlace.text = resources.getString(R.string.English_decimal_palce)
            binding.txtAnsDecimal.text = resources.getString(R.string.English_decimal_palce_)
            binding.txtNumberFormat.text = resources.getString(R.string.English_NumberFormat)
            binding.txtScientific.text = resources.getString(R.string.English_title_Scienitifc_decimal)
            binding.txtgenralDecimal.text = resources.getString(R.string.English_title_genral_decimal)
            binding.txtthousandsSeperator.text = resources.getString(R.string.English_title_Thousand_seprator)
            round_text.text = resources.getString(R.string.English_title_round)
        }

        version.text = BuildConfig.VERSION_NAME
        radioGroup?.check(Unit_preferences.getInt(NumberFormatID, R.id.round1))
        radioGroup?.setOnCheckedChangeListener { group, checkedId ->
            val radioButton = radioGroup!!.findViewById<RadioButton>(checkedId)
            if (null != radioButton && checkedId > -1) {
                editor.putString(NumberFormat, radioButton.text.toString())
                editor.putInt(NumberFormatID, radioButton.id)
                editor.apply()
            }
        }
        
        rate.setOnClickListener {
            mRateUseDialog(false)
        }

        shareApp.setOnClickListener {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(Intent.EXTRA_TEXT, Play_Store_Url + BuildConfig.APPLICATION_ID)
            sendIntent.type = "text/plain"
            startActivity(sendIntent)
        }
        
        mail.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO)
            val recipients = arrayOf("itenicapps@gmail.com")
            intent.data = Uri.parse("mailto:")
            intent.putExtra(Intent.EXTRA_EMAIL, recipients)
            intent.putExtra(Intent.EXTRA_SUBJECT, "Feedback About " + resources.getString(R.string.app_label))
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(Intent.createChooser(intent, "Send mail"))
            }
        }
    }

    private fun init() {
        Unit_preferences = getSharedPreferences(Last_Unit_Tag, Context.MODE_PRIVATE)
        editor = Unit_preferences.edit()
        radioGroup = findViewById(R.id.radio_group)
        rate = findViewById(R.id.R_rate)
        shareApp = findViewById(R.id.R_share)
        mail = findViewById(R.id.R_about)
        suggestion_text = findViewById(R.id.suggetion)
        version = findViewById(R.id.version_name)
        roundOffText = findViewById(R.id.round_off_text)
        shareText = findViewById(R.id.share_text)
        rateText = findViewById(R.id.rate_text)
        round_text = findViewById(R.id.round_text)
        seekbar = findViewById(R.id.seekbar)
        seekbar.progress = Integer.parseInt(Unit_preferences.getString("unit_round", "0")!!)
        roundOffText.text = Unit_preferences.getString("unit_round", "0")

        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                try {
                    setRoundoff(progress)
                    editor.putString("unit_round", progress.toString())
                    editor.apply()
                } catch (e: StackOverflowError) {
                    e.printStackTrace()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {

            }
        })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }

    internal fun setRoundoff(i: Int) {
        when (i) {
            0 -> {
                seekbar.progress = i
                roundOffText.text = "0"
            }
            1 -> {
                seekbar.progress = i
                roundOffText.text = "1"
            }
            2 -> {
                seekbar.progress = i
                roundOffText.text = "2"
            }
            3 -> {
                seekbar.progress = i
                roundOffText.text = "3"
            }
            4 -> {
                seekbar.progress = i
                roundOffText.text = "4"
            }
            5 -> {
                seekbar.progress = i
                roundOffText.text = "5"
            }
            6 -> {
                seekbar.progress = i
                roundOffText.text = "6"
            }
            7 -> {
                seekbar.progress = i
                roundOffText.text = "7"
            }
            8 -> {
                seekbar.progress = i
                roundOffText.text = "8"
            }
            9 -> {
                seekbar.progress = i
                roundOffText.text = "9"
            }
            10 -> {
                seekbar.progress = i
                roundOffText.text = "10"
            }
        }
    }

    private fun mRateUseDialog(isExit: Boolean) {
        val dialog = Dialog(this@SettingsActivity)
        val binding = DialogRateUsBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)
        dialog.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)

        when (myLanStringValue) {
            "Gujarati" -> {
                binding.txtTitle.text = resources.getString(R.string.Gujarati_Rate_this_app)
                binding.txtTitleDialog.text = resources.getString(R.string.Gujarati_rate_desc)
                binding.btnYes.text = resources.getString(R.string.Gujarati_rate_now)
                binding.btnNoThanks.text = resources.getString(R.string.Gujarati_txt_no_thanks)
                binding.btnRemindMeLater.text = resources.getString(R.string.Gujarati_remind_me_later)
            }
            "Hindi" -> {
                binding.txtTitle.text = resources.getString(R.string.Hindi_Rate_this_app)
                binding.txtTitleDialog.text = resources.getString(R.string.Hindi_rate_desc)
                binding.btnYes.text = resources.getString(R.string.Hindi_rate_now)
                binding.btnNoThanks.text = resources.getString(R.string.Hindi_txt_no_thanks)
                binding.btnRemindMeLater.text = resources.getString(R.string.Hindi_remind_me_later)
            }
            else -> {
                binding.txtTitle.text = resources.getString(R.string.English_Rate_this_app)
                binding.txtTitleDialog.text = resources.getString(R.string.English_rate_desc)
                binding.btnYes.text = resources.getString(R.string.English_rate_now)
                binding.btnNoThanks.text = resources.getString(R.string.English_txt_no_thanks)
                binding.btnRemindMeLater.text = resources.getString(R.string.English_remind_me_later)
            }
        }

        dialog.findViewById<View>(R.id.btn_no_thanks).setOnClickListener { view ->
            if (isExit) exitProcess(0)
            else dialog.dismiss()
        }

        dialog.findViewById<View>(R.id.btn_yes).setOnClickListener { view ->
            val editor = Unit_preferences.edit()
            editor.putString(RATE_US_COM, "true")
            editor.apply()

            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=$packageName")))
            dialog.dismiss()
        }

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        dialog.show()
    }
}