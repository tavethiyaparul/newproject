package com.citizencalc.gstcalculator.fragment


import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.widget.AppCompatEditText
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.citizencalc.gstcalculator.BANNER_CONVERTER_ADS_NAME
import com.citizencalc.gstcalculator.Classes.common.AppUtility.*
import com.citizencalc.gstcalculator.Classes.common.UnitTag.*
import com.citizencalc.gstcalculator.CustomAd.ui.AdsInit
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.SUBSCRIPTION_STATE
import com.citizencalc.gstcalculator.activity.*
import com.citizencalc.gstcalculator.adapter.UnitAdapter
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.databinding.LayoutFragmentUtnitBinding
import com.citizencalc.gstcalculator.gstAdsBuilder
import com.citizencalc.gstcalculator.model.UnitData
import com.google.gson.Gson
import java.text.DecimalFormat
import java.util.*

class UnitCalculator : Fragment() {

    lateinit var binding : LayoutFragmentUtnitBinding
    lateinit var recyclerView: RecyclerView
    lateinit var unitAdapter: UnitAdapter
    lateinit var unitData: UnitData
    lateinit var adsInit: AdsInit

    var myLanStringValue: String? = null

    internal var preferencesIronceSourceId: SharedPreferences? = null
    lateinit var preferences: SharedPreferences
    lateinit var Last_Unit: SharedPreferences
    internal var preferencesIronceSourceIdEditer: SharedPreferences.Editor? = null


    internal var exit_layout: RelativeLayout? = null
    lateinit var iornsource_parent: RelativeLayout


    lateinit var databaseGst: DatabaseGst

    lateinit var to_txt: TextView
    lateinit var from_txt: TextView
    lateinit var from_ucode: TextView
    lateinit var to_ucode: TextView
    lateinit var from_edit: AppCompatEditText
    lateinit var to_edit: AppCompatEditText
    lateinit var switch_image: ImageView
    lateinit var rotate: Animation
    internal var switch_from_txt = ""
    internal var switch_to_txt = ""
    internal var switch_from_ucode = ""
    internal var switch_to_ucode = ""
    lateinit var last_used_card: CardView
    internal var decimalformat = DecimalFormat(Decimal_format)


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setHasOptionsMenu(true)
        init(view)

        val sp = activity?.getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        myLanStringValue = sp?.getString("is_radio_name", "")

        val gson = Gson()
        unitData = gson.fromJson(loadJSONFromAsset(requireActivity()), UnitData::class.java)

        decimalformat.minimumFractionDigits = 0
        decimalformat.maximumFractionDigits = 12
        decimalformat.minimumIntegerDigits = 1
        decimalformat.maximumIntegerDigits = 12

        val gridLayoutManager = GridLayoutManager(activity, 3, RecyclerView.VERTICAL, false)
        recyclerView.layoutManager = gridLayoutManager
        unitAdapter = UnitAdapter(requireActivity(), unitData)
        recyclerView.adapter = unitAdapter

        databaseGst = DatabaseGst(activity)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = LayoutFragmentUtnitBinding.inflate(inflater, container, false)
        return binding.root
    }

    private fun init(view: View) {
        preferences = requireActivity().getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        Last_Unit = requireActivity().getSharedPreferences(Last_Unit_Tag, MODE_PRIVATE)
        recyclerView = view.findViewById(R.id.unit_recycle)

        last_used_card = view.findViewById(R.id.last_used_card)


        to_txt = view.findViewById(R.id.to_txt)
        from_txt = view.findViewById(R.id.from_txt)
        from_ucode = view.findViewById(R.id.from_ucode)
        to_ucode = view.findViewById(R.id.to_ucode)
        from_edit = view.findViewById(R.id.from_edit)
        to_edit = view.findViewById(R.id.to_edit)
        switch_image = view.findViewById(R.id.switch_image)
        switch_image.setOnClickListener { switchUnit() }
        rotate = RotateAnimation(
            0f,
            180f,
            Animation.RELATIVE_TO_SELF,
            0.5f,
            Animation.RELATIVE_TO_SELF,
            0.5f
        )
        rotate.duration = 200
        setLast_unit()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.unit_menu, menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_search) {
            startActivity(Intent(activity, SearchActivty::class.java))
        } else if (item.itemId == R.id.action_unit_settings) {
            startActivity(Intent(activity, SettingsActivity::class.java))
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setLast_unit() {
        if (Last_Unit.getString(Unit_Parent, "") == "" && Last_Unit.getString(Unit_From, "") == "" && Last_Unit.getString(Unit_To, "") == "" && Last_Unit.getString(Unit_From_Value, "") == ""
            && Last_Unit.getString(Unit_To_Code, "") == "" && Last_Unit.getString(Unit_From_Code, "") == "") {

            setBackground(last_used_card, Area)

            when (myLanStringValue) {
                "Gujarati" -> {
                    from_txt.text = activity?.resources?.getText(R.string.Gujarati_Square_Meter)
                    to_txt.text = activity?.resources?.getText(R.string.Gujarati_Square_Kilometer)
                }
                "Hindi" -> {
                    from_txt.text = activity?.resources?.getText(R.string.Hindi_Square_Meter)
                    to_txt.text = activity?.resources?.getText(R.string.Hindi_Square_Meter)
                }
                else -> {
                    from_txt.text = activity?.resources?.getText(R.string.English_Square_Meter)
                    to_txt.text = activity?.resources?.getText(R.string.English_Square_Meter)
                }
            }
            from_ucode.text = "m2"
            to_ucode.text = "km2"
            from_edit.setText("1")
            converstetion(Area)

        } else {

            setBackground(last_used_card, Area)
            setBackground(last_used_card, Last_Unit.getString(Unit_Parent, "")!!)
            from_txt.text = Last_Unit.getString(Unit_From, "")
            to_txt.text = Last_Unit.getString(Unit_To, "")
            from_ucode.text = Last_Unit.getString(Unit_From_Code, "")
            to_ucode.text = Last_Unit.getString(Unit_To_Code, "")
            from_edit.setText(Last_Unit.getString(Unit_From_Value, ""))
            converstetion(Last_Unit.getString(Unit_Parent, ""))
        }
    }

    private fun switchUnit() {
        switch_from_txt = from_txt.text.toString()
        switch_to_txt = to_txt.text.toString()
        switch_from_ucode = from_ucode.text.toString()
        switch_to_ucode = to_ucode.text.toString()
        switch_image.startAnimation(rotate)
        rotate.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(animation: Animation) {

            }

            override fun onAnimationEnd(animation: Animation) {
                from_txt.text = switch_to_txt
                to_txt.text = switch_from_txt
                from_ucode.text = switch_to_ucode
                to_ucode.text = switch_from_ucode
                converstetion(Last_Unit.getString(Unit_Parent, ""))
            }

            override fun onAnimationRepeat(animation: Animation) {

            }
        })
    }

    internal fun converstetion(Title: String?) {

        val s = from_ucode.text.toString() + "-" + to_ucode.text.toString()
        from_edit.setSelection(from_edit.text!!.toString().length)
        to_edit.setText(Title?.let { setNumberFormat(s, it) })
    }


    private fun setBackground(v: CardView, s: String) {


        when (s) {
            Area -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.deep_orange
                )
            )
            Length -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.purple
                )
            )
            Weight -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.teal
                )
            )
            Time -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.amber
                )
            )
            Tempreture -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.blue_grey
                )
            )
            Speed -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.yellow
                )
            )
            Volume -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.cyne
                )
            )
            Energy -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.lime
                )
            )
            Fuel -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.brown
                )
            )
            Presure -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.indigo
                )
            )
            Storage -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.green
                )
            )
            else -> v.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.green
                )
            )
        }
    }

    internal fun setNumberFormat(vararg str: String): String {
        try {
            when (Last_Unit.getString(NumberFormat, General)) {
                General -> return String.format(
                    setRoundOff(
                        Integer.parseInt(
                            Last_Unit.getString(
                                "unit_round",
                                "4"
                            )!!
                        )
                    ),
                    java.lang.Double.valueOf(
                        GetConversation(
                            str[0],
                            from_edit.text!!.toString(),
                            str[1]
                        )
                    )
                )
                Thousands -> {
                    val sb = StringBuilder()
                    val formatter = Formatter(sb, Locale.US)
                    return formatter.format(
                        " %(," + setThousandRoundOff(
                            Integer.parseInt(
                                Last_Unit.getString(
                                    "unit_round",
                                    "4"
                                )!!
                            )
                        ),
                        java.lang.Double.valueOf(
                            GetConversation(
                                str[0],
                                from_edit.text!!.toString(),
                                str[1]
                            )
                        )
                    ).toString()
                }
                Scitific -> return java.lang.Double.valueOf(
                    GetConversation(
                        str[0],
                        from_edit.text!!.toString(),
                        str[1]
                    )
                ).toString()
                else -> return String.format(
                    setRoundOff(
                        Integer.parseInt(
                            Last_Unit.getString(
                                "unit_round",
                                "4"
                            )!!
                        )
                    ),
                    java.lang.Double.valueOf(
                        GetConversation(
                            str[0],
                            from_edit.text!!.toString(),
                            str[1]
                        )
                    )
                )
            }
        } catch (e: NumberFormatException) {
            e.printStackTrace()
            return from_edit.text!!.toString()
        } catch (e: NullPointerException) {
            e.printStackTrace()
            return from_edit.text!!.toString()
        } catch (e: Exception) {
            e.printStackTrace()
            return from_edit.text!!.toString()
        }

    }
}
