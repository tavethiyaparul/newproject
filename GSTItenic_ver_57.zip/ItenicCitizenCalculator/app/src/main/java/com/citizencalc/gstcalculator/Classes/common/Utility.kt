package com.citizencalc.gstcalculator.Classes.common

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import com.citizencalc.gstcalculator.AC_ID_AD_ON
import com.citizencalc.gstcalculator.AC_ID_APP_KEY
import com.citizencalc.gstcalculator.AC_ID_CUSTOM_AD_PATH
import com.citizencalc.gstcalculator.AC_ID_GAME_ON
import com.citizencalc.gstcalculator.AC_ID_GAME_PAGE_URL
import com.citizencalc.gstcalculator.AC_ID_NODE_CONNECTION
import com.citizencalc.gstcalculator.AC_ID_SPLASH_BANNER
import com.citizencalc.gstcalculator.AC_PREMIUM_ON
import com.citizencalc.gstcalculator.AC_PRO_DIALOG_DAYS
import com.citizencalc.gstcalculator.ID_PURCHASE_DIALOG
import com.citizencalc.gstcalculator.ID_TIME_STAMP_FULL_SPLASH
import com.citizencalc.gstcalculator.RoomDb.Companion.tbAppConfigDao
import com.citizencalc.gstcalculator.database.table.TbAppConfig

fun insertIntoTable(id: Int, data: String) {
    val settings = TbAppConfig()
    settings.id = id
    settings.data = data
    tbAppConfigDao.insert(settings)
}

inline var NodeConnection: String
    get() = tbAppConfigDao.getData(AC_ID_NODE_CONNECTION) ?: ""
    set(string) = insertIntoTable(AC_ID_NODE_CONNECTION, string)

inline var AppKey: String
    get() = tbAppConfigDao.getData(AC_ID_APP_KEY) ?: ""
    set(string) = insertIntoTable(AC_ID_APP_KEY, string)

inline var Game_On: Int
    get() = tbAppConfigDao.getData(AC_ID_GAME_ON)?.toInt() ?: 0
    set(string) = insertIntoTable(AC_ID_GAME_ON, string.toString())

inline var idAppAdsEnable: Int
    get() = tbAppConfigDao.getData(AC_ID_AD_ON)?.toInt() ?: 0
    set(string) = insertIntoTable(AC_ID_AD_ON, string.toString())
var premium_On: Int
    get() = tbAppConfigDao.getData(AC_PREMIUM_ON)?.toInt() ?: 0
    set(string) = insertIntoTable(AC_PREMIUM_ON, string.toString())

inline var Custom_Ad_Path: String
    get() = tbAppConfigDao.getData(AC_ID_CUSTOM_AD_PATH) ?: ""
    set(string) = insertIntoTable(AC_ID_CUSTOM_AD_PATH, string)

inline var GAME_PAGE_URL: String
    get() = tbAppConfigDao.getData(AC_ID_GAME_PAGE_URL) ?: ""
    set(string) = insertIntoTable(AC_ID_GAME_PAGE_URL, string)

inline var PRO_DIALOG_DAYS: Int
    get() = tbAppConfigDao.getData(AC_PRO_DIALOG_DAYS)?.toInt() ?: 1
    set(string) = insertIntoTable(AC_PRO_DIALOG_DAYS, string.toString())

inline var TIME_STAMP_ID_PURCHASE_DIALOG: Long
    get() = tbAppConfigDao.getData(ID_PURCHASE_DIALOG) ?.toLong() ?: 0L
    set(string) = insertIntoTable(ID_PURCHASE_DIALOG, string.toString())

inline var TIME_STAMP_FULL_SPLASH: Long
    get() = tbAppConfigDao.getData(ID_TIME_STAMP_FULL_SPLASH)?.toLong() ?: 0L
    set(string) = insertIntoTable(ID_TIME_STAMP_FULL_SPLASH, string.toString())

const val config_tag = "app_data"
const val NO_DATA_FOUND = "NO_DATA_FOUND"
const val ALTERNATIVE = "ALTERNATIVE"
const val CUSTOM = "CUSTOM"

const val READ_PERMISSION_CODE = 200
fun hasPermissions(context: Context?, permissions: Array<String>?): Boolean {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
        for (item in permissions) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    item
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }
    }
    return true
}