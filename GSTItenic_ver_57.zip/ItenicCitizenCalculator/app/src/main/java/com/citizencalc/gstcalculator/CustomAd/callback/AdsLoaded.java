package com.citizencalc.gstcalculator.CustomAd.callback;

import java.util.ArrayList;

public interface AdsLoaded {
    void onLoaded(ArrayList<String> arrayList, int pos);

    void onFailed();
}
