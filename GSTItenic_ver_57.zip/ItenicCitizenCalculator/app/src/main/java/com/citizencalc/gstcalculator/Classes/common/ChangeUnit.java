package com.citizencalc.gstcalculator.Classes.common;

public interface ChangeUnit {
    public void SetUnitValues(String...str);
}
