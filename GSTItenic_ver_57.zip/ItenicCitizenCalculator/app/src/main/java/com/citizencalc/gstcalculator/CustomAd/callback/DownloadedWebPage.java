package com.citizencalc.gstcalculator.CustomAd.callback;

public interface DownloadedWebPage {
    void onSuccess();
    void onFailed();
}
