package com.citizencalc.gstcalculator.adapter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.citizencalc.gstcalculator.Classes.custom.SearchFilter;
import com.citizencalc.gstcalculator.R;
import com.citizencalc.gstcalculator.activity.UnitCalculatorActivity;
import com.citizencalc.gstcalculator.holder.SearchHolder;
import com.citizencalc.gstcalculator.model.UnitList;
import java.util.ArrayList;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_Postion;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_Title;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Area;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Energy;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Fuel;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Length;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Presure;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Speed;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Storage;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Tempreture;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Time;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Volume;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Weight;
public class SearchAdapter extends RecyclerView.Adapter<SearchHolder> implements Filterable {
    Activity activity;
    public ArrayList<UnitList> unitLists;
    SearchFilter filter;

    public SearchAdapter(Activity activity, ArrayList<UnitList> unitLists) {
        this.activity = activity;
        this.unitLists = unitLists;
    }

    @NonNull
    @Override
    public SearchHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.search_row_list_item, null);
        return new SearchHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull SearchHolder holder, int position) {


        setBackground(holder.search_icon_bg, unitLists.get(position).getUnit_parent());

        Glide.with(activity.getApplicationContext())
                .load(Uri.parse("file:///android_asset/unit_icon/" + unitLists.get(position).getSmall_icon()))
                .into(holder.search_unit_icon);

        holder.search_unit_name.setText(unitLists.get(position).getUnit_name());
        holder.search_unit_parent_name.setText(unitLists.get(position).getUnit_parent());
        holder.search_unit_code.setText("[ " + unitLists.get(position).getUnit_keyword() + " ]");

        holder.search_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.startActivity(new Intent(activity, UnitCalculatorActivity.class).putExtra(Unit_Title, unitLists.get(position).getUnit_parent()).putExtra(Unit_Postion, unitLists.get(position).getPoition()));
                activity.finish();
            }
        });

    }

    void setBackground(View v, String s) {


        switch (s) {
            case Area:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_orange));
                break;
            case Length:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_deep_purple));
                break;
            case Weight:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_teal));
                break;
            case Time:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_amber));
                break;
            case Tempreture:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_blue_grey));
                break;
            case Speed:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_yellow));
                break;
            case Volume:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_cyne));
                break;
            case Energy:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_lime));
                break;
            case Fuel:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_brown));
                break;
            case Presure:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_indigo));
                break;
            case Storage:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_green));
                break;
            default:
                v.setBackground(activity.getResources().getDrawable(R.drawable.search_icon_bg_green));
                break;


        }
    }

    @Override
    public int getItemCount() {
        return unitLists.size();
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new SearchFilter(this, unitLists);
        }
        return filter;
    }
}
