package com.citizencalc.gstcalculator.adapter

import android.app.Activity
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide
import com.citizencalc.gstcalculator.Classes.common.OnSetTheme
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.activity.SelectTheme

class SlidingImageAdapter(var activity: Activity, private var themeList: java.util.ArrayList<Drawable?>, private var themeNameList: ArrayList<String>, private var setTheme: OnSetTheme): PagerAdapter() {

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val layoutInflater = LayoutInflater.from(activity)
        val view:View = layoutInflater.inflate(R.layout.theme_preview, container, false)

        view.findViewById<AppCompatTextView>(R.id.ThemeName).text = themeNameList[position]

        Glide.with((activity as SelectTheme))
            .load("")
            .placeholder(themeList[position])
            .into(view.findViewById<AppCompatImageView>(R.id.theme_img))
        view.findViewById<AppCompatImageView>(R.id.theme_img).setOnClickListener {
            setTheme.setTheme(position)
        }

        container.addView(view)
        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view == `object`
    }

    override fun getCount(): Int {
        return themeList.size
    }
}