package com.citizencalc.gstcalculator.database.table

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters

@Keep
@Entity
class TbAdsName {
    @PrimaryKey
    var admName = ""
    var count = 0
    var enable = 1
    @TypeConverters
    var adPublisherId = ArrayList<TbAdsPublisherId>()
}