package com.citizencalc.gstcalculator.Classes.common

interface OnSetTheme {
    fun setTheme(pos:Int)
}