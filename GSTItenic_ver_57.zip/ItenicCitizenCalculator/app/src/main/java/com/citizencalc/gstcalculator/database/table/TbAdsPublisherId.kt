package com.citizencalc.gstcalculator.database.table

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey

@Keep
@Entity
class TbAdsPublisherId {
    @PrimaryKey
    var id: String = ""
    var adsId=""
    var adsName=""
    var enable=0
}