package com.citizencalc.gstcalculator.CustomAd;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

public class CustomAdsUtil {
    public static final String ASSERT_LOCATION = "custom_ads";
    public static String ASSERT_FONTS = "";
    public static String PACKAGE_NAME = "";
    public static String ASSERT_FONTS_BOLD = "";
    public static String PARAM_MAIN = "";
    public static String PARAM_PRIMARY = "";
    public static String PARAM_COUNT = "";

    public static boolean isNetworkConnected(final Context context) {
        if (context != null) {
            final ConnectivityManager connectivityManager = (ConnectivityManager) context.
                    getSystemService(Context.CONNECTIVITY_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network network = connectivityManager.getActiveNetwork();
                final NetworkCapabilities capabilities = connectivityManager
                        .getNetworkCapabilities(network);

                return capabilities != null
                        && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            } else {
                NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
                return netInfo != null && netInfo.isConnectedOrConnecting();
            }
        } else {
            return false;
        }
    }

    public static Intent getLaunchIntent(Context context, String packageName) {
        return context.getPackageManager().getLaunchIntentForPackage(packageName);
    }
}
