package com.citizencalc.gstcalculator.adapter

interface SubscriptionSku {
    fun setSku(sku:String)
}