package com.citizencalc.gstcalculator.CustomAd.callback;

public interface BannerAdsListener {
    void onBannerLoad();
    void onBannerFailed();
}
