package com.citizencalc.gstcalculator

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RatingBar
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import com.citizencalc.gstcalculator.Classes.common.*
import com.citizencalc.gstcalculator.Classes.common.GstApp.Companion.appContext
import com.citizencalc.gstcalculator.CustomAd.callback.BannerAdsListener
import com.citizencalc.gstcalculator.CustomAd.ui.BannerAds
import com.citizencalc.gstcalculator.RoomDb.Companion.caAdsDao
import com.citizencalc.gstcalculator.RoomDb.Companion.caTagsDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbAdsNameDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbAppConfigDao
import com.citizencalc.gstcalculator.activity.MainActivity.Companion.isConnectionError
import com.citizencalc.gstcalculator.database.table.*
import com.google.android.gms.ads.*
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.concurrent.TimeUnit


const val AC_ID_NODE_CONNECTION = 1
const val AC_ID_CUSTOM_AD_PATH = 2
const val AC_ID_GAME_PAGE_URL = 3
const val AC_ID_GAME_ON = 4
const val AC_ID_APP_KEY = 5
const val AC_ID_INSTALL_TRACK = 6
const val SUBSCRIPTION_STATE_ID: Int = 7
const val SUBSCRIPTION_ORDER_ID_ID: Int = 8
const val AC_PREMIUM_ON: Int = 10
const val AC_PRO_DIALOG_DAYS: Int = 11
const val AC_ID_AD_ON: Int = 12
const val AC_ID_SPLASH_BANNER: Int = 13
const val ID_TIME_STAMP_FULL_SPLASH: Int = 14
const val ID_PURCHASE_DIALOG: Int = 15

const val BOTTOM_BANNER_ADS_NAME = "Bottom_Banner"
const val SPLASH_INT = "Splash_int"
const val HISTORY_ADS_NAME = "History_int"
const val BANNER_CONVERTER_ADS_NAME = "Banner_Converter"
const val EXIT_NATIVE_ADS_NAME = "Exit_Native"
const val APP_OPEN_ADS_NAME = "App_Open"

const val GOOGLE_ADS = "Google"
const val GOOGLE_INLINE_ADAPTIVE_BANNER = "Google_inline_adaptive_banner"
const val GOOGLE_NATIVE_ADS = "GoogleNative"
const val GOOGLE_BID_ADS = "GoogleBid"

// Live Banner Id
const val LiveBannerId = "ca-app-pub-4244031033574393/4407735525"

interface AdsListener {
    fun onFail()
    fun onClick()
}

fun Context.versionDataStore(callback: () -> Unit) {
    CoroutineScope(Dispatchers.IO).launch {
        val jsonObject = JsonObject()
        jsonObject.addProperty("event_name", "version")
        jsonObject.addProperty("code", BuildConfig.VERSION_CODE.toString())
        val api = getAPIService(NodeConnection)
        if (api != null) {
            val call = api.getData(jsonObject)
            call.enqueue(object : Callback<JsonObject> {
                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    if (response.isSuccessful) {
                        val jsonObjectMain = JSONObject(response.body().toString())
                        val code = jsonObjectMain.getInt("code")
                        if (code == 200) {
                            try {
                                isConnectionError = false
                                val data = jsonObjectMain.getJSONObject("data")
                                val mode_enabled = data.getInt("enabled")
                                Game_On = data.getInt("is_game")
                                premium_On = data.getInt("is_premium")

                                Log.e(
                                    "CALC_TAG_IS_PREMIUM",
                                    "versionDataStore: " + data.getInt("is_premium")
                                )

                                idAppAdsEnable = mode_enabled
                                if (mode_enabled == 1) {
                                    tbAppConfigDao.insert(
                                        addInTable(
                                            AC_ID_AD_ON,
                                            idAppAdsEnable.toString()
                                        )
                                    )
                                    CoroutineScope(Dispatchers.Main).launch {
                                        MobileAds.initialize(appContext)
                                        MobileAds.setRequestConfiguration(
                                            RequestConfiguration.Builder()
                                                .setTestDeviceIds(
                                                    listOf(
                                                        "D8DBC08F3096BD2583D41D55B8189E55",
                                                        "838B53C92A7D41D2C6B60E788009F88B"
                                                    )
                                                )
                                                .build()
                                        )
                                    }
                                }

                                val adMaster = JSONArray(data.getString("ad_master"))
                                if (adMaster.length() > 0) {
                                    for (i in 0 until adMaster.length()) {
                                        val adsObject = adMaster.getJSONObject(i)
                                        val tbAdsName = TbAdsName()
                                        tbAdsName.admName = adsObject.getString("adm_name")
                                        try {
                                            tbAdsName.count =
                                                if (adsObject.getString("count") == "0") 0 else adsObject.getString(
                                                    "count"
                                                ).toInt()
                                        } catch (e: NumberFormatException) {
                                            tbAdsName.count = 0
                                        }
                                        tbAdsName.enable = adsObject.getInt("enable")
                                        val adChild = adsObject.getJSONArray("ad_chield")
                                        for (j in 0 until adChild.length()) {
                                            val adChildObject = adChild.getJSONObject(j)
                                            val adChildModel = TbAdsPublisherId()
                                            adChildModel.id =
                                                "${adsObject.getString("adm_name")}_$j"
                                            adChildModel.adsId = adChildObject.getString("ad_token")
                                            adChildModel.adsName =
                                                adChildObject.getString("ad_keyword")
                                            adChildModel.enable = adChildObject.getInt("enable")
                                            tbAdsName.adPublisherId.add(adChildModel)
                                        }
                                        tbAdsNameDao.insert(tbAdsName)
                                    }
                                }
                            } catch (_: JSONException) {

                            } finally {
                                CoroutineScope(Dispatchers.Main).launch {
                                    callback.invoke()
                                }
                            }
                        } else {
                            isConnectionError = true
                        }
                    } else CoroutineScope(Dispatchers.Main).launch {
                        callback.invoke()
                    }

                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    CoroutineScope(Dispatchers.Main).launch {
                        callback.invoke()
                    }
                }
            })
            /*try {
                call.let {
                    val jsonObjectMain = JSONObject(it.body().toString())
                    val code = jsonObjectMain.getInt("code")
                    if (code == 200) {
                        try {
                            isConnectionError = false
                            val data = jsonObjectMain.getJSONObject("data")
                            val mode_enabled = data.getInt("enabled")
                            Game_On = data.getInt("is_game")
                            premium_On = data.getInt("is_premium")

                            Log.e(
                                "CALC_TAG_IS_PREMIUM",
                                "versionDataStore: " + data.getInt("is_premium")
                            )

                            idAppAdsEnable = mode_enabled
                            if (mode_enabled == 1) {
                                tbAppConfigDao.insert(
                                    addInTable(
                                        AC_ID_AD_ON,
                                        idAppAdsEnable.toString()
                                    )
                                )
                                MobileAds.initialize(appContext)
                                MobileAds.setRequestConfiguration(
                                    RequestConfiguration.Builder()
                                        .setTestDeviceIds(
                                            listOf(
                                                "D8DBC08F3096BD2583D41D55B8189E55",
                                                "838B53C92A7D41D2C6B60E788009F88B"
                                            )
                                        )
                                        .build()
                                )
                            }

                            val adMaster = JSONArray(data.getString("ad_master"))
                            if (adMaster.length() > 0) {
                                for (i in 0 until adMaster.length()) {
                                    val adsObject = adMaster.getJSONObject(i)
                                    val tbAdsName = TbAdsName()
                                    tbAdsName.admName = adsObject.getString("adm_name")
                                    try {
                                        tbAdsName.count =
                                            if (adsObject.getString("count") == "0") 0 else adsObject.getString(
                                                "count"
                                            ).toInt()
                                    } catch (e: NumberFormatException) {
                                        tbAdsName.count = 0
                                    }
                                    tbAdsName.enable = adsObject.getInt("enable")
                                    val adChild = adsObject.getJSONArray("ad_chield")
                                    for (j in 0 until adChild.length()) {
                                        val adChildObject = adChild.getJSONObject(j)
                                        val adChildModel = TbAdsPublisherId()
                                        adChildModel.id = "${adsObject.getString("adm_name")}_$j"
                                        adChildModel.adsId = adChildObject.getString("ad_token")
                                        adChildModel.adsName = adChildObject.getString("ad_keyword")
                                        adChildModel.enable = adChildObject.getInt("enable")
                                        tbAdsName.adPublisherId.add(adChildModel)
                                    }
                                    tbAdsNameDao.insert(tbAdsName)
                                }
                            }
                        } catch (_: JSONException) {

                        } finally {
                            CoroutineScope(Dispatchers.Main).launch {
                                callback.invoke()
                            }
                        }
                    } else {
                        isConnectionError = true
                    }
                }
            } catch (e: JSONException) {
                callback.invoke()
            } finally {
                CoroutineScope(Dispatchers.Main).launch {
                    callback.invoke()
                }
            }*/
        } else {
            isConnectionError = true
        }
    }
}

inline var SUBSCRIPTION_STATE: String
    get() = tbAppConfigDao.getData(SUBSCRIPTION_STATE_ID) ?: ""
    set(string) = insertIntoTable(SUBSCRIPTION_STATE_ID, string)

/*fun insertIntoTable(id: Int, data: String) {
    val tbAppConfig = TbAppConfig()
    tbAppConfig.id = id
    tbAppConfig.data = data
    tbAppConfigDao.insert(tbAppConfig)
}*/

fun addInTable(id: Int, data: String): TbAppConfig {
    val tbAppConfig = TbAppConfig()
    tbAppConfig.id = id
    tbAppConfig.data = data
    return tbAppConfig
}

fun isAdsEnable(name: String): Boolean {
    return tbAdsNameDao.getEnable(name) == 1
}

fun adsFailToLoad(adsName: String, type: String): String {
    val ads = tbAdsNameDao.getData(adsName, 1)
    ads?.adPublisherId?.forEach {
        if (it.adsName == type) {
            return it.adsId
        }
    }
    return CUSTOM
}

fun splashBuilderAds(): String {
    var id = ""
    val currentTimeMillis = System.currentTimeMillis()
    if (SUBSCRIPTION_STATE == "SUBSCRIPTION_STATE_ACTIVE") return id
    tbAdsNameDao.getData(SPLASH_INT, 1)?.let {
        if (currentTimeMillis - TIME_STAMP_ID_PURCHASE_DIALOG >= TimeUnit.DAYS.toMillis(1)) {
            id = ""
        } else if ((TIME_STAMP_FULL_SPLASH == 0L)
            || (currentTimeMillis - TIME_STAMP_FULL_SPLASH >= TimeUnit.MINUTES.toMillis(it.count.toLong()))
        ) {
            it.adPublisherId.forEach { ads ->
                if (ads.adsName == GOOGLE_ADS && it.enable == 1) {
                    TIME_STAMP_FULL_SPLASH = System.currentTimeMillis()
                    id = ads.adsId
                }
            }
        }
    }
    return id
}

fun Context.gstAdsBuilder(adsName: String): ArrayList<String> {
    val preferences = getSharedPreferences("ADS_ALTERNATIVE", Context.MODE_PRIVATE)
    val ads = tbAdsNameDao.getData(adsName, 1)
    if (ads != null && idAppAdsEnable == 1 && SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
        val adsPublisherList = ArrayList<TbAdsPublisherId>()
        ads.adPublisherId.forEach {
            if (it.adsName != CUSTOM && it.adsName != ALTERNATIVE && it.enable != -1) {
                val adsPublisherId = TbAdsPublisherId()
                adsPublisherId.id = it.id
                adsPublisherId.adsId = it.adsId
                adsPublisherId.adsName = it.adsName
                adsPublisherId.enable = it.enable
                adsPublisherList.add(adsPublisherId)
            }
        }
        val strings = ArrayList<String>()
        ads.adPublisherId.forEach {
            if (it.enable == 1 && adsPublisherList.size > 0) {
                when (it.adsName) {
                    CUSTOM -> {
                        return setCustomData()
                    }

                    ALTERNATIVE -> {
                        @SuppressLint("CommitPrefEdits") val editor = preferences.edit()
                        when (preferences.getInt(adsName, 1)) {
                            1 -> {
                                return if (adsPublisherList.size == 1) {
                                    editor.putInt(adsName, 1)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[0].adsName)
                                    strings.add(1, adsPublisherList[0].adsId)
                                    strings
                                } else {
                                    editor.putInt(adsName, 2)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[0].adsName)
                                    strings.add(1, adsPublisherList[0].adsId)
                                    strings
                                }
                            }

                            2 -> {
                                return if (adsPublisherList.size == 2) {
                                    editor.putInt(adsName, 1)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[1].adsName)
                                    strings.add(1, adsPublisherList[1].adsId)
                                    strings
                                } else {
                                    editor.putInt(adsName, 3)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[1].adsName)
                                    strings.add(1, adsPublisherList[1].adsId)
                                    strings
                                }
                            }

                            3 -> {
                                return if (adsPublisherList.size == 3) {
                                    editor.putInt(adsName, 1)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[2].adsName)
                                    strings.add(1, adsPublisherList[2].adsId)
                                    strings
                                } else {
                                    editor.putInt(adsName, 4)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[2].adsName)
                                    strings.add(1, adsPublisherList[2].adsId)
                                    strings
                                }
                            }

                            4 -> {
                                return if (adsPublisherList.size == 4) {
                                    editor.putInt(adsName, 1)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[3].adsName)
                                    strings.add(1, adsPublisherList[3].adsId)
                                    strings
                                } else {
                                    editor.putInt(adsName, 5)
                                    editor.apply()

                                    strings.add(0, adsPublisherList[3].adsName)
                                    strings.add(1, adsPublisherList[3].adsId)
                                    strings
                                }
                            }

                            5 -> {
                                editor.putInt(adsName, 1)
                                editor.apply()

                                strings.add(0, adsPublisherList[4].adsName)
                                strings.add(1, adsPublisherList[4].adsId)
                                return strings
                            }
                        }
                    }

                    else -> {
                        strings.add(0, it.adsName)
                        strings.add(1, it.adsId)
                        return strings
                    }
                }
            }
        }
    }
    return setNoDataFound()
}

fun setNoDataFound(): ArrayList<String> {
    val strings = ArrayList<String>()
    strings.add(0, NO_DATA_FOUND)
    strings.add(1, NO_DATA_FOUND)
    return strings
}

fun setCustomData(): ArrayList<String> {
    val strings = ArrayList<String>()
    strings.add(0, CUSTOM)
    strings.add(1, CUSTOM)
    return strings
}

fun Activity.googleAdaptiveBanner(id: String, layout: LinearLayout, listener: AdsListener) {
    if (!this.isFinishing) {
        try {
            val adView = AdView(this)
            adView.setAdSize(getAdSize())
            adView.adUnitId = if (BuildConfig.DEBUG) "/6499/example/banner" else id
            val adRequest = AdRequest.Builder().build()
            adView.loadAd(adRequest)
            adView.adListener = object : AdListener() {
                override fun onAdLoaded() {
                    super.onAdLoaded()
                    layout.removeAllViews()
                    layout.addView(adView)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    super.onAdFailedToLoad(loadAdError)
                    layout.removeAllViews()
                    listener.onFail()
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    listener.onClick()
                }
            }
        } catch (e: Resources.NotFoundException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

fun Activity.getAdSize(): AdSize {
    // Determine the screen width (less decorations) to use for the ad width.
    val outMetrics = DisplayMetrics()
    windowManager.defaultDisplay.getMetrics(outMetrics)
    val widthPixels = outMetrics.widthPixels.toFloat()
    val density = outMetrics.density
    val adWidth = (widthPixels / density).toInt()
    return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth)
}

fun Activity.googleNativeBanner(id: String, layout: LinearLayout, listener: AdsListener) {
    AdLoader.Builder(this, if (BuildConfig.DEBUG) "/6499/example/native" else id)
        .forNativeAd(object : NativeAd.OnNativeAdLoadedListener {
            override fun onNativeAdLoaded(p0: NativeAd) {
                if (this != null) {
                    @SuppressLint("InflateParams") val adView =
                        layoutInflater.inflate(R.layout.ad_unified, null) as NativeAdView
                    populateUnifiedNativeAdView(p0, adView)
                    layout.removeAllViews()
                    layout.addView(adView)
                    adView.bringToFront()
                    layout.invalidate()
                }
            }
        }).withAdListener(object : AdListener() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                listener.onFail()
            }

            override fun onAdClicked() {
                super.onAdClicked()
                listener.onClick()
            }
        })
        .build()
        .loadAd(AdRequest.Builder().build())
}

private fun populateUnifiedNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
    adView.headlineView = adView.findViewById(R.id.ad_headline)
    adView.bodyView = adView.findViewById(R.id.ad_body)
    adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
    adView.iconView = adView.findViewById(R.id.ad_app_icon)
    adView.priceView = adView.findViewById(R.id.ad_price)
    adView.starRatingView = adView.findViewById(R.id.ad_stars)
    (adView.headlineView as AppCompatTextView).text = nativeAd.headline
    (adView.bodyView as AppCompatTextView).text = nativeAd.body
    (adView.callToActionView as AppCompatButton).text = nativeAd.callToAction
    if (nativeAd.icon == null) {
        adView.iconView?.visibility = View.INVISIBLE
    } else {
        (adView.iconView as ImageView).setImageDrawable(
            nativeAd.icon?.drawable
        )
        adView.iconView?.visibility = View.VISIBLE
    }
    if (nativeAd.price == null) {
        adView.priceView?.visibility = View.INVISIBLE
    } else {
        adView.priceView?.visibility = View.VISIBLE
        (adView.priceView as AppCompatTextView).text = nativeAd.price
    }
    if (nativeAd.starRating == null) {
        adView.starRatingView?.visibility = View.INVISIBLE
    } else {
        (adView.starRatingView as RatingBar).rating = nativeAd.starRating?.toFloat() ?: 0f
        adView.starRatingView?.visibility = View.VISIBLE
    }
    adView.setNativeAd(nativeAd)
}

fun showCustomBanner(layout_banner_view: LinearLayout) {
    try {
        if (layout_banner_view.childCount > 0) {
            layout_banner_view.removeAllViews()
        }

        val bannerAds = BannerAds(layout_banner_view.context)
        mLoadingData(layout_banner_view.context)?.let {
            bannerAds.adLoad(it)
        }

        //Todo Show Banner Ads
        layout_banner_view.addView(bannerAds)
        //Todo listener. it's optional
        bannerAds.setListener(object :
            BannerAdsListener {
            override fun onBannerLoad() {

            }

            override fun onBannerFailed() {

            }
        })
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

var tags: List<CaTags>? = null
var mAdsMax: Int = 0
var getApkCount: Int = 0
private lateinit var customDataResult: ArrayList<CaAds>
lateinit var indices: ArrayList<Int>
fun mLoadingData(context: Context): CaAds? {
    val list = caAdsDao.getData()
    if (!::customDataResult.isInitialized && list != null) {
        customDataResult = list as ArrayList<CaAds>
    } else return null

    tags = caTagsDao.getData()

    if (!::indices.isInitialized) {
        indices = ArrayList(customDataResult.size)

        for (i in 0 until customDataResult.size) {
            indices.add(i)
        }

        indices.shuffle()
    }

    val int = mGetApk(context)
    return if (int == -1) {
        null
    } else {
        customDataResult[indices[int]]
    }
}

private fun mGetApk(context: Context): Int {
    if (::customDataResult.isInitialized) {
        if (customDataResult.size == 0) {
            return -1
        } else if (mAdsMax == customDataResult.size) {
            mAdsMax = 0
        }
        val mAdsAnswer: Int = mAdsMax++
        val app: String = customDataResult[indices[mAdsAnswer]].install
        val packageName = app.substring(app.indexOf("=") + 1)
        if (packageName == BuildConfig.APPLICATION_ID
            || getLaunchIntent(
                context,
                packageName
            ) != null
        ) {
            getApkCount++
            if (getApkCount == customDataResult.size) {
                getApkCount = 0
                return -1
            }
            return mGetApk(context)
        }
        getApkCount = 0
        return mAdsAnswer
    } else return -1
}

private fun getLaunchIntent(context: Context, packageName: String?): Intent? {
    return context.packageManager.getLaunchIntentForPackage(packageName!!)
}

val Activity.maxHeightBanner: Int
    get() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density = outMetrics.density
        val adWidthPixels = resources.getDimension(R.dimen._55sdp)
        return (adWidthPixels / density).toInt()
    }

val Activity.maxHeightNative: Int
    get() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density = outMetrics.density
        val adWidthPixels = resources.getDimension(R.dimen._180sdp)
        return (adWidthPixels / density).toInt()
    }