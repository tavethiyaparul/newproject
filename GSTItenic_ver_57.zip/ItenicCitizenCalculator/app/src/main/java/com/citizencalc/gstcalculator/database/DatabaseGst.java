package com.citizencalc.gstcalculator.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import static com.citizencalc.gstcalculator.database.Helper.DATABASE_NAME;
import static com.citizencalc.gstcalculator.database.Helper.DATABASE_VERSION;
import static com.citizencalc.gstcalculator.database.Helper.ID;
import static com.citizencalc.gstcalculator.database.Helper.RESPONSE;
import static com.citizencalc.gstcalculator.database.Helper.TABLE_RESPONSE;

public class DatabaseGst extends SQLiteOpenHelper {

    public static final String CREATE_TABLE_RESPONSE = "CREATE TABLE " + TABLE_RESPONSE
            + "(" + ID + " INTEGER  PRIMARY KEY NOT NULL, "
            + RESPONSE + " TEXT" + ")";

    public DatabaseGst(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_RESPONSE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_RESPONSE);

        onCreate(sqLiteDatabase);
    }

    public void setResponse(String ids, String value, String isUpdate) throws SQLiteException {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ID, ids);
        cv.put(RESPONSE, value);
        if (isUpdate.equals("true")) {
            db.update(TABLE_RESPONSE, cv, ID + "= ?", new String[]{ids});
        } else {
            db.insert(TABLE_RESPONSE, null, cv);
        }
        db.close();
    }

    public String getResponse(String ids) {
        String response = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor rawQuery = db.rawQuery("SELECT " + RESPONSE + " FROM " + TABLE_RESPONSE + " WHERE " + ID + " = ?",
                new String[]{ids});

        if (rawQuery.moveToFirst()) {
            do {
                response = rawQuery.getString(rawQuery.getColumnIndex(RESPONSE));
            }
            while (rawQuery.moveToNext());
        }
        rawQuery.close();
        db.close();
        return response;
    }
}