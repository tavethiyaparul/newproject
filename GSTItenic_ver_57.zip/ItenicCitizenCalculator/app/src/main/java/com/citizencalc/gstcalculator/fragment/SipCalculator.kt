package com.citizencalc.gstcalculator.fragment

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.activity.PdfListActivity
import com.citizencalc.gstcalculator.adapter.ViewPagerAdapter
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.databinding.LayoutSipBinding

class SipCalculator : Fragment() {

    lateinit var binding: LayoutSipBinding
    lateinit var databaseGst: DatabaseGst

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = LayoutSipBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setHasOptionsMenu(true)
        databaseGst = DatabaseGst(activity)

        setupViewPager(binding.viewpager)
        binding.tablayout.setupWithViewPager(binding.viewpager)
    }

    private fun setupViewPager(viewPager: ViewPager) {

        val adapter = ViewPagerAdapter(childFragmentManager)
        adapter.addFragment(SipSimpleFragment(), "SIP")
        adapter.addFragment(SipLumpSumFragment(), "LUMPSUM")
        viewPager.adapter = adapter
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.start_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {

            R.id.action_list -> {
                startActivity(Intent(activity, PdfListActivity::class.java))
            }
        }
        return super.onOptionsItemSelected(item)
    }
}