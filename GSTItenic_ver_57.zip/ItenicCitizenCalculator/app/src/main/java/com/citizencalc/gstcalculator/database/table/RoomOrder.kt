package com.citizencalc.gstcalculator.database.table

import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity
class RoomOrder {
    @PrimaryKey
    var orderId: String=""
    var purchaseTime: Long=0L
    var month: Int = 0
}