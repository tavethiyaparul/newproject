package com.citizencalc.gstcalculator.Classes.common

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.Lifecycle.Event.ON_START
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import com.citizencalc.gstcalculator.APP_OPEN_ADS_NAME
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.Classes.common.AppUtility.*
import com.citizencalc.gstcalculator.GOOGLE_ADS
import com.citizencalc.gstcalculator.SUBSCRIPTION_STATE
import com.citizencalc.gstcalculator.activity.SplashActivity
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.gstAdsBuilder
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.*

class AppOpenManager(private val app: GstApp) : LifecycleObserver,
    Application.ActivityLifecycleCallbacks {
    init {
        app.registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    private var isShowingAd = false
    private val TAG = "AppOpenManager"
    private var appOpenAd: AppOpenAd? = null
    private var currentActivity: Activity? = null
    private var loadTime: Long = 0
    var databaseGst = DatabaseGst(app)

    @OnLifecycleEvent(ON_START)
    fun onStart() {
        if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
            showAdIfAvailable()
        }
    }

    fun fetchAd() {
        if (isAdAvailable()) return
        if (databaseGst.getResponse(IS_ADFREE) != "YES") {
            appOpenRequest(app.gstAdsBuilder(APP_OPEN_ADS_NAME))
        }
    }

    private fun appOpenRequest(ads: ArrayList<String>) {
        if (ads.size > 0) {
            when (ads[0]) {
                GOOGLE_ADS -> {
                    val request = getAdRequest()
                    if (request != null) {
                        AppOpenAd.load(app, if (BuildConfig.DEBUG) "/6499/example/app-open" else ads[1], request, object : AppOpenAd.AppOpenAdLoadCallback() {
                            override fun onAdLoaded(ad: AppOpenAd) {
                                super.onAdLoaded(ad)
                                appOpenAd = ad
                                loadTime = Date().time
                            }

                            override fun onAdFailedToLoad(p0: LoadAdError) {
                                super.onAdFailedToLoad(p0)

                            }
                        })
                    } else {
                        fetchAd()
                    }
                }
            }
        }
    }

    private fun getAdRequest(): AdRequest? {
        return AdRequest.Builder().build()
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo();
    }

    private fun wasLoadTimeLessThanNHoursAgo(): Boolean {
        val dateDifference = Date().time - loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * 4
    }

    private fun showAdIfAvailable() {
        if (!isShowingAd && isAdAvailable()) {
            val fullScreenContentCallback: FullScreenContentCallback =
                object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        appOpenAd = null
                        isShowingAd = false
                        fetchAd()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {

                    }

                    override fun onAdShowedFullScreenContent() {
                        isShowingAd = true
                    }
                }
            appOpenAd?.fullScreenContentCallback = fullScreenContentCallback
            when {
                currentActivity is SplashActivity -> {

                }
                isClickGames -> isClickGames = false
                else -> appOpenAd?.show(currentActivity!!)
            }
        } else {
            fetchAd()
        }
    }

    override fun onActivityCreated(activity: Activity, bundle: Bundle?) {

    }

    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity

    }

    override fun onActivityPaused(activity: Activity) {

    }

    override fun onActivityStopped(activity: Activity) {

    }

    override fun onActivitySaveInstanceState(activity: Activity, bundle: Bundle) {

    }

    override fun onActivityDestroyed(activity: Activity) {
        currentActivity = null
    }
}