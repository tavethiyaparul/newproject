package com.citizencalc.gstcalculator.CustomAd.ui;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.citizencalc.gstcalculator.Classes.common.UtilityKt;
import com.citizencalc.gstcalculator.CustomAd.callback.BannerAdsListener;
import com.citizencalc.gstcalculator.R;
import com.citizencalc.gstcalculator.database.table.CaAds;

public class BannerAds extends FrameLayout {
    Context context;
    ImageView native_icon_view;
    AppCompatTextView native_ad_title, native_ad_social_context;
    AppCompatRatingBar ratingbar;
    AppCompatButton native_ad_call_to_action;
    BannerAdsListener bannerAdsListener;
    AdsClick adsClick;

    public BannerAds(Context context) {
        super(context);
        this.context = context;
    }

    public void onListner(AdsClick adsClick) {
        this.adsClick = adsClick;
    }

    public void adLoad(CaAds data) {
        try {
            LayoutInflater.from(context).inflate(R.layout.ads_network_custom_banner, this);
            native_icon_view = findViewById(R.id.native_icon_view_ads_network);
            native_ad_title = findViewById(R.id.native_ad_title_ads_network);
            ratingbar = findViewById(R.id.ratingbar_ads_network);
            native_ad_social_context = findViewById(R.id.native_ad_social_context_ads_network);
            native_ad_call_to_action = findViewById(R.id.native_ad_call_to_action_ads_network);

            native_ad_title.setText(data.getAdsTitle());
            native_ad_social_context.setText(data.getAdsDesc());
            ratingbar.setRating(Float.parseFloat(data.getRating()));


            Drawable mDrawable = ContextCompat.getDrawable(context, R.drawable.ads_network_btn_app);
            mDrawable.setColorFilter(new PorterDuffColorFilter(Color.parseColor(data.getColor().equals("null") ? "#444bb6"
                    : data.getColor()), PorterDuff.Mode.MULTIPLY));
            native_ad_call_to_action.setBackground(mDrawable);

            Glide.with(context.getApplicationContext())
                    .load(UtilityKt.getCustom_Ad_Path()+ data.getIcon())
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .skipMemoryCache(true))
                    .into(native_icon_view);

            native_ad_call_to_action.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.setData(Uri.parse(data.getInstall()));
                    context.startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            native_icon_view.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.setData(Uri.parse(data.getInstall()));
                    context.startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            if (bannerAdsListener != null)
                bannerAdsListener.onBannerLoad();
        } catch (IndexOutOfBoundsException | NullPointerException e) {
            e.printStackTrace();
            if (bannerAdsListener != null)
                bannerAdsListener.onBannerFailed();
        } catch (Exception e) {
            e.printStackTrace();
            if (bannerAdsListener != null)
                bannerAdsListener.onBannerFailed();
        }
    }

    public void setListener(BannerAdsListener bannerAdsListener) {
        this.bannerAdsListener = bannerAdsListener;
    }
}