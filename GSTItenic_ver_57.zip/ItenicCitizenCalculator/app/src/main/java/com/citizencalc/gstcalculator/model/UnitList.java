package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
@Keep
public class UnitList implements Serializable
{
   @SerializedName("unit_name")
    private String unit_name;

    @SerializedName("unit_keyword")
    private String unit_keyword;

    @SerializedName("unit_parent")
    private String unit_parent;

    @SerializedName("small_icon")
    private String small_icon;

    @SerializedName("poition")
    private int poition;

    public int getPoition() {
        return poition;
    }

    public void setPoition(int poition) {
        this.poition = poition;
    }

    public String getSmall_icon() {
        return small_icon;
    }

    public void setSmall_icon(String small_icon) {
        this.small_icon = small_icon;
    }

    public String getUnit_name ()
    {
        return unit_name;
    }

    public void setUnit_name (String unit_name)
    {
        this.unit_name = unit_name;
    }

    public String getUnit_keyword ()
    {
        return unit_keyword;
    }

    public void setUnit_keyword (String unit_keyword)
    {
        this.unit_keyword = unit_keyword;
    }

    public String getUnit_parent ()
    {
        return unit_parent;
    }

    public void setUnit_parent (String unit_parent)
    {
        this.unit_parent = unit_parent;
    }


}