package com.citizencalc.gstcalculator.CustomAd.ui;

public class AdsInit {

    public static int mAdsMax = 0;
    public static int getApkcount = 0;

}
