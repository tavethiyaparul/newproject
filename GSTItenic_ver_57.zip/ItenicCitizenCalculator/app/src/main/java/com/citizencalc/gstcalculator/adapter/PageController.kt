package com.citizencalc.gstcalculator.adapter

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.citizencalc.gstcalculator.databinding.PageBinding
import com.davemorrissey.labs.subscaleview.ImageSource

class PageController(private val binding: PageBinding) : RecyclerView.ViewHolder(binding.root) {

    var bitmap: Bitmap? = null
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    fun setPage(page: PdfRenderer.Page) {
        if (bitmap == null) {
            val height = 2000
            val width = height * page.width / page.height
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        }

        bitmap?.eraseColor(-0x1)
        page.render(bitmap!!, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        binding.page.resetScaleAndCenter()
        binding.page.setImage(ImageSource.cachedBitmap(checkNotNull(bitmap)))
    }
}