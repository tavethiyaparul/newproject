package com.citizencalc.gstcalculator.Classes.custom

import android.widget.Filter
import com.citizencalc.gstcalculator.adapter.SearchAdapter

import com.citizencalc.gstcalculator.model.UnitList

import java.util.ArrayList

class SearchFilter(internal var searchAdapter: SearchAdapter, internal var unitLists: ArrayList<UnitList>) : Filter() {


    override fun performFiltering(constraint: CharSequence?): Filter.FilterResults {
        var constraint = constraint
        val results = Filter.FilterResults()

        if (constraint != null && constraint.length > 0) {
            //CHANGE TO UPPER
            constraint = constraint.toString().toUpperCase()
            //STORE OUR FILTERED PLAYERS
            val filteredPlayers = ArrayList<UnitList>()

            for (i in unitLists.indices) {
                //CHECK
                if (unitLists[i].unit_name.toUpperCase().contains(constraint) || unitLists[i].unit_keyword.toUpperCase().contains(constraint)) {
                    //ADD PLAYER TO FILTERED PLAYERS
                    filteredPlayers.add(unitLists[i])
                }
            }

            results.count = filteredPlayers.size
            results.values = filteredPlayers
        } else {
            results.count = unitLists.size
            results.values = unitLists

        }


        return results
    }

    override fun publishResults(constraint: CharSequence, results: Filter.FilterResults) {
        searchAdapter.unitLists = results.values as ArrayList<UnitList>

        //REFRESH
        searchAdapter.notifyDataSetChanged()
    }
}
