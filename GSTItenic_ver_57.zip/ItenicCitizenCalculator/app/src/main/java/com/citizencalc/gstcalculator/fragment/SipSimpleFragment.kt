package com.citizencalc.gstcalculator.fragment

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.Toast
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.citizencalc.gstcalculator.Classes.common.AppUtility.PREF_TAG
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.activity.DetailActivity
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.databinding.SimpleSipLayoutBinding

class SipSimpleFragment : Fragment() {

    lateinit var binding: SimpleSipLayoutBinding
    var chartValue = 1
    var principle = "0"
    var rate = "0"
    var n_period = "0"
    lateinit var theme_Shared: SharedPreferences
    lateinit var databaseGst: DatabaseGst
    var myLanStringValue: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = SimpleSipLayoutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sp = activity?.getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        myLanStringValue = sp?.getString("is_radio_name", "")

        when (myLanStringValue) {
            "Gujarati" -> {
                binding.sipAmount.hint = resources.getString(R.string.Gujarati_monthly_sip_amount)
                binding.expectedGain.hint = resources.getString(R.string.Gujarati_expected_gain)
                binding.txtTenure.text = resources.getString(R.string.Gujarati_sip_turner)
                binding.txtYears.text = resources.getString(R.string.Gujarati_year)
                binding.clearBtn.text = resources.getString(R.string.Gujarati_CLEAR)
                binding.calculateBtn.text = resources.getString(R.string.Gujarati_CALCULATE)
            }
            "Hindi" -> {
                binding.sipAmount.hint = resources.getString(R.string.Hindi_monthly_sip_amount)
                binding.expectedGain.hint = resources.getString(R.string.Hindi_expected_gain)
                binding.txtTenure.text = resources.getString(R.string.Hindi_sip_turner)
                binding.txtYears.text = resources.getString(R.string.Hindi_year)
                binding.clearBtn.text = resources.getString(R.string.Hindi_CLEAR)
                binding.calculateBtn.text = resources.getString(R.string.Hindi_CALCULATE)
            } 
            else -> {
                binding.sipAmount.hint = resources.getString(R.string.English_monthly_sip_amount)
                binding.expectedGain.hint = resources.getString(R.string.English_expected_gain)
                binding.txtTenure.text = resources.getString(R.string.English_sip_turner)
                binding.txtYears.text = resources.getString(R.string.English_year)
                binding.clearBtn.text = resources.getString(R.string.English_CLEAR)
                binding.calculateBtn.text = resources.getString(R.string.English_CALCULATE)
            }
        }
        
        binding.setYear.text = 1.toString()
        binding.seekBar.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, i: Int, b: Boolean) {
                if (i < 1)
                    binding.setYear.text = 1.toString()
                else
                    binding.setYear.text = i.toString()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        binding.calculateBtn.setOnClickListener {
            val imm: InputMethodManager =
                activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

            if (imm.isAcceptingText) {
//                writeToLog("Software Keyboard was shown")
                imm.hideSoftInputFromWindow(view.windowToken, 0)
            } else {
//                writeToLog("Software Keyboard was not shown")
            }

            if (!binding.sipAmount.text.toString().equals("") && !binding.expectedGain.text.toString().equals("")) {
                if (binding.expectedGain.text.toString() == ".") {
                    Toast.makeText(activity, "Please Select Expected Gain another value", Toast.LENGTH_SHORT).show()
                } else {
                    principle = binding.sipAmount.text.toString()
                    rate = binding.expectedGain.text.toString()
                    n_period = binding.setYear.text.toString()
                    sip_calculate(binding.sipAmount.text.toString().toDouble(), binding.expectedGain.text.toString().toDouble(), binding.setYear.text.toString().toDouble())
                }
            } else {
                Toast.makeText(activity, "Fill All Fields", Toast.LENGTH_SHORT).show()
            }
        }

        binding.clearBtn.setOnClickListener {
            binding.summaryLayout.visibility = View.GONE
            binding.sipAmount.text = null
            binding.expectedGain.text = null
            binding.seekBar.progress = 0
        }

        binding.btnDetail.setOnClickListener {
            startActivity(Intent(activity, DetailActivity::class.java).putExtra("chart", chartValue)
                .putExtra("sip", principle).putExtra("rate", rate).putExtra("period", n_period)
                .putExtra("type", "Simple"))
        }

        theme_Shared = requireContext().getSharedPreferences("AppPref", MODE_PRIVATE)
        setButtonTheme(theme_Shared.getInt("Theme", 0))
        databaseGst = DatabaseGst(activity)
    }

    fun View.hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

    private fun sip_calculate(p: Double, r: Double, N: Double) {
        binding.summaryLayout.visibility = View.VISIBLE

        try {
            val ans = r / 100 / 12

            val n = (N * 12)

            val phase_1 = (p * ((Math.pow((1.00 + ans), n) - 1.00) / ans) * (1.00 + ans))

            binding.totalAmount.text = "\u20B9 " + String.format("%,d", phase_1.toInt())
            binding.totalInvestedAmount.text = "\u20B9 " + String.format("%,d", (p * n).toInt())
            binding.profitAmount.text = "\u20B9 " + String.format("%,d", (phase_1 - (p * n)).toInt())
            var chart = (p * n) * 100
            chart = chart / phase_1
            chartValue = chart.toInt()
        } catch (e: ArithmeticException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setButtonTheme(currentTheme: Int) {
        when (currentTheme) {
            0 -> {
                setTextViewDrawableColor(binding.calculateBtn, R.color.App_dark)
                setTextViewDrawableColor(binding.clearBtn, R.color.App_dark)
                setTextViewDrawableColor(binding.btnDetail, R.color.App_dark)
            }
            1 -> {
                setTextViewDrawableColor(binding.calculateBtn, R.color.theme1_ColorPrimaryDark)
                setTextViewDrawableColor(binding.clearBtn, R.color.theme1_ColorPrimaryDark)
                setTextViewDrawableColor(binding.btnDetail, R.color.theme1_ColorPrimaryDark)
            }
            2 -> {
                setTextViewDrawableColor(binding.calculateBtn, R.color.theme2_ColorPrimary)
                setTextViewDrawableColor(binding.clearBtn, R.color.theme2_ColorPrimary)
                setTextViewDrawableColor(binding.btnDetail, R.color.theme2_ColorPrimary)
            }
            3 -> {
                setTextViewDrawableColor(binding.calculateBtn, R.color.theme3_ColorPrimary)
                setTextViewDrawableColor(binding.clearBtn, R.color.theme3_ColorPrimary)
                setTextViewDrawableColor(binding.btnDetail, R.color.theme3_ColorPrimary)
            }
            4 -> {
                setTextViewDrawableColor(binding.calculateBtn, R.color.theme4_ColorPrimary)
                setTextViewDrawableColor(binding.clearBtn, R.color.theme4_ColorPrimary)
                setTextViewDrawableColor(binding.btnDetail, R.color.theme4_ColorPrimary)
            }
            5 -> {
                //createSelecteState(R.drawable.select_button_3_theme6, R.drawable.select_button_1_theme6, R.drawable.select_button_2_theme6)
                setTextViewDrawableColor(binding.calculateBtn, R.color.theme5_ButtonBG)
                setTextViewDrawableColor(binding.clearBtn, R.color.theme5_ButtonBG)
                setTextViewDrawableColor(binding.btnDetail, R.color.theme5_ButtonBG)
            }
            6 -> {
                setTextViewDrawableColor(binding.calculateBtn, R.color.theme6_ColorPrimary)
                setTextViewDrawableColor(binding.clearBtn, R.color.theme6_ColorPrimary)
                setTextViewDrawableColor(binding.btnDetail, R.color.theme6_ColorPrimary)
            }
        }
    }

    private fun setTextViewDrawableColor(textView: AppCompatTextView, color: Int) {
        DrawableCompat.setTint(DrawableCompat.wrap(textView.background), ContextCompat.getColor(requireContext(), color))
    }
}