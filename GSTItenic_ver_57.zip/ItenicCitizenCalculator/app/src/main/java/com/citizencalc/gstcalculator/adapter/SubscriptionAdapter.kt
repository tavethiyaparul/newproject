package com.citizencalc.gstcalculator.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.databinding.SubscribeRowItemBinding
import com.revenuecat.purchases.Package
import com.revenuecat.purchases.models.GoogleStoreProduct
import java.math.RoundingMode
import java.text.DecimalFormat
import java.util.ArrayList
import java.util.Currency

class SubscriptionAdapter(
    var activity: Activity,
    private var availablePackages: ArrayList<Package>,
    val call: (titleSub: String) -> Unit
) : RecyclerView.Adapter<SubscriptionAdapter.SubscriptionHolder>() {

    private val TAG: String = "PurchaseInfo"
    var lastSelection: Int = 1
    var packageIds: ArrayList<String> = arrayListOf("", "", "", "")

    init {
        if (availablePackages.size > 0)
            call.invoke("${availablePackages[1].product.price.formatted} / Year")
    }

    inner class SubscriptionHolder(val binding: SubscribeRowItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubscriptionHolder {
        val binding =
            SubscribeRowItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SubscriptionHolder(binding)
    }

    override fun getItemCount(): Int {
        return availablePackages.size
    }

    @SuppressLint("ResourceType")
    override fun onBindViewHolder(holder: SubscriptionHolder, position: Int) {
        with(holder) {
            with(availablePackages[position]) {
                try {
//                    binding.apply {
                    /*viewLayout.setBackgroundColor(Color.parseColor(skuList[position].color[0]))
                    adPrice.setTextColor(Color.parseColor(skuList[position].color[0]))
                    txtRupee.setTextColor(Color.parseColor(skuList[position].color[0]))
                    subPeriod.text = skuList[position].title
                    subPackname.text = skuList[position].content
                    adPrice.text = skuList[position].defaultValue
                    val gd = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor(skuList[position].color[0]), Color.parseColor(skuList[position].color[1])))
                    gd.cornerRadius = 5f
                    chooseBtn.setBackgroundDrawable(gd)
                    chooseBtn.setOnClickListener {
                        selectSku.setSku(skuList[position].sku)
                    }*/

                    /*if (position == 0) {
                        oneMDesc.text = activity.getString(R.string.ruppee) + skuList[position].defaultValue + " per " + skuList[position].title
                        this@SubscriptionAdapter.sku = skuList[position].sku
                    } else {
                        val value = skuList[position].defaultValue.toDouble() / skuList[position].validity.toDouble()
                        oneMDesc.text = skuList[position].title + " at " + activity.getString(R.string.ruppee) + roundOffDecimal(value) + " / month"
                        this@SubscriptionAdapter.sku = skuList[position].sku
                    }

                    oneMPrice.text = activity.getString(R.string.ruppee) + skuList[position].defaultValue + " / " + skuList[position].title
//                        if (position != 0) oneMPriceDisc.text = disc[position].toString() + "% OFF" else disc_chip.visibility = View.GONE
                    if (lastSelection == position) {
                        imgIcon.background = ContextCompat.getDrawable(imgIcon.context, R.drawable.selection)
                        imgIcon.setColorFilter(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.MULTIPLY)
                        oneMDesc.setTextColor(Color.parseColor("#80FFFFFF"))
                        RLBACKGROUND.background = ContextCompat.getDrawable(RLBACKGROUND.context, R.drawable.subscription_bg_selection)
                        oneMPrice.setTextColor(ContextCompat.getColor(oneMPrice.context, R.color.white))
                        sku = skuList[position].sku
                    } else {
                        imgIcon.background = ContextCompat.getDrawable(imgIcon.context, R.drawable.circle)
                        imgIcon.setColorFilter(ContextCompat.getColor(imgIcon.context, R.color.white), android.graphics.PorterDuff.Mode.MULTIPLY)
                        oneMDesc.setTextColor(Color.parseColor("#888888"))
                        RLBACKGROUND.background = ContextCompat.getDrawable(RLBACKGROUND.context, R.drawable.subscription_bg)
                        oneMPrice.setTextColor(ContextCompat.getColor(oneMPrice.context, R.color.black))
                    }

                    RLONEMONT.setOnClickListener {
                        lastSelection = position
                        notifyDataSetChanged()
                        RLBACKGROUND.background = ContextCompat.getDrawable(RLBACKGROUND.context, R.drawable.subscription_bg_selection)
                        imgIcon.background = ContextCompat.getDrawable(imgIcon.context, R.drawable.selection)
//                            selectSku.setSku(skuList[position].sku)
                    }*/
//                    }

                    Log.e(TAG, "packageType > ${this.product}")
                    Log.e(TAG, "selection > $lastSelection")

                    val baseplanId = (this.product as GoogleStoreProduct).basePlanId
                    Log.e(TAG, "baseplanId = $baseplanId")

                    binding.apply {
//                        val skuPremium1yearPrice = this@with.product.price.formatted
//                        val SKU_PRICECURRENCYCODE = this@with.product.price.currencyCode
//
//                        val currancySymbol = Currency.getInstance(SKU_PRICECURRENCYCODE).symbol

//                        if (skuPremium1yearPrice.contains(currancySymbol)) {
                        /*val priceA = skuPremium1yearPrice.replace(currancySymbol, "").trim()
                        val priceDoubleA = priceA.replace(",", "").trim().toDouble()
                        Log.e("PriceTag", "number >> $priceDoubleA")*/


//                        }

                        if (position != 0) {
                            /*val priceDoubleA = priceA.replace(",", "").trim().toDouble()
                            val priceAA: Double = priceDoubleA / 12
                            var pricePerMonthA = DecimalFormat("0.00").format(priceAA)
                            Log.e("PriceTag", "pmp >> $pricePerMonthA")
                            if (pricePerMonthA.contains(".00")) pricePerMonthA =
                                pricePerMonthA.replace(".00", "")*/

                            oneMPrice.text = "${this@with.product.price.formatted} / Year"
                            oneMDesc.text = "For 1 Year"
                            tvSaveOffer.text = "Save 20%"
                        } else {
                            oneMPrice.text = "${this@with.product.price.formatted} / Month"
                            tvSaveOffer.visibility = View.GONE
                            oneMDesc.text = "For 1 Month"
                        }


//                                oneMPrice.text = activity.getString(R.string.ruppee) + skuList[position].defaultValue + " / " + skuList[position].title
                        if (lastSelection == position) {
                            imgIcon.background =
                                ContextCompat.getDrawable(imgIcon.context, R.drawable.selection)
                            imgIcon.setColorFilter(
                                Color.TRANSPARENT,
                                android.graphics.PorterDuff.Mode.MULTIPLY
                            )
                            oneMDesc.setTextColor(Color.parseColor("#80FFFFFF"))
                            RLBACKGROUND.background = ContextCompat.getDrawable(
                                RLBACKGROUND.context,
                                R.drawable.subscription_bg_selection
                            )
                            oneMPrice.setTextColor(
                                ContextCompat.getColor(
                                    oneMPrice.context,
                                    R.color.white
                                )
                            )
                            tvSaveOffer.setTextColor(
                                ContextCompat.getColor(
                                    tvSaveOffer.context,
                                    R.color.white
                                )
                            )
//                                    sku = skuList[position].sku
                        } else {
                            imgIcon.background =
                                ContextCompat.getDrawable(imgIcon.context, R.drawable.circle)
                            imgIcon.setColorFilter(
                                ContextCompat.getColor(
                                    imgIcon.context,
                                    R.color.white
                                ), android.graphics.PorterDuff.Mode.MULTIPLY
                            )
                            oneMDesc.setTextColor(Color.parseColor("#888888"))
                            RLBACKGROUND.background = ContextCompat.getDrawable(
                                RLBACKGROUND.context,
                                R.drawable.subscription_bg
                            )
                            oneMPrice.setTextColor(
                                ContextCompat.getColor(
                                    oneMPrice.context,
                                    R.color.black
                                )
                            )
                            tvSaveOffer.setTextColor(
                                ContextCompat.getColor(
                                    tvSaveOffer.context,
                                    R.color.black
                                )
                            )
                        }

                        RLONEMONT.setOnClickListener {
                            call.invoke(oneMPrice.text.toString())
                            lastSelection = position
                            notifyDataSetChanged()
                            RLBACKGROUND.background = ContextCompat.getDrawable(
                                RLBACKGROUND.context,
                                R.drawable.subscription_bg_selection
                            )
                            imgIcon.background =
                                ContextCompat.getDrawable(imgIcon.context, R.drawable.selection)
                        }
                    }

                    packageIds.removeAt(position)
                    packageIds.add(position, baseplanId!!)

//                      var isVisible = binding.rowSkuSelectionQuarterly.visibility == View.VISIBLE
//                      if (!isVisible) {
//                          isVisible = binding.rowSkuSelectionYear.visibility == View.VISIBLE
//                      }
//                      if (isVisible) {
//                          binding.actionMonthly.visibility = View.VISIBLE
//                      } else {
//                          binding.chkYear.setBackgroundResource(R.drawable.ic_baseline_check_circle_24)
//                          binding.chkQuarterly.setBackgroundResource(R.drawable.ic_baseline_radio_button_unchecked)
//                          binding.chkMonthly.setBackgroundResource(R.drawable.ic_baseline_radio_button_unchecked)
//
//                          binding.actionYeartime.setBackgroundResource(R.drawable.purchase_selection)
//                          binding.actionQuarterly.setBackgroundResource(R.drawable.purchase_deselection)
//                          binding.actionMonthly.setBackgroundResource(R.drawable.purchase_deselection)
//
//                          binding.actionGetPro.text = paywallTheme?.subscriptionDays
//                          binding.rowSkuSelectionYear.visibility = View.VISIBLE
//                          binding.actionYeartime.visibility = View.VISIBLE
//                          val stringWithoutFirstLetter = skuLifelongPrice.substring(1)
//                          val stringWithoutCommas = stringWithoutFirstLetter.replace(",", "")
//
//                          SKU_FORMATTEDAMOUNT = stringWithoutCommas.toDouble()
//
//                          AllLog.logError("PD SKU_PRODUCTID  else >>$SKU_FORMATTEDAMOUNT")
//                      }
//
//                      binding.actionYeartime.visibility = View.VISIBLE
//                      skuPremium1yearPrice = packageToDisplay.product.price.formatted
//                      SKU_PRICECURRENCYCODE = packageToDisplay.product.price.currencyCode
//
//                      SKU_PRODUCTID = packageToDisplay.product.id
//
//                      binding.txtYearPrice.text = "12 Months"
//                      binding.txtYearPriceSub.text = "$skuPremium1yearPrice Yearly Subscription"
//                      val currancySymbol = Currency.getInstance(SKU_PRICECURRENCYCODE).symbol
//                      if (skuPremium1yearPrice.contains(currancySymbol)) {
//                          val priceA = skuPremium1yearPrice.replace(currancySymbol, "").trim()
//                          val priceDoubleA = priceA.replace(",", "").trim().toDouble()
//                          Log.e("PriceTag", "number >> $priceDoubleA")
//                          val priceAA:Double = priceDoubleA / 12
//                          var pricePerMonthA = DecimalFormat("0.00").format(priceAA)
//                          Log.e("PriceTag", "pmp >> $pricePerMonthA")
//                          if (pricePerMonthA.contains(".00")) pricePerMonthA = pricePerMonthA.replace(".00","")
//                          binding.txtYearPM.text = "$currancySymbol $pricePerMonthA / mo"
//                      }

//                      Log.e("PriceTag", "skuPremium1yearPrice: $skuPremium1yearPrice")
//                      Log.e("PriceTag", "SKU_period  else >>${packageToDisplay.product.period}")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun roundOffDecimal(number: Double): Double? {
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.CEILING
        return df.format(number).toDouble()
    }
}