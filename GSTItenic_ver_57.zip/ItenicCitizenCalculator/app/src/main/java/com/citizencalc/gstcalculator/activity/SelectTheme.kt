package com.citizencalc.gstcalculator.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.viewpager.widget.ViewPager
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility
import com.citizencalc.gstcalculator.Classes.common.AppUtility
import com.citizencalc.gstcalculator.Classes.common.OnSetTheme
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.adapter.SlidingImageAdapter
import com.citizencalc.gstcalculator.databinding.ThemeSelectBinding

class SelectTheme : RootClass() {
    
    lateinit var binding: ThemeSelectBinding
    lateinit var sharedPref: SharedPreferences
    var myLanStringValue: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        binding = ThemeSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPref = getSharedPreferences("AppPref", Context.MODE_PRIVATE)

        Log.d("activityTXN", "${this@SelectTheme.localClassName} onCreate")

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        val v = LayoutInflater.from(this).inflate(R.layout.custom_actionbar, null)
        val sp = getSharedPreferences(AppUtility.PREF_TAG, MODE_PRIVATE)
        myLanStringValue = sp.getString("is_radio_name", "")

        when (myLanStringValue) {
            "Gujarati" -> {
                v.findViewById<TextView>(R.id.action_bar_title).text = resources.getText(R.string.Gujarati_Choose_Your_Theme)
                binding.BtnApplyTheme.text = resources.getText(R.string.Gujarati_apply_theme)
            }
            "Hindi" -> {
                v.findViewById<TextView>(R.id.action_bar_title).text = resources.getText(R.string.Hindi_Choose_Your_Theme)
                binding.BtnApplyTheme.text = resources.getText(R.string.Hindi_apply_theme)
            }
            else -> {
                v.findViewById<TextView>(R.id.action_bar_title).text = resources.getText(R.string.English_Choose_Your_Theme)
                binding.BtnApplyTheme.text = resources.getText(R.string.English_apply_theme)
            }
        }

        v.findViewById<TextView>(R.id.action_bar_title).textSize = 22f
        v.findViewById<TextView>(R.id.action_bar_title).gravity = Gravity.CENTER
        v.findViewById<TextView>(R.id.action_bar_title).setTypeface(null, Typeface.BOLD)
        v.findViewById<TextView>(R.id.action_bar_title).setTextColor(ContextCompat.getColor(this@SelectTheme, R.color.white))
        v.findViewById<View>(R.id.gift_layout).visibility = View.GONE
        v.findViewById<View>(R.id.AdText).visibility = View.GONE
        v.findViewById<View>(R.id.img_app).visibility = View.GONE

        val upArrow = ContextCompat.getDrawable(this@SelectTheme, R.drawable.ic_back)
        supportActionBar?.setHomeAsUpIndicator(upArrow)
        supportActionBar?.customView = v

        val ThemeList = arrayOf(
            ContextCompat.getDrawable(this, R.drawable.theme_1_preview),
            ContextCompat.getDrawable(this, R.drawable.theme_2_preview),
            ContextCompat.getDrawable(this, R.drawable.theme_3_preview),
            ContextCompat.getDrawable(this, R.drawable.theme_4_preview),
            ContextCompat.getDrawable(this, R.drawable.theme_5_preview),
            ContextCompat.getDrawable(this, R.drawable.theme_6_preview),
            ContextCompat.getDrawable(this, R.drawable.theme_7_preview)
        ).toCollection(java.util.ArrayList())

        val ThemeName = arrayOf(
            "Black Pearl",
            "Aubergine",
            "Cyprus",
            "Prussian Blue",
            "Black",
            "Navy Blue",
            "Blue & White"
        ).toCollection(java.util.ArrayList())

        val adapter = SlidingImageAdapter(this@SelectTheme, ThemeList, ThemeName, object : OnSetTheme {
            override fun setTheme(pos: Int) {

            }
        })
        binding.ViewPager.adapter = adapter
        binding.ViewPager.currentItem = sharedPref.getInt("Theme", 0)

        if (binding.ViewPager.currentItem == 0) binding.btnPrev.visibility = View.GONE
        else binding.btnPrev.visibility = View.VISIBLE

        if (binding.ViewPager.currentItem == (ThemeList.size - 1)) binding.btnNext.visibility = View.GONE
        else binding.btnNext.visibility = View.VISIBLE

        binding.ViewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {}
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {
                if (position == 0)
                    binding.btnPrev.visibility = View.GONE
                else
                    binding.btnPrev.visibility = View.VISIBLE

                if (position == (ThemeList.size - 1))
                    binding.btnNext.visibility = View.GONE
                else
                    binding.btnNext.visibility = View.VISIBLE
            }
        })

        binding.BtnApplyTheme.setOnClickListener {
            val editor = sharedPref.edit()
            AppConstUtility.THEME_NUMBER = binding.ViewPager.currentItem
            editor.putInt("Theme", binding.ViewPager.currentItem)
            editor.apply()
            startActivity(Intent(this@SelectTheme, MainActivity::class.java))
            finish()

            when (myLanStringValue) {
                "Gujarati" -> {
                    Toast.makeText(this@SelectTheme, resources.getString(R.string.Gujarati_theme_change), Toast.LENGTH_SHORT).show()
                }
                "Hindi" -> {
                    Toast.makeText(this@SelectTheme, resources.getString(R.string.Hindi_theme_change), Toast.LENGTH_SHORT).show()
                }
                else -> {
                    Toast.makeText(this@SelectTheme, resources.getString(R.string.English_theme_change), Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.btnPrev.setOnClickListener {
            if (binding.ViewPager.currentItem != 0)
                binding.ViewPager.currentItem = binding.ViewPager.currentItem - 1
        }
        binding.btnNext.setOnClickListener {
            if (binding.ViewPager.currentItem > -1 && binding.ViewPager.currentItem != (ThemeList.size - 1))
                binding.ViewPager.currentItem = binding.ViewPager.currentItem + 1
        }
    }
}