package com.citizencalc.gstcalculator.fragment

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.SeekBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.citizencalc.gstcalculator.*
import com.citizencalc.gstcalculator.Classes.common.AppUtility.PREF_TAG
import com.citizencalc.gstcalculator.activity.DetailActivity
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.databinding.SimpleLumpsumLayoutBinding

import java.lang.NullPointerException

class SipLumpSumFragment : Fragment() {

    lateinit var binding: SimpleLumpsumLayoutBinding
    var chartValue = 1
    var principle = "0"
    var rate = "0"
    var n_period = "0"
    lateinit var databaseGst: DatabaseGst

    var myLanStringValue: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = SimpleLumpsumLayoutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sp = activity?.getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        myLanStringValue = sp?.getString("is_radio_name", "")

        when (myLanStringValue) {
            "Gujarati" -> {
                binding.LSAmount.hint = activity?.resources?.getString(R.string.Gujarati_monthly_lumpsum_amount)
                binding.LSRate.hint = activity?.resources?.getString(R.string.Gujarati_expected_gain)
                binding.txtTenureLum.text = activity?.resources?.getString(R.string.Gujarati_sip_turner)
                binding.txtYearsLum.text = activity?.resources?.getString(R.string.Gujarati_year)
                binding.LSClearBtn.text = activity?.resources?.getString(R.string.Gujarati_CLEAR)
                binding.LSCalculateBtn.text = activity?.resources?.getString(R.string.Gujarati_CALCULATE)
    
            }
            "Hindi" -> {
                binding.LSAmount.hint = activity?.resources?.getString(R.string.Hindi_monthly_lumpsum_amount)
                binding.LSRate.hint = activity?.resources?.getString(R.string.Hindi_expected_gain)
                binding.txtTenureLum.text = activity?.resources?.getString(R.string.Hindi_sip_turner)
                binding.txtYearsLum.text = activity?.resources?.getString(R.string.Hindi_year)
                binding.LSClearBtn.text = activity?.resources?.getString(R.string.Hindi_CLEAR)
                binding.LSCalculateBtn.text = activity?.resources?.getString(R.string.Hindi_CALCULATE)
    
            }
            else -> {
                binding.LSAmount.hint = activity?.resources?.getString(R.string.English_monthly_lumpsum_amount)
                binding.LSRate.hint = activity?.resources?.getString(R.string.English_expected_gain)
                binding.txtTenureLum.text = activity?.resources?.getString(R.string.English_sip_turner)
                binding.txtYearsLum.text = activity?.resources?.getString(R.string.English_year)
                binding.LSClearBtn.text = activity?.resources?.getString(R.string.English_CLEAR)
                binding.LSCalculateBtn.text = activity?.resources?.getString(R.string.English_CALCULATE)
            }
        }

        databaseGst = DatabaseGst(activity)
        binding.LSYear.text = 1.toString()
        binding.LSSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, i: Int, b: Boolean) {
                if (i < 1) binding.LSYear.text = 1.toString()
                else binding.LSYear.text = i.toString()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        binding.LSCalculateBtn.setOnClickListener {
            val imm: InputMethodManager = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

            if (imm.isAcceptingText) {
//                writeToLog("Software Keyboard was shown")
                imm.hideSoftInputFromWindow(view.windowToken, 0)
            } else {
//                writeToLog("Software Keyboard was not shown")
            }

            if (binding.LSAmount.text.toString() != "" && binding.LSRate.text.toString() != "") {

                if (binding.LSRate.text.toString() == ".") {
                    Toast.makeText(activity, "Please Select Expected Gain another value", Toast.LENGTH_SHORT).show()
                } else {
                    principle = binding.LSAmount.text.toString()
                    rate = binding.LSRate.text.toString()
                    n_period = binding.LSYear.text.toString()
                    sip_calculate(
                        binding.LSAmount.text.toString().toDouble(),
                        binding.LSRate.text.toString().toDouble(),
                        binding.LSYear.text.toString().toDouble()
                    )
                }

            }
        }
        binding.LSClearBtn.setOnClickListener {
            binding.LSSummaryLayout.visibility = View.GONE
            binding.LSAmount.text = null
            binding.LSRate.text = null
            binding.LSSeekBar.progress = 0
        }

        binding.LsBtnDetail.setOnClickListener {
            startActivity(
                Intent(activity, DetailActivity::class.java).putExtra("chart", chartValue)
                    .putExtra("sip", principle).putExtra("rate", rate).putExtra("period", n_period)
                    .putExtra("type", "Lumpsum")
            )
        }

    }

    private fun sip_calculate(p: Double, r: Double, N: Double) {
        try {
            binding.LSSummaryLayout.visibility = View.VISIBLE

            val ans = r / 100
            val phase_1 = (p * (Math.pow((1.00 + ans), N)))

            binding.LSTotalAmount.text = "\u20B9 " + String.format("%,d", phase_1.toInt())
            binding.LSTotalInvestedAmount.text = "\u20B9 " + String.format("%,d", p.toInt())
            binding.LSProfitAmount.text = "\u20B9 " + String.format("%,d", (phase_1 - p).toInt())
            var chart = (p) * 100
            chart /= phase_1
            chartValue = chart.toInt()
        } catch (e: ArithmeticException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}