package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
@Keep

public class InAppData implements Serializable {

   @SerializedName("result")
    private Result result;

    @SerializedName("dataCount")
    private String dataCount;

    public Result getResult ()
    {
        return result;
    }

    public void setResult (Result result)
    {
        this.result = result;
    }

    public String getDataCount ()
    {
        return dataCount;
    }

    public void setDataCount (String dataCount)
    {
        this.dataCount = dataCount;
    }


}
