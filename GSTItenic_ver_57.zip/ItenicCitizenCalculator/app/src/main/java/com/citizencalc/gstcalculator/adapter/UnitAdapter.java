package com.citizencalc.gstcalculator.adapter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.citizencalc.gstcalculator.R;
import com.citizencalc.gstcalculator.activity.UnitCalculatorActivity;
import com.citizencalc.gstcalculator.holder.UnitHolder;
import com.citizencalc.gstcalculator.model.UnitData;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_Postion;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_Title;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Area;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Energy;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Fuel;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Length;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Presure;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Speed;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Storage;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Tempreture;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Time;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Volume;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Weight;

public class UnitAdapter extends RecyclerView.Adapter<UnitHolder> {

    Activity activity;
    UnitData unitData;

    public UnitAdapter(Activity activity, UnitData unitData) {
        this.activity = activity;
        this.unitData = unitData;
    }

    @NonNull
    @Override
    public UnitHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.list_row_item_2, null);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        view.findViewById(R.id.layout).setLayoutParams(new RelativeLayout.LayoutParams(width / 3, width / 4));

        return new UnitHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UnitHolder holder, int position) {
        setBackground(holder.card_bg, unitData.getUnit().get(position).getUnit_title());
        Glide.with(activity.getApplicationContext())
                .load(Uri.parse("file:///android_asset/unit_icon/" + unitData.getUnit().get(position).getUnit_icon()))
                .into(holder.menu_icon);
        holder.menu_name.setText(unitData.getUnit().get(position).getUnit_title());

        holder.layout.setOnClickListener(v -> activity.startActivity(new Intent(activity, UnitCalculatorActivity.class).putExtra(Unit_Title, unitData.getUnit().get(position).getUnit_title()).putExtra(Unit_Postion, position)));
    }

    void setBackground(CardView v, String s) {

        switch (s) {
            case Area:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.deep_orange));
                break;
            case Length:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.purple));

                break;
            case Weight:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.teal));

                break;
            case Time:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.amber));
                break;
            case Tempreture:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.blue_grey));

                break;
            case Speed:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.yellow));

                break;
            case Volume:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.cyne));

                break;
            case Energy:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.lime));

                break;
            case Fuel:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.brown));

                break;
            case Presure:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.indigo));

                break;
            case Storage:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.green));

                break;
            default:
                v.setCardBackgroundColor(activity.getResources().getColor(R.color.green));
                break;


        }
    }

    @Override
    public int getItemCount() {
        return unitData.getUnit().size();
    }
}
