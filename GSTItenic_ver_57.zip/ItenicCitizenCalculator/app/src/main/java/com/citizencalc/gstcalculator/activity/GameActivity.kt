package com.citizencalc.gstcalculator.activity

import android.annotation.TargetApi
import android.content.ActivityNotFoundException
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.VectorDrawable
import android.net.Uri
import android.os.Build
import android.util.Log
import android.view.WindowManager
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.Classes.common.AppUtility
import com.citizencalc.gstcalculator.Classes.common.GAME_PAGE_URL
import com.citizencalc.gstcalculator.R



fun RedirectToPage(context: Context) {

    try {
        AppUtility.isClickGames = true
        val builder = CustomTabsIntent.Builder()
        builder.setToolbarColor(ContextCompat.getColor(context, R.color.white))
        builder.setCloseButtonIcon(bitmapFromDrawable(context, R.drawable.ic_back))

        val customTabsIntent = builder.build()
        customTabsIntent.intent.setPackage("com.android.chrome")
        customTabsIntent.launchUrl(context, Uri.parse(GAME_PAGE_URL))
    } catch (e: ActivityNotFoundException) {
        if (BuildConfig.DEBUG) Log.e("error", "ActivityNotFoundException", e)
    }
}

fun bitmapFromDrawable(context: Context, drawableId: Int): Bitmap {
    val drawable = ContextCompat.getDrawable(context, drawableId)
    return (if (drawable is VectorDrawable) {
        bitmapFromVectorDrawable(drawable)
    } else (drawable as BitmapDrawable?)!!.bitmap)!!
}

@TargetApi(Build.VERSION_CODES.LOLLIPOP)
fun bitmapFromVectorDrawable(vectorDrawable: VectorDrawable): Bitmap? {
    val bitmap = Bitmap.createBitmap(vectorDrawable.intrinsicWidth, vectorDrawable.intrinsicHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    vectorDrawable.setBounds(0, 0, canvas.width, canvas.height)
    vectorDrawable.draw(canvas)
    return bitmap
}