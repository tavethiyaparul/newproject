package com.citizencalc.gstcalculator.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.citizencalc.gstcalculator.R;

public class UnitHolder extends RecyclerView.ViewHolder {

    public ImageView menu_icon;
    public TextView menu_name;
    public RelativeLayout layout;
    public CardView card_bg;

    public UnitHolder(@NonNull View itemView) {
        super(itemView);
        menu_icon = itemView.findViewById(R.id.menu_icon);
        menu_name = itemView.findViewById(R.id.menu_name);
        layout = itemView.findViewById(R.id.layout);
        card_bg = itemView.findViewById(R.id.card_bg);
    }
}