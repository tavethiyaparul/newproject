package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;
@Keep
public class UnitData implements Serializable {
    @SerializedName("unit")
    private List<Unit> unit;

    public List<Unit> getUnit() {
        return unit;
    }

    public void setUnit(List<Unit> unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "ClassPojo [unit = " + unit + "]";
    }
}