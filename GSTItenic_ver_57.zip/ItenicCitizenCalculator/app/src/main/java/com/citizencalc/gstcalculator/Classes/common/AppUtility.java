package com.citizencalc.gstcalculator.Classes.common;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

import com.citizencalc.gstcalculator.CustomAd.ui.AdsInit;

import java.io.IOException;
import java.io.InputStream;

public class AppUtility {

    //static string
    public static boolean isClickGames = false;
    public static final String RATE_US_COM = "COMPLETE";
    public static final String Unit_Parent = "Unit_Parent";
    public static final String Unit_From = "Unit_From";
    public static final String Unit_From_Code = "Unit_From_Code";
    public static final String Unit_To = "Unit_To";
    public static final String Unit_To_Code = "Unit_To_Code";
    public static final String Unit_From_Value = "Unit_From_Value";
    public static final String Last_Unit_Tag = "Last_Unit_Tag";
    public static final String Rate_First_Time = "Rate_First_Time";
    public static final String Rate_Date = "Rate_Date";
    public static final String Rate_Dialog_show = "Rate_Dialog_show";
    public static final String Rate_After_Five_Day_Date = "Rate_After_Five_Day_Date";
    public static final String Rate_After_Five_Day = "Rate_After_Five_Day";

    public static final String NumberFormat = "NumberFormat";
    public static final String NumberFormatID = "NumberFormatID";

    public static final String General = "General";
    public static final String Thousands = "Thousands";
    public static final String Scitific = "Scitific";


    public static final String Nativ_default_ID = "";
    //  public static final String Interstial_default_ID = "ca-app-pub-3940256099942544/1033173712"; //test id
    public static final String Play_Store_Url = "http://play.google.com/store/apps/details?id=";
    public static final String Decimal_format = "@############";
    //public static final String Decimal_format = "##,###.##";
    public static final String Number_format = "###.#####";
    public static final String Date_format = "dd/MM/yyyy";
    public static final String PREF_TAG = "APP_PREF";
    public static final String plus_3 = "+3";
    public static final String plus_5 = "+5";
    public static final String plus_12 = "+12";
    public static final String plus_18 = "+18";
    public static final String plus_28 = "+28";
    public static final String minus_3 = "-3";
    public static final String minus_5 = "-5";
    public static final String minus_12 = "-12";
    public static final String minus_18 = "-18";
    public static final String minus_28 = "-28";


    public static boolean is_gst_button = false;
    public static boolean is_done = false;

    //intent Key
    public static final String Unit_Title = "UnitTitle";
    public static final String Unit_Postion = "position";

    public static String IS_ADFREE = "10";

    public static boolean isNetworkAvailable(Activity activity) {
        final ConnectivityManager connectivityManager = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);

        Network network = connectivityManager.getActiveNetwork();
        final NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);

        return capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    public static AdsInit adsInit;
    public static String loadJSONFromAsset(Activity activity) {
        String json = null;
        try {
            InputStream is = activity.getAssets().open("unit.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public static String setRoundOff(int i) {
        return switch (i) {
            case 0 -> "%.0f";
            case 1 -> "%.1f";
            case 2 -> "%.2f";
            case 3 -> "%.3f";
            case 5 -> "%.5f";
            case 6 -> "%.6f";
            case 7 -> "%.7f";
            case 8 -> "%.8f";
            case 9 -> "%.9f";
            case 10 -> "%.10f";
            default -> "%.4f";
        };
    }

    public static String setThousandRoundOff(int i) {
        return switch (i) {
            case 0 -> ".0f";
            case 1 -> ".1f";
            case 2 -> ".2f";
            case 3 -> ".3f";
            case 5 -> ".5f";
            case 6 -> ".6f";
            case 7 -> ".7f";
            case 8 -> ".8f";
            case 9 -> ".9f";
            case 10 -> ".10f";
            default -> ".4f";
        };
    }
}