package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;
@Keep
public class Sku {

    @SerializedName("content")
    private String content;

    @SerializedName("title")
    private String title;

    @SerializedName("validity")
    private String validity;

    @SerializedName("default_value")
    private String default_value;

    @SerializedName("sku")
    private String sku;


    @SerializedName("_id")
    private String _id;

    @SerializedName("enable")
    private int enable;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public int getEnable() {
        return enable;
    }

    public void setEnable(int enable) {
        this.enable = enable;
    }

    public String getContent ()
    {
        return content;
    }

    public void setContent (String content)
    {
        this.content = content;
    }

    public String getTitle ()
    {
        return title;
    }

    public void setTitle (String title)
    {
        this.title = title;
    }

    public String getValidity ()
    {
        return validity;
    }

    public void setValidity (String validity)
    {
        this.validity = validity;
    }

    public String getDefault_value ()
    {
        return default_value;
    }

    public void setDefault_value (String default_value)
    {
        this.default_value = default_value;
    }

    public String getSku ()
    {
        return sku;
    }

    public void setSku (String sku)
    {
        this.sku = sku;
    }

}
