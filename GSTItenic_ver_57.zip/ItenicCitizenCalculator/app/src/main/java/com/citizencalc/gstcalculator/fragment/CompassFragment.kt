package com.citizencalc.gstcalculator.fragment

import android.content.Context.MODE_PRIVATE
import android.os.Bundle
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.citizencalc.gstcalculator.Classes.common.AppUtility.PREF_TAG
import com.citizencalc.gstcalculator.Classes.common.GstApp
import com.citizencalc.gstcalculator.Classes.common.GstApp.Companion.appContext
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.activity.MainActivity
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.databinding.LayoutCompassBinding
import com.citizencalc.gstcalculator.sensor.SensorListener
import com.citizencalc.gstcalculator.sensor.SensorUtil
import com.citizencalc.gstcalculator.sensor.utils.Utility.getDirectionText

class CompassFragment : Fragment(), SensorListener.OnValueChangedListener {

    lateinit var binding: LayoutCompassBinding
    lateinit var mSensorListener: SensorListener
    lateinit var databaseGst: DatabaseGst
    var myLanStringValue: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // super.onCreateView(inflater, container, savedInstanceState)
        binding = LayoutCompassBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val sp = activity?.getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        myLanStringValue = sp?.getString("is_radio_name", "")

        databaseGst = DatabaseGst(activity)

        if (!hasSensor()) {
            binding.alertBtn.visibility = View.VISIBLE
            showDialogUnsupported()
        } else binding.alertBtn.visibility = View.GONE

        binding.alertBtn.setOnClickListener { showDialogUnsupported() }

        mSensorListener = SensorListener(context)
        mSensorListener.setOnValueChangedListener(this)
    }

    override fun onStart() {
        super.onStart()
        if (mSensorListener != null) mSensorListener.start()
    }

    override fun onStop() {
        if (mSensorListener != null) mSensorListener.stop()
        super.onStop()
    }

    private fun hasSensor(): Boolean {
        return SensorUtil.hasAccelerometer(appContext) && SensorUtil.hasMagnetometer(appContext)
    }

    private fun showDialogUnsupported() {
        val builder = AlertDialog.Builder((activity as MainActivity))

        if (myLanStringValue == "Gujarati") {
            builder.setTitle(resources.getString(R.string.Gujarati_alert_compass_title))
            builder.setMessage(resources.getString(R.string.Gujarati_alert_compass))
            builder.setPositiveButton(Html.fromHtml("<font color='#000000'>સારું</font>")) { dialog, which -> dialog.dismiss() }.create().show()
        } else if (myLanStringValue == "Hindi") {
            builder.setTitle(resources.getString(R.string.Hindi_alert_compass_title))
            builder.setMessage(resources.getString(R.string.Hindi_alert_compass))
            builder.setPositiveButton(Html.fromHtml("<font color='#000000'>ठीक</font>")) { dialog, which -> dialog.dismiss() }.create().show()
        } else {
            builder.setTitle(resources.getString(R.string.English_alert_compass_title))
            builder.setMessage(resources.getString(R.string.English_alert_compass))
            builder.setPositiveButton(Html.fromHtml("<font color='#000000'>Ok</font>")) { dialog, which -> dialog.dismiss() }.create().show()
        }
    }

    override fun onMagneticFieldChanged(value: Float) {
        binding.compassView.sensorValue.magneticField = value
    }

    override fun onRotationChanged(azimuth: Float, pitch: Float, oldDegree: Float) {
        val str = azimuth.toInt().toString() + "° " + getDirectionText(azimuth)
        binding.degreeTxt.text = str
        binding.compassView.sensorValue.setRotation(azimuth, oldDegree, pitch)
        binding.accelerometerView.sensorValue.setRotation(azimuth, oldDegree, pitch)
    }
}