package com.citizencalc.gstcalculator.activity

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.Html
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.citizencalc.gstcalculator.Classes.common.READ_PERMISSION_CODE
import com.citizencalc.gstcalculator.Classes.common.hasPermissions
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.adapter.PdfListAdapter
import com.citizencalc.gstcalculator.databinding.ActivityPdfListBinding

import java.io.File
import kotlin.collections.ArrayList

class PdfListActivity : AppCompatActivity() {
    
    lateinit var binding: ActivityPdfListBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        window.setFlags(1024, 1024)
        binding = ActivityPdfListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarList)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val inflator = LayoutInflater.from(this)
        val v: View = inflator.inflate(R.layout.custom_actionbar, null)
        v.findViewById<TextView>(R.id.action_bar_title).text = "Saved Pdf List"
        supportActionBar?.customView = v
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pdfLists()
        } else {
            if (hasPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))) {
                pdfLists()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION_CODE)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun pdfLists() {
        val pdfList: ArrayList<File> = ArrayList()
        val gridLayoutManager = GridLayoutManager(this, 3)
        binding.pdfRecycle.layoutManager = gridLayoutManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val dir = File(filesDir, resources.getString(R.string.app_label))
            if (!dir.exists()) dir.mkdirs()
            if (dir.isDirectory) {
                val listfile: Array<File> = dir.listFiles()
                if (listfile.isNotEmpty()) {
                    pdfList.clear()
                    for (i in listfile.indices) {
                        pdfList.add(listfile[i])
                    }
                }
            }
            if (pdfList.size > 0) {
                binding.noDocument.visibility = View.GONE
                pdfList.reverse()
                val pdfListAdapter = PdfListAdapter(pdfList, this)
                binding.pdfRecycle.adapter = pdfListAdapter
            } else {
                binding.noDocument.visibility = View.VISIBLE
            }

        } else {
            val appFolder = File(Environment.getExternalStorageDirectory(), resources.getString(R.string.app_label))
            if (!appFolder.exists()) {
                appFolder.mkdirs()
            }
            if (appFolder.isDirectory) {
                val listfile: Array<File> = appFolder.listFiles()
                if (listfile.isNotEmpty()) {
                    pdfList.clear()
                    for (i in listfile.indices) {
                        pdfList.add(listfile.get(i))
                    }
                }
            }
            if (pdfList.size > 0) {
                binding.noDocument.visibility = View.GONE
                pdfList.reverse()
                val pdfListAdapter = PdfListAdapter(pdfList, this)
                binding.pdfRecycle.adapter = pdfListAdapter
            } else {
                binding.noDocument.visibility = View.VISIBLE
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == READ_PERMISSION_CODE) {
            if (grantResults[0] < 0) {
                showAlert()
            } else {
                pdfLists()
            }
        }
    }

    private fun showAlert() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(resources.getString(R.string.app_label))
        builder.setMessage("Allow permission to continue")

        builder.setPositiveButton(Html.fromHtml("<font color='#000000'>Ok</font>")) { dialog, which -> dialog.dismiss()
            if (hasPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))) {
                pdfLists()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION_CODE)
            }
        }.create().show()

        builder.setNegativeButton(Html.fromHtml("<font color='#000000'>CANCEL</font>")) { dialog, which -> finish() }.create().show()
        val dialog = builder.create()
        dialog.show()
        dialog.setCanceledOnTouchOutside(false)
    }
}