package com.citizencalc.gstcalculator.Classes.common;

public interface Dialogdismiss {

    void onDismiss(boolean state);
}
