package com.citizencalc.gstcalculator.database.table
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.annotation.Keep

@Keep
@Entity
class CaAds {
    @PrimaryKey
    var id=""
    var adsDesc=""
    var adsTitle=""
    var advertisementCustomMulti=""
    var banner=""
    var color=""
    var date=""
    var designPage=""
    var download=""
    var enable=0
    var icon=""
    var install=""
    var rating=""
    var review=""
}