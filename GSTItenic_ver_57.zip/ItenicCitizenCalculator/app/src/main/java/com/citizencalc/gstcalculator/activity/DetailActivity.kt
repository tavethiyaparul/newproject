package com.citizencalc.gstcalculator.activity

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfDocument.PageInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.Html
import android.util.DisplayMetrics
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.Classes.common.READ_PERMISSION_CODE
import com.citizencalc.gstcalculator.Classes.common.hasPermissions
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.databinding.ActivityDetailBinding
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class DetailActivity : AppCompatActivity() {
    
    lateinit var binding: ActivityDetailBinding
    var fileName = "SIP_Statment_"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(1024, 1024)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarDtl)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val v: View = layoutInflater.inflate(R.layout.custom_actionbar, null)
        v.findViewById<TextView>(R.id.action_bar_title).text = resources.getString(R.string.app_label)
        supportActionBar?.customView = v

        binding.textView.text = "Returns for different time durations at [ " + intent.getStringExtra("rate") + "% ]"
        binding.statsProgressbar.progress = intent.getIntExtra("chart", 1)
        if (intent.getStringExtra("type").equals("Simple")) {
            v.findViewById<TextView>(R.id.action_bar_title).text = "SIP Calculation Detail"
            fileName = "SIP_Statment_"
            sip_calculate(
                intent.getStringExtra("sip")?.toDouble()!!,
                intent.getStringExtra("rate")?.toDouble()!!,
                intent.getStringExtra("period")?.toDouble()!!
            )
        } else {
            v.findViewById<TextView>(R.id.action_bar_title).text = "Lumpsum Calculation Detail"
            fileName = "LS_Statment_"
            binding.middleTitle.text = "Wealth Gained"
            binding.lastTitle.text = "Maturity Amount"

            lumpsum_calculate(
                intent.getStringExtra("sip")?.toDouble()!!,
                intent.getStringExtra("rate")?.toDouble()!!,
                intent.getStringExtra("period")?.toDouble()!!
            )
        }
        val yearsArray = arrayOf<Int>(5, 8, 10, 12, 15, 18, 20, 22, 25, 28, 30, 35)
        try {
            binding.rowLayout.removeAllViews()
            for (i in yearsArray.indices) {
                val viewRow = layoutInflater.inflate(R.layout.row_item, null)
                //

                val p = intent.getStringExtra("sip")?.toDouble()
                val r = intent.getStringExtra("rate")?.toDouble()
                val N = yearsArray[i].toDouble()

                if (intent.getStringExtra("type").equals("Simple")) {

                    val ans = (r?.div(100))?.div(12)
                    val n = (N * 12)
                    val phase1 = (p?.times((Math.pow((1.00 + ans!!), n) - 1.00))?.div(ans)
                        ?.times((1.00 + ans)))
                    viewRow.findViewById<AppCompatTextView>(R.id.duretion_value).text = yearsArray[i].toString() + " Year"
                    viewRow.findViewById<AppCompatTextView>(R.id.amount_value).text = "\u20B9 " + String.format("%,d", intent.getStringExtra("sip")!!.toInt())
                    viewRow.findViewById<AppCompatTextView>(R.id.feture_value).text = "\u20B9 " + String.format("%,d", phase1?.toInt())
                } else {
                    val ans = r?.div(100)

                    val phase1 = (p?.times(Math.pow((1.00 + ans!!), N)))
                    viewRow.findViewById<AppCompatTextView>(R.id.duretion_value).text = yearsArray[i].toString() + " Year"
                    viewRow.findViewById<AppCompatTextView>(R.id.amount_value).text = "\u20B9 " + String.format("%,d", (phase1?.minus(intent.getStringExtra("sip")!!.toDouble())?.toInt()))
                    viewRow.findViewById<AppCompatTextView>(R.id.feture_value).text = "\u20B9 " + String.format("%,d", phase1?.toInt())
                }

                binding.rowLayout.addView(viewRow)
            }

        } catch (e: ArithmeticException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun sip_calculate(p: Double, r: Double, N: Double) {

        try {
            val ans = r / 100 / 12
            val n = (N * 12)
            val phase_1 = (p * ((Math.pow((1.00 + ans), n) - 1.00) / ans) * (1.00 + ans))
            binding.durValue.text = N.toInt().toString() + " Year"
            binding.amntValue.text = "\u20B9 " + String.format("%,d", p.toInt())
            binding.fetValue.text = "\u20B9 " + String.format("%,d", phase_1.toInt())
        } catch (e: ArithmeticException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun lumpsum_calculate(p: Double, r: Double, N: Double) {

        try {
            val ans = r / 100
            val phase1 = (p * (Math.pow((1.00 + ans), N)))
            binding.durValue.text = N.toInt().toString() + " Year"
            binding.amntValue.text = "\u20B9 " + String.format("%,d", (phase1 - p).toInt())
            binding.fetValue.text = "\u20B9 " + String.format("%,d", phase1.toInt())
        } catch (e: ArithmeticException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.detail_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
            R.id.action_download -> {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    createPdf()
                } else {
                    if (hasPermissions(
                            this,
                            arrayOf(
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                            )
                        )
                    ) {
                        createPdf()
                    } else {
                        ActivityCompat.requestPermissions(
                            this,
                            arrayOf(
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                            ), READ_PERMISSION_CODE
                        )
                    }
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun loadBitmapFromView(v: ScrollView): Bitmap {


        val b = Bitmap.createBitmap(v.width, v.getChildAt(0).height, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        v.draw(c)
        return b
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == READ_PERMISSION_CODE) {

            if (grantResults[0] < 0) {
                showAlert()
            }
        }
    }

    private fun showAlert() {
        val builder = AlertDialog.Builder(this)

        builder.setTitle(resources.getString(R.string.app_label))
        builder.setMessage("Allow permission to continue")

        builder.setPositiveButton(Html.fromHtml("<font color='#000000'>OK</font>")) { dialog, which ->  dialog.dismiss()
            if (hasPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))) {
                createPdf()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION_CODE)
            }
        }.create().show()

        builder.setNegativeButton(Html.fromHtml("<font color='#000000'>CANCEL</font>")) { dialog, which -> finish() }.create().show()
        val dialog = builder.create()
        dialog.show()
        dialog.setCanceledOnTouchOutside(false)
    }

    private fun createPdf() {
        SaveProgressDialog()
        val bitmap = loadBitmapFromView(binding.scrollView)

        val document = PdfDocument()
        val pageInfo = PageInfo.Builder(bitmap?.width!!.toInt(), bitmap.height, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()
        canvas.drawPaint(paint)

        paint.color = Color.BLUE
        canvas.drawBitmap(bitmap, 0f, 0f, null)
        document.finishPage(page)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val dir = File(filesDir, resources.getString(R.string.app_label))

            if (!dir.exists()) dir.mkdir()

            var fileNo = 0
            val sp = getSharedPreferences("MyPref", MODE_PRIVATE)
            fileNo = sp.getInt("file_count", fileNo)
            val tablesFile = File(dir, "$fileName$fileNo.pdf")

            fileNo++
            val editor = sp.edit()
            editor.putInt("file_count", fileNo)
            editor.apply()

            val filePath: File = tablesFile
            try {
                document.writeTo(FileOutputStream(filePath))
            } catch (e: IOException) {
                e.printStackTrace()
                Toast.makeText(this, "Something wrong: " + e.toString(), Toast.LENGTH_LONG).show()
            }
            // close the document
            document.close()

        } else {
            val appFolder = File(Environment.getExternalStorageDirectory(), resources.getString(R.string.app_label))

            if (!appFolder.exists()) appFolder.mkdirs()
            var fileNo = 0
            val sp = getSharedPreferences("MyPref", MODE_PRIVATE)
            fileNo = sp.getInt("file_count", fileNo)
            val tablesFile = File(appFolder, "$fileName$fileNo.pdf")

            fileNo++
            val editor = sp.edit()
            editor.putInt("file_count", fileNo)
            editor.apply()

            val filePath: File = tablesFile
            try {
                document.writeTo(FileOutputStream(filePath))
            } catch (e: IOException) {
                e.printStackTrace()
                Toast.makeText(this, "Something wrong: $e", Toast.LENGTH_LONG).show()
            }
            document.close()
        }
    }

    private fun SaveProgressDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dowmload_dialog)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)
        dialog.window?.decorView?.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        val progressBar = dialog.findViewById(R.id.my_progressBar) as ProgressBar
        val showAction: LinearLayout = dialog.findViewById(R.id.action_pdf_dailog)
        val heading: TextView = dialog.findViewById(R.id.text_header)
        val openPdf: RelativeLayout = dialog.findViewById(R.id.open)
        val cancel: RelativeLayout = dialog.findViewById(R.id.cancel)
        Handler(Looper.getMainLooper()).postDelayed({
            showAction.visibility = View.VISIBLE
            heading.text = "Pdf Save Successfully."
        }, 5000)
        openPdf.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val dir = File(filesDir, resources.getString(R.string.app_label))
                if (dir.isDirectory) {
                    val listFile: Array<File> = dir.listFiles()
                    if (listFile.isNotEmpty()) {
                        val pdfURI: Uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".gstcalculator", listFile[listFile.size - 1])
                        val intent = Intent(this, ShowPdf::class.java)
                        intent.putExtra("URI", pdfURI.toString())
                        startActivity(intent)
                        dialog.dismiss()
                    }
                }
            } else {
                val appFolder = File(Environment.getExternalStorageDirectory(), resources.getString(R.string.app_label))
                if (appFolder.isDirectory) {
                    val listFile: Array<File> = appFolder.listFiles()
                    if (listFile.isNotEmpty()) {
                        val pdfURI: Uri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".gstcalculator", listFile[listFile.size - 1])
                        val intent = Intent(this, ShowPdf::class.java)
                        intent.putExtra("URI", pdfURI.toString())
                        startActivity(intent)
                        dialog.dismiss()
                    }
                }
            }
        }
        cancel.setOnClickListener { dialog.dismiss() }
        progressBar.visibility = View.VISIBLE
        val progressAnimator = ObjectAnimator.ofInt(progressBar, "progress", 0, 100)
        progressAnimator.duration = 5000
        progressAnimator.interpolator = LinearInterpolator()
        progressAnimator.start()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        val win: Window? = dialog.window
        win?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }
}