package com.citizencalc.gstcalculator.sensor.drawer;


import static com.citizencalc.gstcalculator.Classes.common.GstApp.appContext;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.citizencalc.gstcalculator.R;
import com.citizencalc.gstcalculator.sensor.model.SensorValue;




public class AccelerometerDrawer {
    private static final String TAG = "AccelerometerCompassHel";
    private final Paint mPathPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SensorValue mSensorValue = new SensorValue();
    private final Path mPath = new Path();
    private boolean mIsPaintCreated = false;
    /*Color*/
    @ColorInt
    private int mForegroundColor;
    @ColorInt
    private int mBackgroundColor;
    @ColorInt
    private int mPrimaryTextColor;
    @ColorInt
    private int mSecondaryTextColor;
    @ColorInt
    private int mAccentColor;
    @NonNull
    private Context mContext;
    private float mPixelScale;
    private Point mCenter;
    private float mUnitPadding;

    public AccelerometerDrawer(@NonNull Context context) {
        this.mContext = context;
    }

    public void draw(Canvas canvas) {
        mPixelScale = ((float) Math.min(canvas.getWidth(), canvas.getHeight())) / 1000.0f;
        mCenter = new Point(canvas.getWidth() / 2, canvas.getHeight() / 2);
        mUnitPadding = realPx(5);
        initPaint();

        //drawSunTime(canvas);
        drawPitchRoll(canvas);
    }

    private float realPx(float width) {
        return width * mPixelScale;
    }

    private void initPaint() {
        //no need setup
        if (mIsPaintCreated) {
            return;
        }
        SharedPreferences theme_Shared = appContext.getSharedPreferences("AppPref", Context.MODE_PRIVATE);
        setThemeStyle(theme_Shared.getInt("Theme", 0));


        mPathPaint.setStrokeCap(Paint.Cap.ROUND);

        mIsPaintCreated = true;
    }
    private void setThemeStyle(int currentTheme) {
        switch (currentTheme) {
            case 0 : {

                mForegroundColor = ContextCompat.getColor(mContext, R.color.compass_foreground_color);
                mBackgroundColor = ContextCompat.getColor(mContext, R.color.compass_background_color);
                mPrimaryTextColor = ContextCompat.getColor(mContext, R.color.compass_text_primary_color);
                mSecondaryTextColor = ContextCompat.getColor(mContext, R.color.compass_text_secondary_color);
                mAccentColor = ContextCompat.getColor(mContext, R.color.compass_accent_color);
                break;
            }
            case 1 : {

                mForegroundColor = ContextCompat.getColor(mContext, R.color.theme1_ColorPrimaryDark);
                mBackgroundColor = ContextCompat.getColor(mContext, R.color.theme1_ColorPrimary);
                mPrimaryTextColor = ContextCompat.getColor(mContext, R.color.compass_text_primary_color);
                mSecondaryTextColor = ContextCompat.getColor(mContext, R.color.compass_text_secondary_color);
                mAccentColor = ContextCompat.getColor(mContext, R.color.theme1_windowBackground);
                break;

            }
            case 2 : {

                mForegroundColor = ContextCompat.getColor(mContext, R.color.theme2_ColorPrimaryDark);
                mBackgroundColor = ContextCompat.getColor(mContext, R.color.theme2_ColorPrimary);
                mPrimaryTextColor = ContextCompat.getColor(mContext, R.color.theme2_ColorAccent);
                mSecondaryTextColor = ContextCompat.getColor(mContext, R.color.compass_text_secondary_color);
                mAccentColor = ContextCompat.getColor(mContext, R.color.theme2_ColorAccent);
                break;
            }
            case 3 : {
                mForegroundColor = ContextCompat.getColor(mContext, R.color.theme3_ColorPrimaryDark);
                mBackgroundColor = ContextCompat.getColor(mContext, R.color.theme3_ColorPrimary);
                mPrimaryTextColor = ContextCompat.getColor(mContext, R.color.compass_text_primary_color);
                mSecondaryTextColor = ContextCompat.getColor(mContext, R.color.theme3_windowBackground);
                mAccentColor = ContextCompat.getColor(mContext, R.color.theme3_windowBackground);
                break;
            }
            case 4 : {

                mForegroundColor = ContextCompat.getColor(mContext, R.color.theme4_ColorPrimary);
                mBackgroundColor = ContextCompat.getColor(mContext, R.color.theme4_ColorPrimaryDark);
                mPrimaryTextColor = ContextCompat.getColor(mContext, R.color.theme4_ColorAccent);
                mSecondaryTextColor = ContextCompat.getColor(mContext, R.color.theme4_ColorAccent);
                mAccentColor = ContextCompat.getColor(mContext, R.color.theme4_ColorAccent);


                break;

            }
            case 5 : {
                mForegroundColor = ContextCompat.getColor(mContext, R.color.theme5_ColorPrimary);
                mBackgroundColor = ContextCompat.getColor(mContext, R.color.theme5_ColorPrimaryDark);
                mPrimaryTextColor = ContextCompat.getColor(mContext, R.color.theme5_ColorAccent);
                mSecondaryTextColor = ContextCompat.getColor(mContext, R.color.compass_text_secondary_color);
                mAccentColor = ContextCompat.getColor(mContext, R.color.theme5_ColorAccent);
                break;

            }
            case 6 : {

                mForegroundColor = ContextCompat.getColor(mContext, R.color.theme6_ColorPrimary);
                mBackgroundColor = ContextCompat.getColor(mContext, R.color.theme6_ColorPrimaryDark);
                mPrimaryTextColor = ContextCompat.getColor(mContext, R.color.theme5_ColorAccent);
                mSecondaryTextColor = ContextCompat.getColor(mContext, R.color.theme6_windowBackground);
                mAccentColor = ContextCompat.getColor(mContext, R.color.theme5_ColorAccent);
                break;
            }

        }
    }

    public SensorValue getSensorValue() {
        return mSensorValue;
    }

    private void drawPitchRoll(Canvas canvas) {
        int length = 470;
        float maxRadius = realPx(length);
        float radius = maxRadius;

        mPathPaint.setColor(mBackgroundColor);
        mPathPaint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(mCenter.x, mCenter.y, radius, mPathPaint);

        mPathPaint.setColor(mPrimaryTextColor);
        mPathPaint.setStyle(Paint.Style.FILL);
        float roll = mSensorValue.getRoll();
        float pitch = mSensorValue.getPitch();

        float cosP = (float) Math.cos(Math.toRadians(90 - pitch));
        float x = realPx(370) * cosP;
        float cosR = (float) Math.cos(Math.toRadians(90 - roll));
        float y = realPx(370) * cosR;
        canvas.drawCircle(mCenter.x - x, mCenter.y + y, realPx(100), mPathPaint);

        radius = maxRadius;
        mPath.reset();
        mPath.moveTo(mCenter.x - radius, mCenter.y);
        mPath.lineTo(mCenter.x + radius, mCenter.y);
        mPath.moveTo(mCenter.x, mCenter.y - radius);
        mPath.lineTo(mCenter.x, mCenter.y + radius);
        mPath.addCircle(mCenter.x, mCenter.y, radius, Path.Direction.CCW);

        mPathPaint.setShadowLayer(realPx(3), 0, 0, Color.BLACK);
        mPathPaint.setColor(mSecondaryTextColor);
        mPathPaint.setStrokeWidth(realPx(5));
        mPathPaint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(mPath, mPathPaint);

    }

    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        mIsPaintCreated = false;
    }
}
