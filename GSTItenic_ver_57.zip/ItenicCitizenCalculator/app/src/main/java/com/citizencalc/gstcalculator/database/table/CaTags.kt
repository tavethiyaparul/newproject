package com.citizencalc.gstcalculator.database.table

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.annotation.Keep

@Keep
@Entity
class CaTags {
    @PrimaryKey
    var id = ""
    var attr = ""
    var ids = ""
    var order = 0
}