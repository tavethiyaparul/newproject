package com.citizencalc.gstcalculator.database.dao

import androidx.room.*
import com.citizencalc.gstcalculator.database.table.*

@Dao
interface CaAdsDao {
    @Query("SELECT * FROM CaAds ")
    fun getData(): List<CaAds>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(ads: CaAds)

    @Update
    fun update(ads: CaAds)

    @Query("DELETE FROM CaAds where enable=0")
    fun delete()
}

@Dao
interface CaTagsDao {
    @Query("SELECT * FROM CaTags ")
    fun getData(): List<CaTags>

    @Query("SELECT * FROM CaTags ")
    fun getDataTest(): List<CaTags>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(data: CaTags)

    @Update
    fun update(data: CaTags)

    @Query("DELETE FROM CaTags")
    fun delete()
}

@Dao
interface TbAdsNameDao {
    @Query("SELECT * FROM TbAdsName")
    fun getADS(): List<TbAdsName>?

    @Query("SELECT * FROM TbAdsName where admName=:name and enable=:enable")
    fun getData(name: String, enable: Int): TbAdsName?

    @Query("SELECT count FROM TbAdsName where admName=:name")
    fun getCount(name: String): Int

    @Query("SELECT enable FROM TbAdsName where admName=:name")
    fun getEnable(name: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(data: TbAdsName)

    @Update
    fun update(data: TbAdsName)

    @Query("DELETE FROM TbAdsName")
    fun delete()
}

@Dao
interface TbAppConfigDao {
    @Query("SELECT data FROM TbAppConfig where id = :AppId")
    fun getData(AppId: Int): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(data: TbAppConfig)

    @Update
    fun update(data: TbAppConfig)

    @Query("DELETE FROM TbAppConfig")
    fun delete()
}

@Dao
interface TbSkuDao {
    @Query("SELECT * FROM TbSku ")
    fun getData(): List<TbSku>?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(data: TbSku)

    @Update
    fun update(data: TbSku)

    @Query("DELETE FROM TbSku")
    fun delete()
}

@Dao
interface RoomOrderDao {
    @Query("Select * from RoomOrder")
    fun getRoomOrder(): List<RoomOrder>?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomOrder(roomVersion: RoomOrder)

    @Update
    fun updateRoomOrder(roomVersion: RoomOrder)

    @Delete
    fun deleteRoomOrder(roomVersion: RoomOrder)
}