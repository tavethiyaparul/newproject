package com.citizencalc.gstcalculator.database.table

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.annotation.Keep

@Keep
@Entity
class TbSku {
    @PrimaryKey
    var id = ""
    var sku = ""
    var title = ""
    var content = ""
    var defaultValue = ""
    var validity = ""
    var color = ArrayList<String>()
}