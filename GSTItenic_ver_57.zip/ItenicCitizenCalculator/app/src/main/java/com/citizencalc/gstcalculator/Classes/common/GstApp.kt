package com.citizencalc.gstcalculator.Classes.common

import android.app.Activity
import android.app.Application
import android.content.Context
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.Classes.common.AppUtility.PREF_TAG
import com.google.firebase.FirebaseApp
import com.revenuecat.purchases.LogLevel
import com.revenuecat.purchases.Purchases
import com.revenuecat.purchases.PurchasesConfiguration

class GstApp : Application() {


    companion object {
        lateinit var appInstance: GstApp

        lateinit var appContext: Context
    }

    override fun onCreate() {
        super.onCreate()

        FirebaseApp.initializeApp(this)
        AppOpenManager(this)
        appInstance = this
        appContext = applicationContext

        if (BuildConfig.DEBUG) {
            Purchases.logLevel = LogLevel.DEBUG
        } else {
            Purchases.logLevel = LogLevel.ERROR
        }
        /*  Purchases.logLevel(LogLevel.DEBUG)
      else Purchases.setLogLevel(LogLevel.ERROR)*/

        Purchases.configure(
            PurchasesConfiguration.Builder(appInstance, "goog_olnifFKtsbrXZNMaaAqZJonBLrl")
                .showInAppMessagesAutomatically(false)
                .build()
        )

        val sp = getSharedPreferences(PREF_TAG, Activity.MODE_PRIVATE)
        val myIntValue = sp.getString("is_radio_name", "")

        /* FirebaseApp.initializeApp(this@GstApp)
         AppOpenManager(this)
         gstAppContext = this
         context = applicationContext*/
//        if (BuildConfig.DEBUG) Purchases.setLogLevel(LogLevel.DEBUG) else Purchases.setLogLevel(
//            LogLevel.ERROR
//        )
//        Purchases.configure(
//            Builder(this@GstApp, "goog_olnifFKtsbrXZNMaaAqZJonBLrl")
//                .showInAppMessagesAutomatically(false)
//                .build()
//        )
//        val sp = getSharedPreferences(AppUtility.PREF_TAG, MODE_PRIVATE)
//        val myIntValue = sp.getString("is_radio_name", "")


    }



}