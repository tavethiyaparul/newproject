package com.citizencalc.gstcalculator.database.table

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.annotation.Keep

@Keep
@Entity
class TbAppConfig {
    @PrimaryKey
    var id: Int = 0
    var data: String = ""
}