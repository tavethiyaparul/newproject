package com.citizencalc.gstcalculator.model

data class PaywallTheme(
    val current_offering: String?,
    val header: String?,
    val plan1: String?,
    val plan2: String?,
    val plan3: String?,
    val offer1: String?,
    val offer2: String?,
    val offer3: String?,
    val offer4: String?,
    val subscriptionDays: String?,
    val discount1: String?,
    val discount2: String?,
    val discount3: String?,
    val bgImage: String?,
    val accentColor: String?,
    val subscribeColor: String?,
    val gradientColor1: String?,
    val gradientColor2: String?,
    val gradientColor3: String?,
    val exitColor: String?
)