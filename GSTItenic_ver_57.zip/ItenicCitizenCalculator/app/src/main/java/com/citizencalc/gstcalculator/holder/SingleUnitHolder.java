package com.citizencalc.gstcalculator.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.citizencalc.gstcalculator.R;

public class SingleUnitHolder extends RecyclerView.ViewHolder {

    public ImageView single_unit_image;
    public TextView single_unit_name,single_unit_answer,single_unit_code;
    public RelativeLayout single_unit_icon_bg,fornt_view;

    public SingleUnitHolder(@NonNull View itemView) {
        super(itemView);
        single_unit_image = itemView.findViewById(R.id.single_unit_image);
        single_unit_name = itemView.findViewById(R.id.single_unit_name);
        single_unit_answer = itemView.findViewById(R.id.single_unit_answer);
        single_unit_icon_bg = itemView.findViewById(R.id.single_unit_icon_bg);
        single_unit_code = itemView.findViewById(R.id.single_unit_code);
        fornt_view = itemView.findViewById(R.id.fornt_view);
    }
}
