package com.citizencalc.gstcalculator.fragment

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Resources
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.SwitchCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.TEXT_FEEDBACK
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.TEXT_MAIL
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.TEXT_MAIL_TO
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.TEXT_SENDMAIL
import com.citizencalc.gstcalculator.Classes.common.AppUtility.*
import com.citizencalc.gstcalculator.LocaleHelper
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.activity.MainActivity
import com.citizencalc.gstcalculator.activity.SelectTheme
import com.citizencalc.gstcalculator.databinding.FragmentSettingsBinding

class SettingFragment : Fragment() {

    lateinit var binding: FragmentSettingsBinding
    internal var context: Context? = null
    private var resources1: Resources? = null

    lateinit var soundText: TextView
    lateinit var vibrationText: TextView
    lateinit var suggestionText: TextView
    lateinit var languageText: TextView
    lateinit var roundText: TextView
    lateinit var themeText: TextView
    lateinit var shareText: TextView
    lateinit var rateText: TextView
    lateinit var versionText: TextView
    lateinit var preferences: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    private var radioGroup: RadioGroup? = null
    lateinit var switchSound: SwitchCompat
    lateinit var switchVibration: SwitchCompat
    lateinit var rate: RelativeLayout
    lateinit var shareApp: RelativeLayout
    lateinit var mail: RelativeLayout
    lateinit var version: TextView
    lateinit var roundOffText: TextView
    lateinit var seekbar: SeekBar

    private var states = arrayOf(intArrayOf(-android.R.attr.state_checked), intArrayOf(android.R.attr.state_checked))
    private var thumbColors = intArrayOf(Color.WHITE, Color.rgb(255, 136, 0))
    private var trackColors = intArrayOf(Color.rgb(30, 28, 31), Color.rgb(122, 88, 49))

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init(view)

        version.text = BuildConfig.VERSION_NAME

        switchSound.isChecked = preferences.getBoolean("is_sound", true)
        switchVibration.isChecked = preferences.getBoolean("is_vibrate", true)

        DrawableCompat.setTintList(DrawableCompat.wrap(switchSound.thumbDrawable), ColorStateList(states, thumbColors))
        DrawableCompat.setTintList(DrawableCompat.wrap(switchSound.trackDrawable), ColorStateList(states, trackColors))
        DrawableCompat.setTintList(DrawableCompat.wrap(switchVibration.thumbDrawable), ColorStateList(states, thumbColors))
        DrawableCompat.setTintList(DrawableCompat.wrap(switchVibration.trackDrawable), ColorStateList(states, trackColors))

        if (preferences.getInt("is_radio_id", 0) == 0) {
            editor.putInt("is_radio_id", R.id.round_off)
            editor.apply()
        }
        radioGroup!!.check(preferences.getInt("is_radio_id", R.id.round_off))
        setLangauage(preferences.getInt("is_radio_id", R.id.round_off))

        try {
            setRoundoff(Integer.parseInt(preferences.getString("is_round", "3")!!))
        } catch (e: NumberFormatException) {
            e.printStackTrace()
        } catch (e: StackOverflowError) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        radioGroup!!.setOnCheckedChangeListener { group, checkedId ->
            val radioButton = radioGroup!!.findViewById<View>(checkedId) as RadioButton
            if (null != radioButton && checkedId > -1) {

                setLangauage(radioButton.id)

                editor.putInt("is_radio_id", radioButton.id)
                editor.putString("is_radio_name", radioButton.text.toString())
                editor.apply()
            }
        }
        switchSound.setOnCheckedChangeListener { buttonView, isChecked ->
            editor.putBoolean("is_sound", isChecked)
            editor.apply()
        }
        switchVibration.setOnCheckedChangeListener { buttonView, isChecked ->
            editor.putBoolean("is_vibrate", isChecked)
            editor.apply()
        }
        rate.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Play_Store_Url + BuildConfig.APPLICATION_ID))) }

        shareApp.setOnClickListener {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(Intent.EXTRA_TEXT, Play_Store_Url + BuildConfig.APPLICATION_ID)
            sendIntent.type = "text/plain"
            startActivity(sendIntent)
        }

        mail.clickWithDebounce  {
            val intent = Intent(Intent.ACTION_SENDTO)
            val recipients = arrayOf(TEXT_MAIL)
            intent.data = Uri.parse(TEXT_MAIL_TO)
            intent.putExtra(Intent.EXTRA_EMAIL, recipients)
            intent.putExtra(Intent.EXTRA_SUBJECT, TEXT_FEEDBACK + resources.getString(R.string.app_label))
            if (intent.resolveActivity(requireActivity().packageManager) != null) {
                startActivity(Intent.createChooser(intent, TEXT_SENDMAIL))
            } else {
                Log.e("====", "onViewCreated activity null: ", )
            }
        }

        binding.RTheme.setOnClickListener {
            startActivity(Intent((activity as MainActivity), SelectTheme::class.java))
        }
    }

    private fun View.clickWithDebounce(debounceTime: Long = 600L, action: () -> Unit) {
        this.setOnClickListener(object : View.OnClickListener {
            private var lastClickTime: Long = 0

            override fun onClick(v: View) {
                if (SystemClock.elapsedRealtime() - lastClickTime < debounceTime) return
                else action()

                lastClickTime = SystemClock.elapsedRealtime()
            }
        })
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    private fun init(view: View) {
        preferences = requireActivity().getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        editor = preferences.edit()
        radioGroup = view.findViewById(R.id.radio_group)
        switchSound = view.findViewById(R.id.sw_sound)
        switchVibration = view.findViewById(R.id.sw_vibration)
        rate = view.findViewById(R.id.R_rate)
        shareApp = view.findViewById(R.id.R_share)
        mail = view.findViewById(R.id.R_about)
        suggestionText = view.findViewById(R.id.suggetion)
        version = view.findViewById(R.id.version_name)
        roundOffText = view.findViewById(R.id.round_off_text)
        soundText = view.findViewById(R.id.sound_text)
        vibrationText = view.findViewById(R.id.vibration_text)
        shareText = view.findViewById(R.id.share_text)
        rateText = view.findViewById(R.id.rate_text)
        roundText = view.findViewById(R.id.round_text)
        themeText = view.findViewById(R.id.theme_text)
        languageText = view.findViewById(R.id.language_text)
        versionText = view.findViewById(R.id.version_text)
        seekbar = view.findViewById(R.id.seekbar)

        seekbar.progress = Integer.parseInt(preferences.getString("is_round", "0")!!)
        roundOffText.text = preferences.getString("is_round", "0")

        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                try {
                    setRoundoff(progress)
                    editor.putString("is_round", progress.toString())
                    editor.apply()
                } catch (e: StackOverflowError) {
                    e.printStackTrace()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {

            }
        })

    }

    internal fun setRoundoff(i: Int) {
        when (i) {
            0 -> {
                seekbar.progress = i
                roundOffText.text = "0"
            }
            1 -> {
                seekbar.progress = i
                roundOffText.text = "0.0"
            }
            2 -> {
                seekbar.progress = i
                roundOffText.text = "0.00"
            }
            3 -> {
                seekbar.progress = i
                roundOffText.text = "0.000"
            }
            4 -> {
                seekbar.progress = i
                roundOffText.text = "0.0000"
            }
            5 -> {
                seekbar.progress = i
                roundOffText.text = "0.00000"
            }
        }

    }

    internal fun setLangauage(i: Int) {

        when (i) {

            R.id.round_off -> {
                context = LocaleHelper.setLocale(requireActivity(), "en")
                resources1 = requireContext().resources
                setEngLang()
            }
            R.id.round1 -> {
                context = LocaleHelper.setLocale(requireActivity(), "hi")
                resources1 = requireContext().resources
                setHindiLang()
            }
            R.id.round2 -> {
                context = LocaleHelper.setLocale(requireActivity(), "gu")
                resources1 = requireContext().resources
                setGujLang()
            }
        }


    }

    internal fun setEngLang() {
        soundText.text = resources1?.getString(R.string.English_title_sound)
        vibrationText.text = resources1?.getString(R.string.English_title_vibration)
        languageText.text = resources1?.getString(R.string.English_title_language)
        roundText.text = resources1?.getString(R.string.English_title_round)
        themeText.text = resources1?.getString(R.string.English_title_theme)
        rateText.text = resources1?.getString(R.string.English_title_rate)
        shareText.text = resources1?.getString(R.string.English_title_share)
        suggestionText.text = resources1?.getString(R.string.English_title_suggestion)
        versionText.text = resources1?.getString(R.string.English_title_version)

    }

    internal fun setHindiLang() {
        soundText.text = resources1?.getString(R.string.Hindi_title_sound)
        vibrationText.text = resources1?.getString(R.string.Hindi_title_vibration)
        languageText.text = resources1?.getString(R.string.Hindi_title_language)
        roundText.text = resources1?.getString(R.string.Hindi_title_round)
        themeText.text = resources1?.getString(R.string.Hindi_title_theme)
        rateText.text = resources1?.getString(R.string.Hindi_title_rate)
        shareText.text = resources1?.getString(R.string.Hindi_title_share)
        suggestionText.text = resources1?.getString(R.string.Hindi_title_suggestion)
        versionText.text = resources1?.getString(R.string.Hindi_title_version)
    }

    internal fun setGujLang() {
        soundText.text = resources1?.getString(R.string.Gujarati_title_sound)
        vibrationText.text = resources1?.getString(R.string.Gujarati_title_vibration)
        languageText.text = resources1?.getString(R.string.Gujarati_title_language)
        roundText.text = resources1?.getString(R.string.Gujarati_title_round)
        themeText.text = resources1?.getString(R.string.Gujarati_title_theme)
        rateText.text = resources1?.getString(R.string.Gujarati_title_rate)
        shareText.text = resources1?.getString(R.string.Gujarati_title_share)
        suggestionText.text = resources1?.getString(R.string.Gujarati_title_suggestion)
        versionText.text = resources1?.getString(R.string.Gujarati_title_version)
    }
}
