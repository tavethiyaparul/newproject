package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;
@Keep
public class Unit implements Serializable {
    @SerializedName("unit_icon")
    private String unit_icon;

    @SerializedName("UnitList")
    private List<UnitList> UnitList;

    @SerializedName("unit_code")
    private String unit_code;

    @SerializedName("unit_title")
    private String unit_title;

    public String getUnit_icon() {
        return unit_icon;
    }

    public void setUnit_icon(String unit_icon) {
        this.unit_icon = unit_icon;
    }

    public List<com.citizencalc.gstcalculator.model.UnitList> getUnitList() {
        return UnitList;
    }

    public void setUnitList(List<com.citizencalc.gstcalculator.model.UnitList> unitList) {
        UnitList = unitList;
    }

    public String getUnit_code() {
        return unit_code;
    }

    public void setUnit_code(String unit_code) {
        this.unit_code = unit_code;
    }

    public String getUnit_title() {
        return unit_title;
    }

    public void setUnit_title(String unit_title) {
        this.unit_title = unit_title;
    }


}