package com.citizencalc.gstcalculator.activity

import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.citizencalc.gstcalculator.R
import com.revenuecat.purchases.CustomerInfo

abstract class RootClass : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedPref: SharedPreferences = getSharedPreferences("AppPref", Context.MODE_PRIVATE)
        setAppTheme(sharedPref.getInt("Theme", 0))
    }

    fun mNoInternetDialog() {
        val dialog = Dialog(this@RootClass)
        dialog.setContentView(R.layout.dialog_nointernet)
        dialog.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)

        dialog.findViewById<View>(R.id.btn_yes).setOnClickListener {
            if (this@RootClass != null) {
                dialog.dismiss()
                finishAffinity()
            }
        }

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)

        if (!isFinishing) {
            dialog.show()
        }

    }


    private fun setAppTheme(currentTheme: Int) {
        when (currentTheme) {
            0 -> setTheme(R.style.AppTheme_Theme_Default)
            1 -> setTheme(R.style.AppTheme_Theme_one)
            2 -> setTheme(R.style.AppTheme_Theme_two)
            3 -> setTheme(R.style.AppTheme_Theme_three)
            4 -> setTheme(R.style.AppTheme_Theme_four)
            5 -> setTheme(R.style.AppTheme_Theme_five)
            6 -> setTheme(R.style.AppTheme_Theme_six)
        }
    }
}