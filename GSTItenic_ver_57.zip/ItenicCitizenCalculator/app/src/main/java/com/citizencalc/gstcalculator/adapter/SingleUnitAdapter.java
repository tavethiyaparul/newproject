package com.citizencalc.gstcalculator.adapter;

import android.app.Activity;
import android.content.SharedPreferences;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.citizencalc.gstcalculator.Classes.common.AppUtility;
import com.citizencalc.gstcalculator.R;
import com.citizencalc.gstcalculator.holder.SingleUnitHolder;
import com.citizencalc.gstcalculator.model.UnitList;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Locale;
import static android.content.Context.MODE_PRIVATE;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.General;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.Last_Unit_Tag;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.Scitific;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.Thousands;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.setRoundOff;
import static com.citizencalc.gstcalculator.Classes.common.AppUtility.setThousandRoundOff;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Area;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Energy;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Fuel;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.GetConversation;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Length;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Presure;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Speed;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Storage;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Tempreture;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Time;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Volume;
import static com.citizencalc.gstcalculator.Classes.common.UnitTag.Weight;

public class SingleUnitAdapter extends RecyclerView.Adapter<SingleUnitHolder> {

    Activity activity;
    String[] str;
    ArrayList<UnitList> unitLists;
    SharedPreferences Last_Unit;
    
    public SingleUnitAdapter(Activity activity, String[] str, ArrayList<UnitList> unitLists) {
        this.activity = activity;
        this.str = str;
        this.unitLists = unitLists;
    }

    @NonNull
    @Override
    public SingleUnitHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        Last_Unit = activity.getSharedPreferences(Last_Unit_Tag, MODE_PRIVATE);
        view = layoutInflater.inflate(R.layout.list_row_single_item, null);

        return new SingleUnitHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SingleUnitHolder holder, int position) {
        
        if (!str[3].equals(unitLists.get(position).getUnit_name()) && str[4].equals(unitLists.get(position).getUnit_name()))
            holder.fornt_view.setVisibility(View.GONE);
        
        if (str[3].equals(unitLists.get(position).getUnit_name()) && !str[4].equals(unitLists.get(position).getUnit_name()))
            holder.fornt_view.setVisibility(View.GONE);

        setBackground(holder.single_unit_icon_bg, str[2]);
        Glide.with(activity.getApplicationContext())
                .load(Uri.parse("file:///android_asset/unit_icon/" + unitLists.get(position).getSmall_icon()))
                .into(holder.single_unit_image);
        String s = str[0] + "-" + unitLists.get(position).getUnit_keyword();
        holder.single_unit_name.setText(unitLists.get(position).getUnit_name());
      //  holder.single_unit_answer.setText(String.format(setRoundOff(Integer.parseInt(Last_Unit.getString("unit_round", "4"))), Double.valueOf(GetConversation(s, str[1], str[2]))));
        holder.single_unit_answer.setText(setNumberFormat(s,str[1],str[2]));
        holder.single_unit_code.setText(unitLists.get(position).getUnit_keyword());
    }

    @Override
    public int getItemCount() {
        return unitLists.size();
    }

    void setBackground(View v, String s) {
        switch (s) {
            case Area ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_orange));
            case Length ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_deep_purple));
            case Weight ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_teal));
            case Time ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_amber));
            case Tempreture ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_blue_grey));
            case Speed ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_yellow));
            case Volume ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_cyne));
            case Energy ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_lime));
            case Fuel ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_brown));
            case Presure ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_indigo));
            default ->
                    v.setBackground(ContextCompat.getDrawable(activity, R.drawable.search_icon_bg_green));
        }
    }

    String setNumberFormat(String... str) {
        try {
            switch (Last_Unit.getString(AppUtility.NumberFormat, General)) {
                case Thousands -> {
                    StringBuilder sb = new StringBuilder();
                    Formatter formatter = new Formatter(sb, Locale.US);
                    return formatter.format(" %(," + setThousandRoundOff(Integer.parseInt(Last_Unit.getString("unit_round", "4"))), Double.valueOf(GetConversation(str[0], str[1], str[2]))).toString();
                }
                case Scitific -> {
                    return String.valueOf(Double.valueOf(GetConversation(str[0], str[1], str[2])));
                }
                default -> {
                    return String.format(setRoundOff(Integer.parseInt(Last_Unit.getString("unit_round", "4"))), Double.valueOf(GetConversation(str[0], str[1], str[2])));
                }
            }
        } catch (NumberFormatException | NullPointerException e) {
            e.printStackTrace();
            return str[1];
        } catch (Exception e) {
            e.printStackTrace();
            return str[1];
        }
    }
}