package com.citizencalc.gstcalculator.activity

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.WindowManager
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.model.UnitData
import com.citizencalc.gstcalculator.model.UnitList
import com.google.gson.Gson

import java.util.ArrayList

import com.citizencalc.gstcalculator.Classes.common.AppUtility.loadJSONFromAsset
import com.citizencalc.gstcalculator.adapter.SearchAdapter

class SearchActivty : AppCompatActivity() {

    lateinit var edtSearch: EditText
    lateinit var searchAdapter: SearchAdapter
    lateinit var recyclerView: RecyclerView
    lateinit var layoutManager: LinearLayoutManager
    lateinit var unitData: UnitData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.layout_search_acticity)


        val gson = Gson()
        unitData = gson.fromJson(loadJSONFromAsset(this@SearchActivty), UnitData::class.java)

        val unitLists = ArrayList<UnitList>()
        unitLists.clear()


        for (i in 0 until unitData.unit.size) {
            for (j in 0 until unitData.unit[i].unitList.size) {
                val model = UnitList()
                model.unit_name = unitData.unit[i].unitList[j].unit_name
                model.unit_keyword = unitData.unit[i].unitList[j].unit_keyword
                model.unit_parent = unitData.unit[i].unitList[j].unit_parent
                model.small_icon = unitData.unit[i].unit_icon
                model.poition = i
                unitLists.add(model)
            }
        }

        val toolbar = findViewById<Toolbar>(R.id.toolbar_setting)
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayShowCustomEnabled(true)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        val inflator = LayoutInflater.from(this)
        val v = inflator.inflate(R.layout.search_custom_actionbar, null)
        edtSearch = v.findViewById(R.id.edt_search)
        supportActionBar!!.customView = v
        recyclerView = findViewById(R.id.search_recyclview)
        layoutManager = LinearLayoutManager(this@SearchActivty)
        recyclerView.layoutManager = layoutManager
        searchAdapter = SearchAdapter(this@SearchActivty, unitLists)
        recyclerView.adapter = searchAdapter
        edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s.isNotEmpty())
                    searchAdapter.filter.filter(s)
            }
            override fun afterTextChanged(s: Editable) {

            }
        })

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {

            android.R.id.home -> {
                finish()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }

    }
}
