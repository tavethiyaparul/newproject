package com.citizencalc.gstcalculator.activity

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.citizencalc.gstcalculator.Classes.common.AppUtility
import com.citizencalc.gstcalculator.Classes.common.ChangeUnit
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.model.UnitData
import com.citizencalc.gstcalculator.model.UnitList
import com.google.gson.Gson

import java.util.ArrayList
import java.util.Formatter
import java.util.Locale

import com.citizencalc.gstcalculator.Classes.common.AppUtility.General
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Last_Unit_Tag
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Scitific
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Thousands
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_From
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_From_Code
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_From_Value
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_Parent
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_Postion
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_Title
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_To
import com.citizencalc.gstcalculator.Classes.common.AppUtility.Unit_To_Code
import com.citizencalc.gstcalculator.Classes.common.AppUtility.loadJSONFromAsset
import com.citizencalc.gstcalculator.Classes.common.AppUtility.setRoundOff
import com.citizencalc.gstcalculator.Classes.common.AppUtility.setThousandRoundOff
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Area
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Energy
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Fuel
import com.citizencalc.gstcalculator.Classes.common.UnitTag.GetConversation
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Length
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Presure
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Speed
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Storage
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Tempreture
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Time
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Volume
import com.citizencalc.gstcalculator.Classes.common.UnitTag.Weight
import com.citizencalc.gstcalculator.adapter.SingleUnitAdapter
import com.citizencalc.gstcalculator.databinding.ListrowitemBinding

class UnitCalculatorActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var ActionBarTitle: TextView
    private lateinit var dialog: Dialog
    private lateinit var dilog_adapter: DialogAdapter
    private lateinit var unitData: UnitData
    private lateinit var from_unit: RelativeLayout
    private lateinit var to_unit: RelativeLayout
    private lateinit var to_txt: TextView
    private lateinit var from_txt: TextView
    private lateinit var from_ucode: TextView
    private lateinit var to_ucode: TextView
    private lateinit var from_edit: EditText
    private lateinit var to_edit: EditText
    private lateinit var switch_image: ImageView
    private var switch_from_txt = ""
    private var switch_to_txt = ""
    private var switch_from_ucode = ""
    private var switch_to_ucode = ""
    private lateinit var rotate: Animation
    private lateinit var first_layout: LinearLayout
    private lateinit var single_unit_recycleview: RecyclerView
    private lateinit var singleUnitAdapter: SingleUnitAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var unitLists: ArrayList<UnitList>
    private lateinit var Last_Unit: SharedPreferences
    private lateinit var Last_Unit_Editor: SharedPreferences.Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_unit_calaculator)

        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        unitData = Gson().fromJson(loadJSONFromAsset(this@UnitCalculatorActivity), UnitData::class.java)

        Last_Unit = getSharedPreferences(Last_Unit_Tag, Context.MODE_PRIVATE)
        Last_Unit_Editor = Last_Unit.edit()

        val toolbar = findViewById<Toolbar>(R.id.toolbar_setting)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val inflator = LayoutInflater.from(this)
        val v = inflator.inflate(R.layout.custom_actionbar, null)
        ActionBarTitle = v.findViewById(R.id.action_bar_title)
        v.findViewById<View>(R.id.gift_layout).setOnClickListener(this)
        v.findViewById<View>(R.id.gift_layout).visibility = View.VISIBLE
        v.findViewById<View>(R.id.AdText).visibility = View.GONE
        v.findViewById<View>(R.id.img_app).visibility = View.GONE

        first_layout = findViewById(R.id.first_layout)

        if (intent.getStringExtra(Unit_Title) != "") {
            ActionBarTitle.text = intent.getStringExtra(Unit_Title)
            setActionBarColor(intent.getStringExtra(Unit_Title)!!)
        }

        supportActionBar?.customView = v

        from_unit = findViewById(R.id.from_unit)
        from_unit.setOnClickListener(this)
        to_unit = findViewById(R.id.to_unit)
        to_unit.setOnClickListener(this)
        to_txt = findViewById(R.id.to_txt)
        from_txt = findViewById(R.id.from_txt)
        from_ucode = findViewById(R.id.from_ucode)
        to_ucode = findViewById(R.id.to_ucode)
        from_edit = findViewById(R.id.from_edit)
        to_edit = findViewById(R.id.to_edit)
        switch_image = findViewById(R.id.switch_image)
        switch_image.setOnClickListener(this)
        rotate = RotateAnimation(0f, 180f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
        rotate.duration = 200

        if (intent.getStringExtra(Unit_Title) != "")
            ActionBarTitle.text = intent.getStringExtra(Unit_Title)


        from_txt.text = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[0].unit_name
        from_ucode.text = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[0].unit_keyword
        to_txt.text = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[1].unit_name
        to_ucode.text = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[1].unit_keyword

        single_unit_recycleview = findViewById(R.id.single_unit_recycleview)
        layoutManager = LinearLayoutManager(this@UnitCalculatorActivity)
        single_unit_recycleview.layoutManager = layoutManager

        for (i in 0 until unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList.size) {
            val s = from_ucode.text.toString() + "-" + unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[i].unit_keyword
        }

        from_edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s.length > 0)
                    converstetion()
            }

            override fun afterTextChanged(s: Editable) {

            }
        })

        if (from_edit.text.toString().isNotEmpty())
            converstetion()


    }


    internal fun converstetion() {

        try {
            val s = from_ucode.text.toString() + "-" + to_ucode.text.toString()
            from_edit.setSelection(from_edit.text.toString().length)
            to_edit.setText(setNumberFormat(s, ActionBarTitle.text.toString()))

            val str = arrayOf(from_ucode.text.toString(), from_edit.text.toString(), ActionBarTitle.text.toString(), from_txt.text.toString(), to_txt.text.toString())

            unitLists = ArrayList()
            unitLists.clear()


            for (j in 0 until unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList.size) {
                val model = UnitList()
                model.unit_name = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[j].unit_name
                model.unit_keyword = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[j].unit_keyword
                model.unit_parent = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList[j].unit_parent
                model.small_icon = unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unit_icon
                model.poition = intent.getIntExtra(Unit_Postion, 0)
                unitLists.add(model)
            }
            // }
            setLast_Unit()
            singleUnitAdapter = SingleUnitAdapter(this@UnitCalculatorActivity, str, unitLists)
            single_unit_recycleview.adapter = singleUnitAdapter
        } catch (e: NumberFormatException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: ArrayIndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    internal fun setLast_Unit() {
        Last_Unit_Editor.putString(Unit_Parent, ActionBarTitle.text.toString())
        Last_Unit_Editor.putString(Unit_From, from_txt.text.toString())
        Last_Unit_Editor.putString(Unit_To, to_txt.text.toString())
        Last_Unit_Editor.putString(Unit_From_Value, from_edit.text.toString())
        Last_Unit_Editor.putString(Unit_From_Code, from_ucode.text.toString())
        Last_Unit_Editor.putString(Unit_To_Code, to_ucode.text.toString())
        Last_Unit_Editor.apply()
    }


    internal fun setActionBarColor(s: String) {

        when (s) {
            Area -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.deep_orange)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.deep_orange))
            }
            Length -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.purple)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.purple))
            }
            Weight -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.teal)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.teal))
            }
            Time -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.amber)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.amber))
            }
            Tempreture -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.blue_grey)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.blue_grey))
            }
            Speed -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.yellow)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.yellow))
            }
            Volume -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.cyne)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.cyne))
            }
            Energy -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.lime)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.lime))
            }
            Fuel -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.brown)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.brown))
            }
            Presure -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.indigo)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.indigo))
            }
            Storage -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.green)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.green))
            }
            else -> {
                supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, R.color.green)))
                first_layout.background = ColorDrawable(ContextCompat.getColor(this, R.color.green))
            }
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.unit_menu, menu)
        val item = menu.findItem(R.id.action_search)
        item.isVisible = false
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                hideSoftKeyboard(from_edit)
                finish()
                true
            }

            R.id.action_unit_settings -> {
                startActivity(Intent(this@UnitCalculatorActivity, SettingsActivity::class.java))
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun OpenUnitList(vararg textViews: TextView) {
        dialog = Dialog(this@UnitCalculatorActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.country_list_view_dialog)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        dialog.setCanceledOnTouchOutside(true)
        dialog.setCancelable(true)
        val dialog_recycle: RecyclerView
        val layoutManager: RecyclerView.LayoutManager
        val search: EditText

        dialog_recycle = dialog.findViewById(R.id.country_list)
        search = dialog.findViewById(R.id.search)


        layoutManager = LinearLayoutManager(this@UnitCalculatorActivity)
        dialog_recycle.layoutManager = layoutManager

        dilog_adapter = DialogAdapter(unitData.unit[intent.getIntExtra(Unit_Postion, 0)].unitList, this@UnitCalculatorActivity) { str ->
            textViews[0].text = str[0]
            textViews[1].text = str[1]
            converstetion()
            dialog.dismiss()
        }
        dialog_recycle.adapter = dilog_adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s != "") dilog_adapter.filter.filter(s)
            }

            override fun afterTextChanged(s: Editable) {

            }
        })

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.from_unit -> OpenUnitList(from_txt, from_ucode)
            R.id.to_unit -> OpenUnitList(to_txt, to_ucode)
            R.id.switch_image -> switchUnit()
            R.id.gift_layout -> startActivity(Intent(this@UnitCalculatorActivity, SearchActivty::class.java))
        }
    }

    private fun switchUnit() {
        switch_from_txt = from_txt.text.toString()
        switch_to_txt = to_txt.text.toString()
        switch_from_ucode = from_ucode.text.toString()
        switch_to_ucode = to_ucode.text.toString()
        switch_image.startAnimation(rotate)
        rotate.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(animation: Animation) {

            }

            override fun onAnimationEnd(animation: Animation) {
                from_txt.text = switch_to_txt
                to_txt.text = switch_from_txt
                from_ucode.text = switch_to_ucode
                to_ucode.text = switch_from_ucode
                converstetion()
            }

            override fun onAnimationRepeat(animation: Animation) {

            }
        })
    }

    inner class DialogAdapter(internal var datalist: List<UnitList>, internal var context: Context, private var changeUnit: ChangeUnit) : RecyclerView.Adapter<DialogAdapter.DilogViewHolder>(), Filterable {

        private var namelist: List<UnitList> = datalist
        private var filter: CustomFilter? = null

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DilogViewHolder {
            val binding = ListrowitemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return DilogViewHolder(binding)
        }

        override fun onBindViewHolder(holder: DilogViewHolder, position: Int) {
             with(holder) {
                 with(datalist[position]) {
                     binding.countryName.text = datalist[position].unit_name
                     binding.unitCode.text = "[ ${datalist[position].unit_keyword} ]"
                     binding.countryItem.setOnClickListener { changeUnit.SetUnitValues(*arrayOf(datalist[position].unit_name, datalist[position].unit_keyword)) }
                 }
             }
        }

        override fun getItemCount(): Int {
            return datalist.size
        }

        override fun getFilter(): Filter {
            if (filter == null) {
                filter = CustomFilter(this, namelist)
            }
            return filter as CustomFilter
        }

        inner class DilogViewHolder(val binding: ListrowitemBinding) : RecyclerView.ViewHolder(binding.root)
    }

    inner class CustomFilter(private var dailogAdapter: DialogAdapter, private var namelist: List<UnitList>) : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val results = FilterResults()

            if (!constraint.isNullOrEmpty()) {
                val constraint1 = constraint.toString().uppercase(Locale.getDefault())
                val filteredPlayers = ArrayList<UnitList>()

                for (i in namelist.indices) {
                    if (namelist[i].unit_name.uppercase(Locale.getDefault()).contains(constraint1) || namelist[i].unit_keyword.uppercase(Locale.getDefault()).contains(constraint1)) {
                        filteredPlayers.add(namelist[i])
                    }
                }

                results.count = filteredPlayers.size
                results.values = filteredPlayers
            } else {
                results.count = namelist.size
                results.values = namelist
            }
            return results
        }

        override fun publishResults(constraint: CharSequence, results: FilterResults) {
            dailogAdapter.datalist = results.values as List<UnitList>
            dailogAdapter.notifyDataSetChanged()
        }
    }

    private fun setNumberFormat(vararg str: String): String {
        try {
            return when (Last_Unit.getString(AppUtility.NumberFormat, General)) {
                General -> String.format(setRoundOff(Integer.parseInt(Last_Unit.getString("unit_round", "4")!!)), java.lang.Double.valueOf(GetConversation(str[0], from_edit.text.toString(), str[1])))
                Thousands -> {
                    val sb = StringBuilder()
                    val formatter = Formatter(sb, Locale.US)
                    formatter.format(" %(," + setThousandRoundOff(Integer.parseInt(Last_Unit.getString("unit_round", "4")!!)), java.lang.Double.valueOf(GetConversation(str[0], from_edit.text.toString(), str[1]))).toString()
                }
                Scitific -> java.lang.Double.valueOf(GetConversation(str[0], from_edit.text.toString(), str[1])).toString()
                else -> String.format(setRoundOff(Integer.parseInt(Last_Unit.getString("unit_round", "4")!!)), java.lang.Double.valueOf(GetConversation(str[0], from_edit.text.toString(), str[1])))
            }
        } catch (e: NumberFormatException) {
            e.printStackTrace()
            return from_edit.text.toString()
        } catch (e: NullPointerException) {
            e.printStackTrace()
            return from_edit.text.toString()
        } catch (e: Exception) {
            e.printStackTrace()
            return from_edit.text.toString()
        }
    }

    private fun hideSoftKeyboard(view: View?) {
        if (view == null) return
        var mFocusView = view

        val context = view.context
        if (context != null && context is Activity) {
            mFocusView = context.currentFocus
        }
        if (mFocusView == null) {
            return
        }
        mFocusView.clearFocus()
        val manager = mFocusView.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.hideSoftInputFromWindow(mFocusView.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }
}