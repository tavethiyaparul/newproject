package com.citizencalc.gstcalculator.CustomAd.sync;

import android.content.Context;
import android.os.AsyncTask;

import com.citizencalc.gstcalculator.CustomAd.callback.DownloadedWebPage;
import com.citizencalc.gstcalculator.CustomAd.model.PageSaver;

import java.io.File;

import static android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY;

import static com.citizencalc.gstcalculator.CustomAd.CustomAdsUtil.ASSERT_LOCATION;


public class DownloadingWebPage extends AsyncTask<String, Integer, Boolean> {
    private PageSaver pageSaver;
    private String destinationDirectory;
    private Context context;
    private DownloadedWebPage interstitialCustom;
    private String url;

    public DownloadingWebPage(Context context, DownloadedWebPage interstitialCustom) {
        this.context = context;
        this.interstitialCustom = interstitialCustom;
        pageSaver = new PageSaver();
        File mLocationDir = null;
        String sdCard = context.getFilesDir().toString();
        mLocationDir = new File(sdCard, ASSERT_LOCATION);
        if (!mLocationDir.exists()) {
            mLocationDir.mkdir();
        }
        destinationDirectory = mLocationDir.toString();
    }

    @Override
    protected Boolean doInBackground(String... strings) {
        android.os.Process.setThreadPriority(THREAD_PRIORITY_URGENT_DISPLAY);
        boolean success = pageSaver.getPage(strings[0], destinationDirectory, strings[0].substring(strings[0].lastIndexOf('/') + 1));
        return success;
    }

    @Override
    protected void onPostExecute(Boolean aBoolean) {
        super.onPostExecute(aBoolean);
        if (aBoolean) {
            //Log.e("onSuccess","**************************************************************");
            interstitialCustom.onSuccess();
        } else {
            interstitialCustom.onFailed();
            //Log.e("onFailed","**************************************************************");
        }
    }
}
