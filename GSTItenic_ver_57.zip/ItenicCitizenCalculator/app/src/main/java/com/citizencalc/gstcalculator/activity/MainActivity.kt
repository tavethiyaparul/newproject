package com.citizencalc.gstcalculator.activity

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.android.billingclient.api.*
import com.bumptech.glide.Glide
import com.citizencalc.gstcalculator.*
import com.citizencalc.gstcalculator.Classes.common.AppUtility.*
import com.citizencalc.gstcalculator.Classes.common.CUSTOM
import com.citizencalc.gstcalculator.Classes.common.Custom_Ad_Path
import com.citizencalc.gstcalculator.Classes.common.GAME_PAGE_URL
import com.citizencalc.gstcalculator.Classes.common.Game_On
import com.citizencalc.gstcalculator.Classes.common.PRO_DIALOG_DAYS
import com.citizencalc.gstcalculator.Classes.common.TIME_STAMP_ID_PURCHASE_DIALOG
import com.citizencalc.gstcalculator.Classes.common.premium_On
import com.citizencalc.gstcalculator.CustomAd.CustomAdsUtil.isNetworkConnected
import com.citizencalc.gstcalculator.CustomAd.ui.AdsInit
import com.citizencalc.gstcalculator.RoomDb.Companion.roomOrderDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbAdsNameDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbSkuDao
import com.citizencalc.gstcalculator.adapter.SubscriptionAdapter
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.database.table.CaAds
import com.citizencalc.gstcalculator.databinding.ActivityMainBinding
import com.citizencalc.gstcalculator.databinding.CustomActionbarBinding
import com.citizencalc.gstcalculator.databinding.DialogGiftBinding
import com.citizencalc.gstcalculator.databinding.DialogNowRetryBinding
import com.citizencalc.gstcalculator.databinding.DialogRateUsBinding
import com.citizencalc.gstcalculator.databinding.SubscribeDilogNewBinding
import com.citizencalc.gstcalculator.fragment.*
import com.citizencalc.gstcalculator.model.PaywallTheme
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.navigation.NavigationView
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.google.android.play.core.tasks.Task
import com.google.gson.JsonSyntaxException
import com.revenuecat.purchases.CustomerInfo
import com.revenuecat.purchases.PurchaseParams
import com.revenuecat.purchases.Purchases
import com.revenuecat.purchases.getOfferingsWith
import com.revenuecat.purchases.interfaces.UpdatedCustomerInfoListener
import com.revenuecat.purchases.models.GoogleStoreProduct
import com.revenuecat.purchases.purchaseWith
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.roundToLong
import kotlin.system.exitProcess


class MainActivity : RootClass(), NavigationView.OnNavigationItemSelectedListener,
    UpdatedCustomerInfoListener {

    lateinit var binding: ActivityMainBinding
    lateinit var customActionbarBinding: CustomActionbarBinding
    var exitnative: NativeAd? = null
    var exitAdView: AdView? = null
    var context: Context? = null
    lateinit var preferences: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    lateinit var Update_editor: SharedPreferences.Editor
    lateinit var reviewManager: ReviewManager
    var databaseGst: DatabaseGst? = null
    var fragment: Fragment? = null
    lateinit var dialog_subscribe: Dialog
    var expireSevenDialogs: Dialog? = null
    var subscriptionDetectedDialogs: Dialog? = null
    private var CurrentDate = ""
    private var CurrentDatenew = ""
    private val specialformat = SimpleDateFormat(Date_format)
    lateinit var listener: InstallStateUpdatedListener
    private lateinit var appUpdateManager: AppUpdateManager
    private var myLanStringValue: String? = null
    private var isFirstTime: Boolean = false
    private var prefs: SharedPreferences? = null
    var count = 1
    var handler = Handler(Looper.getMainLooper())
    private var paywallTheme: PaywallTheme? = null
    private var availablePackages: ArrayList<com.revenuecat.purchases.Package> = ArrayList()

    var myMenu: Menu? = null

    private var runnable = object : Runnable {
        override fun run() {
            if (CheackGameUrl()) {
                if (isNetworkAvailable(this@MainActivity) && SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE" && Game_On == 1) {
                    val nav_Menu: Menu = binding.navView.menu
                    nav_Menu.findItem(R.id.nav_Play_game).isVisible = true
                    customActionbarBinding.btnPlaygame.visibility = View.VISIBLE
                }
            } else {
                if (count < 10) {
                    handler.postDelayed(this, 500)
                }
            }
            count++
        }
    }

    fun CheackGameUrl(): Boolean {
        return GAME_PAGE_URL != ""
    }

    //    private lateinit var sharedPreferences: SharedPreferences
    val lastExecutionKey = "last_execution_timestamp"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        if (!isNetworkConnected()) mNoInternetDialog()

//      if (instances == null) instances = RoomDb.getInstance(this)

        preferences = getSharedPreferences("sevenDaysPreferences", Context.MODE_PRIVATE)

        Log.e("TAG_IS_PREMIUM", "isNetworkConnected() ==> " + isNetworkConnected())

        initDatabase()

        preferences = getSharedPreferences(PREF_TAG, Context.MODE_PRIVATE)
        editor = preferences.edit()

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        customActionbarBinding = CustomActionbarBinding.inflate(layoutInflater)
        supportActionBar?.customView = customActionbarBinding.root

        databaseGst = DatabaseGst(this@MainActivity)

        if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
            binding.adLayout.visibility = View.VISIBLE
        } else {
            binding.adLayout.visibility = View.GONE
        }

        GotoFragment(0)
        fragments_settings = 1


        val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)

        val toggle: ActionBarDrawerToggle = object : ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        ) {
            override fun onDrawerOpened(drawerView: View) {
                super.onDrawerOpened(drawerView)
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager

                if (imm.isAcceptingText) {
                    val inputMethodManager =
                        getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                    inputMethodManager.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
                }
            }

            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                super.onDrawerSlide(drawerView, slideOffset)
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                if (imm.isAcceptingText) {
                    imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
                }
            }
        }

        drawer.addDrawerListener(toggle)
        toggle.syncState()

        binding.navView.setNavigationItemSelectedListener(this)
        when (myLanStringValue) {
            "Gujarati" -> {
                binding.first.text = resources.getString(R.string.Gujarati_Thank_You)
                binding.third.text = resources.getString(R.string.Gujarati_Press_Back)
                binding.navView.menu.findItem(R.id.nav_gst_calculator).title =
                    resources.getString(R.string.Gujarati_menu_Gst)
                binding.navView.menu.findItem(R.id.nav_unit_converter).title =
                    resources.getString(R.string.Gujarati_Unit_Converter)
                binding.navView.menu.findItem(R.id.nav_sip_calculator).title =
                    resources.getString(R.string.Gujarati_Sip_Calculator)
                binding.navView.menu.findItem(R.id.nav_compass).title =
                    resources.getString(R.string.Gujarati_Compass)
                binding.navView.menu.findItem(R.id.nav_theme).title =
                    resources.getString(R.string.Gujarati_menu_theme)
                binding.navView.menu.findItem(R.id.nav_Settings).title =
                    resources.getString(R.string.Gujarati_Settings)
                binding.navView.menu.findItem(R.id.nav_AD_Block).title =
                    resources.getString(R.string.Gujarati_menu_premium)
                binding.navView.menu.findItem(R.id.nav_manage_subscript).title =
                    resources.getString(R.string.Gujarati_manage_subscript)
                binding.navView.menu.findItem(R.id.nav_Play_game).title =
                    resources.getString(R.string.Gujarati_menu_game)
                binding.navView.menu.findItem(R.id.nav_Rate).title =
                    resources.getString(R.string.Gujarati_menu_rate)
                binding.navView.menu.findItem(R.id.nav_share).title =
                    resources.getString(R.string.Gujarati_menu_share)
            }

            "Hindi" -> {
                binding.first.text = resources.getString(R.string.Hindi_Thank_You)
                binding.third.text = resources.getString(R.string.Hindi_Press_Back)

                binding.navView.menu.findItem(R.id.nav_gst_calculator).title =
                    resources.getString(R.string.Hindi_menu_Gst)
                binding.navView.menu.findItem(R.id.nav_unit_converter).title =
                    resources.getString(R.string.Hindi_Unit_Converter)
                binding.navView.menu.findItem(R.id.nav_sip_calculator).title =
                    resources.getString(R.string.Hindi_Sip_Calculator)
                binding.navView.menu.findItem(R.id.nav_compass).title =
                    resources.getString(R.string.Hindi_Compass)
                binding.navView.menu.findItem(R.id.nav_theme).title =
                    resources.getString(R.string.Hindi_menu_theme)
                binding.navView.menu.findItem(R.id.nav_Settings).title =
                    resources.getString(R.string.Hindi_Settings)
                binding.navView.menu.findItem(R.id.nav_AD_Block).title =
                    resources.getString(R.string.Hindi_menu_premium)
                binding.navView.menu.findItem(R.id.nav_manage_subscript).title =
                    resources.getString(R.string.Hindi_manage_subscript)
                binding.navView.menu.findItem(R.id.nav_Play_game).title =
                    resources.getString(R.string.Hindi_menu_game)
                binding.navView.menu.findItem(R.id.nav_Rate).title =
                    resources.getString(R.string.Hindi_menu_rate)
                binding.navView.menu.findItem(R.id.nav_share).title =
                    resources.getString(R.string.Hindi_menu_share)
            }

            else -> {
                binding.first.text = resources.getString(R.string.English_Thank_You)
                binding.third.text = resources.getString(R.string.English_Press_Back)

                binding.navView.menu.findItem(R.id.nav_gst_calculator).title =
                    resources.getString(R.string.English_menu_Gst)
                binding.navView.menu.findItem(R.id.nav_unit_converter).title =
                    resources.getString(R.string.English_Unit_Converter)
                binding.navView.menu.findItem(R.id.nav_sip_calculator).title =
                    resources.getString(R.string.English_Sip_Calculator)
                binding.navView.menu.findItem(R.id.nav_compass).title =
                    resources.getString(R.string.English_Compass)
                binding.navView.menu.findItem(R.id.nav_theme).title =
                    resources.getString(R.string.English_menu_theme)
                binding.navView.menu.findItem(R.id.nav_Settings).title =
                    resources.getString(R.string.English_Settings)
                binding.navView.menu.findItem(R.id.nav_AD_Block).title =
                    resources.getString(R.string.English_menu_premium)
                binding.navView.menu.findItem(R.id.nav_manage_subscript).title =
                    resources.getString(R.string.English_manage_subscript)
                binding.navView.menu.findItem(R.id.nav_Play_game).title =
                    resources.getString(R.string.English_menu_game)
                binding.navView.menu.findItem(R.id.nav_Rate).title =
                    resources.getString(R.string.English_menu_rate)
                binding.navView.menu.findItem(R.id.nav_share).title =
                    resources.getString(R.string.English_menu_share)
            }
        }

        Purchases.sharedInstance.updatedCustomerInfoListener = this
        Handler(Looper.getMainLooper()).postDelayed({
            adsInit = AdsInit()
            val date1 = Calendar.getInstance().time
            CurrentDate = specialformat.format(date1)

            val date = Calendar.getInstance().time
            CurrentDate = specialformat.format(date)

            if (CurrentDate == preferences.getString(Rate_After_Five_Day_Date, "26/01/1990")) {
                editor.putBoolean(Rate_After_Five_Day, false).apply()
            }

            if (!preferences.getBoolean(Rate_After_Five_Day, false)) {
                if (preferences.getString(Rate_Date, "26/01/1990") != CurrentDate) {
                    if (!preferences.getBoolean(Rate_Dialog_show, false)) {
                        if (preferences.getBoolean(Rate_First_Time, false)) {
                            mRateUseDialog(false)
                            editor.putBoolean(Rate_First_Time, false)
                            editor.putString(Rate_Date, CurrentDate)
                            editor.apply()
                        } else {
                            editor.putBoolean(Rate_First_Time, true).apply()
                        }
                    }
                }
            }

            if (databaseGst!!.getResponse(IS_ADFREE) == null) {
                val isUpdatestr =
                    if (databaseGst!!.getResponse(IS_ADFREE) == null) "false" else "true"
                databaseGst?.setResponse(IS_ADFREE, "NO", isUpdatestr)
            }

            val sharedPreferences = getSharedPreferences("StoreData", Context.MODE_PRIVATE)
            Update_editor = sharedPreferences.edit()
            @SuppressLint("SimpleDateFormat") val spf = SimpleDateFormat("MM/dd/yyyy")
            val date2 = Calendar.getInstance().time
            CurrentDatenew = spf.format(date2)

            if (CurrentDatenew != sharedPreferences.getString("update", "")) {
                UpdateDialog()
            }

            customActionbarBinding.giftLayout.setOnClickListener { GiftDialog() }
            if (isNetworkAvailable(this@MainActivity) && databaseGst!!.getResponse(IS_ADFREE) != "YES") {
                customActionbarBinding.giftLayout.visibility = View.GONE
                customActionbarBinding.imgApp.setImageDrawable(
                    ContextCompat.getDrawable(
                        this, R.drawable.ic_gift
                    )
                )
                customActionbarBinding.imgApp.visibility = View.VISIBLE
            } else {
                binding.navView.menu.findItem(R.id.nav_AD_Block).isVisible = false
                customActionbarBinding.giftLayout.visibility = View.GONE
                customActionbarBinding.AdText.visibility = View.GONE
            }

            handler.postDelayed(runnable, 1000)
            Log.e("TAG_IS_PREMIUM", "SUBSCRIPTION_STATE: 2 " + SUBSCRIPTION_STATE)
            if (isNetworkAvailable(this@MainActivity) && (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE")) {

                if (premium_On == 0) {
                    binding.navView.menu.findItem(R.id.nav_AD_Block).isVisible = false
                    binding.navView.menu.findItem(R.id.nav_manage_subscript).isVisible = false
                } else {
                    binding.navView.menu.findItem(R.id.nav_AD_Block).isVisible = true
                }

                supportFragmentManager.findFragmentById(R.id.frame_layout)?.let {
                    if (it is GstCalculator) {
                        (fragment as GstCalculator).refreshView1()
                    }
                }

            }

            customActionbarBinding.btnPlaygame.setOnClickListener {
                if (GAME_PAGE_URL != "") {
                    RedirectToPage(this@MainActivity)
                }
            }

            if (tbAdsNameDao.getADS()?.isNotEmpty() == true) {
                if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
                    bannerAdsLoading(
                        gstAdsBuilder(BOTTOM_BANNER_ADS_NAME),
                        binding.googleLayout,
                        BOTTOM_BANNER_ADS_NAME
                    )
                    CoroutineScope(Dispatchers.Main).launch {
                        delay(3000)
                        nativeLoadingOnly(gstAdsBuilder(EXIT_NATIVE_ADS_NAME))
                    }
                } else {
                    binding.adLayout.visibility = View.GONE
                }
            } else {
                val handler = Handler(Looper.getMainLooper())
                val runnable = object : Runnable {
                    override fun run() {

                        if (tbAdsNameDao.getADS()?.isNotEmpty() == true) {
                            if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
                                bannerAdsLoading(
                                    gstAdsBuilder(BOTTOM_BANNER_ADS_NAME),
                                    binding.googleLayout,
                                    BOTTOM_BANNER_ADS_NAME
                                )
                                CoroutineScope(Dispatchers.Main).launch {
                                    delay(3000)
                                    nativeLoadingOnly(gstAdsBuilder(EXIT_NATIVE_ADS_NAME))
                                }
                            }
                        } else {
                            handler.postDelayed(this, 400)
                        }
                    }
                }
                handler.postDelayed(runnable, 400)
            }
        }, 2000)

        reviewManager = ReviewManagerFactory.create(this)

        Log.e("SwitchTag", "onCreate" + premium_On)



        fetchRemoteData {
            versionDataStore {
                try {
                    CoroutineScope(Dispatchers.IO).launch {
                        val sp = getSharedPreferences(PREF_TAG, MODE_PRIVATE)
                        myLanStringValue = sp.getString("is_radio_name", "")
                        isFirstTime = sp.getBoolean("is_first_time", false)
                        if (!isFirstTime) {
                            fetchSku(true)
                            sp.edit().putBoolean("is_first_time", true).apply()
                        } else {
                            fetchSku(false)
                        }

                    }
                } catch (e: java.lang.NullPointerException) {
                    e.printStackTrace()
                }
                jobSKU {
                    installTrackJob {
                        customAdsTags()
                    }
                }
            }

        }

    }

    // Call this method to check and execute the function if 7 days have passed
    fun checkAndExecuteFunction() {
        val currentTimeMillis = System.currentTimeMillis()
        if (currentTimeMillis - TIME_STAMP_ID_PURCHASE_DIALOG >= TimeUnit.DAYS.toMillis(
                PRO_DIALOG_DAYS.toLong()
            )
        ) {
            Subscription_Dilog()
            TIME_STAMP_ID_PURCHASE_DIALOG = currentTimeMillis
        }
    }

    private fun networkError(activity: Activity) {
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val inflater = activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val DialogRetryJbBinding = DialogNowRetryBinding.inflate(inflater)
        dialog.setContentView(DialogRetryJbBinding.root)

        DialogRetryJbBinding.actionRetry.setOnClickListener {
            if (!isNetworkConnected(this@MainActivity)) {
                Toast.makeText(activity, "Please Check Network", Toast.LENGTH_SHORT).show()
            } else {
                dialog.dismiss()
            }
        }

        DialogRetryJbBinding.cancle.setOnClickListener {
            dialog.dismiss()
            activity.finishAffinity()
        }

        val wm = activity.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.show()
    }

    private fun initDatabase() {
        val sku = roomOrderDao.getRoomOrder()
        if (!sku.isNullOrEmpty()) {
            sku.forEach {
                val diff: Long = Calendar.getInstance().timeInMillis - it.purchaseTime
                val dayCount = diff.toFloat() / (24 * 60 * 60 * 1000)
                val days = dayCount.roundToLong()
                val totalDays = it.month

                val myVal = totalDays - 7
                val myVal1 = totalDays - 6
                val myVal2 = totalDays - 5
                val myVal3 = totalDays - 4
                val myVal4 = totalDays - 3
                val myVal5 = totalDays - 2
                val myVal6 = totalDays - 1

                val sharedPref = getSharedPreferences("PREFS_NAME", 0)
                val sdf = SimpleDateFormat("yyyyMMdd")
                val currentDate = sdf.format(Date())
                if (sharedPref.getString("LAST_LAUNCH_DATE", "nodate")!!.contains(currentDate)) {
                    // Date matches. User has already Launched the app once today. So do nothing.
                } else {
                    // Display dialog text here......
                    // Do all other actions for first time launch in the day...
                    if (myVal == days.toInt()) {
                        expireSeven()
                    } else if (myVal1 == days.toInt()) {
                        expireSix()
                    } else if (myVal2 == days.toInt()) {
                        expireFive()
                    } else if (myVal3 == days.toInt()) {
                        expireFour()
                    } else if (myVal4 == days.toInt()) {
                        expireThree()
                    } else if (myVal5 == days.toInt()) {
                        expireTwo()
                    } else if (myVal6 == days.toInt()) {
                        expireOne()
                    }
                    // Set the last Launched date to today.
                    val editor = sharedPref.edit()
                    editor.putString("LAST_LAUNCH_DATE", currentDate)
                    editor.apply()
                }
            }
        }

        getSkuData()
    }

    private fun getSkuData() {
        val handler = Handler(Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                val skuListData = tbSkuDao.getData()
                if (!skuListData.isNullOrEmpty()) {
                    inAppDetail()
                } else {
                    handler.postDelayed(this, 1000)
                }
            }
        }
        handler.postDelayed(runnable, 1000)
    }

    var listDetailsMain: ArrayList<ProductDetails> = ArrayList()

    //todo inapp
    fun inAppDetail() {
        try {
            val skuListData = tbSkuDao.getData()
//            if (!skuListData.isNullOrEmpty())
//                inApp.startConnection(object : BillingClientStateListener {
//                    override fun onBillingSetupFinished(billingResult: BillingResult) {
//
//                        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
//                            // The BillingClient is ready. You can query purchases here.
//                            skuListData.forEach {
//                                val productList = listOf(
//                                    QueryProductDetailsParams.Product.newBuilder()
//                                        .setProductId(it.sku)
//                                        .setProductType(BillingClient.ProductType.SUBS).build()
//                                )
//
//                                val params = QueryProductDetailsParams.newBuilder().setProductList(productList)
//
//                                inApp.queryProductDetailsAsync(params.build()) { billingResult, productDetailsList ->
//                                    if (productDetailsList.isNotEmpty()) {
//                                        listDetailsMain.addAll(productDetailsList)
//                                    }
//                                }
//                            }
//
//                            inApp.queryPurchaseHistoryAsync(
//                                QueryPurchaseHistoryParams.newBuilder()
//                                    .setProductType(BillingClient.ProductType.SUBS).build()
//                            ) { billingResult1, purchaseHistoryRecord ->
//                                if (billingResult1.responseCode == BillingClient.BillingResponseCode.OK) {
//                                    purchaseHistoryRecord?.let { list ->
//                                        if (list.size > 0) {
//                                            list.sortByDescending { it.purchaseTime }
//                                            CoroutineScope(Dispatchers.IO).launch {
//                                                verificationPurchase(
//                                                    JSONObject(list[0].originalJson).getString("productId"),
//                                                    list[0].purchaseToken
//                                                )
//                                            }
//                                        }
//                                    }
//                                }
//                            }
//                            runOnUiThread {
//                                invalidateOptionsMenu()
//                            }
//                        }
//                    }
//
//                    override fun onBillingServiceDisconnected() {
//                    }
//                })
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: ArrayIndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: JsonSyntaxException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

//    suspend fun verificationPurchase(sku: String, token: String) {
//        val api = getAPIService(NodeConnection.replace("api/", ""))
//        if (api != null) {
//            val call = api.getVerificationData(
//                packageName = BuildConfig.APPLICATION_ID,
//                sku = sku,
//                token = token
//            )
//            try {
//                val jsonObject = JSONObject(call.body().toString())
//                val code = jsonObject.getInt("code")
//                try {
//                    if (jsonObject.has("data")) {
//                        val jsonObject1 = jsonObject.getJSONObject("data")
//                        if (jsonObject1.has("subscriptionState")) {
//                            if (SUBSCRIPTION_STATE != jsonObject1.get("subscriptionState")
//                                    .toString()
//                            ) {
//                                if (jsonObject1.get("subscriptionState")
//                                        .toString() == "SUBSCRIPTION_STATE_ACTIVE"
//                                ) {
//                                    CoroutineScope(Dispatchers.Main).launch {
//                                        binding.navView.menu.findItem(R.id.nav_Play_game).isVisible =
//                                            false
//                                        binding.navView.menu.findItem(R.id.nav_AD_Block).isVisible =
//                                            false
//                                        customActionbarBinding.btnPlaygame.visibility = View.GONE
//                                        binding.adLayout.visibility = View.GONE
////                                    menuMain?.getItem(0)?.isVisible = false
//                                        supportFragmentManager.findFragmentById(R.id.frame_layout)
//                                            ?.let {
//                                                if (it is GstCalculator) {
//                                                    (fragment as GstCalculator).refreshView()
//                                                }
//                                            }
//                                        subscriptionDetect()
//                                    }
//                                }
//                            }
//                            SUBSCRIPTION_STATE = jsonObject1.get("subscriptionState").toString()
//                        }
//                    }
//                } catch (_: JsonSyntaxException) {
//                } catch (_: Exception) {
//                }
//            } catch (e: JSONException) {
//                Log.e("verificationPurchase", "JSONException: ${e.localizedMessage}")
//            }
//        }
//    }


    private fun restoreCompleted() {
        val dialog = Dialog(this)
        dialog.window?.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_restore_completed)
        dialog.findViewById<AppCompatButton>(R.id.layClose).setOnClickListener { dialog.dismiss() }
        dialog.findViewById<AppCompatButton>(R.id.layRestart)
            .setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun subscriptionDetect() {
        subscriptionDetectedDialogs = Dialog(this)
        subscriptionDetectedDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        subscriptionDetectedDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        subscriptionDetectedDialogs?.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        subscriptionDetectedDialogs?.setCanceledOnTouchOutside(false)
        subscriptionDetectedDialogs?.setCancelable(false)
        subscriptionDetectedDialogs?.setContentView(R.layout.dialog_subscription_detected)

        val layClose = subscriptionDetectedDialogs?.findViewById<AppCompatButton>(R.id.layClose)
        val layRestart = subscriptionDetectedDialogs?.findViewById<AppCompatButton>(R.id.layRestart)

        layRestart?.setOnClickListener {
//            val editor: SharedPreferences.Editor = prefs!!.edit()
//            editor.putBoolean("FirstTime", true)
//            editor.apply()

//            val intent = Intent(this, SplashActivity::class.java)
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//            startActivity(intent)
//            finish()
//            Runtime.getRuntime().exit(0)

            subscriptionDetectedDialogs?.dismiss()
        }

        layClose?.setOnClickListener {
            subscriptionDetectedDialogs?.dismiss()
        }


        if (!isFinishing) {
            subscriptionDetectedDialogs?.show()
        }
    }

    fun expireSeven() {
        expireSevenDialogs = Dialog(this)
        expireSevenDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        val win = expireSevenDialogs!!.window
        win?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs?.setCanceledOnTouchOutside(false)
        expireSevenDialogs?.setCancelable(false)
        expireSevenDialogs?.setContentView(R.layout.dialog_expire_seven)

        expireSevenDialogs?.findViewById<AppCompatButton>(R.id.layClose)?.setOnClickListener {
            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireSix() {
        expireSevenDialogs = Dialog(this)
        expireSevenDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        expireSevenDialogs?.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs?.setCanceledOnTouchOutside(false)
        expireSevenDialogs?.setCancelable(false)
        expireSevenDialogs?.setContentView(R.layout.dialog_expire_seven)

        expireSevenDialogs?.findViewById<AppCompatTextView>(R.id.txtDesc)?.text =
            getString(R.string.expire_desc_6)

        expireSevenDialogs?.findViewById<AppCompatButton>(R.id.layClose)?.setOnClickListener {
            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireFive() {
        expireSevenDialogs = Dialog(this)
        expireSevenDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        expireSevenDialogs?.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs?.setCanceledOnTouchOutside(false)
        expireSevenDialogs?.setCancelable(false)
        expireSevenDialogs?.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_5)

        layClose.setOnClickListener {
            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireFour() {
        expireSevenDialogs = Dialog(this)
        expireSevenDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        expireSevenDialogs?.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs?.setCanceledOnTouchOutside(false)
        expireSevenDialogs?.setCancelable(false)
        expireSevenDialogs?.setContentView(R.layout.dialog_expire_seven)

        expireSevenDialogs?.findViewById<AppCompatTextView>(R.id.txtDesc)?.text =
            getString(R.string.expire_desc_4)
        expireSevenDialogs?.findViewById<AppCompatButton>(R.id.layClose)?.setOnClickListener {
            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireThree() {
        expireSevenDialogs = Dialog(this)
        expireSevenDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        val win = expireSevenDialogs!!.window
        win?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_3)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireTwo() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        val win = expireSevenDialogs!!.window
        win?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_2)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireOne() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs?.window?.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs?.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        val win = expireSevenDialogs!!.window
        win?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs?.setCanceledOnTouchOutside(false)
        expireSevenDialogs?.setCancelable(false)
        expireSevenDialogs?.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_1)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun inAppRateApp() {
        val request: Task<ReviewInfo> = reviewManager.requestReviewFlow()
        request.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val reviewInfo: ReviewInfo = task.result
                val flow: Task<Void> = reviewManager.launchReviewFlow(this, reviewInfo)
                flow.addOnSuccessListener {
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)
                        )
                    )
                }
                flow.addOnFailureListener {
                    Toast.makeText(this@MainActivity, "${it.message}", Toast.LENGTH_LONG).show()
                }
                flow.addOnCompleteListener {

                }

            } else {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)
                    )
                )
            }
        }
    }

    private var doubleBackToExitPressedOnce = false

    private fun showExitDialog() {
        val bottomSheetDialog = BottomSheetDialog(this@MainActivity)
        bottomSheetDialog.setCanceledOnTouchOutside(true)
        val parentView: View =
            LayoutInflater.from(this@MainActivity).inflate(R.layout.ly_exit, null)
        bottomSheetDialog.setContentView(parentView)
        val nativeAds = parentView.findViewById<LinearLayout>(R.id.nativeAd)
//        val btnExit = parentView.findViewById<RelativeLayout>(R.id.btnExit)
        val btnExit = parentView.findViewById<AppCompatButton>(R.id.actionTapToExit)
        ShowExitNative(nativeAds)
        btnExit.setOnClickListener { view ->
            bottomSheetDialog.dismiss()
            finishAndRemoveTask();
            ActivityCompat.finishAffinity(this@MainActivity);
            exitProcess(0)
        }

        if (Game_On == 1) {
            (parentView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.VISIBLE
            (parentView.findViewById(R.id.ivGame) as RelativeLayout).setOnClickListener {
                if (GAME_PAGE_URL != "") RedirectToPage(this@MainActivity)
            }
            setAlphaAnimation(parentView.findViewById(R.id.ivGame))
        } else {
            (parentView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.GONE
        }

        bottomSheetDialog.setOnCancelListener {
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.setOnKeyListener { _, keyCode, _ ->
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                bottomSheetDialog.dismiss()
                exitProcess(0)
                true
            } else false
        }

        bottomSheetDialog.setOnCancelListener {
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.setOnKeyListener { _, keyCode, _ ->
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                bottomSheetDialog.dismiss()
                exitProcess(0)
                true
            } else false
        }
        bottomSheetDialog.show()
    }


    fun setAlphaAnimation(v: View) {
        val scaleDownX = ObjectAnimator.ofFloat(v, "scaleX", 0.8f)
        val scaleDownY = ObjectAnimator.ofFloat(v, "scaleY", 0.8f)
        scaleDownX.duration = 1000
        scaleDownY.duration = 1000

        val scaleUpX = ObjectAnimator.ofFloat(v, "scaleX", 1f)
        val scaleUpY = ObjectAnimator.ofFloat(v, "scaleY", 1f)
        scaleUpX.duration = 1000
        scaleUpY.duration = 1000

        /*val fadeIn = ObjectAnimator.ofFloat(v, "alpha", 0.3f, 1f)
        fadeIn.duration = 500

        val fadeOut = ObjectAnimator.ofFloat(v, "alpha", 1f, 0.3f)
        fadeOut.duration = 500*/

        val zoomInZoomOut = AnimatorSet()

        zoomInZoomOut.play(scaleUpX).with(scaleUpY).after(scaleDownX).after(scaleDownY)
        zoomInZoomOut.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                super.onAnimationEnd(animation)
                zoomInZoomOut.start()
            }
        })
        zoomInZoomOut.start()
    }


    private fun ShowExitNative(layout: LinearLayout) {
        if (exitAdView != null) {
            val adViewParent = exitAdView?.parent as? ViewGroup
            adViewParent?.removeView(exitAdView)
            layout.removeAllViews()
            layout.addView(exitAdView)
        } else if (exitnative != null) {
            setexitNativeAdView(exitnative!!, layout)
        } else {
            layout.visibility = View.GONE
        }
    }

    private fun nativeLoadingOnly(ads: ArrayList<String>) {
        when (ads[0]) {
            GOOGLE_INLINE_ADAPTIVE_BANNER -> {
                val adView = AdView(this)
                adView.setAdSize(
                    AdSize.getInlineAdaptiveBannerAdSize(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        maxHeightNative
                    )
                )
                adView.adUnitId =
                    if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/9214589741" else ads[1]
                adView.loadAd(AdRequest.Builder().build())
                adView.adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        exitAdView = adView
                    }
                }
            }

            GOOGLE_ADS -> {
                AdLoader.Builder(this, if (BuildConfig.DEBUG) "/6499/example/native" else ads[1])
                    .forNativeAd { nativeAd ->
                        if (!this.isFinishing) {
                            this.exitnative = nativeAd
                        }
                    }.withAdListener(object : AdListener() {
                    }).build().loadAd(AdRequest.Builder().build())
            }

            CUSTOM -> {}
        }
    }

    private fun setexitNativeAdView(param_nativeAd: NativeAd, layout: LinearLayout) {
        val inflater = layout.context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val adView = inflater.inflate(R.layout.ads_native, null) as NativeAdView

        val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
        adView.mediaView = mediaView
        adView.headlineView = adView.findViewById(R.id.ad_headline)
        adView.bodyView = adView.findViewById(R.id.ad_body)
        adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
        adView.iconView = adView.findViewById(R.id.ad_app_icon)
//        adView.priceView = adView.findViewById(R.id.ad_price)
//        adView.starRatingView = adView.findViewById(R.id.ad_stars)

        (adView.headlineView as TextView?)?.text = param_nativeAd.headline
//    (adView.headlineView as TextView?)?.isSelected = true
        (adView.bodyView as TextView?)?.text = param_nativeAd.body

        (adView.callToActionView as AppCompatButton?)?.text = param_nativeAd.callToAction
        (adView.findViewById(R.id.ad_btn_exit) as AppCompatTextView?)?.setOnClickListener {
            exitProcess(0)
            finishAffinity()
        }

        if (param_nativeAd.icon == null) {
            (adView.iconView as ImageView?)!!.visibility = View.GONE
        } else {
            (adView.iconView as ImageView?)!!.setImageDrawable(
                param_nativeAd.icon!!.drawable
            )
            (adView.iconView as ImageView?)!!.visibility = View.VISIBLE
        }

        /*if (param_nativeAd.starRating == null) {
            (adView.starRatingView as RatingBar?)!!.visibility = View.GONE
        } else {
            (adView.starRatingView as RatingBar?)!!.rating =
                param_nativeAd.starRating.toString().toFloat()
            (adView.starRatingView as RatingBar?)!!.visibility = View.VISIBLE
        }*/

        adView.setNativeAd(param_nativeAd)
        layout.removeAllViews()
        layout.addView(adView)
        adView.bringToFront()
        layout.invalidate()
    }

    private fun setCustomExitNativeAdView(layout: LinearLayout) {
        mLoadingData(this@MainActivity)?.let {
            val dataone: CaAds = it

            val inflater =
                layout.context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val adView = inflater.inflate(R.layout.ads_custom_native, null)

//            if (isGameLoad()) {
//                (adView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.VISIBLE
//                (adView.findViewById(R.id.ivGame) as RelativeLayout).setOnClickListener {
//                    if (GAME_PAGE_URL != "") RedirectToPage(this@MainActivity)
//                }
//            } else {
//                (adView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.GONE
//            }

            (adView.findViewById<View>(R.id.ad_headline) as TextView).text = dataone.adsTitle
            (adView.findViewById<View>(R.id.ad_headline) as TextView).setTextColor(
                Color.parseColor(
                    "#000000"
                )
            )
            (adView.findViewById<View>(R.id.ad_headline) as TextView).isSelected = true
            (adView.findViewById<View>(R.id.ad_body) as TextView).text = dataone.adsDesc
            (adView.findViewById<View>(R.id.ad_body) as TextView).setTextColor(Color.parseColor("#000000"))
            val calltoAction = adView.findViewById<AppCompatButton>(R.id.ad_call_to_action)
            calltoAction.text = "INSTALL"

            calltoAction.setOnClickListener { view: View? ->
                startActivity(Intent("android.intent.action.VIEW", Uri.parse(dataone.install)))
            }

            val btnExit = adView.findViewById<AppCompatTextView>(R.id.ad_btn_exit)
            btnExit.setOnClickListener {
                finishAffinity()
                exitProcess(0)
            }

            if (dataone.icon == null) {
                (adView.findViewById<View>(R.id.ad_app_icon) as AppCompatImageView).visibility =
                    View.GONE
            } else {
                Log.e(
                    "123", "setCustomExitNativeAdView : Link------> $Custom_Ad_Path ${dataone.icon}"
                )
                Glide.with(this@MainActivity).load(Custom_Ad_Path + dataone.icon)
                    .into(adView.findViewById<View>(R.id.ad_app_icon) as AppCompatImageView)
            }

            if (dataone.banner == null) {
                (adView.findViewById<View>(R.id.ad_media) as ImageView).visibility = View.GONE
            } else {
                Log.e(
                    "123",
                    "setCustomExitNativeAdView : Link------> $Custom_Ad_Path ${dataone.banner}"
                )
                Glide.with(this@MainActivity).load(Custom_Ad_Path + dataone.banner)
                    .into(adView.findViewById<View>(R.id.ad_media) as ImageView)
            }

            layout.removeAllViews()
            layout.background = null
            layout.addView(adView)
            layout.bringToFront()
            layout.invalidate()
        }
    }

    private fun HideActionBarMenu() {
        customActionbarBinding.giftLayout.visibility = View.GONE
        customActionbarBinding.imgApp.visibility = View.GONE
        customActionbarBinding.AdText.visibility = View.GONE
    }

    private fun ShowActionBarMenu() {
        customActionbarBinding.giftLayout.visibility = View.GONE
        customActionbarBinding.imgApp.visibility = View.VISIBLE
        customActionbarBinding.AdText.visibility = View.VISIBLE
    }

    private fun GotoFragment(position: Int) {
        try {
            fragment = null
            var fc: Class<*>? = null

            if (position == 0) {
                if (isNetworkAvailable(this@MainActivity) && databaseGst!!.getResponse(IS_ADFREE) != "YES") ShowActionBarMenu()
                else HideActionBarMenu()
                customActionbarBinding.giftLayout.visibility = View.GONE

                fc = GstCalculator::class.java
                fragment = GstCalculator()

                when (myLanStringValue) {
                    "Gujarati" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Gujarati_Calculator)
                    }

                    "Hindi" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Hindi_Calculator)
                    }

                    else -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.English_Calculator)
                    }
                }

                if (Game_On == 1 && SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
                    if (isNetworkAvailable(this@MainActivity)) {
                        binding.navView.menu.findItem(R.id.nav_Play_game).isVisible = true
                        customActionbarBinding.btnPlaygame.visibility = View.VISIBLE
                    }
                } else {
                    binding.navView.menu.findItem(R.id.nav_Play_game).isVisible = false
                    customActionbarBinding.btnPlaygame.visibility = View.GONE
                }

            } else if (position == 1) {
                customActionbarBinding.btnPlaygame.visibility = View.GONE
                HideActionBarMenu()
                fc = UnitCalculator::class.java
                fragment = UnitCalculator()

                when (myLanStringValue) {
                    "Gujarati" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Gujarati_Unit_Converter)
                    }

                    "Hindi" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Hindi_Unit_Converter)
                    }

                    else -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.English_Unit_Converter)
                    }
                }
            } else if (position == 2) {
                customActionbarBinding.btnPlaygame.visibility = View.GONE
                HideActionBarMenu()

                fc = SipCalculator::class.java
                fragment = SipCalculator()

                when (myLanStringValue) {
                    "Gujarati" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Gujarati_Sip_Calculator)
                    }

                    "Hindi" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Hindi_Sip_Calculator)
                    }

                    else -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.English_Sip_Calculator)
                    }
                }
            } else if (position == 3) {
                customActionbarBinding.btnPlaygame.visibility = View.GONE
                HideActionBarMenu()

                fc = SettingFragment::class.java
                fragment = SettingFragment()

                when (myLanStringValue) {
                    "Gujarati" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Gujarati_Settings)
                    }

                    "Hindi" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Hindi_Settings)
                    }

                    else -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.English_Settings)
                    }
                }
            } else if (position == 4) {
                customActionbarBinding.btnPlaygame.visibility = View.GONE
                HideActionBarMenu()

                fc = CompassFragment::class.java
                fragment = CompassFragment()

                when (myLanStringValue) {
                    "Gujarati" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Gujarati_Compass)
                    }

                    "Hindi" -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.Hindi_Compass)
                    }

                    else -> {
                        customActionbarBinding.actionBarTitle.text =
                            resources.getText(R.string.English_Compass)
                    }
                }
            }

            fragment = fc?.newInstance() as Fragment
            if (fragment != null) {
                supportFragmentManager.beginTransaction().setCustomAnimations(
                    R.anim.fade_in, R.anim.fade_out, R.anim.fade_in, R.anim.fade_out
                ).replace(R.id.frame_layout, fragment!!).addToBackStack(null).commit()
            }
            //   }
        } catch (e: InstantiationException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NumberFormatException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_gst_calculator -> {
                fragments_settings = 1
                GotoFragment(0)
            }

            R.id.nav_unit_converter -> {
                fragments_settings = 2
                GotoFragment(1)
            }

            R.id.nav_sip_calculator -> {
                fragments_settings = 3
                GotoFragment(2)
            }

            R.id.nav_Settings -> {
                fragments_settings = 4
                GotoFragment(3)
            }

            R.id.nav_compass -> {
                fragments_settings = 5
                GotoFragment(4)
            }

            R.id.nav_theme -> {
                startActivity(Intent(this@MainActivity, SelectTheme::class.java))
                finish()
            }

            R.id.nav_AD_Block -> {
                if (isNetworkAvailable(this)) Subscription_Dilog()
                else Toast.makeText(
                    this, resources.getString(R.string.check_connectivity), Toast.LENGTH_SHORT
                ).show()
            }

            R.id.nav_manage_subscript -> {
                val browserIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/account/subscriptions")
                )
                startActivity(browserIntent)
            }

            R.id.nav_Rate -> inAppRateApp()
            R.id.nav_Play_game -> {
                if (GAME_PAGE_URL != "") RedirectToPage(this@MainActivity)
            }

            R.id.nav_share -> {
                val s1 = Play_Store_Url + BuildConfig.APPLICATION_ID
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(Intent.EXTRA_TEXT, s1)
                sendIntent.type = "text/plain"
                startActivity(sendIntent)
            }
        }

        binding.drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    fun Subscription_Dilog() {
        Log.e("TAG_IS_PREMIUM", "Subscription_Dilog()")
        dialog_subscribe = Dialog(this)
        dialog_subscribe.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog_subscribe.window?.decorView?.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        dialog_subscribe.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog_subscribe.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog_subscribe.setCanceledOnTouchOutside(false)
        dialog_subscribe.setCancelable(false)
        val binding = SubscribeDilogNewBinding.inflate(layoutInflater)
        dialog_subscribe.setContentView(binding.root)

        when (myLanStringValue) {
            "Gujarati" -> {
                binding.txtSub.text = resources.getString(R.string.Gujarati_subscription)
                binding.txtSubDesc.text = HtmlCompat.fromHtml(
                    getString(R.string.Gujarati_subscription_desc), HtmlCompat.FROM_HTML_MODE_LEGACY
                )
            }

            "Hindi" -> {
                binding.txtSub.text = resources.getString(R.string.Hindi_subscription)
                binding.txtSubDesc.text = HtmlCompat.fromHtml(
                    getString(R.string.Hindi_subscription_desc), HtmlCompat.FROM_HTML_MODE_LEGACY
                )
            }

            else -> {
//                binding.txtSub.text = resources.getString(R.string.English_subscription)
//                binding.txtSubDesc.text = HtmlCompat.fromHtml(getString(R.string.English_subscription_desc), HtmlCompat.FROM_HTML_MODE_LEGACY)
            }
        }

        /*handler.postDelayed({
            binding.icClose.visibility = View.VISIBLE
            dialog_subscribe.setCancelable(true)
        }, 2000)*/

        binding.icClose.setOnClickListener {
            if (dialog_subscribe.isShowing) dialog_subscribe.dismiss()
            this.binding.drawerLayout.visibility = View.VISIBLE
        }

        dialog_subscribe.setOnCancelListener {
            this.binding.drawerLayout.visibility = View.VISIBLE
        }

        val adapter = SubscriptionAdapter(this@MainActivity, availablePackages) { titleSub ->
            binding.actionButtonSubTitle.text = titleSub
        }
        binding.subscriptionRecycle.adapter = adapter

        binding.btnSelection.setOnClickListener {
            this.binding.drawerLayout.visibility = View.VISIBLE
            val packageIds = (binding.subscriptionRecycle.adapter as SubscriptionAdapter).packageIds
            val lastSelection =
                (binding.subscriptionRecycle.adapter as SubscriptionAdapter).lastSelection
            availablePackages.sortedBy { it.product.period?.unit }.takeUnless { it.isEmpty() }
                ?.forEach { packageToDisplay ->
                    Log.e("PurchaseInfo", "packageType > ${packageToDisplay.product}")
                    Log.e("PurchaseInfo", "selection > $lastSelection)")

                    var params: PurchaseParams.Builder? = null
                    when (lastSelection) {
                        0 -> {
                            if (packageIds[0] == (packageToDisplay.product as GoogleStoreProduct).basePlanId) {
                                params = PurchaseParams.Builder(
                                    this@MainActivity,
                                    packageToDisplay.product.subscriptionOptions!![0]
                                )
                            }
                        }

                        1 -> {
                            if (packageIds[1] == (packageToDisplay.product as GoogleStoreProduct).basePlanId) {
                                params = PurchaseParams.Builder(
                                    this@MainActivity,
                                    packageToDisplay.product.subscriptionOptions!![0]
                                )
                            }
                        }
                    }

                    if (params != null) {
                        Purchases.sharedInstance.purchaseWith(params.build(),
                            onError = { error, userCancelled ->
                                Log.d("PurchaseInfo", "Purchase Cancels - ${error.message}")
                            },
                            onSuccess = { storeTransaction, customerInfo ->
                                Log.d(
                                    "PurchaseInfo",
                                    "Purchase storeTransaction : ${storeTransaction!!.productIds} --- "
                                )
                                Log.d(
                                    "PurchaseInfo",
                                    "Purchase customerInfo : ${customerInfo.entitlements} --- "
                                )

                                if (customerInfo.activeSubscriptions.isNotEmpty()) {
                                    Log.d(
                                        "PurchaseInfo",
                                        "Purchase activeSubscriptions - ${customerInfo.activeSubscriptions} : ${customerInfo.activeSubscriptions.size}"
                                    )
                                    Log.d(
                                        "PurchaseInfo",
                                        "Purchase latestExpirationDate - ${customerInfo.latestExpirationDate}"
                                    )

                                    val expireDate = customerInfo.latestExpirationDate
                                }
                            })
                    }
                }
            dialog_subscribe.dismiss()
        }

        binding.btnRestore.setOnClickListener {
            if (SUBSCRIPTION_STATE == "SUBSCRIPTION_STATE_ACTIVE") subscriptionDetect() else restoreCompleted()
        }


        binding.subPrivacyPolicy.setOnClickListener {
            if (isNetworkAvailable(this@MainActivity)) {
                showGame("https://sites.google.com/view/itenicapps/home")
            } else {
                Toast.makeText(this@MainActivity, "Network Connection Required", Toast.LENGTH_SHORT)
                    .show()
            }
        }


        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        Log.e("TAG_IS_PREMIUM", "premium_On" + premium_On)
        if (premium_On == 1) {
            if (!this@MainActivity.isFinishing) dialog_subscribe.show()
        }
    }

    private fun fetchSku(isFirstTime: Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            Purchases.sharedInstance.getOfferingsWith(onError = { error ->
                // Optional error handling
            }, onSuccess = { offerings ->
                val offeringsHashMap = offerings.all
                offerings.current?.let {
                    if (it.metadata.isNotEmpty()) {
                        Log.d("PurchaseInfo", "*** Printing metadata ***")
                    } else {
                        Log.d("PurchaseInfo", "paywall_theme not found in metadata")
                    }
                }
                offeringsHashMap.forEach { offering ->
                    availablePackages =
                        offering.value.availablePackages as ArrayList<com.revenuecat.purchases.Package>
                }
//                    if (isFirstTime) {
                CoroutineScope(Dispatchers.Main).launch {
                    this@MainActivity.binding.progressCircular.visibility = View.GONE

                    if (!SUBSCRIPTION_STATE.equals("SUBSCRIPTION_STATE_ACTIVE")) {
                        checkAndExecuteFunction()
                        supportFragmentManager.findFragmentById(R.id.frame_layout)?.let {
                            if (it is GstCalculator) {
                                if (premium_On == 1) {
                                    (fragment as GstCalculator).refreshView1()
                                } else {
                                    (fragment as GstCalculator).refreshView()
                                }
                            }
                        }
                    } else {
                        this@MainActivity.binding.drawerLayout.visibility = View.VISIBLE
                    }
                }
//                    }
            })
        }
    }

    fun showGame(link: String) {
        try {
            val builder = CustomTabsIntent.Builder()
            builder.setToolbarColor(ContextCompat.getColor(this, R.color.windowBackGround))
            builder.setCloseButtonIcon(
                bitmapFromDrawable(
                    this@MainActivity, R.drawable.ads_network_ic_close
                )
            )
            val customTabsIntent = builder.build()
            customTabsIntent.intent.setPackage("com.android.chrome")
            customTabsIntent.launchUrl(this, Uri.parse(link))
        } catch (e: ActivityNotFoundException) {
            e.localizedMessage
        }
    }

    private fun AdCloseIntentExit() {
        binding.drawerLayout.visibility = View.VISIBLE
//        binding.exitLayout.visibility = View.VISIBLE
        this.doubleBackToExitPressedOnce = true
    }

    private fun mRateUseDialog(isExit: Boolean) {
        val dialog = Dialog(this@MainActivity)
        val binding = DialogRateUsBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.window?.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)

        when (myLanStringValue) {
            "Gujarati" -> {
                binding.txtTitle.text = resources.getString(R.string.Gujarati_Rate_this_app)
                binding.txtTitleDialog.text = resources.getString(R.string.Gujarati_rate_desc)
                binding.btnYes.text = resources.getString(R.string.Gujarati_rate_now)
                binding.btnNoThanks.text = resources.getString(R.string.Gujarati_txt_no_thanks)
                binding.btnRemindMeLater.text =
                    resources.getString(R.string.Gujarati_remind_me_later)

            }

            "Hindi" -> {
                binding.txtTitle.text = resources.getString(R.string.Hindi_Rate_this_app)
                binding.txtTitleDialog.text = resources.getString(R.string.Hindi_rate_desc)
                binding.btnYes.text = resources.getString(R.string.Hindi_rate_now)
                binding.btnNoThanks.text = resources.getString(R.string.Hindi_txt_no_thanks)
                binding.btnRemindMeLater.text = resources.getString(R.string.Hindi_remind_me_later)

            }

            else -> {
                binding.txtTitle.text = resources.getString(R.string.English_Rate_this_app)
                binding.txtTitleDialog.text = resources.getString(R.string.English_rate_desc)
                binding.btnYes.text = resources.getString(R.string.English_rate_now)
                binding.btnNoThanks.text = resources.getString(R.string.English_txt_no_thanks)
                binding.btnRemindMeLater.text =
                    resources.getString(R.string.English_remind_me_later)
            }
        }

        dialog.findViewById<View>(R.id.btn_no_thanks).setOnClickListener { view ->
            if (isExit) exitProcess(0)
            else dialog.dismiss()

            val editor = preferences.edit()
            editor.putString(RATE_US_COM, "true")
            editor.putBoolean(Rate_First_Time, true)
            editor.putBoolean(Rate_Dialog_show, true)
            editor.apply()
        }

        dialog.findViewById<View>(R.id.btn_remind_me_later).setOnClickListener { view ->
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_MONTH, 5)
            val editor = preferences.edit()
            editor.putString(Rate_After_Five_Day_Date, specialformat.format(c.time))
            editor.putBoolean(Rate_After_Five_Day, true)
            editor.apply()

            dialog.dismiss()
        }

        dialog.findViewById<View>(R.id.btn_yes).setOnClickListener { view ->
            val editor = preferences.edit()
            editor.putString(RATE_US_COM, "true")
            editor.putBoolean(Rate_First_Time, true)
            editor.putBoolean(Rate_Dialog_show, true)
            editor.apply()
            inAppRateApp()
            dialog.dismiss()
        }

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        val win = dialog.window
        win?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        if (this@MainActivity != null && !this@MainActivity.isFinishing) dialog.show()
    }

    private fun UpdateDialog() {
        appUpdateManager = AppUpdateManagerFactory.create(this@MainActivity)
        val appUpdateInfoTask = appUpdateManager.appUpdateInfo

        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(
                    AppUpdateType.FLEXIBLE
                )
            ) {
                try {
                    appUpdateManager.startUpdateFlowForResult(
                        appUpdateInfo, AppUpdateType.FLEXIBLE, this, MY_REQUEST_CODE
                    )
                } catch (e: IntentSender.SendIntentException) {
                    e.printStackTrace()
                }
            }
        }


        listener = InstallStateUpdatedListener { installState ->
            if (installState.installStatus() == InstallStatus.DOWNLOADED) {

            }
        }

        appUpdateManager.registerListener(listener)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MY_REQUEST_CODE) {
            if (resultCode != RESULT_OK) {

            }
        }
    }

    private fun GiftDialog() {
        val dialog = Dialog(this@MainActivity)
        val binding = DialogGiftBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(true)

        val myImageView = dialog.findViewById<ImageView>(R.id.close)
        val mClose = dialog.findViewById<ImageView>(R.id.close_dialog)
        val layoutGiftAdsContainer = dialog.findViewById<LinearLayout>(R.id.layoutGiftAdsContainer)

        mClose.setOnClickListener { view ->
            customActionbarBinding.imgApp.clearAnimation()
            dialog.dismiss()
        }

        customActionbarBinding.imgApp.setOnClickListener {}

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(DisplayMetrics())
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.show()
    }

    companion object {
        var is_update = false

        var fragments_settings = 0
        private val MY_REQUEST_CODE = 111

        var isConnectionError: Boolean? = false
        val PREFS_NAME = "MyPrefsGST"
    }

    fun bannerAdsLoading(ads: ArrayList<String>, layout: LinearLayout, adsName: String) {

        var settings = getSharedPreferences(PREFS_NAME, 0)
        if (settings.getBoolean("my_first_time", true)) {
            // first time
            Log.e("StaticTAG", "bannerAdsLoading: firestTime - live")
//            Toast.makeText(this, "FT - live", Toast.LENGTH_SHORT).show()
            googleAdaptiveBanner(if (BuildConfig.DEBUG) "/6499/example/banner" else LiveBannerId,
                layout,
                object : AdsListener {
                    override fun onFail() {
                        val data = adsFailToLoad(adsName, GOOGLE_NATIVE_ADS)
                        if (data == CUSTOM) {
                            showCustomBanner(layout)
                        } else {
                            googleNativeBanner(ads[1], layout, object : AdsListener {
                                override fun onFail() {
                                    showCustomBanner(layout)
                                }

                                override fun onClick() {
                                    if (layout != null) bannerAdsLoading(
                                        gstAdsBuilder(adsName), layout, adsName
                                    )
                                }
                            })
                        }
                    }

                    override fun onClick() {
                        if (layout != null) bannerAdsLoading(
                            gstAdsBuilder(adsName), layout, adsName
                        )
                    }

                })
            settings.edit().putBoolean("my_first_time", false).commit();
        } else {
            if (isConnectionError!!) {
//                Toast.makeText(this, "bannerAdsLoading: isConnectionError - live", Toast.LENGTH_SHORT).show()
                Log.e("StaticTAG", "live - ConnectionError ")
                // isConnectionError time
                googleAdaptiveBanner(if (BuildConfig.DEBUG) "/6499/example/banner" else LiveBannerId,
                    layout,
                    object : AdsListener {
                        override fun onFail() {
                            val data = adsFailToLoad(adsName, GOOGLE_NATIVE_ADS)
                            if (data == CUSTOM) {
                                showCustomBanner(layout)
                            } else {
                                googleNativeBanner(ads[1], layout, object : AdsListener {
                                    override fun onFail() {
                                        showCustomBanner(layout)
                                    }

                                    override fun onClick() {
                                        if (layout != null) bannerAdsLoading(
                                            gstAdsBuilder(adsName), layout, adsName
                                        )
                                    }
                                })
                            }
                        }

                        override fun onClick() {
                            if (layout != null) bannerAdsLoading(
                                gstAdsBuilder(adsName), layout, adsName
                            )
                        }
                    })
                settings.edit().putBoolean("my_first_time", false).commit();
            } else {
                Log.e("StaticTAG", "bannerAdsLoading: Normal Case")
//                Toast.makeText(this, "Normal Case", Toast.LENGTH_SHORT).show()
                when (ads[0]) {
                    GOOGLE_ADS -> {
                        googleAdaptiveBanner(if (BuildConfig.DEBUG) "/6499/example/banner" else ads[1],
                            layout,
                            object : AdsListener {
                                override fun onFail() {
                                    val data = adsFailToLoad(adsName, GOOGLE_NATIVE_ADS)
                                    if (data == CUSTOM) {
                                        showCustomBanner(layout)
                                    } else {
                                        googleNativeBanner(ads[1], layout, object : AdsListener {
                                            override fun onFail() {
                                                showCustomBanner(layout)
                                            }

                                            override fun onClick() {
                                                if (layout != null) bannerAdsLoading(
                                                    gstAdsBuilder(adsName), layout, adsName
                                                )
                                            }
                                        })
                                    }
                                }

                                override fun onClick() {
                                    if (layout != null) bannerAdsLoading(
                                        gstAdsBuilder(adsName), layout, adsName
                                    )
                                }
                            })
                    }

                    GOOGLE_NATIVE_ADS -> {
                        googleNativeBanner(if (BuildConfig.DEBUG) "/6499/example/native" else ads[1],
                            layout,
                            object : AdsListener {
                                override fun onFail() {
                                    val data = adsFailToLoad(adsName, GOOGLE_ADS)
                                    if (data == CUSTOM) {
                                        showCustomBanner(layout)
                                    } else {
                                        googleAdaptiveBanner(ads[1], layout, object : AdsListener {
                                            override fun onFail() {
                                                showCustomBanner(layout)
                                            }

                                            override fun onClick() {
                                                if (layout != null) bannerAdsLoading(
                                                    gstAdsBuilder(adsName), layout, adsName
                                                )
                                            }
                                        })
                                    }
                                }

                                override fun onClick() {
                                    if (layout != null) bannerAdsLoading(
                                        gstAdsBuilder(adsName), layout, adsName
                                    )
                                }
                            })
                    }

                    GOOGLE_BID_ADS -> {
                        googleAdaptiveBanner(ads[1], layout, object : AdsListener {
                            override fun onFail() {
                                val data = adsFailToLoad(adsName, GOOGLE_NATIVE_ADS)
                                if (data == CUSTOM) {
                                    showCustomBanner(layout)
                                } else {
                                    googleNativeBanner(ads[1], layout, object : AdsListener {
                                        override fun onFail() {
                                            if (layout != null) bannerAdsLoading(
                                                gstAdsBuilder(adsName), layout, adsName
                                            )
                                        }

                                        override fun onClick() {
                                            if (layout != null) bannerAdsLoading(
                                                gstAdsBuilder(adsName), layout, adsName
                                            )
                                        }
                                    })
                                }
                            }

                            override fun onClick() {
                                if (layout != null) bannerAdsLoading(
                                    gstAdsBuilder(adsName), layout, adsName
                                )
                            }
                        })
                    }

                    CUSTOM -> {
                        showCustomBanner(layout)
                    }
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if ((fragment is GstCalculator) && (fragment as GstCalculator).isLoadingAds()) {
                return true
            }
            when {
                binding.drawerLayout.isOpen -> {
                    binding.drawerLayout.close()
                }

                binding.exitLayout.visibility == View.VISIBLE -> {
                    exitProcess(0)
                }

                exitnative != null || exitAdView != null -> {
                    showExitDialog()
                }

                else -> {
                    if (doubleBackToExitPressedOnce) {
                        exitProcess(0)
                    }
                    this.doubleBackToExitPressedOnce = true
                    Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT)
                        .show()

                    Handler(Looper.getMainLooper()).postDelayed({
                        doubleBackToExitPressedOnce = false
                    }, 2000)
                }
            }
            return true
        } else return super.onKeyDown(keyCode, event)
    }

    override fun onReceived(customerInfo: CustomerInfo) {
        if (customerInfo.activeSubscriptions.isNotEmpty()) {
            if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
                subscriptionDetect()
            }
            SUBSCRIPTION_STATE = "SUBSCRIPTION_STATE_ACTIVE"
            CoroutineScope(Dispatchers.Main).launch {
                binding.navView.menu.findItem(R.id.nav_Play_game).isVisible = false
                binding.navView.menu.findItem(R.id.nav_AD_Block).isVisible = false
                binding.navView.menu.findItem(R.id.nav_manage_subscript).isVisible = true
                customActionbarBinding.btnPlaygame.visibility = View.GONE
                binding.adLayout.visibility = View.GONE
                supportFragmentManager.findFragmentById(R.id.frame_layout)?.let {
                    if (it is GstCalculator) {
                        if (premium_On == 1) {
                            (fragment as GstCalculator).refreshView1()
                        } else {
                            (fragment as GstCalculator).refreshView()
                        }
                    }
                }
            }

        } else {
            SUBSCRIPTION_STATE = ""
        }
    }

//    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
//        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
//            val skuListData = instances?.tbSkuDao()?.getData()
//            if (!skuListData.isNullOrEmpty()) {
//                for (purchase in purchases) {
//                    val originalJson = JSONObject(purchase.originalJson)
//                    val productId = originalJson.getString("productId")
//                    CoroutineScope(Dispatchers.IO).launch {
//                        verificationPurchase(productId, purchase.purchaseToken)
//                    }
//
//                    val tbAppConfig = TbAppConfig()
//                    tbAppConfig.id = SUBSCRIPTION_ORDER_ID_ID
//                    tbAppConfig.data = purchase.orderId ?: purchase.purchaseToken
//                    instances?.tbAppConfigDao()?.insert(tbAppConfig)
//                }
//            }
//        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
//            runOnUiThread(Toast.makeText(this@MainActivity, "Purchase Canceled", Toast.LENGTH_SHORT)::show)
//        }
//    }

    var countHistory = 0
    val handlerHistory = Handler(Looper.getMainLooper())
    val runnableHistory = object : Runnable {
        override fun run() {
            if (adsAdHistoryFail) {
                if (fragment is GstCalculator) {
                    (fragment as GstCalculator).showProgress(8)
                }
                callbackAdHistory?.invoke()
            } else if (interstitialAdHistory != null) {
                interstitialAdHistory?.show(this@MainActivity)
                interstitialAdHistory?.fullScreenContentCallback =
                    object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            if (fragment is GstCalculator) {
                                (fragment as GstCalculator).showProgress(8)
                            }
                            callbackAdHistory?.invoke()
                            interstitialAdHistory = null
                        }

                        override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                            super.onAdFailedToShowFullScreenContent(p0)
                            if (fragment is GstCalculator) {
                                (fragment as GstCalculator).showProgress(8)
                            }
                            callbackAdHistory?.invoke()
                            interstitialAdHistory = null
                        }
                    }
            } else if (20 < countHistory) {
                if (fragment is GstCalculator) {
                    (fragment as GstCalculator).showProgress(8)
                }
                callbackAdHistory?.invoke()
            } else {
                countHistory += 1
                handlerHistory.postDelayed(this, 250)
            }
        }
    }
    var adsAdHistoryFail = false
    var interstitialAdHistory: InterstitialAd? = null
    var callbackAdHistory: (() -> Unit)? = null
    fun historyClick(callback: () -> Unit) {
        if (interstitialAdHistory != null) {
            interstitialAdHistory?.show(this@MainActivity)
            interstitialAdHistory?.fullScreenContentCallback =
                object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        if (fragment is GstCalculator) {
                            (fragment as GstCalculator).showProgress(8)
                        }
                        callbackAdHistory?.invoke()
                        interstitialAdHistory = null
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        if (fragment is GstCalculator) {
                            (fragment as GstCalculator).showProgress(8)
                        }
                        callbackAdHistory?.invoke()
                        interstitialAdHistory = null
                    }
                }
        } else {
            callbackAdHistory = callback
            countHistory = 0
            adsAdHistoryFail = false
            handlerHistory.postDelayed(runnableHistory, 250)
            if (fragment is GstCalculator) {
                (fragment as GstCalculator).showProgress(0)
            }
            val ads = gstAdsBuilder(HISTORY_ADS_NAME)
            when (ads[0]) {
                GOOGLE_ADS -> {
                    InterstitialAd.load(this,
                        if (BuildConfig.DEBUG) "/6499/example/interstitial" else ads[1],
                        AdRequest.Builder().build(),
                        object : InterstitialAdLoadCallback() {
                            override fun onAdLoaded(ads: InterstitialAd) {
                                interstitialAdHistory = ads
                            }

                            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                                adsAdHistoryFail = true
                            }
                        })
                }

                else -> {
                    if (fragment is GstCalculator) {
                        (fragment as GstCalculator).showProgress(8)
                    }
                    handlerHistory.removeCallbacks(runnableHistory)
                    callbackAdHistory?.invoke()
                }
            }
        }
    }

}