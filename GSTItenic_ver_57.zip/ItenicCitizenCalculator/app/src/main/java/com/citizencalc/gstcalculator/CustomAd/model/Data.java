package com.citizencalc.gstcalculator.CustomAd.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class Data implements Serializable
{
    @SerializedName("cadid")
    private String cadid;
    @SerializedName("color")
    private String color;
    @SerializedName("icon")
    private String icon;
    @SerializedName("rating")
    private String rating;
    @SerializedName("banner")
    private String banner;
    @SerializedName("title")
    private String title;
    @SerializedName("download")
    private String download;
    @SerializedName("install")
    private String install;
    @SerializedName("review")
    private String review;
    @SerializedName("id")
    private ArrayList<String> id;
    @SerializedName("attr")
    private ArrayList<String> attr;
    @SerializedName("value")
    private ArrayList<String> value;
    @SerializedName("desc")
    private String desc;
    @SerializedName("design_page")
    private String design_page;
    @SerializedName("icon_download")
    private String icon_download;
    @SerializedName("banner_download")
    private String banner_download;

    public String getIcon_download() {
        return icon_download;
    }

    public void setIcon_download(String icon_download) {
        this.icon_download = icon_download;
    }

    public String getBanner_download() {
        return banner_download;
    }

    public void setBanner_download(String banner_download) {
        this.banner_download = banner_download;
    }

    public String getDesign_page() {
        return design_page;
    }

    public void setDesign_page(String design_page) {
        this.design_page = design_page;
    }

    public String getCadid ()
    {
        return cadid;
    }

    public void setCadid (String cadid)
    {
        this.cadid = cadid;
    }

    public String getColor ()
    {
        return color;
    }

    public void setColor (String color)
    {
        this.color = color;
    }

    public String getInstall ()
    {
        return install;
    }

    public void setInstall (String install)
    {
        this.install = install;
    }

    public String getIcon ()
    {
        return icon;
    }

    public void setIcon (String icon)
    {
        this.icon = icon;
    }

    public String getBanner ()
    {
        return banner;
    }

    public void setBanner (String banner)
    {
        this.banner = banner;
    }

    public String getTitle ()
    {
        return title;
    }

    public void setTitle (String title)
    {
        this.title = title;
    }

    public String getDesc ()
    {
        return desc;
    }

    public void setDesc (String desc)
    {
        this.desc = desc;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getDownload() {
        return download;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public ArrayList<String> getId() {
        return id;
    }

    public void setId(ArrayList<String> id) {
        this.id = id;
    }

    public ArrayList<String> getAttr() {
        return attr;
    }

    public void setAttr(ArrayList<String> attr) {
        this.attr = attr;
    }

    public ArrayList<String> getValue() {
        return value;
    }

    public void setValue(ArrayList<String> value) {
        this.value = value;
    }
}