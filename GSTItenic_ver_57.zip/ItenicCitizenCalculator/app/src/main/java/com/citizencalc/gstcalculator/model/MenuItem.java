package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import java.util.List;
@Keep
public class MenuItem
{
    public List<Menu> menu;

    public List<Menu> getMenu() {
        return menu;
    }

    public void setMenu(List<Menu> menu) {
        this.menu = menu;
    }
}
	