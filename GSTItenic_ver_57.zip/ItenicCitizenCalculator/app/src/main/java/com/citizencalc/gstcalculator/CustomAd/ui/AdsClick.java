package com.citizencalc.gstcalculator.CustomAd.ui;

public interface AdsClick {
    void onClick(String... strings);
}
