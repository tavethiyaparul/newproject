package com.citizencalc.gstcalculator.fragment

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Context.VIBRATOR_SERVICE
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Resources
import android.media.AudioManager
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.util.Log.e
import android.util.TypedValue
import android.view.*
import android.widget.Button
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.android.billingclient.api.*
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Tag_Round
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Tag_Sound
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Tag_Vibrate
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_0
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_1
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_2
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_3
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_4
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_5
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_Devide_Char
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_Mines_Char
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_Module
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_Multiple_Char
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_Plus_Char
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_equal_Char
import com.citizencalc.gstcalculator.Classes.common.AppConstUtility.Companion.Text_plus
import com.citizencalc.gstcalculator.Classes.common.AppUtility.*
import com.citizencalc.gstcalculator.Classes.common.DialogCalss
import com.citizencalc.gstcalculator.Classes.common.DialogCalss.*
import com.citizencalc.gstcalculator.Classes.common.Dialogdismiss
import com.citizencalc.gstcalculator.Classes.common.premium_On
import com.citizencalc.gstcalculator.CustomAd.ui.AdsInit
import com.citizencalc.gstcalculator.GOOGLE_ADS
import com.citizencalc.gstcalculator.HISTORY_ADS_NAME
import com.citizencalc.gstcalculator.PURCHASE
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.RoomDb
import com.citizencalc.gstcalculator.RoomDb.*
import com.citizencalc.gstcalculator.RoomDb.Companion.roomOrderDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbAdsNameDao
import com.citizencalc.gstcalculator.RoomDb.Companion.tbSkuDao
import com.citizencalc.gstcalculator.SUBSCRIPTION_STATE
import com.citizencalc.gstcalculator.activity.HistoryActivity
import com.citizencalc.gstcalculator.activity.MainActivity
import com.citizencalc.gstcalculator.database.DatabaseGst
import com.citizencalc.gstcalculator.database.table.RoomOrder
import com.citizencalc.gstcalculator.databinding.LayoutCalculatorActivityBinding
import com.citizencalc.gstcalculator.gstAdsBuilder
import com.citizencalc.gstcalculator.model.HistoryData
import com.citizencalc.gstcalculator.model.InAppData
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.DecimalFormat
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToLong

class GstCalculator : Fragment(), View.OnClickListener, Dialogdismiss, PurchasesUpdatedListener {

    private var mCalculatorDisplayString = ""
    private var mCalculationString: String? = ""
    var resultArray: ArrayList<Double>? = null
    var operatorArray: ArrayList<Char>? = null
    var mCalculatorDisplay1 = ""
    var mCalculatorDisplay2 = ""
    var historyData: HistoryData? = null
    var tempSavedOperator = '='
    var tempsavedOperand = 0.0
    private var menu: Menu? = null
    private lateinit var binding: LayoutCalculatorActivityBinding
    private var decimalformat = DecimalFormat(Decimal_format)
    private var numberformat: NumberFormat = DecimalFormat(Number_format)
    private var gstDisplayString: String = Text_0
    private val gstCalculationString = ""
    private var t1 = ""
    private var preoprandstring = ""
    private val pretempstring = ""
    private var gstCalculatorDisplay1 = ""
    private var gstCalculatorDisplay2 = ""
    var gstoperandArray: ArrayList<Double> = ArrayList()
    var gstoperatorArray: ArrayList<Char> = ArrayList()
    var gstresultArray: ArrayList<Double> = ArrayList()
    var operandArray1: ArrayList<Double?>? = ArrayList()
    var operatorArray1: ArrayList<Char> = ArrayList()
    var resultArray1: ArrayList<Double?>? = ArrayList()
    var operandFirst_history: ArrayList<Double> = ArrayList()
    var operator_history: ArrayList<Char> = ArrayList()
    var operandSecond_history: ArrayList<Double> = ArrayList()
    var result_history: ArrayList<Double> = ArrayList()
    var grand_total: ArrayList<Double> = ArrayList()
    var MemoryArray: ArrayList<Double> = ArrayList()
    private var checkIndex = -1
    private var autoReply: CountDownTimer? = null
    private var prevOperator = Text_equal_Char
    private var savedOperator = Text_equal_Char
    private var memoryOpretor = Text_equal_Char
    private var result = 0.0
    private var savedOperand = 0.0
    private var mCalculatorMemory = 0.0
    private var result_calculate = 0.0
    private var oprand_one = 0.0
    private var oprand_two = 0.0
    private var oprand_result = 0.0
    private var mu_oprand = 0.0

    var j = 0
    var i = 0
    var operandArray: ArrayList<Double>? = null
    var buttonPressed: String? = null
    var tmpprevOperator = '='
    var mPrefs: SharedPreferences? = null
    var isCheckRoot: Boolean = false

    private var FirstBuff = StringBuilder()
    private var secondBuff = StringBuilder()
    lateinit var display1: String
    lateinit var two: String
    private var round: String = Text_2
    private var formattedDate = ""
    private var is_oprand = 0
    private var is_oprand_renew = 0
    private var is_equal = false
    private var is_gst = false
    private var is_mu = false
    private var ans_gst = false
    private var ans_equ_gst = false
    private var sound = false
    private var vibrate = false
    private var doubleBack = false
    private var is_ad_once = false
    private var flag_Ad_fail = false
    private var is_subscribe = false
    private var count = 0
    lateinit var preferences: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    private var myAudioManager: AudioManager? = null

    private var handler_back = Handler()
    private var dilog: Dialog? = null
    lateinit var dialog_subscribe: Dialog
    private var dilog_update: Dialog? = null

    lateinit var inApp: BillingClient
    private var inAppData: InAppData? = null

    private var gst_val: Double = 0.0
    private var total_gst: Double = 0.0
    private var gst_val1: Double = 0.0
    private var result_gst = 0.0
    private var gst_dis = ""
    private var GST = ""
    private var dialogCustomShowSelection: Dialog? = null
    private var is_custom_ad = false
    private val CurrentDate = ""
    private val specialformat = SimpleDateFormat(Date_format)

    private val isForce = false

    private val mLastClickTime: Long = 0

    private var snackbar: Snackbar? = null

    lateinit var slab_prefr: SharedPreferences
    private var preferencesIronceSourceId: SharedPreferences? = null
    private var preferencesIronceSourceIdEditer: SharedPreferences.Editor? = null

    var myLanStringValue: String? = null

    lateinit var pref_values: MutableList<String>
    private val defaul_val = arrayOf(
        plus_3,
        plus_5,
        plus_12,
        plus_18,
        plus_28,
        minus_3,
        minus_5,
        minus_12,
        minus_18,
        minus_28
    )
    private val ids = intArrayOf(
        R.id.buttongst3,
        R.id.buttongst5,
        R.id.buttongst12,
        R.id.buttongst18,
        R.id.buttongst28,
        R.id.buttongstsub3,
        R.id.buttongstsub5,
        R.id.buttongstsub12,
        R.id.buttongstsub18,
        R.id.buttongstsub28
    )

    private lateinit var btn_p1: Button
    private lateinit var btn_p2: Button
    private lateinit var btn_p3: Button
    private lateinit var btn_p4: Button
    private lateinit var btn_p5: Button
    private lateinit var btn_m1: Button
    private lateinit var btn_m2: Button
    private lateinit var btn_m3: Button
    private lateinit var btn_m4: Button
    private lateinit var btn_m5: Button
    private var databaseGst: DatabaseGst? = null
    lateinit var sharedPref: SharedPreferences

    private fun setpref() {
        for (i in ids.indices) {
            long_click(ids[i])
            slab_prefr.getString("slab_$i", defaul_val[i])?.let { pref_values.add(it) }
        }
    }

    private fun long_click(i: Int) {
        val button = view?.findViewById<Button>(i)
        button?.setOnLongClickListener {
            slabDialog()
            true
        }
    }

    private fun Gst_value(i: Int, str: String): Double {
        var str = str
        if (str.contains(Text_Module)) str = str.replace(Text_Module, "")
        var value = 0.0

        value = if (i <= 4) {
            java.lang.Double.valueOf(str.substring(1, str.length))
        } else {
            100.0 + java.lang.Double.valueOf(str.substring(1, str.length))
        }

        return value
    }

    private fun slabDialog() {
        val dialog = DialogCalss(activity, this@GstCalculator)

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)

        val wm = activity?.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = dialog.window
        win?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )

        dialog.show()
    }

    fun clearall() {
        operandFirst_history.clear()
        operator_history.clear()
        operandSecond_history.clear()
        result_history.clear()
        MemoryArray.clear()

        FirstBuff.setLength(0)
        FirstBuff.trimToSize()

        secondBuff.setLength(0)
        secondBuff.trimToSize()

        oprand_one = 0.0
        oprand_two = 0.0
        mu_oprand = 0.0
        oprand_result = 0.0
        result_calculate = 0.0
        count = 0
    }

    private fun init(view: View) {
        inAppData = InAppData()
        preferences = activity?.getSharedPreferences(PREF_TAG, MODE_PRIVATE) as SharedPreferences
        editor = preferences.edit()
        mPrefs = requireActivity().getSharedPreferences("myVal", MODE_PRIVATE)
        myAudioManager = activity?.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        decimalformat.minimumFractionDigits = 0
        decimalformat.maximumFractionDigits = 12
        decimalformat.minimumIntegerDigits = 1
        decimalformat.maximumIntegerDigits = 12

        binding.button0.setOnClickListener(this)
        binding.button1.setOnClickListener(this)
        binding.button2.setOnClickListener(this)
        binding.button3.setOnClickListener(this)
        binding.button4.setOnClickListener(this)
        binding.button5.setOnClickListener(this)
        binding.button6.setOnClickListener(this)
        binding.button7.setOnClickListener(this)
        binding.button8.setOnClickListener(this)
        binding.button9.setOnClickListener(this)
        binding.buttonAdd.setOnClickListener(this)
        binding.buttonSubtract.setOnClickListener(this)
        binding.buttonMultiply.setOnClickListener(this)
        binding.buttonDivide.setOnClickListener(this)
        binding.buttonToggleSign.setOnClickListener(this)
        binding.buttonDecimalPoint.setOnClickListener(this)
        binding.buttonEquals.setOnClickListener(this)
        binding.buttonClear.setOnClickListener(this)
        binding.buttonAddToMemory.setOnClickListener(this)
        binding.buttonSubtractFromMemory.setOnClickListener(this)
        binding.buttonRecallMemory.setOnClickListener(this)
        binding.buttonModulas.setOnClickListener(this)
//        buttonCheck.setOnClickListener(this)
//        buttonCorrect.setOnClickListener(this)
        binding.buttonGT.setOnClickListener(this)
        binding.buttonRoot.setOnClickListener(this)
        binding.buttonMU.setOnClickListener(this)
        binding.buttongst12.setOnClickListener(this)
        binding.buttongst18.setOnClickListener(this)
        binding.buttongst28.setOnClickListener(this)
        binding.buttongst5.setOnClickListener(this)
        binding.buttongst3.setOnClickListener(this)
        binding.buttongstsub3.setOnClickListener(this)
        binding.buttongstsub5.setOnClickListener(this)
        binding.buttongstsub12.setOnClickListener(this)
        binding.buttongstsub18.setOnClickListener(this)
        binding.buttongstsub28.setOnClickListener(this)
//        button_chnge_gst.setOnClickListener(this)
        Handler(Looper.getMainLooper()).postDelayed({ binding.buttonClear.performClick() }, 200)
        binding.btnGST.setOnClickListener {
            it?.apply { isEnabled = false; postDelayed({ isEnabled = true }, 400) } //400 ms
            slabDialog()
        }
//        btnCorrect.setOnClickListener(this)
        binding.btnCheck.setOnClickListener {
//            it?.apply { isEnabled = false; postDelayed({ isEnabled = true }, 400) } //400 ms

            if (autoReply != null) {
                autoReply?.cancel()
                autoReply = null
                binding.textView2.text =
                    if (gstDisplayString.compareTo("") == 0) gstoperatorArray[gstoperatorArray.size].toString() else " "
                binding.textView1.text =
                    if (gstDisplayString.compareTo("") == 0) decimalformat.format(gstresultArray[gstresultArray.size - 1]) else gstDisplayString
                binding.stepCount.text =
                    decimalformat.format((gstresultArray.size + if (gstDisplayString.compareTo("") == 0) 0 else 1).toLong())
            }

            if (savedOperator != Text_equal_Char && prevOperator == Text_equal_Char && gstDisplayString.compareTo(
                    ""
                ) == 0
            ) gstDisplayString = decimalformat.format(result)

            if (gstDisplayString.compareTo("") == 0) return@setOnClickListener

            gstDisplayString = gstDisplayString.substring(0, gstDisplayString.length - 1)

            if (gstDisplayString.compareTo("") == 0 || gstDisplayString.compareTo("-") == 0) gstDisplayString =
                Text_0

            binding.textView2.text = " "
            binding.textView1.text = gstDisplayString
            binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
        }

        binding.btnCorrect.setOnClickListener {
//            it?.apply { isEnabled = false; postDelayed({ isEnabled = true }, 400) } //400 ms
            try {
                if (operandArray!!.size == 0) return@setOnClickListener
                checkIndex++
                checkIndex %= resultArray!!.size

                binding.textView2.text = operatorArray!![checkIndex].toString()
                binding.textView1.text = decimalformat.format(operandArray!![checkIndex])
                binding.stepCount.text = decimalformat.format((checkIndex + 1).toLong())
            } catch (e: IndexOutOfBoundsException) {

            }

            /* if (checkIndex >= 0) { //Pressing '=' will show current result while checking
                 binding.textView1.text = decimalformat.format(gstresultArray[checkIndex])
                 binding.textView2.text = Text_equal
             } else {
                 checkIndex = -1
             }
             e("++--++", "init: ")

             try {
                 e("++--++", "init try: "+operandArray?.size)
                 if (operandArray!!.size == 0) return@setOnClickListener

                 binding.textRep.visibility = View.VISIBLE
                 checkIndex++

                 checkIndex %= gstresultArray.size

                 binding.textView2.text = gstoperatorArray[checkIndex].toString()
                 binding.textView1.text = decimalformat.format(operandArray!![checkIndex])
                 binding.stepCount.text = decimalformat.format((checkIndex + 1).toLong())

                 if ((operandArray!!.size - 1) == checkIndex && gstoperatorArray[gstoperatorArray.size - 2] == '=') {
                     binding.textView2.text = "="
                     binding.textAns.visibility = View.VISIBLE
                 } else binding.textAns.visibility = View.GONE
             } catch (e: IndexOutOfBoundsException) {
                 e("++--++", "init IndexOutOfBoundsException: $e")
                 e.printStackTrace()
             } catch (e: NullPointerException) {
                 e("++--++", "init NullPointerException: $e")
                 e.printStackTrace()
             } catch (e: NumberFormatException) {
                 e("++--++", "init NumberFormatException: $e")
                 e.printStackTrace()
             } catch (e: Exception) {
                 e("++--++", "init Exception: $e")
                 e.printStackTrace()
             }*/
        }

        slab_prefr =
            activity?.getSharedPreferences("slab_values", MODE_PRIVATE) as SharedPreferences
        pref_values = ArrayList()

        sharedPref = (activity as MainActivity).getSharedPreferences("AppPref", MODE_PRIVATE)
        setButtonTheme(sharedPref.getInt("Theme", 0))

        btn_p1 = view.findViewById(ids[0])
        btn_p2 = view.findViewById(ids[1])
        btn_p3 = view.findViewById(ids[2])
        btn_p4 = view.findViewById(ids[3])
        btn_p5 = view.findViewById(ids[4])
        btn_m1 = view.findViewById(ids[5])
        btn_m2 = view.findViewById(ids[6])
        btn_m3 = view.findViewById(ids[7])
        btn_m4 = view.findViewById(ids[8])
        btn_m5 = view.findViewById(ids[9])


        slab_p1 = slab_prefr.getString("slab_" + 0, defaul_val[0])!! + Text_Module
        slab_p2 = slab_prefr.getString("slab_" + 1, defaul_val[1])!! + Text_Module
        slab_p3 = slab_prefr.getString("slab_" + 2, defaul_val[2])!! + Text_Module
        slab_p4 = slab_prefr.getString("slab_" + 3, defaul_val[3])!! + Text_Module
        slab_p5 = slab_prefr.getString("slab_" + 4, defaul_val[4])!! + Text_Module
        slab_m1 = slab_prefr.getString("slab_" + 5, defaul_val[5])!! + Text_Module
        slab_m2 = slab_prefr.getString("slab_" + 6, defaul_val[6])!! + Text_Module
        slab_m3 = slab_prefr.getString("slab_" + 7, defaul_val[7])!! + Text_Module
        slab_m4 = slab_prefr.getString("slab_" + 8, defaul_val[8])!! + Text_Module
        slab_m5 = slab_prefr.getString("slab_" + 9, defaul_val[9])!! + Text_Module
        setpref()
        SetSlabValue()
    }

    fun round_off(case_id: String, round_val: Double): Double {
        var round_val = round_val
        when (case_id) {
            Text_0 -> round_val = Math.round(round_val * 1.0) / 1.0
            Text_1 -> round_val = Math.round(round_val * 10.0) / 10.0
            Text_2 -> round_val = Math.round(round_val * 100.0) / 100.0
            Text_3 -> round_val = Math.round(round_val * 1000.0) / 1000.0
            Text_4 -> round_val = Math.round(round_val * 10000.0) / 10000.0
            Text_5 -> round_val = Math.round(round_val * 100000.0) / 100000.0
            else -> {
            }
        }
        return round_val
    }

    private fun SetSlabValue() {
        btn_p1.text = slab_p1
        btn_p2.text = slab_p2
        btn_p3.text = slab_p3
        btn_p4.text = slab_p4
        btn_p5.text = slab_p5
        btn_m1.text = slab_m1
        btn_m2.text = slab_m2
        btn_m3.text = slab_m3
        btn_m4.text = slab_m4
        btn_m5.text = slab_m5
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init(view)

        inApp = BillingClient.newBuilder(requireActivity())
            .setListener(this)
            .enablePendingPurchases()
            .build()

        initDatabase()

        val sp = requireActivity().getSharedPreferences(PREF_TAG, MODE_PRIVATE)
        myLanStringValue = sp?.getString("is_radio_name", "")

        try {
            vibrate = preferences.getBoolean(Tag_Vibrate, true)
            sound = preferences.getBoolean(Tag_Sound, true)
            round = preferences.getString(Tag_Round, Text_2).toString()
        } catch (e: Exception) {
        }

        databaseGst = DatabaseGst(activity)
        setHasOptionsMenu(true)

        try {
            if (tbAdsNameDao.getADS()?.isNotEmpty() == true) {
                if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
                }
            } else {
                val handler = Handler(Looper.getMainLooper())
                val runnable = object : Runnable {
                    override fun run() {
                        if (tbAdsNameDao.getADS()?.isNotEmpty() == true) {
                            if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
                            }
                        } else {
                            handler.postDelayed(this, 500)
                        }
                    }
                }
                handler.postDelayed(runnable, 500)
            }
        } catch (e: NullPointerException) {
        }
    }

    private fun initDatabase() {
        val sku = RoomDb.roomOrderDao.getRoomOrder()
        if (!sku.isNullOrEmpty()) {
            sku.forEach {
                val diff: Long = Calendar.getInstance().timeInMillis - it.purchaseTime
                val dayCount = diff.toFloat() / (24 * 60 * 60 * 1000)
                val days = dayCount.roundToLong()
                val totalDays = it.month

                val sharedPref = activity?.getSharedPreferences("PREFS_NAME", 0)
                val sdf = SimpleDateFormat("yyyyMMdd")
                val currentDate = sdf.format(Date())
                if (sharedPref?.getString("LAST_LAUNCH_DATE", "nodate")!!.contains(currentDate)) {
                    // Date matches. User has already Launched the app once today. So do nothing.
                } else {
                    sharedPref.edit().putString("LAST_LAUNCH_DATE", currentDate)?.apply()
                }
            }
        }
        getSkuData()
    }

    private fun getSkuData() {
        val handler = Handler(Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                val skuListData = tbSkuDao.getData()
                if (!skuListData.isNullOrEmpty()) {
                    inAppDetail()
                } else {
                    handler.postDelayed(this, 1000)
                }
            }
        }
        handler.postDelayed(runnable, 1000)
    }

    fun inAppDetail() {
        try {
            val skuListData = tbSkuDao.getData()
            if (!skuListData.isNullOrEmpty())
                inApp.startConnection(object : BillingClientStateListener {
                    override fun onBillingSetupFinished(billingResult: BillingResult) {
                        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                            skuListData.forEach {
                                val productList =
                                    listOf(
                                        QueryProductDetailsParams.Product.newBuilder()
                                            .setProductId(it.sku)
                                            .setProductType(BillingClient.ProductType.SUBS)
                                            .build()
                                    )

                                val params =
                                    QueryProductDetailsParams.newBuilder()
                                        .setProductList(productList)

                                inApp.queryProductDetailsAsync(params.build()) { billingResult, productDetailsList ->
                                    if (productDetailsList != null && productDetailsList.isNotEmpty()) {
//                                        listDetailsMain = productDetailsList as List<ProductDetails>
                                        listDetailsMain.addAll(productDetailsList)
                                    }
                                }
                            }


                            inApp.queryPurchaseHistoryAsync(BillingClient.SkuType.SUBS) { billingResult1, list ->
                                if (list != null) {
                                    list.forEach {
                                        val diff: Long =
                                            Calendar.getInstance().timeInMillis - it.purchaseTime
                                        val dayCount = diff.toFloat() / (24 * 60 * 60 * 1000)
                                        val days = dayCount.roundToLong()

                                        val originalJson = JSONObject(it.originalJson)
                                        val productId = originalJson.getString("productId")
                                        skuListData.forEach { itSub ->
                                            if (productId == itSub.sku) {
                                                val totalDays = itSub.validity.toInt() * 30
                                                if (days <= totalDays) {
                                                    val order = RoomOrder()
                                                    order.orderId = productId
                                                    order.purchaseTime = it.purchaseTime
                                                    order.month = itSub.validity.toInt() * 30
                                                    roomOrderDao.insertRoomOrder(order)
                                                }
                                            }
                                        }
                                    }
                                    val sku = roomOrderDao.getRoomOrder()
                                    if (!sku.isNullOrEmpty()) {
                                        sku.forEach {
                                            val diff: Long =
                                                Calendar.getInstance().timeInMillis - it.purchaseTime
                                            val dayCount = diff.toFloat() / (24 * 60 * 60 * 1000)
                                            val days = dayCount.roundToLong()
                                            val totalDays = it.month
                                        }
                                    }
                                }
                            }
                        }
                    }

                    override fun onBillingServiceDisconnected() {

                    }
                }) else {
            }
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: ArrayIndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: JsonSyntaxException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = LayoutCalculatorActivityBinding.inflate(inflater, container, false)
        e("TAG_IS_PREMIUM", "onCreateView " + premium_On)
        if (premium_On == 0) {
            refreshView()
        }
        return binding.root
    }

    fun View.clickWithDebounce(debounceTime: Long = 600L, action: () -> Unit) {
        this.setOnClickListener(object : View.OnClickListener {
            private var lastClickTime: Long = 0

            override fun onClick(v: View) {
                if (SystemClock.elapsedRealtime() - lastClickTime < debounceTime) return
                else action()

                lastClickTime = SystemClock.elapsedRealtime()
            }
        })
    }

    /*@SuppressLint("WrongConstant")
    override fun onClick(v: View) {

        var buttonPressed: String? = null
        try {
            count++

            if (gstDisplayString.length!! >= 10) {
                binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 50f)
            } else {
                binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 60f)
            }

            if (vibrate) {

                val vibrator = context?.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(
                            50,
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )
                } else {

                    @Suppress("DEPRECATION")
                    vibrator.vibrate(50)
                }
            }

            if (sound) {
                myAudioManager?.playSoundEffect(SoundEffectConstants.CLICK, 0.7f)
            }


            buttonPressed = (v as Button).text.toString()

            Log.e("=============", "onClick: " + buttonPressed)

            if (buttonPressed.compareTo(Text_Check) != 0) {
                if (buttonPressed.compareTo(Text_equal) != 0)
                    checkIndex = -1
                else if (checkIndex >= 0) { //Pressing '=' will show current result while checking
                    binding.textView1.text = decimalformat.format(gstresultArray[checkIndex])
                    binding.textView2.text = Text_equal
                    return
                }
            }

            if (buttonPressed.compareTo(Text_Auto_Replay) == 0) {
                if (autoReply != null) return
            } else if (autoReply != null) {
                autoReply?.cancel()
                autoReply = null
                binding.textView2.text = if (gstDisplayString.compareTo("") == 0) gstoperatorArray[gstoperatorArray.size].toString()
                else " "
                binding.textView1.text = if (gstDisplayString.compareTo("") == 0) decimalformat.format(gstresultArray[gstresultArray.size - 1])
                else gstDisplayString
                binding.stepCount.text = decimalformat.format((gstresultArray.size + if (gstDisplayString.compareTo("") == 0) 0 else 1).toLong())
            }

            if (buttonPressed.compareTo(resources.getString(R.string.button_chnge_gst)) == 0) {
                if (isOpenRecently()) return //this one line enough
                slabDialog()
            }

            try {
                if (buttonPressed == slab_p1) {
                    gstCalculatiion(Gst_value(0, buttonPressed), Text_plus)
                } else if (buttonPressed == slab_p2) {
                    gstCalculatiion(Gst_value(1, buttonPressed), Text_plus)
                } else if (buttonPressed == slab_p3) {
                    gstCalculatiion(Gst_value(2, buttonPressed), Text_plus)
                } else if (buttonPressed == slab_p4) {
                    gstCalculatiion(Gst_value(3, buttonPressed), Text_plus)
                } else if (buttonPressed == slab_p5) {
                    gstCalculatiion(Gst_value(4, buttonPressed), Text_plus)
                } else if (buttonPressed == slab_m1) {
                    gstCalculatiion(Gst_value(5, buttonPressed), Text_minus)
                } else if (buttonPressed == slab_m2) {
                    gstCalculatiion(Gst_value(6, buttonPressed), Text_minus)
                } else if (buttonPressed == slab_m3) {
                    gstCalculatiion(Gst_value(7, buttonPressed), Text_minus)
                } else if (buttonPressed == slab_m4) {
                    gstCalculatiion(Gst_value(8, buttonPressed), Text_minus)
                } else if (buttonPressed == slab_m5) {
                    gstCalculatiion(Gst_value(9, buttonPressed), Text_minus)
                }
            } catch (e: NumberFormatException) {
                e.printStackTrace()
            } catch (e: NullPointerException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }


            try {
                when (buttonPressed) {
                    Text_Auto_Replay -> {
                        if (gstoperandArray.size == 0)
                            return

                        val TickTime = 1000//milliseconds
                        autoReply = object : CountDownTimer(
                            (TickTime * (gstoperandArray.size + 2)).toLong(),
                            TickTime.toLong()
                        ) {
                            var m = 0

                            override fun onTick(millisUntilFinished: Long) {
                                if (m < gstoperandArray.size) {
                                    binding.textView2.text = gstoperatorArray[m].toString()
                                    binding.textView1.text = decimalformat.format(gstoperandArray[m])
                                    m++
                                    binding.stepCount.text = decimalformat.format(m.toLong())
                                } else {
                                    cancel()

                                    binding.textView2.text = if (gstDisplayString.compareTo("") == 0)
                                        gstoperatorArray[m - 1].toString()
                                    else
                                        " "
                                    binding.textView1.text = if (gstDisplayString.compareTo("") == 0)
                                        decimalformat.format(gstoperandArray[gstoperandArray.size - 1])
                                    else
                                        gstDisplayString
                                    binding.stepCount.text = decimalformat.format(
                                        (gstresultArray.size + if (gstDisplayString.compareTo("") == 0) 0 else 1).toLong()
                                    )

                                    autoReply = null
                                }
                            }

                            override fun onFinish() {}
                        }.start()
                    }
                    Text_Check ->


                        try {
                            if (gstoperandArray.size == 0)
                                return

                            binding.textRep.visibility = View.VISIBLE
                            checkIndex++

                            checkIndex %= gstresultArray.size

                            binding.textView2.text = gstoperatorArray[checkIndex].toString()
                            binding.textView1.text = decimalformat.format(gstoperandArray[checkIndex])
                            binding.stepCount.text = decimalformat.format((checkIndex + 1).toLong())

                            if ((gstoperandArray.size - 1) == checkIndex && gstoperatorArray[gstoperatorArray.size - 2] == '=') {
                                binding.textView2.text = "="
                                binding.textAns.visibility = View.VISIBLE
                            } else
                                binding.textAns.visibility = View.GONE

                        } catch (e: IndexOutOfBoundsException) {
                            e.printStackTrace()
                        } catch (e: NullPointerException) {
                            e.printStackTrace()
                        } catch (e: NumberFormatException) {
                            e.printStackTrace()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }


                    Text_1, Text_2, Text_3, Text_4, Text_5, Text_6, Text_7, Text_8, Text_9, Text_0 -> {

                        if (gstDisplayString.length!! >= decimalformat.maximumIntegerDigits +
                            (if (gstDisplayString.contains(".")) 1 else 0) +
                            if (gstDisplayString.contains("-")) 1 else 0
                        )
                            return

                        gstDisplayString += buttonPressed
                        if (!gstDisplayString.contains(".")) {
                            try {
                                gstDisplayString = decimalformat.format(
                                    java.lang.Double.parseDouble(gstDisplayString)
                                )
                            } catch (e: NumberFormatException) {
                                e.printStackTrace()
                            }

                        }

                        for (i in gstDisplayString.indices) {
                            if (gstDisplayString.contains(Text_Dot)) {
                                binding.textView2.text = " "
                                binding.textView1.text = gstDisplayString
                                preoprandstring = binding.textView1.text.toString()
                            } else {
                                val longval = java.lang.Long.parseLong(gstDisplayString)
                                t1 = DecimalFormat(Pattern).format(longval)
                                binding.textView2.text = " "
                                binding.textView1.text = t1
                            }
                        }
                        binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                    }

                    Text_Dot -> {
                        if (!gstDisplayString.contains(Text_Dot)) gstDisplayString += if (gstDisplayString.compareTo("") == 0) "0." else buttonPressed

                        binding.textView2.text = " "
                        binding.textView1.text = gstDisplayString
                        binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                    }

                    Text_00 -> {
                        if (gstDisplayString.length >= decimalformat.maximumIntegerDigits + (if (gstDisplayString.contains(Text_Dot)) 1 else 0) + if (gstDisplayString.contains(Text_Mines)) 1 else 0) return
                        if (gstDisplayString.compareTo("") == 0 || gstDisplayString.compareTo("0") == 0) return
                        var t1: String = gstDisplayString as String
                        t1 += Text_00
                        for (i in t1.indices) {
                            if (i > 9) {
                                t1 = t1.substring(0, t1.length - 1)
                                return
                            }
                        }
                        gstDisplayString = t1
                        if (gstDisplayString.contains(".")) {

                            binding.textView2.text = " "
                            binding.textView1.text = gstDisplayString
                            preoprandstring = binding.textView1.text.toString()

                        } else {

                            val longval = java.lang.Long.parseLong(gstDisplayString)
                            val formater = DecimalFormat(Pattern)
                            val f1 = formater.format(longval)
                            t1 = f1
                            // pretempstring =f1;
                            binding.textView2.text = " "
                            binding.textView1.text = t1
                        }
                        binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                    }


                    Text_Correct -> {
                        if (savedOperator != Text_equal_Char && prevOperator == Text_equal_Char && gstDisplayString.compareTo(
                                ""
                            ) == 0
                        )
                            gstDisplayString = decimalformat.format(result)

                        if (gstDisplayString.compareTo("") == 0)
                            return

                        gstDisplayString =
                            gstDisplayString.substring(0, gstDisplayString.length - 1)

                        if (gstDisplayString.compareTo("") == 0 || gstDisplayString.compareTo("-") == 0)
                            gstDisplayString = Text_0

                        binding.textView2.text = " "
                        binding.textView1.text = gstDisplayString
                        binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                    }


                    Text_C -> {


                        if (autoReply != null) {
                            autoReply?.cancel()
                            autoReply = null
                        }
                        for (i in gstoperandArray.indices) {
                            operandArray1.add(gstoperandArray[i])
                            operatorArray1.add(gstoperatorArray[i])
                            resultArray1.add(gstresultArray[i])

                        }

                        gstoperandArray = ArrayList()
                        gstoperatorArray = ArrayList()
                        gstresultArray = ArrayList()

                        prevOperator = Text_equal_Char
                        savedOperator = Text_equal_Char
                        savedOperator = Text_equal_Char
                        memoryOpretor = Text_equal_Char
                        savedOperand = 0.0
                        result = 0.0

                        checkIndex = -1
                        clearall()

                        gstDisplayString = ""


                        mCalculatorMemory = 0.0
                        binding.Msymbol.text = " "
                        binding.textView2.text = " "
                        binding.textView1.text = Text_0
                        binding.stepCount.text = decimalformat.format(gstresultArray.size.toLong())//0

                        binding.gstA.visibility = View.GONE
                        binding.gstGst.visibility = View.GONE
                        binding.gstA.visibility = View.GONE
                        binding.gstGst.visibility = View.GONE

                        binding.textRep.visibility = View.GONE
                        binding.textAns.visibility = View.GONE
                    }

                    Text_CE -> {
                        if (gstDisplayString.compareTo("") == 0)
                            return
                        gstDisplayString = Text_0
                        binding.textView2.text = " "
                        binding.textView1.text = gstDisplayString
                        binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                    }

                    Text_root ->
                        try {
                            gstDisplayString = binding.textView1.text.toString()
                            if (gstDisplayString.contains(",")) gstDisplayString = gstDisplayString.replace(",", "")

                            if (gstDisplayString.compareTo("") == 0) gstDisplayString = Text_0
                            else gstDisplayString = decimalformat.format(Math.sqrt(java.lang.Double.parseDouble(gstDisplayString)))

                            var cd = java.lang.Double.parseDouble(gstDisplayString)
                            cd = round_off(round, cd)
                            val ans = cd.toString()
                            binding.textView2.text = " "

                            operator_history.add('√')
                            result_calculate = java.lang.Double.valueOf(cd)
                            binding.textView1.text = ans

                            binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                        } catch (e: NumberFormatException) {
                            e.printStackTrace()
                        }

                    Text_MC -> mCalculatorMemory = 0.0

                    Text_mPlus -> {
                        var test1: String? = null
                        try {
                            if (gstDisplayString.compareTo("") == 0 && gstresultArray.size == 0)
                                return
                            test1 = ""
                            for (i in gstoperatorArray.indices) {
                                test1 = gstoperatorArray[i].toString()
                            }
                            if (test1 != "") {
                                test1 = binding.textView1.text.toString() + test1
                                test1 = test1.substring(0, test1.length - 1)
                                gstDisplayString = test1
                            } else {
                                test1 = binding.textView1.text.toString()
                                gstDisplayString = test1
                            }

                            if (gstDisplayString != "0") {
                                val a = gstDisplayString.replace(",", "")
                                val j2 = java.lang.Double.parseDouble(a)
                                gstresultArray.add(j2)
                                MemoryArray.add(j2)
                                binding.Msymbol.text = Text_mPlus
                                gstDisplayString = ""

                                try {
                                    if (binding.textView2.text.toString() == " " && MemoryArray != null) {

                                        if (MemoryArray.size > 1) {
                                            binding.textView1.text = mValue(
                                                memoryOpretor,
                                                MemoryArray!![MemoryArray.size - 2],
                                                MemoryArray!![MemoryArray.size - 1]
                                            )
                                            mCalculatorMemory += java.lang.Double.valueOf(binding.textView1.text.toString())
                                        } else {
                                            // mCalculatorMemory += if(gstDisplayString.compareTo("") == 0) decimalformat.format(MemoryArray!![MemoryArray.size - 1]) else gstDisplayString.let { java.lang.Double.parseDouble(it) }
                                        }

                                        MemoryArray.add(result)
                                        binding.textView2.text = Text_equal
                                        prevOperator = Text_equal_Char
                                    }
                                } catch (e: NumberFormatException) {
                                    e.printStackTrace()
                                } catch (e: NullPointerException) {
                                    e.printStackTrace()
                                } catch (e: ArrayIndexOutOfBoundsException) {
                                    e.printStackTrace()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }

                            }
                        } catch (e: NumberFormatException) {
                            e.printStackTrace()
                        }

                    }
                    Text_mMins -> try {
                        if (gstDisplayString.compareTo("") == 0 && gstresultArray.size == 0)
                            return

                        val test = ""
                        var H = ""

                        if (test != "") {
                            H = binding.textView1.text.toString()
                            H = H + test
                            H = H.substring(0, H.length - 1)
                            gstDisplayString = H

                        } else {
                            H = binding.textView1.text.toString()
                            gstDisplayString = H

                        }

                        if (gstDisplayString != Text_0) {
                            val a = gstDisplayString.replace(",", "")
                            val j2 = java.lang.Double.parseDouble(a)
                            gstresultArray.add(j2)
                            MemoryArray.add(j2)

                            binding.Msymbol.text = Text_mMins
                            gstDisplayString = ""


                            try {
                                if (binding.textView2.text.toString() == " " && MemoryArray != null) {

                                    if (MemoryArray.size > 1) {
                                        binding.textView1.text = mValue(
                                            memoryOpretor,
                                            MemoryArray!![MemoryArray.size - 2],
                                            MemoryArray!![MemoryArray.size - 1]
                                        )
                                        mCalculatorMemory -= java.lang.Double.valueOf(binding.textView1.text.toString())
                                    } else {
                                        mCalculatorMemory -= java.lang.Double.parseDouble(
                                            if (gstDisplayString.compareTo(
                                                    ""
                                                ) == 0
                                            ) decimalformat.format(MemoryArray!![MemoryArray.size - 1]) else gstDisplayString
                                        )
                                    }

                                    MemoryArray.add(result)
                                    binding.textView2.text = Text_equal
                                    prevOperator = Text_equal_Char
                                }
                            } catch (e: NumberFormatException) {
                                e.printStackTrace()
                            } catch (e: NullPointerException) {
                                e.printStackTrace()
                            } catch (e: ArrayIndexOutOfBoundsException) {
                                e.printStackTrace()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    } catch (e: NumberFormatException) {
                        e.printStackTrace()
                    }

                    Text_MR -> {
                        gstDisplayString = decimalformat.format(mCalculatorMemory)

                        binding.textView2.text = " "
                        binding.textView1.text = gstDisplayString
                        binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                    }
                    Text_GT -> {


                        var tmp = 0.0
                        run {
                            var i = 0
                            while (i < gstoperandArray.size && i < gstoperatorArray.size) {
                                if (gstoperatorArray[i] == ':')
                                    tmp += gstoperandArray[i]
                                i++
                            }
                        }
                        gstDisplayString = decimalformat.format(tmp)

                        binding.textView2.text = " "
                        binding.textView1.text = gstDisplayString
                        binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())


                        for (i in grand_total.indices) {
                            FirstBuff.append(
                                "+" + "      " +
                                        grand_total[i] + "\n"
                            )
                        }


                        FirstBuff.append(
                            "---------------------------" + "\n" + "GT   =" + "      " +
                                    sum_tot(grand_total) + "\n"
                        )


                        grand_total.clear()
                        FirstBuff.setLength(0)
                        FirstBuff.trimToSize()
                    }
                    Text_Plus, Text_Mines, Text_Multiple, Text_Devide, Text_equal, Text_MU, Text_Module -> {

                        if (buttonPressed[0] == Text_M_Char) {
                            is_mu = true

                            if (gstDisplayString != "") {
                                mu_oprand = java.lang.Double.valueOf(gstDisplayString)
                            }
                        }

                        if (prevOperator == Text_M_Char && buttonPressed[0] != Text_Module_Char)
                            return
                        if (prevOperator == Text_equal_Char || prevOperator == Text_Module_Char) {
                            if (buttonPressed[0] == Text_Module_Char) {
                                return
                            } else if (buttonPressed[0] == Text_equal_Char) {

                                if (savedOperator != Text_equal_Char) {
                                    try {
                                        result =
                                            if (gstDisplayString.compareTo("") == 0) result else java.lang.Double.parseDouble(
                                                gstDisplayString
                                            )//For correct button pressed on result
                                        when (savedOperator) {

                                            Text_Plus_Char -> result += savedOperand
                                            Text_Mines_Char -> result -= savedOperand
                                            Text_Multiple_Char -> result *= savedOperand
                                            Text_Devide_Char -> result /= savedOperand
                                            Text_Module_Char -> {
                                                var symbol: Char = 0.toChar()
                                                for (k in operator_history.indices) {
                                                    symbol = operator_history[k]
                                                }


                                                if (symbol == Text_Plus_Char) {
                                                    result = oprand_one + result
                                                } else if (symbol == Text_Mines_Char) {
                                                    result = oprand_one - result
                                                } else if (symbol == Text_Multiple_Char) {
                                                    result = oprand_one * result
                                                } else if (symbol == '/') {
                                                    result = oprand_one / result
                                                } else {
                                                }
                                            }
                                        }

                                        gstCalculatorDisplay2 = result.toString()
                                        gstCalculatorDisplay2 =
                                            gstCalculatorDisplay2.replace(".0", "")
                                        try {
                                            if (gstCalculatorDisplay2.contains(Text_Dot)) {
                                                binding.textView2.text = buttonPressed
                                                binding.textView1.text = decimalformat.format(result)

                                            } else {
                                                val formater = DecimalFormat(Pattern)
                                                val f1 = formater.format(result)
                                                display1 = f1
                                                binding.textView2.text = buttonPressed
                                                binding.textView1.text = display1


                                            }
                                        } catch (e: Exception) {

                                            e.printStackTrace()
                                        }

                                        if (gstoperatorArray[gstoperatorArray.size - 1] != ':')
                                            gstoperandArray[gstoperandArray.size - 1] = savedOperand
                                        gstoperatorArray[gstoperatorArray.size - 2] = savedOperator
                                        gstoperatorArray[gstoperatorArray.size - 1] =
                                            buttonPressed[0]
                                        gstresultArray[gstresultArray.size - 1] = result
                                        gstoperandArray.add(result)
                                        gstoperatorArray.add(':')
                                        gstresultArray.add(result)
                                        MemoryArray.add(result)
                                        binding.stepCount.text =
                                            decimalformat.format((gstresultArray.size + 1).toLong())
                                        gstDisplayString = ""
                                    } catch (e: NumberFormatException) {
                                        e.printStackTrace()
                                    } catch (e: ArrayIndexOutOfBoundsException) {
                                        e.printStackTrace()
                                    } catch (e: NullPointerException) {
                                        e.printStackTrace()
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }

                                }
                            } else {
                                try {

                                    result =
                                        if (gstDisplayString.compareTo("") == 0) result else java.lang.Double.parseDouble(
                                            binding.textView1.text.toString().replace(",", "")
                                        )

                                    prevOperator = buttonPressed[0]
                                    savedOperator = buttonPressed[0]
                                    memoryOpretor = buttonPressed[0]

                                    binding.textView2.text = buttonPressed
                                    binding.textView1.text =
                                        decimalformat.format(result)//Redundant for AutoReply And Check case.
                                    binding.stepCount.text =
                                        decimalformat.format((gstresultArray.size + 1).toLong())

                                    gstoperandArray.add(result)
                                    gstoperatorArray.add(buttonPressed[0])
                                    gstresultArray.add(result)
                                    MemoryArray.add(result)

                                    if (gstDisplayString != "") {
                                        oprand_one =
                                            java.lang.Double.parseDouble(gstDisplayString)
                                    }

                                    if (is_oprand == 0) {

                                        if (is_oprand_renew == 1) {
                                            gstDisplayString = binding.textView1.text.toString()
                                            oprand_one =
                                                java.lang.Double.parseDouble(gstDisplayString)
                                            is_oprand_renew = 0
                                        }

                                        if (gstDisplayString != "") {
                                            operandFirst_history.add(oprand_one)
                                            is_oprand = 1
                                        }
                                    }

                                    gstDisplayString = ""
                                } catch (e: NumberFormatException) {
                                    e.printStackTrace()
                                } catch (e: ArrayIndexOutOfBoundsException) {
                                    e.printStackTrace()
                                } catch (e: NullPointerException) {
                                    e.printStackTrace()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }

                            }
                        } else if (gstDisplayString.compareTo("") == 0) {

                            if (buttonPressed[0] != Text_equal_Char
                                && prevOperator != Text_M_Char
                                && buttonPressed[0] != Text_Module_Char
                            ) {
                                prevOperator = buttonPressed[0]
                                savedOperator = buttonPressed[0]
                                memoryOpretor = buttonPressed[0]


                                gstoperatorArray[gstoperatorArray.size - 1] = buttonPressed[0]

                                binding.textView2.text = buttonPressed
                                binding.textView1.text = if (gstDisplayString.compareTo("") == 0)
                                //I think textView1String will always be "" here.
                                    decimalformat.format(gstresultArray[gstresultArray.size - 1])
                                else
                                    gstDisplayString//Redundant for AutoReply And Check case.
                                binding.stepCount.text =
                                    decimalformat.format(gstresultArray.size.toLong())//Redundant for AutoReply And Check case.
                            }
                        } else {

                            try {
                                oprand_two = java.lang.Double.parseDouble(gstDisplayString)
                                operandSecond_history.add(oprand_two)
                                two = gstCalculationString

                                operator_history.add(prevOperator)


                                when (prevOperator) {

                                    Text_Plus_Char -> if (buttonPressed[0] == Text_Module_Char) {
                                        result += result * java.lang.Double.parseDouble(
                                            gstDisplayString
                                        ) / 100
                                        result = round_off(Text_5, result)
                                    } else {
                                        result += java.lang.Double.parseDouble(gstDisplayString)
                                        result = round_off(Text_5, result)
                                    }
                                    Text_Mines_Char -> if (buttonPressed[0] == Text_Module_Char) {
                                        result -= result * java.lang.Double.parseDouble(
                                            gstDisplayString
                                        ) / 100
                                        result = round_off(Text_5, result)
                                    } else {
                                        result -= java.lang.Double.parseDouble(gstDisplayString)
                                        result = round_off(Text_5, result)
                                    }
                                    Text_Multiple_Char -> if (buttonPressed[0] == Text_Module_Char) {
                                        result =
                                            result * java.lang.Double.parseDouble(gstDisplayString) / 100
                                        result = round_off(Text_5, result)
                                    } else {
                                        result *= java.lang.Double.parseDouble(gstDisplayString)
                                        result = round_off(Text_5, result)
                                    }
                                    Text_Devide_Char -> if (buttonPressed[0] == Text_Module_Char) {
                                        result = result * (100 / java.lang.Double.parseDouble(
                                            gstDisplayString
                                        ))
                                        result = round_off(Text_5, result)
                                    } else {
                                        result /= java.lang.Double.parseDouble(gstDisplayString)
                                        result = round_off(Text_5, result)
                                    }
                                    Text_M_Char -> {
                                        result = result * 100 / (100 - java.lang.Double.parseDouble(
                                            gstDisplayString
                                        ))
                                        result = round_off(Text_5, result)
                                    }
                                }
                                prevOperator = buttonPressed[0]
                                if (buttonPressed[0] != Text_equal_Char) {
                                    savedOperator = buttonPressed[0]
                                    memoryOpretor = buttonPressed[0]
                                }
                                savedOperand = java.lang.Double.parseDouble(gstDisplayString)
                                binding.textView2.text = buttonPressed
                                result_calculate = result

                                if (is_oprand == 1) {
                                    operandFirst_history.add(oprand_two)
                                }
                                result_history.add(result_calculate)
                                result_calculate = round_off(round, result_calculate)
                                val d1 = result_calculate.toString()


                                try {
                                    if (preoprandstring.contains(Text_Dot) || gstDisplayString.contains(
                                            Text_Dot
                                        ) || d1.contains(Text_Dot)
                                    ) {


                                        binding.textView2.text = " "
                                        binding.textView1.text = String.format("%,.2f", result_calculate)
                                        preoprandstring = ""
                                    } else if (preoprandstring == "" && !gstDisplayString.contains(".")) {

                                        val formater = DecimalFormat(Pattern)
                                        val f1 = formater.format(result_calculate)
                                        display1 = f1
                                        binding.textView2.text = " "
                                        binding.textView1.text = display1

                                    } else {
                                    }
                                } catch (e: Exception) {

                                    e.printStackTrace()
                                }

                                binding.stepCount.text =
                                    decimalformat.format((gstresultArray.size + 1).toLong())
                                gstoperandArray.add(savedOperand)
                                gstoperatorArray.add(buttonPressed[0])
                                gstresultArray.add(result)
                                MemoryArray.add(result)
                                if (buttonPressed[0] == Text_equal_Char || buttonPressed[0] == Text_Module_Char) {
                                    operator_history.add(buttonPressed[0])
                                    is_equal = !is_mu
                                    result_history.add(result)
                                    binding.stepCount.text = decimalformat.format((gstresultArray.size + 1).toLong())
                                    gstoperandArray.add(result)
                                    gstoperatorArray.add(':')
                                    gstresultArray.add(result)
                                    MemoryArray.add(result)
                                    grand_total.add(result)
                                }
                                gstDisplayString = ""
                            } catch (e: NumberFormatException) {
                                e.printStackTrace()
                            } catch (e: ArrayIndexOutOfBoundsException) {
                                e.printStackTrace()
                            } catch (e: NullPointerException) {
                                e.printStackTrace()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                        }
                    }
                }
            } catch (e: NumberFormatException) {
                e.printStackTrace()
            } catch (e: NullPointerException) {
                e.printStackTrace()
            } catch (e: ArrayIndexOutOfBoundsException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        } catch (e: Resources.NotFoundException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: IndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: NumberFormatException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }*/


    @SuppressLint("WrongConstant")
    override fun onClick(v: View) {
        try {
            count++
            if (mCalculatorDisplayString.length >= 10) {
                binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 50f)
            } else {
                binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 60f)
            }

            if (vibrate) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    (requireActivity().getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.vibrate(
                        VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    (requireActivity().getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(50)
                }
            }
            if (sound) myAudioManager?.playSoundEffect(SoundEffectConstants.CLICK, 0.7f)
            buttonPressed = (v as Button).text.toString()
            // int buttonpress = v.getId();
            e("buttonPressed:", "onClick: $buttonPressed")
            if (buttonPressed!!.compareTo("Check") != 0) {
                if (buttonPressed!!.compareTo("=") != 0) checkIndex = -1
                else if (checkIndex >= 0) { //Pressing '=' will show current result while checking
                    binding.textView1.text = decimalformat.format(resultArray!![checkIndex])
                    binding.textView2.text = "="
                    return
                }
            }
            if (buttonPressed!!.compareTo("Auto Replay") == 0) {
                if (autoReply != null) return
            } else if (autoReply != null) {
                autoReply!!.cancel()
                autoReply = null

                binding.textView2.text =
                    if (mCalculatorDisplayString.compareTo("") == 0) operatorArray?.get(
                        operatorArray!!.size
                    ).toString() else " "
                binding.textView1.text =
                    if (mCalculatorDisplayString.compareTo("") == 0) decimalformat.format(
                        resultArray!![resultArray!!.size - 1]
                    ) else mCalculatorDisplayString
                binding.stepCount.text = decimalformat.format(
                    (resultArray!!.size + if (mCalculatorDisplayString.compareTo("") == 0) 0 else 1).toLong()
                )
            }
            if (buttonPressed!!.compareTo(resources.getString(R.string.button_chnge_gst)) == 0) {
                v.setClickable(false)
                slabDialog()
                Handler(Looper.getMainLooper()).postDelayed({ v.setClickable(true) }, 2000)
            }
            when (buttonPressed) {
                pref_values[0] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    gst_val = result / 100.0f * gst_val(0)
                    total_gst = result + gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('A')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    oprand_one = result
                    GST = "A"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('A')
                    result_history.add(total_gst)


                    /*gst_dis = numberformat.format(total_gst);
                            String gst_valdist = numberformat.format(gst_val);
                            String cgst_valt = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdist = String.format("%,.2f", gst_val)
                    val cgst_valt = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdist"
                    binding.cgstA.text = "CGST/SGST = $cgst_valt"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[1] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = java.lang.Double.valueOf(mCalculatorDisplay1)
                    gst_val = result / 100.0f * gst_val(1)
                    total_gst = result + gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('B')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    oprand_one = result
                    GST = "B"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('B')
                    result_history.add(total_gst)


                    /*gst_dis = numberformat.format(total_gst);
                            String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)

                    /* String gst_valdist = numberformat.format(gst_val);
                                String cgst_valt = numberformat.format(gst_val1);*/if (gst_dis.length >= 11) {
                        binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 50f)
                    } else {
                        binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 60f)
                    }
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[2] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    gst_val = result / 100.0f * gst_val(2)
                    total_gst = result + gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('C')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    oprand_one = result
                    GST = "C"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('C')
                    result_history.add(total_gst)

                    /*gst_dis = numberformat.format(total_gst);

                            // gst_dis = total_gst.toString();
                            String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/
                    gst_dis = String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[3] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    gst_val = result / 100.0f * gst_val(3) //(1000/100)*18=180
                    total_gst = result + gst_val //1180
                    gst_val1 = gst_val / 2

                    /*gst_val = Math.round(gst_val * 100.0) / 100.0;
                                gst_val1 = Math.round(gst_val1 * 100.0) / 100.0;
                                total_gst = Math.round(total_gst * 100.0) / 100.0;*/result_gst =
                        total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    MemoryArray.add(total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('D')
                    resultArray?.add(total_gst)
                    oprand_one = result
                    GST = "D"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('D')
                    result_history.add(total_gst)

                    /*gst_dis = numberformat.format(total_gst);

                            // gst_dis = total_gst.toString();
                            String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[4] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    gst_val = result / 100.0f * gst_val(4)
                    total_gst = result + gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('E')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    gst_dis = numberformat.format(total_gst)
                    oprand_one = result
                    GST = "E"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('E')
                    result_history.add(total_gst)

                    //  gst_dis = total_gst.toString();
                    /* String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[5] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    //gst_val=(screen /100.0f)*5;
                    gst_val = result - result * (100.0 / gst_val(5))
                    total_gst = result - gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('a')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    gst_dis = numberformat.format(total_gst)
                    oprand_one = result
                    GST = "a"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('a')
                    result_history.add(total_gst)

                    // gst_dis = total_gst.toString().trim();
                    /*String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[6] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    //gst_val=(screen /100.0f)*5;
                    gst_val = result - result * (100.0 / gst_val(6))
                    total_gst = result - gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('b')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    gst_dis = numberformat.format(total_gst)
                    oprand_one = result
                    GST = "b"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('b')
                    result_history.add(total_gst)

                    // gst_dis = total_gst.toString().trim();
                    /* String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[7] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    //gst_val=(screen /100.0f)*12;
                    gst_val = result - result * (100.0 / gst_val(7))
                    total_gst = result - gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('c')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    gst_dis = numberformat.format(total_gst)
                    oprand_one = result
                    GST = "c"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('c')
                    result_history.add(total_gst)

                    //  gst_dis = total_gst.toString();
                    /* String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)


                    //DecimalFormat dfs = new DecimalFormat("#.##");
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[8] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    // gst_val=(screen /100.0f)*15.25; //(1000/100)*18=180
                    gst_val = result - result * (100.0 / gst_val(8)) //1000-(1000*(100/118))=
                    total_gst = result - gst_val //84.74
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('d')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    gst_dis = numberformat.format(total_gst)
                    oprand_one = result
                    GST = "d"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('d')
                    result_history.add(total_gst)

                    // gst_dis = total_gst.toString();
                    /*String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }

                pref_values[9] + "%" -> {
                    mCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
                    result = mCalculatorDisplay1.toDouble()
                    //gst_val=(screen /100.0f)*28;
                    gst_val = result - result * (100.0 / gst_val(9))
                    total_gst = result - gst_val
                    gst_val1 = gst_val / 2
                    result_gst = total_gst
                    gst_val = round_off(round, gst_val)
                    gst_val1 = round_off(round, gst_val1)
                    total_gst = round_off(round, total_gst)
                    operandArray?.add(total_gst)
                    operatorArray?.add('e')
                    resultArray?.add(total_gst)
                    MemoryArray.add(total_gst)
                    gst_dis = numberformat.format(total_gst)
                    oprand_one = result
                    GST = "e"
                    oprand_two = gst_val
                    oprand_result = total_gst
                    if (operator_history.size < 2) {
                        is_gst = true
                    } else {
                        ans_gst = true
                    }
                    operandFirst_history.add(result)
                    operator_history.add('e')
                    result_history.add(total_gst)

                    // gst_dis = total_gst.toString();
                    /* String gst_valdis = numberformat.format(gst_val);
                            String cgst_val = numberformat.format(gst_val1);*/gst_dis =
                        String.format("%,.2f", total_gst)
                    val gst_valdis = String.format("%,.2f", gst_val)
                    val cgst_val = String.format("%,.2f", gst_val1)
                    binding.textView1.text = gst_dis
                    binding.gstA.text = "IGST = $gst_valdis"
                    binding.cgstA.text = "CGST/SGST = $cgst_val"
                    binding.gstA.visibility = View.VISIBLE
                    binding.gstGst.visibility = View.VISIBLE
                    binding.cgstA.visibility = View.VISIBLE
                    binding.cgstGst.visibility = View.VISIBLE
                }
            }
            when (buttonPressed) {
                "Auto Replay" -> {
                    if (operandArray!!.size == 0) return
                    val TickTime = 1000 //milliseconds
                    autoReply = object : CountDownTimer(
                        (TickTime * (operandArray!!.size + 2)).toLong(),
                        TickTime.toLong()
                    ) {
                        var m = 0
                        override fun onTick(millisUntilFinished: Long) {
                            if (m < operandArray!!.size) {
                                binding.textView2.text = operatorArray?.get(m).toString()
                                binding.textView1.text = decimalformat.format(operandArray!![m])
                                m++
                                binding.stepCount.text = decimalformat.format(m.toLong())
                            } else {
                                cancel()
                                binding.textView2.text =
                                    if (mCalculatorDisplayString.compareTo("") == 0) operatorArray?.get(
                                        m - 1
                                    ).toString() else " "
                                binding.textView1.text =
                                    if (mCalculatorDisplayString.compareTo("") == 0) decimalformat.format(
                                        operandArray!![operandArray!!.size - 1]
                                    ) else mCalculatorDisplayString
                                binding.stepCount.text = decimalformat.format(
                                    (resultArray!!.size + if (mCalculatorDisplayString.compareTo("") == 0) 0 else 1).toLong()
                                )
                                autoReply = null
                            }
                        }

                        override fun onFinish() {}
                    }.start()
                }

                "Check" -> {
                    e("Check", "Check Clicked.")
                    if (operandArray!!.size == 0) return
                    checkIndex++
                    checkIndex %= resultArray!!.size
                    binding.textView2.text = operatorArray?.get(checkIndex).toString()
                    binding.textView1.text = decimalformat.format(operandArray!![checkIndex])
                    binding.stepCount.text = decimalformat.format((checkIndex + 1).toLong())
                }

                "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" -> {
                    if (mCalculatorDisplayString.length >= decimalformat.maximumIntegerDigits + (if (mCalculatorDisplayString.contains(
                                "."
                            )
                        ) 1 else 0) + if (mCalculatorDisplayString.contains("-")) 1 else 0
                    ) return
                    mCalculatorDisplayString += buttonPressed //Applies for mCalculatorDisplayString="" too.
                    if (!mCalculatorDisplayString.contains(".")) mCalculatorDisplayString =
                        decimalformat.format(mCalculatorDisplayString.toDouble()) //Removes additional zeros.
                    run {
                        var i = 0
                        while (i < mCalculatorDisplayString.length) {
                            if (mCalculatorDisplayString.contains(".")) {
                                binding.textView2.text = " "
                                binding.textView1.text = mCalculatorDisplayString
                                preoprandstring = binding.textView1.text.toString()
                            } else {
                                val longval = mCalculatorDisplayString.toLong()
                                val formater = DecimalFormat("##,##,##,##,###")
                                val f1 = formater.format(longval)
                                t1 = f1
                                binding.textView2.text = " "
                                binding.textView1.text = t1
                            }
                            i++
                        }
                    }
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                }

                "." -> {
                    if (!mCalculatorDisplayString.contains(".")) mCalculatorDisplayString += if (mCalculatorDisplayString.compareTo(
                            ""
                        ) == 0
                    ) "0." else buttonPressed
                    binding.textView2.text = " "
                    binding.textView1.text = mCalculatorDisplayString
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                }

                "00" -> {
                    if (mCalculatorDisplayString.length >= decimalformat.maximumIntegerDigits +
                        (if (mCalculatorDisplayString.contains(".")) 1 else 0) + if (mCalculatorDisplayString.contains(
                                "-"
                            )
                        ) 1 else 0
                    ) return
                    if (mCalculatorDisplayString.compareTo("") == 0 || mCalculatorDisplayString.compareTo(
                            "0"
                        ) == 0
                    ) return
                    var t1 = mCalculatorDisplayString
                    t1 = t1 + "00"
                    run {
                        var i = 0
                        while (i < t1.length) {
                            if (i > 9) {
                                t1 = t1.substring(0, t1.length - 1)
                                break
                            }
                            i++
                        }
                    }
                    mCalculatorDisplayString = t1
                    if (mCalculatorDisplayString.contains(".")) {
                        binding.textView2.text = " "
                        binding.textView1.text = mCalculatorDisplayString
                        preoprandstring = binding.textView1.text.toString()
                    } else {
                        val longval = mCalculatorDisplayString.toLong()
                        val formater = DecimalFormat("##,##,##,##,###")
                        val f1 = formater.format(longval)
                        t1 = f1
                        // pretempstring =f1;
                        binding.textView2.text = " "
                        binding.textView1.text = t1
                    }
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                }

                "Correct" -> {
                    if (savedOperator != '=' && prevOperator == '=' && mCalculatorDisplayString.compareTo(
                            ""
                        ) == 0
                    ) mCalculatorDisplayString = decimalformat.format(result)
                    e(
                        "@@@@@@",
                        "onClick mCalculatorDisplayString savedOperator != '=' && prevOperator ==: $mCalculatorDisplayString"
                    )
                    if (mCalculatorDisplayString.compareTo("") == 0) return
                    mCalculatorDisplayString =
                        mCalculatorDisplayString.substring(0, mCalculatorDisplayString.length - 1)
                    e(
                        "@@@@@@",
                        "onClick mCalculatorDisplayString mCalculatorDisplayString.substring(0, mCalculatorDisplayString.length() - 1): $mCalculatorDisplayString"
                    )
                    if (mCalculatorDisplayString.compareTo("") == 0 || mCalculatorDisplayString.compareTo(
                            "-"
                        ) == 0
                    ) mCalculatorDisplayString = "0"
                    e(
                        "@@@@@@",
                        "onClick mCalculatorDisplayString mCalculatorDisplayString.compareTo(\"\") == 0 ||: $mCalculatorDisplayString"
                    )
                    binding.textView2.text = " "
                    binding.textView1.text = mCalculatorDisplayString
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                }

                "C" -> {
                    if (autoReply != null) {
                        autoReply?.cancel()
                        autoReply = null
                    }
                    if (!operandArray.isNullOrEmpty()) {
                        for (i in 0 until operandArray!!.size) {
                            operandArray1?.add(operandArray!![i])
                            operatorArray1.add(operatorArray!![i])
                            resultArray1?.add(resultArray!![i])
                        }
                        operatorArray1.add(' ')
                    } else {
                        operandArray1!!.add(null)
                        operatorArray1.add(' ')
                        resultArray1!!.add(null)
                    }
                    operandArray = ArrayList()
                    operatorArray = ArrayList<Char>()
                    resultArray = ArrayList<Double>()
                    MemoryArray?.clear()
                    prevOperator = '='
                    //                    tmpprevOperator = '=';
                    savedOperator = '='
                    memoryOpretor = '='
                    savedOperand = 0.0
                    result = 0.0
                    checkIndex = -1
                    clearall()
                    mCalculatorDisplayString = ""
                    e("@@@@@@", "onClick mCalculatorDisplayString C: $mCalculatorDisplayString")
                    mCalculatorMemory = 0.0
                    binding.Msymbol.text = " "
                    binding.textView2.text = " "
                    binding.textView1.text = "0"
                    binding.stepCount.text = decimalformat.format(resultArray!!.size.toLong()) //0
                    binding.gstA.visibility = View.GONE
                    binding.gstGst.visibility = View.GONE
                    binding.cgstA.visibility = View.GONE
                    binding.cgstGst.visibility = View.GONE
                }

                "CE" -> {
                    if (mCalculatorDisplayString.compareTo("") == 0) return
                    mCalculatorDisplayString = "0"
                    e("@@@@@@", "onClick mCalculatorDisplayString CE: $mCalculatorDisplayString")
                    binding.textView2.text = " "
                    binding.textView1.text = mCalculatorDisplayString
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                }

                "√x" -> {
                    val myval: String = binding.textView1.text.toString()
                    mCalculatorDisplayString = binding.textView1.text.toString()
                    e(
                        "@@@@@@",
                        "onClick mCalculatorDisplayString binding.textView1.getText().toString(): $mCalculatorDisplayString"
                    )
                    e("$$$$$", "onClick mCalculatorDisplayString: $mCalculatorDisplayString")
                    if (mCalculatorDisplayString.contains(",")) mCalculatorDisplayString =
                        mCalculatorDisplayString.replace(",", "")
                    e(
                        "@@@@@@",
                        "onClick mCalculatorDisplayString mCalculatorDisplayString.contains(\",\")): $mCalculatorDisplayString"
                    )
                    if (mCalculatorDisplayString.compareTo("") == 0) {
                        mCalculatorDisplayString = "0"
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString mCalculatorDisplayString.compareTo(\"\") == 0 if): $mCalculatorDisplayString"
                        )
                    } else {
                        mCalculatorDisplayString =
                            decimalformat.format(Math.sqrt(mCalculatorDisplayString.toDouble()))
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString mCalculatorDisplayString.compareTo(\"\") == 0 else): $mCalculatorDisplayString"
                        )
                    }
                    var cd: Double = mCalculatorDisplayString.toDouble()
                    cd = round_off(round, cd)
                    val ans = cd.toString()
                    e("$$$$$", "onClick ans: $ans")
                    binding.textView2.text = " "
                    // binding.textView1.setText(mCalculatorDisplayString);
                    // operandFirst_history.add(cd);

                    // operandFirst_history.add(Double.valueOf(ans));
                    operator_history.add('√')
                    result_calculate = java.lang.Double.valueOf(cd)
                    e("$$$$$", "onClick result_calculate: $result_calculate")
                    binding.textView1.text = ans
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                    is_equal = true
                    isCheckRoot = true
                    if (buttonPressed!!.compareTo("=") == 0) {
                        FirstBuff.append("√$myval\n =        \n$ans")
                    }
                }

                "MC" -> mCalculatorMemory = 0.0
                "M+" -> {
                    if (mCalculatorDisplayString.compareTo("") == 0 && resultArray!!.size == 0) return
                    // mCalculatorMemory += Double.parseDouble((mCalculatorDisplayString.compareTo("") == 0) ? decimalformat.format(resultArray!!.get(resultArray!!.size() - 1)) : mCalculatorDisplayString);
                    var test1 = ""
                    var d = ""
                    run {
                        var i = 0
                        while (i < operatorArray!!.size) {
                            test1 = operatorArray!![i].toString()
                            i++
                        }
                    }
                    if (test1 != "") {
                        d = binding.textView1.text.toString()
                        d += test1
                        d = d.substring(0, d.length - 1)
                        mCalculatorDisplayString = d
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString d if): $mCalculatorDisplayString"
                        )
                    } else {
                        d = binding.textView1.text.toString()
                        mCalculatorDisplayString = d
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString d else): $mCalculatorDisplayString"
                        )
                    }
                    if (mCalculatorDisplayString != "0") {
                        val a: String = mCalculatorDisplayString.replace(",", "")
                        val j2 = a.toDouble()
                        resultArray?.add(j2)
                        binding.Msymbol.setText("M+")
                        MemoryArray.add(j2)
                        mCalculatorDisplayString = ""
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString !mCalculatorDisplayString.equals(\"0\"): $mCalculatorDisplayString"
                        )
                        try {
                            if (binding.textView2.text.toString() == " " && MemoryArray != null) {
                                if (MemoryArray.size > 1) {
                                    binding.textView1.text = mValue(
                                        memoryOpretor,
                                        MemoryArray[MemoryArray.size - 2],
                                        MemoryArray[MemoryArray.size - 1]
                                    )
                                    mCalculatorMemory += java.lang.Double.valueOf(binding.textView1.text.toString())
                                } else {
                                    mCalculatorMemory += (if (mCalculatorDisplayString.compareTo("") == 0) decimalformat.format(
                                        MemoryArray[MemoryArray.size - 1]
                                    ) else mCalculatorDisplayString).toDouble()
                                }
                                MemoryArray.add(result)
                                binding.textView2.text = "="
                                prevOperator = '='
//                                tmpprevOperator = '=';
                            }
                        } catch (e: java.lang.NumberFormatException) {
                            e.printStackTrace()
                        } catch (e: java.lang.NullPointerException) {
                            e.printStackTrace()
                        } catch (e: ArrayIndexOutOfBoundsException) {
                            e.printStackTrace()
                        } catch (e: java.lang.Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                "M-" -> {
                    if (mCalculatorDisplayString.compareTo("") == 0 && resultArray!!.size == 0) return
                    // mCalculatorMemory -= Double.parseDouble((mCalculatorDisplayString.compareTo("") == 0) ? decimalformat.format(resultArray!!.get(resultArray!!.size() - 1)) : mCalculatorDisplayString);
                    val test = ""
                    var H = ""
                    /* for (int i = 0; i < operatorArray!!.size(); i++) {
                        test1 = operatorArray!![i].toString();
                        Log.e("TTTTTT", test);
                    }*/
                    if (test != "") {
                        H = binding.textView1.text.toString()
                        H += test
                        H = H.substring(0, H.length - 1)
                        mCalculatorDisplayString = H
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString H if: $mCalculatorDisplayString"
                        )
                    } else {
                        H = binding.textView1.text.toString()
                        mCalculatorDisplayString = H
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString H else: $mCalculatorDisplayString"
                        )
                    }
                    if (mCalculatorDisplayString != "0") {
                        val a: String = mCalculatorDisplayString.replace(",", "")
                        val j2 = a.toDouble()
                        resultArray?.add(j2)
                        MemoryArray.add(j2)
                        binding.Msymbol.setText("M-")
                        mCalculatorDisplayString = ""
                        e(
                            "@@@@@@",
                            "onClick mCalculatorDisplayString !mCalculatorDisplayString.equals(\"0\"): $mCalculatorDisplayString"
                        )
                        try {
                            if (binding.textView2.text.toString() == " " && MemoryArray != null) {
                                if (MemoryArray.size > 1) {
                                    binding.textView1.text = mValue(
                                        memoryOpretor,
                                        MemoryArray[MemoryArray.size - 2],
                                        MemoryArray[MemoryArray.size - 1]
                                    )
                                    mCalculatorMemory -= java.lang.Double.valueOf(binding.textView1.text.toString())
                                } else {
                                    mCalculatorMemory -= (if (mCalculatorDisplayString.compareTo("") == 0) decimalformat.format(
                                        MemoryArray[MemoryArray.size - 1]
                                    ) else mCalculatorDisplayString).toDouble()
                                }
                                MemoryArray.add(result)
                                binding.textView2.text = "="
                                prevOperator = '='
                                //                                tmpprevOperator = '=';
                            }
                        } catch (e: java.lang.NumberFormatException) {
                            e.printStackTrace()
                        } catch (e: java.lang.NullPointerException) {
                            e.printStackTrace()
                        } catch (e: ArrayIndexOutOfBoundsException) {
                            e.printStackTrace()
                        } catch (e: java.lang.Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                "MR" -> {
                    mCalculatorDisplayString = decimalformat.format(mCalculatorMemory)
                    e("@@@@@@", "onClick mCalculatorDisplayString MR: $mCalculatorDisplayString")
                    binding.textView2.text = " "
                    binding.textView1.text = mCalculatorDisplayString
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                }

                "GT" -> {
                    var tmp = 0.0
                    run {
                        var i = 0
                        while (i < operandArray!!.size && i < operatorArray!!.size) {
                            if (operatorArray!![i] == ':') tmp += operandArray!![i]
                            i++
                        }
                    }
                    mCalculatorDisplayString = decimalformat.format(tmp)
                    e(
                        "@@@@@@",
                        "onClick mCalculatorDisplayString for (int i = 0; i < operandArray.size() && i < operatorArray!!.size(); i++): $mCalculatorDisplayString"
                    )
                    binding.textView2.text = " "
                    binding.textView1.text = mCalculatorDisplayString
                    binding.stepCount.text = decimalformat.format((resultArray!!.size + 1).toLong())
                    run {
                        var i = 0
                        while (i < grand_total.size) {
                            if (buttonPressed!!.compareTo("=") == 0) {
                                FirstBuff.append(
                                    """
                            +      ${grand_total[i]}
                            
                            """.trimIndent()
                                )
                            }
                            i++
                        }
                    }
                    if (buttonPressed!!.compareTo("=") == 0) {
                        FirstBuff.append(
                            """
                    ---------------------------
                    GT   =      ${sum_tot(grand_total)}
                    
                    """.trimIndent()
                        )
                    }
                    historyData = HistoryData()
                    historyData?.first_oprand = FirstBuff.toString()
                    historylog_list.add(j, historyData!!)
                    e("######", "onClick historyData: $historyData")
                    j++
                    grand_total.clear()
                    FirstBuff.setLength(0)
                    FirstBuff.trimToSize()
                }

                "+", "-", "x", "÷", "=" -> {
                    e("||||||", "onClick =: ")
                    e("======", "% innn buttonPressed: $buttonPressed")
                    if (buttonPressed!![0] == 'M') {
                        e("======", "buttonPressed.charAt(0): " + buttonPressed!![0])
                        e("@@@@@@", "onClick : " + buttonPressed!![0])
                        is_mu = true
                        GST = "M"
                        e("@@@@@@", "onClick mCalculatorDisplayString: $mCalculatorDisplayString")
                        if (mCalculatorDisplayString != "") {
                            mu_oprand = java.lang.Double.valueOf(mCalculatorDisplayString)
                            e("@@@@@@", "onClick mu_oprand iff: $mu_oprand")
                        } else {
                            e("@@@@@@", "onClick mu_oprand elsee: $mu_oprand")
                        }
                    }
                    e(
                        "GSTTTTTT",
                        "onClick prevOperator: " + prevOperator + " -->>> " + (prevOperator == 'M' && buttonPressed!![0] != '%')
                    )
                    e("GSTTTTTT", "onClick buttonPressed.charAt(0): " + buttonPressed!![0])
                    e(
                        "GSTTTTTT",
                        "onClick mCalculatorDisplayString.compareTo(\"\"): " + mCalculatorDisplayString.compareTo(
                            ""
                        )
                    )

                    /*if (buttonPressed.charAt(0) == '=' && prevOperator == '+') {

                        Toast.makeText(getActivity(), "Invalid Format", Toast.LENGTH_LONG).show();

                    }*/
                    if (prevOperator == 'M' && buttonPressed!![0] != '%') return
                    if (prevOperator == '=' || prevOperator == '%') {
                        e("GSTTTTTT", "onClick ifff innnn: " + buttonPressed!![0])
                        if (buttonPressed!![0] == '%') {
                            e("======", "onClick buttonPressed.charAt(0) == '%': ")
                            return
                        } else if (buttonPressed!![0] == '=') {
                            e(
                                "======",
                                "buttonPressed.charAt(0):::::::::::::::::::::::::::::::: == '=' savedOperator: $savedOperator"
                            )
                            if (savedOperator != '=') {
                                result =
                                    if (mCalculatorDisplayString.compareTo("") == 0) result else mCalculatorDisplayString.toDouble() //For correct button pressed on result
                                when (savedOperator) {
                                    '+' -> {
                                        result += savedOperand
                                        e("jhjhjhjh", result.toString() + "")
                                    }

                                    '-' -> result -= savedOperand
                                    'x' -> result *= savedOperand
                                    '÷' -> result /= savedOperand
                                    '%' -> {
                                        var symbol = 0.toChar()
                                        var k = 0
                                        while (k < operator_history.size) {
                                            symbol = operator_history[i]
                                            e("$$$$$", "onClick symbol: $symbol")
                                            k++
                                        }
                                        when (symbol) {
                                            '+' -> result = oprand_one + result
                                            '-' -> result = oprand_one - result
                                            'x' -> result = oprand_one * result
                                            '/' -> result = oprand_one / result
                                            else -> {}
                                        }
                                    }
                                }
                                mCalculatorDisplay2 = result.toString()
                                mCalculatorDisplay2 = mCalculatorDisplay2.replace(".0", "")
                                try {
                                    if (mCalculatorDisplay2.contains(".")) {
                                        binding.textView2.text = buttonPressed
                                        binding.textView1.text = decimalformat.format(result)
                                    } else {
                                        val formater = DecimalFormat("##,##,##,##,###")
                                        val f1 = formater.format(result)
                                        display1 = f1
                                        binding.textView2.text = buttonPressed
                                        binding.textView1.text = display1
                                    }
                                } catch (e: java.lang.Exception) {
                                    e.printStackTrace()
                                }
                                if (operatorArray!![operatorArray!!.size - 1] != ':') {
                                    e("ERROR!", "=== failed!!!")
                                    operandArray!![operandArray!!.size - 1] = savedOperand
                                }
                                operatorArray!![operatorArray!!.size - 2] = savedOperator
                                operatorArray!![operatorArray!!.size - 1] = buttonPressed!![0]
                                resultArray!![resultArray!!.size - 1] = result
                                operandArray?.add(result)
                                operatorArray?.add(':')
                                resultArray?.add(result)
                                MemoryArray.add(result)
                                binding.stepCount.text =
                                    decimalformat.format((resultArray!!.size + 1).toLong())
                                mCalculatorDisplayString = ""
                                e(
                                    "@@@@@@",
                                    "onClick mCalculatorDisplayString operatorArray.get(operatorArray.size() - 1: $mCalculatorDisplayString"
                                )
                            }
                        } else {
                            e("======", "else: ")
                            if (result_gst != 0.0) {
                                mCalculatorDisplayString = total_gst.toString()
                                binding.gstA.visibility = View.GONE
                                binding.gstGst.visibility = View.GONE
                                binding.cgstA.visibility = View.GONE
                                binding.cgstGst.visibility = View.GONE
                                e(
                                    "@@@@@@",
                                    "onClick mCalculatorDisplayString result_gst != 0: $mCalculatorDisplayString"
                                )
                            }
                            e(
                                "======",
                                "else result toppp binding.textView1.getText().toString(): " + binding.textView1.text.toString()
                            )
                            result =
                                if (mCalculatorDisplayString.compareTo("") == 0) result else binding.textView1.text.toString()
                                    .replace(",", "").toDouble()
                            e("======", "else result toppp upppp: $result")
                            prevOperator = buttonPressed!![0]
                            savedOperator = buttonPressed!![0]
                            memoryOpretor = buttonPressed!![0]
                            tmpprevOperator = prevOperator
                            e("======", "else prevOperator: $prevOperator")
                            e("======", "else savedOperator: $savedOperator")
                            e("======", "else memoryOpretor: $memoryOpretor")
                            binding.textView2.text = buttonPressed
                            binding.textView1.text =
                                decimalformat.format(result) //Redundant for AutoReply And Check case.
                            binding.stepCount.text =
                                decimalformat.format((resultArray!!.size + 1).toLong())
                            e("======", "else result upppp: $result")
                            e("======", "else operandArray_before: $operandArray")
                            e(
                                "======",
                                "else operatorArray?.add(buttonPressed.charAt(0)_before: $operatorArray"
                            )
                            e("======", "else resultArray_before: $resultArray")
                            e("======", "else MemoryArray_before: $MemoryArray")
                            e("======", "else result_before: $result")
                            operandArray?.add(result)
                            operatorArray?.add(buttonPressed!![0])
                            resultArray?.add(result)
                            MemoryArray.add(result)
                            e("======", "else operandArray: $operandArray")
                            e(
                                "======",
                                "else operatorArray?.add(buttonPressed.charAt(0): $operatorArray"
                            )
                            e("======", "else resultArray: $resultArray")
                            e("======", "else MemoryArray: $MemoryArray")
                            e("======", "else result: $result")
                            if (mCalculatorDisplayString != "") {
                                oprand_one = mCalculatorDisplayString.toDouble()
                                e("######", "!mCalculatorDisplayString.equals(\"\"): $oprand_one")
                            }
                            if (is_oprand == 0) {
                                if (is_oprand_renew == 1) {
                                    mCalculatorDisplayString = binding.textView1.text.toString()
                                    oprand_one = mCalculatorDisplayString.toDouble()
                                    e("######", "is_oprand_renew == 1: $oprand_one")
                                    is_oprand_renew = 0
                                }
                                if (mCalculatorDisplayString != "") {
                                    operandFirst_history.add(oprand_one)
                                    is_oprand = 1
                                }
                            }
                            mCalculatorDisplayString = ""
                        }
                    } else if (mCalculatorDisplayString.compareTo("") == 0) {
                        if (buttonPressed!![0] != '=' && prevOperator != 'M' && buttonPressed!![0] != '%') {
                            prevOperator = buttonPressed!![0]
                            savedOperator = buttonPressed!![0]
                            memoryOpretor = buttonPressed!![0]

//                            tmpprevOperator = prevOperator;
                            operatorArray!!.set(operatorArray!!.size - 1, buttonPressed!![0])
                            binding.textView2.text = buttonPressed
                            binding.textView1.text =
                                if (mCalculatorDisplayString.compareTo("") == 0) //I think mCalculatorDisplayString will always be "" here.
                                    decimalformat.format(resultArray!!.get(resultArray!!.size - 1)) else mCalculatorDisplayString //Redundant for AutoReply And Check case.
                            binding.stepCount.text =
                                decimalformat.format(resultArray!!.size.toLong()) //Redundant for AutoReply And Check case.
                        }
                    } else {
                        if (buttonPressed!!.compareTo("=") == 0) {
                            e("TAG:::::::", "onClick = press ifff beloww: ")

//                Toast.makeText(getActivity(), "= press", Toast.LENGTH_LONG).show();
                        } else {
                            e("TAG:::::::", "onClick another click elseeee beloww: ")
                            //                Toast.makeText(getActivity(), "another click", Toast.LENGTH_LONG).show();
                        }
                        oprand_two = mCalculatorDisplayString.toDouble()
                        operandSecond_history.add(oprand_two)
                        two = mCalculationString!!
                        e("(((TAG)))", "onClick prevOperator: $prevOperator")
                        operator_history.add(prevOperator)
                        when (prevOperator) {
                            '+' -> {
                                result += if (buttonPressed!![0] == '%') result * mCalculatorDisplayString.toDouble() / 100 else mCalculatorDisplayString.toDouble()
                                result = round_off("5", result)
                                e("$$$$$", "onClick + result: $result")
                            }

                            '-' -> {
                                result -= if (buttonPressed!![0] == '%') result * mCalculatorDisplayString.toDouble() / 100 else mCalculatorDisplayString.toDouble()
                                result = round_off("5", result)
                                e("$$$$$", "onClick - result: $result")
                            }

                            'x' -> {
                                result =
                                    if (buttonPressed!![0] == '%') result * mCalculatorDisplayString.toDouble() / 100 else result * mCalculatorDisplayString.toDouble()
                                e("$$$$$", "onClick x result: ${String.format("%,.2f", result)}")
                                result = round_off("5", result)
                            }

                            '÷' -> {
                                result =
                                    if (buttonPressed!![0] == '%') result * (100 / mCalculatorDisplayString.toDouble()) else result / mCalculatorDisplayString.toDouble()
                                result = round_off("5", result)
                                e("$$$$$", "onClick ÷ result: $result")
                            }

                            'M' -> {
                                result = result * 100 / (100 - mCalculatorDisplayString.toDouble())
                                result = round_off("5", result)
                                e("$$$$$", "onClick 'M' result: $result")
                            }
                        }
                        prevOperator = buttonPressed!![0]
                        //                        tmpprevOperator = prevOperator;
                        if (buttonPressed!![0] != '=') {
                            savedOperator = buttonPressed!![0]
                            memoryOpretor = buttonPressed!![0]
                            tempSavedOperator = savedOperator
                        }
                        savedOperand = mCalculatorDisplayString.toDouble()
                        e("<<<<<", "onClick savedOperand: $savedOperand")
                        tempsavedOperand = savedOperand
                        e("<<<<<", "onClick tempsavedOperand: $tempsavedOperand")
                        binding.textView2.text = buttonPressed
                        result_calculate = result
                        if (is_oprand == 1) {
                            operandFirst_history.add(oprand_two)
                        }
                        e("######", "onClick prevOperator: $prevOperator")
                        e("######", "onClick savedOperator: $savedOperator")
                        e("######", "onClick memoryOpretor: $memoryOpretor")
                        e("######", "onClick savedOperand: $savedOperand")
                        e("######", "onClick result_calculate: $result_calculate")
                        result_history.add(result_calculate)
                        e("????", "onClick result_history: " + result_history.size)
                        result_calculate = round_off(round, result_calculate)
                        val d1 = result_calculate.toString()
                        try {
                            if (preoprandstring.contains(".") || mCalculatorDisplayString.contains(".") || d1.contains(
                                    "."
                                )
                            ) {
                                e("!!!!!!!!!", "^^^^^^^^^^--%,d--^^^^^^^^>")
                                binding.textView2.text = " "
                                // binding.textView1.setText(decimalformat.format(result_calculate));
                                binding.textView1.text = String.format("%,.2f", result_calculate)
                                preoprandstring = ""
                            } else if (preoprandstring == "" && !mCalculatorDisplayString.contains(".")) {
                                val formater = DecimalFormat("##,##,##,##,###")
                                val f1 = formater.format(result_calculate)
                                display1 = f1
                                binding.textView2.text = " "
                                binding.textView1.text = display1
                            }
                        } catch (e: java.lang.Exception) {
                            e.printStackTrace()
                        }
                        binding.stepCount.text =
                            decimalformat.format((resultArray!!.size + 1).toLong())
                        operandArray?.add(savedOperand)
                        operatorArray?.add(buttonPressed!![0])
                        resultArray?.add(result)
                        MemoryArray.add(result)
                        if (buttonPressed!![0] == '=' || buttonPressed!![0] == '%') {
                            operator_history.add(buttonPressed!![0])
                            is_equal = !is_mu
                            e("######", "onClick result_history result: $result")
                            result_history.add(result)
                            binding.stepCount.text =
                                decimalformat.format((resultArray!!.size + 1).toLong())
                            operandArray?.add(result)
                            operatorArray?.add(':')
                            resultArray?.add(result)
                            MemoryArray.add(result)
                            grand_total.add(result)
                        }
                        mCalculatorDisplayString = ""
                    }
                }

                "MU", "%" -> {
                    e("======", "% innn buttonPressed: $buttonPressed")
                    if (buttonPressed!![0] == 'M') {
                        e("======", "buttonPressed.charAt(0): " + buttonPressed!![0])
                        e("@@@@@@", "onClick : " + buttonPressed!![0])
                        is_mu = true
                        GST = "M"
                        e("@@@@@@", "onClick mCalculatorDisplayString: $mCalculatorDisplayString")
                        if (mCalculatorDisplayString != "") {
                            mu_oprand = java.lang.Double.valueOf(mCalculatorDisplayString)
                            e("@@@@@@", "onClick mu_oprand iff: $mu_oprand")
                        } else {
                            e("@@@@@@", "onClick mu_oprand elsee: $mu_oprand")
                        }
                    }
                    e(
                        "GSTTTTTT",
                        "onClick prevOperator: " + prevOperator + " -->>> " + (prevOperator == 'M' && buttonPressed!![0] != '%')
                    )
                    e("GSTTTTTT", "onClick buttonPressed.charAt(0): " + buttonPressed!![0])
                    e(
                        "GSTTTTTT",
                        "onClick mCalculatorDisplayString.compareTo(\"\"): " + mCalculatorDisplayString.compareTo(
                            ""
                        )
                    )
                    if (prevOperator == 'M' && buttonPressed!![0] != '%') return
                    if (prevOperator == '=' || prevOperator == '%') {
                        e("GSTTTTTT", "onClick ifff innnn: " + buttonPressed!![0])
                        if (buttonPressed!![0] == '%') {
                            e("======", "onClick buttonPressed.charAt(0) == '%': ")
                            return
                        } else if (buttonPressed!![0] == '=') {
                            e(
                                "======",
                                "buttonPressed.charAt(0):::::::::::::::::::::::::::::::: == '=' savedOperator: $savedOperator"
                            )
                            if (savedOperator != '=') {
                                result =
                                    if (mCalculatorDisplayString.compareTo("") == 0) result else mCalculatorDisplayString.toDouble()
                                when (savedOperator) {
                                    '+' -> {
                                        result += savedOperand
                                        e("jhjhjhjh", result.toString() + "")
                                    }

                                    '-' -> result -= savedOperand
                                    'x' -> result *= savedOperand
                                    '÷' -> result /= savedOperand
                                    '%' -> {
                                        var symbol = 0.toChar()
                                        var k = 0
                                        while (k < operator_history.size) {
                                            symbol = operator_history[i]
                                            e("$$$$$", "onClick symbol: $symbol")
                                            k++
                                        }
                                        if (symbol == '+') {
                                            result = oprand_one + result
                                        } else if (symbol == '-') {
                                            result = oprand_one - result
                                        } else if (symbol == 'x') {
                                            result = oprand_one * result
                                        } else if (symbol == '/') {
                                            result = oprand_one / result
                                        } else {
                                        }
                                    }
                                }
                                mCalculatorDisplay2 = result.toString()
                                mCalculatorDisplay2 = mCalculatorDisplay2.replace(".0", "")
                                try {
                                    if (mCalculatorDisplay2.contains(".")) {
                                        binding.textView2.text = buttonPressed
                                        binding.textView1.text = decimalformat.format(result)
                                    } else {
                                        val formater = DecimalFormat("##,##,##,##,###")
                                        val f1 = formater.format(result)
                                        display1 = f1
                                        binding.textView2.text = buttonPressed
                                        binding.textView1.text = display1
                                    }
                                } catch (e: java.lang.Exception) {
                                    e.printStackTrace()
                                }
                                if (operatorArray!!.get(operatorArray!!.size - 1) != ':') e(
                                    "ERROR!",
                                    "=== failed!!!"
                                )
                                operandArray!![operandArray!!.size - 1] = savedOperand
                                operatorArray!![operatorArray!!.size - 2] = savedOperator
                                operatorArray!![operatorArray!!.size - 1] = buttonPressed!![0]
                                resultArray?.set(resultArray!!.size - 1, result)
                                operandArray?.add(result)
                                operatorArray?.add(':')
                                resultArray?.add(result)
                                MemoryArray.add(result)
                                binding.stepCount.text =
                                    decimalformat.format((resultArray!!.size + 1).toLong())
                                mCalculatorDisplayString = ""
                                e(
                                    "@@@@@@",
                                    "onClick mCalculatorDisplayString operatorArray!!.get(operatorArray!!.size() - 1: $mCalculatorDisplayString"
                                )
                            }
                        } else {
                            e("======", "else: ")
                            if (result_gst != 0.0) {
                                mCalculatorDisplayString = total_gst.toString()
                                binding.gstA.visibility = View.GONE
                                binding.gstGst.visibility = View.GONE
                                binding.cgstA.visibility = View.GONE
                                binding.cgstGst.visibility = View.GONE
                                e(
                                    "@@@@@@",
                                    "onClick mCalculatorDisplayString result_gst != 0: $mCalculatorDisplayString"
                                )
                            }
                            e(
                                "======",
                                "else result toppp binding.textView1.getText().toString(): " + binding.textView1.text.toString()
                            )
                            result =
                                if (mCalculatorDisplayString.compareTo("") == 0) result else binding.textView1.text
                                    .toString().replace(",", "").toDouble()
                            e("======", "else result toppp upppp: $result")
                            prevOperator = buttonPressed!![0]
                            savedOperator = buttonPressed!![0]
                            memoryOpretor = buttonPressed!![0]
                            tmpprevOperator = prevOperator
                            e("======", "else prevOperator: $prevOperator")
                            e("======", "else savedOperator: $savedOperator")
                            e("======", "else memoryOpretor: $memoryOpretor")
                            binding.textView2.text = buttonPressed
                            binding.textView1.text = decimalformat.format(result)
                            binding.stepCount.text =
                                decimalformat.format((resultArray!!.size + 1).toLong())
                            e("======", "else result upppp: $result")
                            e("======", "else operandArray_before: $operandArray")
                            e(
                                "======",
                                "else operatorArray?.add(buttonPressed.charAt(0)_before: $operatorArray"
                            )
                            e("======", "else resultArray_before: $resultArray")
                            e("======", "else MemoryArray_before: $MemoryArray")
                            e("======", "else result_before: $result")
                            operandArray?.add(result)
                            operatorArray?.add(buttonPressed!![0])
                            resultArray?.add(result)
                            MemoryArray.add(result)
                            e("======", "else operandArray: $operandArray")
                            e(
                                "======",
                                "else operatorArray?.add(buttonPressed.charAt(0): $operatorArray"
                            )
                            e("======", "else resultArray: $resultArray")
                            e("======", "else MemoryArray: $MemoryArray")
                            e("======", "else result: $result")
                            if (mCalculatorDisplayString != "") {
                                oprand_one = mCalculatorDisplayString.toDouble()
                                e(
                                    "######",
                                    "!mCalculatorDisplayString.equals(\"\"): $oprand_one"
                                )
                            }
                            if (is_oprand == 0) {
                                if (is_oprand_renew == 1) {
                                    mCalculatorDisplayString = binding.textView1.text.toString()
                                    oprand_one = mCalculatorDisplayString.toDouble()
                                    e("######", "is_oprand_renew == 1: $oprand_one")
                                    is_oprand_renew = 0
                                }
                                if (mCalculatorDisplayString != "") {
                                    operandFirst_history.add(oprand_one)
                                    is_oprand = 1
                                }
                            }
                            mCalculatorDisplayString = ""
                        }
                    } else if (mCalculatorDisplayString.compareTo("") == 0) {
                        if (buttonPressed!![0] != '=' && prevOperator != 'M' && buttonPressed!![0] != '%') {
                            prevOperator = buttonPressed!![0]
                            savedOperator = buttonPressed!![0]
                            memoryOpretor = buttonPressed!![0]
                            operatorArray!!.set(operatorArray!!.size - 1, buttonPressed!![0])
                            binding.textView2.text = buttonPressed
                            binding.textView1.text =
                                if (mCalculatorDisplayString.compareTo("") == 0) decimalformat.format(
                                    resultArray!!.get(resultArray!!.size - 1)
                                ) else mCalculatorDisplayString
                            binding.stepCount.text =
                                decimalformat.format(resultArray!!.size.toLong())
                        }
                    } else {
                        if (buttonPressed!!.compareTo("=") == 0) {
                            e("TAG:::::::", "onClick = press ifff beloww: ")
                        } else {
                            e("TAG:::::::", "onClick another click elseeee beloww: ")
                        }
                        oprand_two = mCalculatorDisplayString.toDouble()
                        operandSecond_history.add(oprand_two)
                        two = mCalculationString!!
                        e("(((TAG)))", "onClick prevOperator: $prevOperator")
                        operator_history.add(prevOperator)
                        when (prevOperator) {
                            '+' -> {
                                result += if (buttonPressed!![0] == '%') result * mCalculatorDisplayString.toDouble() / 100 else mCalculatorDisplayString.toDouble()
                                result = round_off("5", result)
                                e("$$$$$", "onClick result: $result")
                            }

                            '-' -> {
                                result -= if (buttonPressed!![0] == '%') result * mCalculatorDisplayString.toDouble() / 100 else mCalculatorDisplayString.toDouble()
                                result = round_off("5", result)
                                e("$$$$$", "onClick result: $result")
                            }

                            'x' -> {
                                if (buttonPressed!![0] == '%') result =
                                    result * mCalculatorDisplayString.toDouble() / 100 else result *= mCalculatorDisplayString.toDouble()
                                result = round_off("5", result)
                                e("$$$$$", "onClick result: $result")
                            }

                            '÷' -> {
                                if (buttonPressed!![0] == '%') result =
                                    result * (100 / mCalculatorDisplayString.toDouble()) else result /= mCalculatorDisplayString.toDouble()
                                result = round_off("5", result)
                                e("$$$$$", "onClick result: $result")
                            }

                            'M' -> {
                                result = result * 100 / (100 - mCalculatorDisplayString.toDouble())
                                result = round_off("5", result)
                                e("$$$$$", "onClick result 'M': $result")
                            }
                        }
                        prevOperator = buttonPressed!![0]
                        if (buttonPressed!![0] != '=') {
                            savedOperator = buttonPressed!![0]
                            memoryOpretor = buttonPressed!![0]
                            tempSavedOperator = savedOperator
                        }
                        savedOperand = mCalculatorDisplayString.toDouble()
                        e("<<<<<", "onClick savedOperand: $savedOperand")
                        tempsavedOperand = savedOperand
                        e("<<<<<", "onClick tempsavedOperand: $tempsavedOperand")
                        binding.textView2.text = buttonPressed
                        result_calculate = result
                        if (is_oprand == 1) {
                            operandFirst_history.add(oprand_two)
                        }
                        e("######", "onClick prevOperator: $prevOperator")
                        e("######", "onClick savedOperator: $savedOperator")
                        e("######", "onClick memoryOpretor: $memoryOpretor")
                        e("######", "onClick savedOperand: $savedOperand")
                        e("######", "onClick result_calculate: $result_calculate")
                        result_history.add(result_calculate)
                        e("????", "onClick result_history: " + result_history.size)
                        result_calculate = round_off(round, result_calculate)
                        val d1 = result_calculate.toString()
                        try {
                            if (preoprandstring.contains(".") || mCalculatorDisplayString.contains(".") || d1.contains(
                                    "."
                                )
                            ) {
                                e("!!!!!!!!!", "^^^^^^^^^^--%,d--^^^^^^^^>")
                                binding.textView2.text = " "
                                binding.textView1.text = String.format("%,.2f", result_calculate)
                                preoprandstring = ""
                            } else if (preoprandstring == "" && !mCalculatorDisplayString.contains(".")) {
                                val formater = DecimalFormat("##,##,##,##,###")
                                display1 = formater.format(result_calculate)
                                binding.textView2.text = " "
                                binding.textView1.text = display1
                            }
                        } catch (e: java.lang.Exception) {
                            e.printStackTrace()
                        }
                        binding.stepCount.text =
                            decimalformat.format((resultArray!!.size + 1).toLong())
                        operandArray?.add(savedOperand)
                        operatorArray?.add(buttonPressed!![0])
                        resultArray?.add(result)
                        MemoryArray.add(result)
                        if (buttonPressed!![0] == '=' || buttonPressed!![0] == '%') {
                            operator_history.add(buttonPressed!![0])
                            is_equal = !is_mu
                            e("######", "onClick result_history result: $result")
                            result_history.add(result)
                            binding.stepCount.text =
                                decimalformat.format((resultArray!!.size + 1).toLong())
                            operandArray?.add(result)
                            operatorArray?.add(':')
                            resultArray?.add(result)
                            MemoryArray.add(result)
                            grand_total.add(result)
                        }
                        mCalculatorDisplayString = ""
                    }
                }
            }
        } catch (e: NumberFormatException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: ArrayIndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: RuntimeException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun gst_val(i: Int): Double {
        var `val` = 0.0
        `val` = if (i <= 4) {
            java.lang.Double.valueOf(pref_values[i].substring(1, pref_values[i].length))
        } else {
            100.0 + java.lang.Double.valueOf(pref_values[i].substring(1, pref_values[i].length))
        }
        return `val`
    }

    override fun onDismiss(state: Boolean) {
        if (state) {
            SetSlabValue()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        this.menu = menu
        Log.e("TAG_IS_PREMIUM", "onCreate: " + premium_On)
        if (premium_On == 0) {
            refreshView()
        } else {
            if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
                e("TAG_IS_PREMIUM", "onCreateOptionsMenu refreshView")
                refreshView()
            }
        }
        inflater.inflate(R.menu.gst_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_history -> {
                ShowAdsexit {
                    item.isEnabled = false
                    Handler(Looper.getMainLooper()).postDelayed({ item.isEnabled = true }, 2000)
                    history()
                }
            }

            R.id.action_inApp -> {
                try {
                    if (isNetworkAvailable(requireActivity())) {
                        (requireActivity() as MainActivity).Subscription_Dilog()
                    } else {
                        Toast.makeText(
                            context,
                            resources.getString(R.string.check_connectivity),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    return true
                } catch (e: Resources.NotFoundException) {
                    e.printStackTrace()
                } catch (e: NullPointerException) {
                    e.printStackTrace()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        return super.onOptionsItemSelected(item)
    }

    private fun ShowAdsexit(callback: () -> Unit) {
        if ((SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE")) {
            (activity as MainActivity). historyClick {
                callback.invoke()
            }
        } else {
            callback.invoke()
        }
    }

    fun refreshView() {
        CoroutineScope(Dispatchers.Main).launch {
            menu.let {
                it?.findItem(R.id.action_inApp)?.isVisible = false
            }
        }
    }

    fun refreshView1() {
        CoroutineScope(Dispatchers.Main).launch {
            if (premium_On == 1) {
                menu.let {
                    it?.findItem(R.id.action_inApp)?.isVisible = true
                }
            }

        }
    }

    private fun history() {
        // isCheckHistoryClick = true
        try {
            if (sound) {
                myAudioManager?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.7F)
            }
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Resources.NotFoundException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        is_oprand = 0
        is_oprand_renew = 1
        count = 0

        if (!is_equal) {
            if (!is_gst) {
                if (is_mu) {
                    var c = 0.toChar()
                    for (k in 0 until operator_history.size) {
                        c = operator_history[k]
                    }

                    val isMUFirst = false
                    var isMUAdd = 0
                    var isMUCount = 0

                    val indexMUSize = ArrayList<Int>()
                    val isMuEqualOrNotArr = ArrayList<String>()
                    var isMuEqualOrNot = false

                    for (i in 0 until operator_history.size - 1) {
                        if ('M' == operator_history[i]) {
                            val indexPrev = i - 1
                            val indexObj = operator_history[indexPrev]
                            if ('=' == indexObj) {
                                isMuEqualOrNotArr.add("0")
                            } else {
                                isMuEqualOrNotArr.add("1")
                            }
                        }
                    }

                    isMuEqualOrNot = verifyAllEqualUsingALoop(isMuEqualOrNotArr)
                    e("TAG", "history:verifyAllEqualUsingALoop $isMuEqualOrNot")

                    if (isMuEqualOrNot) {
                        for (i in 0 until operator_history.size) {
                            if ('M' == operator_history[i]) {
                                isMUCount++
                                val indexPrev = i - 1
                                val indexObj = operator_history[indexPrev]

                                isMUAdd = if ('=' == indexObj) {
                                    val pos = i + isMUAdd
                                    indexMUSize.add(pos)
                                    val posNew = pos + 3
                                    indexMUSize.add(posNew)
                                    e(
                                        "TAG",
                                        "history:pos::::== pos:$pos:i:$i:isMUAdd:$isMUAdd:posNew:$posNew:isMUCount:$isMUCount"
                                    )
                                    isMUCount + 2
                                } else {
                                    val pos = i + isMUAdd
                                    val posNew = pos + 2
                                    e(
                                        "TAG",
                                        "history:pos::::!= pos:$pos:i:$i:isMUAdd:$isMUAdd:posNew:$posNew:isMUCount:$isMUCount"
                                    )
                                    indexMUSize.add(posNew)
                                    isMUCount
                                }

                                e("TAG", "history:size:indexMUSize:::::if : : $isMUAdd")
                            }
                        }
                    } else {
                        for (i in 0 until operator_history.size) {
                            if ('M' == operator_history[i]) {
                                val indexPrev = i - 1
                                val indexObj = operator_history[indexPrev]

                                if ('=' == indexObj) {
                                    val pos = i + isMUAdd
                                    indexMUSize.add(pos)
                                    val posNew = pos + 3
                                    indexMUSize.add(posNew)
                                    e(
                                        "TAG",
                                        "history:pos::::== pos:$pos:i:$i:isMUAdd:$isMUAdd:posNew:$posNew:isMUCount:$isMUCount"
                                    )
                                } else {
                                    val pos = i + isMUAdd
                                    val posNew = pos + 2
                                    e(
                                        "TAG",
                                        "history:pos::::!= pos:$pos:i:$i:isMUAdd:$isMUAdd:posNew:$posNew:isMUCount:$isMUCount"
                                    )
                                    indexMUSize.add(posNew)
                                }
                                e(
                                    "TAG",
                                    "history:size:indexMUSize:::::if:bf : : $isMUAdd : $isMUCount :"
                                )
                                isMUAdd += 2
                                e(
                                    "TAG",
                                    "history:size:indexMUSize:::::if:af : : $isMUAdd : $isMUCount :"
                                )
                            }
                        }
                    }

                    val operandArrayTemp = ArrayList<Double>()
                    operandArrayTemp.addAll(operandArray!!)
                    if (indexMUSize.isNotEmpty()) indexMUSize.removeAt(0)
                    e("TAG", "history:size:indexMUSize $indexMUSize")
                    e(
                        "TAG",
                        "history:sizeoperandArrayTemp : : $operandArray === : === : $operandArrayTemp"
                    )

                    try {
                        for (i in 0 until indexMUSize.size) {
                            e(
                                "TAG",
                                "history:size:index:remove:before : : $operandArrayTemp : i:${indexMUSize[i]}"
                            )
                            val index = indexMUSize[i]
                            operandArrayTemp.removeAt(index)
                            e("TAG", "history:size:index:remove:after : : $operandArrayTemp")
                        }

                        e(
                            "TAG",
                            "history:size:operandArrayTemp:after ${operandArrayTemp.size} : "
                        )
                        e(
                            "TAG",
                            "history:size : ${indexMUSize.size} : $operator_history === : === $operandArray === : == $operandArrayTemp"
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    val operandArrayTempNew = ArrayList<String>()
                    val operandArrayTempNewFinal = ArrayList<String>()

                    for (i in 0 until operandArrayTemp.size) {
                        var str = operandArrayTemp[i].toString()
                        operandArrayTempNew.add(str)
                        if (operandArrayTemp.size - 1 != i) {
                            try {
                                str = operator_history[i].toString()
                                operandArrayTempNew.add(str)
                            } catch (e: IndexOutOfBoundsException) {
                            }
                        }
                    }

                    for (i in 0 until operandArrayTempNew.size) {
                        try {
                            try {
                                if (i == 0) {
                                    operandArrayTempNewFinal.addAll(operandArrayTempNew)
                                }
                                if ("M" == operandArrayTempNew[i]) {
                                    val indexPrevData = i - 1
                                    val indexObj = operandArrayTempNew[indexPrevData]

                                    if ("=" == indexObj) {
                                        val indexPrev = i - 1
                                        val indexPrevOfPrev = i - 2
                                        val colon = ":"

                                        e(
                                            "TAG",
                                            "history: indexPrev:data : $indexPrev : ${operandArrayTempNew[indexPrev]} : $i"
                                        )
                                        e(
                                            "TAG",
                                            "history: indexPrev : $indexPrevOfPrev : ${operandArrayTempNew[indexPrevOfPrev]} : $i"
                                        )

                                        operandArrayTempNewFinal.add(
                                            indexPrevOfPrev + 2,
                                            operandArrayTempNew[indexPrev]
                                        )
                                        operandArrayTempNewFinal.add(indexPrev + 1, colon)

                                        e(
                                            "TAG",
                                            "history: indexPrev:data:if : $indexPrevData : ${operandArrayTempNew[indexPrevData]} : $i : $indexObj"
                                        )
                                    } else {
                                        var ii = 0
                                        var count1 = 0
                                        val count2 = 4
                                        var valueTemp = "0"
                                        var value = "0"
                                        var valueFinal = 0.0
                                        var valueOprand = ' '
                                        var ismu = false
                                        var isMUAddNext = 0
                                        var isMUNext = -1
                                        var indexPrev = 0
                                        var indexPrevOfPrev = 0
                                        var isMUNextAdd = 0

                                        for (i in 0 until operandArrayTempNew.size) {
                                            e(
                                                "TAG",
                                                "history:operandArrayTempNew:i $i : ${operandArrayTempNew[i]}"
                                            )

                                            ii = i

                                            if ("M" == operandArrayTempNew[ii]) {
                                                e("TAG", "history:!!!!!!!:if:bf:M $ii")
                                                ismu = true

                                                indexPrev = ii + isMUNextAdd
                                                indexPrevOfPrev = ii + isMUNextAdd

                                                val colon = ":"

                                                operandArrayTempNewFinal.add(
                                                    indexPrevOfPrev,
                                                    valueFinal.toString()
                                                )
                                                operandArrayTempNewFinal.add(indexPrev, colon)

                                                isMUAddNext = ii + 3
                                                count1 = ii + count2

                                                isMUNextAdd += 2
                                            } else {
                                                if (!ismu) {
                                                    var posOprand = 0
                                                    value = operandArrayTempNew[ii]

                                                    e(
                                                        "TAG",
                                                        "history:isMUNext:i:value $isMUNext : $ii : $value : $valueFinal"
                                                    )

                                                    if (ii != 0 || ii == isMUNext) {
                                                        posOprand = ii - 1
                                                        valueOprand =
                                                            operandArrayTempNew[posOprand][0]

                                                        when (valueOprand) {
                                                            '+' -> valueFinal += value.toDouble()
                                                            '-' -> valueFinal -= value.toDouble()
                                                            'x' -> valueFinal *= value.toDouble()
                                                            '÷' -> valueFinal /= value.toDouble()
                                                            else -> {
                                                            }
                                                        }
                                                    } else {
                                                        valueFinal = value.toDouble()
                                                    }
                                                    e(
                                                        "TAG",
                                                        "history:isMUNext:i $isMUNext : $i : $valueFinal : $value"
                                                    )
                                                } else {
                                                    if ("%" == operandArrayTempNew[ii]) {
                                                        valueFinal =
                                                            operandArrayTempNew[isMUAddNext].toDouble()
                                                        if (operandArrayTempNew.size >= count1) {
                                                            ismu = false
                                                            isMUNext = ii
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        e(
                                            "TAG",
                                            "history: indexPrev:data:else : $indexPrevData : ${operandArrayTempNew[indexPrevData]} : $i : $indexObj"
                                        )
                                    }
                                }
                            } catch (e: IndexOutOfBoundsException) {
                            }
                        } catch (e: Exception) {
                        }
                    }

                    val secondBuff = StringBuilder()
                    for (i in 0 until operandArrayTempNewFinal.size) {
                        if (i % 2 == 0) {
                            secondBuff.append("${operandArrayTempNewFinal[i]}\n")
                        } else {
                            secondBuff.append("${operandArrayTempNewFinal[i]}\t")
                        }
                    }

                    e("TAG", "history:operandArrayTempNew $operandArrayTempNew")
                    e("TAG", "history:operandArrayTempNewFinal $operandArrayTempNewFinal")
                    e("TAG", "history:operandArrayTempNewFinal:secondBuff $secondBuff")

                    is_mu = false
                } else {
                    for (i in 0 until operator_history.size) {
                        if (buttonPressed == "=") {
                            e("TAG", "history oprand_one: $oprand_one")
                            e("TAG", "history gst_text(GST): ${gst_text(GST)}")
                            e("TAG", "history oprand_two: $oprand_two")
                            e("TAG", "history oprand_result: $oprand_result")

                            secondBuff.append("\n$oprand_one\n$tmpprevOperator      $oprand_two\n---------------------------\n=      $result_calculate\n")
                            is_gst = false
                            e("TAG", "for (is_gst = false; secondBuff: $secondBuff")
                        }
                    }
                }
            } else {
                if (buttonPressed == "=") {
                    e("TAG", "history nnnn oprand_one: $oprand_one")
                    e("TAG", "history nnnn gst_text(GST): ${gst_text(GST)}")
                    e("TAG", "history nnnn oprand_two: $oprand_two")
                    e(
                        "TAG",
                        "history nnnn oprand_result: ${String.format("%,.2f", oprand_result)}"
                    )

                    secondBuff.append(
                        "\n$oprand_one\n${gst_text(GST)}      $oprand_two\n---------------------------\n${
                            String.format(
                                "%,.2f",
                                oprand_result
                            )
                        }\n"
                    )
                    is_gst = false
                    e("TAG", "for (is_gst = false; secondBuff: $secondBuff")
                }
            }

            if (secondBuff.isNotEmpty()) {
                e("TAG", "secondBuff: $secondBuff")

                val historyData = HistoryData()
                historyData.first_oprand = secondBuff.toString()

                historylog_list.add(0, historyData)

                val json = Gson().toJson(historylog_list)
                mPrefs?.edit()?.putString("MyObject", json)?.apply()

                operandFirst_history.clear()
                operator_history.clear()
                operandSecond_history.clear()
                result_history.clear()
                secondBuff.setLength(0)
            }
        } else {
            if (operator_history.size > 2) {
                operator_history.add(0, ' ')

                for (i in 0 until operandFirst_history.size) {
                    if (buttonPressed == "=") {
                        FirstBuff.append("${gst_text(operator_history[i].toString())}      ${operandFirst_history[i]}\n")
                    }
                }
            } else {
                if (!isCheckRoot) {
                    var c = 0.toChar()
                    for (k in 0 until operator_history.size) {
                        c = operator_history[i]
                    }

                    if (buttonPressed == "=") {
                        FirstBuff.append(
                            "\n$oprand_one\n$c      $oprand_two\n---------------------------\n$prevOperator      ${
                                String.format(
                                    "%,.2f",
                                    result_calculate
                                )
                            }\n"
                        )
                    }
                } else {
                    isCheckRoot = false
                }
            }
            if (operator_history.size > 2) {
                if (buttonPressed == "=") {
                    FirstBuff.append(
                        "---------------------------\n=      ${
                            String.format(
                                "%,.2f",
                                result_calculate
                            )
                        }\n"
                    )
                }

                if (ans_gst && !is_gst) {
                    if (buttonPressed == "=") {
                        FirstBuff.append(
                            "\n$oprand_one\n${gst_text(GST)}      $oprand_two\n---------------------------\n${
                                String.format(
                                    "%,.2f",
                                    oprand_result
                                )
                            }\n"
                        )
                        ans_gst = false
                    }
                }
            }

            if (FirstBuff.isNotEmpty()) {
                val historyData = HistoryData()
                historyData.first_oprand = FirstBuff.toString()

                historylog_list.add(0, historyData)

                val json = Gson().toJson(historylog_list)
                mPrefs?.edit()?.putString("MyObject", json)?.apply()

                operandFirst_history.clear()
                operator_history.clear()
                operandSecond_history.clear()
                result_history.clear()
                FirstBuff.setLength(0)
            }
            is_equal = false
        }

//        ConstantKt.setDoubleBackToExitPressedOnce(false)
        startActivity(Intent(requireActivity(), HistoryActivity::class.java))
    }

    private fun gst_text(gst: String): String {
        val gst = if (gst.equals("A", ignoreCase = true)) {
            if (gst == "A") {
                pref_values[0]
            } else {
                pref_values[5]
            }
        } else if (gst.equals("B", ignoreCase = true)) {
            if (gst == "B") {
                pref_values[1]
            } else {
                pref_values[6]
            }
        } else if (gst.equals("C", ignoreCase = true)) {
            if (gst == "C") {
                pref_values[2]
            } else {
                pref_values[7]
            }
        } else if (gst.equals("D", ignoreCase = true)) {
            if (gst == "D") {
                pref_values[3]
            } else {
                pref_values[8]
            }
        } else if (gst.equals("E", ignoreCase = true)) {
            if (gst == "E") {
                pref_values[4]
            } else {
                pref_values[9]
            }
        } else if (gst.equals("M", ignoreCase = true)) {
            "MU"
        } else {
            return gst
        }
        return gst
    }

    fun verifyAllEqualUsingALoop(list: List<String>): Boolean {
        for (s in list) {
            if (s != list[0]) return false
        }
        return true
    }

    var listDetailsMain: ArrayList<ProductDetails> = ArrayList()

    private fun mValue(s: Char, op1: Double, op2: Double): String {
        return when (s) {
            Text_Plus_Char -> (op1 + op2).toString()
            Text_Mines_Char -> (op1 - op2).toString()
            Text_Multiple_Char -> (op1 * op2).toString()
            Text_Devide_Char -> (op1 / op2).toString()
            else -> op2.toString()
        }
    }

    companion object {
        lateinit var adsInit: AdsInit

        var is_update = false

        fun sum_tot(list: List<Double>): Double? {
            var sum: Double? = 0.0
            if (sum != null) {
                for (i in list) {
                    sum += i
                }
            }
            return sum
        }

        var historylog_list: ArrayList<HistoryData> = ArrayList<HistoryData>()
    }

    fun gstCalculatiion(Gst_value: Double, str: String) {
        gstCalculatorDisplay1 = binding.textView1.text.toString().replace(",", "")
        result = java.lang.Double.parseDouble(gstCalculatorDisplay1)

        if (str == Text_plus) {
            gst_val = result / 100.0f * Gst_value
            total_gst = result + gst_val
            gst_val1 = gst_val / 2
        } else {
            gst_val = result - result * (100.0 / Gst_value)
            total_gst = result - gst_val
            gst_val1 = gst_val / 2
        }

        result_gst = total_gst

        gst_dis = String.format("%,.2f", round_off(round, total_gst))
        val gst_valdist = String.format("%,.2f", round_off(round, gst_val))
        val cgst_valt = String.format("%,.2f", round_off(round, gst_val1))

        if (gst_dis.length >= 11)
            binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 50f)
        else
            binding.textView1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 60f)


        binding.textView1.text = gst_dis

        binding.gstA.text = gst_valdist
        binding.gstA.text = cgst_valt

        setVisibleGstField()
    }

    fun setVisibleGstField() {
        binding.gstA.visibility = View.VISIBLE
        binding.gstGst.visibility = View.VISIBLE
        binding.gstA.visibility = View.VISIBLE
        binding.gstGst.visibility = View.VISIBLE
    }

    private fun setButtonTheme(currentTheme: Int) {
        when (currentTheme) {
            0 -> {
                createSelecteState(
                    R.drawable.select_button_1_default,
                    R.drawable.select_button_3_default,
                    R.drawable.select_button_2_default
                )
                binding.BtnBgPanel.setBackgroundColor(
                    ContextCompat.getColor(
                        requireActivity(),
                        R.color.App_dark
                    )
                )
            }

            1 -> {
                createSelecteState(
                    R.drawable.select_button_1,
                    R.drawable.select_button_3,
                    R.drawable.select_button_2
                )
                SettextColorBlack(
                    ContextCompat.getColor(requireActivity(), R.color.white),
                    ContextCompat.getColor(requireActivity(), R.color.black)
                )
                binding.BtnBgPanel.setBackgroundColor(
                    ContextCompat.getColor(
                        requireActivity(),
                        R.color.theme1_ColorPrimaryDark
                    )
                )
            }

            2 -> {
                createSelecteState(
                    R.drawable.select_button_1_theme3,
                    R.drawable.select_button_3_theme3,
                    R.drawable.select_button_2_theme3
                )
                SettextColorBlack(
                    ContextCompat.getColor(requireActivity(), R.color.black),
                    ContextCompat.getColor(requireActivity(), R.color.white)
                )
                binding.BtnBgPanel.setBackgroundColor(
                    ContextCompat.getColor(
                        requireActivity(),
                        R.color.theme2_ColorPrimary
                    )
                )
            }

            3 -> {
                createSelecteState(
                    R.drawable.select_button_1_theme4,
                    R.drawable.select_button_3_theme4,
                    R.drawable.select_button_2_theme4
                )
                SettextColorBlack(
                    ContextCompat.getColor(requireActivity(), R.color.white),
                    ContextCompat.getColor(requireActivity(), R.color.black)
                )
                binding.BtnBgPanel.setBackgroundColor(
                    ContextCompat.getColor(
                        requireActivity(),
                        R.color.theme3_ColorPrimary
                    )
                )
            }

            4 -> {
                createSelecteState(
                    R.drawable.select_button_1_theme5,
                    R.drawable.select_button_3_theme5,
                    R.drawable.select_button_2_theme5
                )
                binding.BtnBgPanel.setBackgroundColor(
                    ContextCompat.getColor(
                        requireActivity(),
                        R.color.theme4_ColorPrimary
                    )
                )
            }

            5 -> {
                createSelecteState(
                    R.drawable.select_button_3_theme6,
                    R.drawable.select_button_1_theme6,
                    R.drawable.select_button_2_theme6
                )
                SettextColorBlack(
                    ContextCompat.getColor(requireActivity(), R.color.white),
                    ContextCompat.getColor(requireActivity(), R.color.black)
                )
                binding.BtnBgPanel.setBackgroundColor(
                    ContextCompat.getColor(
                        requireActivity(),
                        R.color.theme5_ButtonBG
                    )
                )
            }

            6 -> {
                createSelecteState(
                    R.drawable.select_button_3_theme7,
                    R.drawable.select_button_1_theme7,
                    R.drawable.select_button_2_theme7
                )
                binding.BtnBgPanel.setBackgroundColor(
                    ContextCompat.getColor(
                        requireActivity(),
                        R.color.theme6_ColorPrimary
                    )
                )
                SettextColorBlack(
                    ContextCompat.getColor(requireActivity(), R.color.white),
                    ContextCompat.getColor(requireActivity(), R.color.black)
                )
            }
        }
    }

    fun createSelecteState(normalDrawable: Int, oprationDrawable: Int, functionDrawable: Int) {

        //TODO NormalButton
        binding.button0.setBackgroundResource(normalDrawable)
        binding.button1.setBackgroundResource(normalDrawable)
        binding.button2.setBackgroundResource(normalDrawable)
        binding.button3.setBackgroundResource(normalDrawable)
        binding.button4.setBackgroundResource(normalDrawable)
        binding.button5.setBackgroundResource(normalDrawable)
        binding.button6.setBackgroundResource(normalDrawable)
        binding.button7.setBackgroundResource(normalDrawable)
        binding.button8.setBackgroundResource(normalDrawable)
        binding.button9.setBackgroundResource(normalDrawable)

        binding.buttongst12.setBackgroundResource(normalDrawable)
        binding.buttongst18.setBackgroundResource(normalDrawable)
        binding.buttongst28.setBackgroundResource(normalDrawable)
        binding.buttongst5.setBackgroundResource(normalDrawable)
        binding.buttongst3.setBackgroundResource(normalDrawable)
        binding.buttongstsub12.setBackgroundResource(normalDrawable)
        binding.buttongstsub18.setBackgroundResource(normalDrawable)
        binding.buttongstsub28.setBackgroundResource(normalDrawable)
        binding.buttongstsub3.setBackgroundResource(normalDrawable)
        binding.buttongstsub5.setBackgroundResource(normalDrawable)

        binding.buttonAddToMemory.setBackgroundResource(normalDrawable)
        binding.buttonSubtractFromMemory.setBackgroundResource(normalDrawable)
        binding.buttonRecallMemory.setBackgroundResource(normalDrawable)
        binding.buttonRoot.setBackgroundResource(normalDrawable)
        binding.buttonGT.setBackgroundResource(normalDrawable)
        binding.buttonMU.setBackgroundResource(normalDrawable)
        binding.buttonDecimalPoint.setBackgroundResource(normalDrawable)
        binding.buttonToggleSign.setBackgroundResource(normalDrawable)

        //TODO OprationButton

        binding.buttonDivide.setBackgroundResource(oprationDrawable)
        binding.buttonMultiply.setBackgroundResource(oprationDrawable)
        binding.buttonAdd.setBackgroundResource(oprationDrawable)
        binding.buttonModulas.setBackgroundResource(oprationDrawable)
        binding.buttonSubtract.setBackgroundResource(oprationDrawable)

        //TODO FunctionButton

        if (sharedPref.getInt("Theme", 0) == 0) {
            binding.buttonDivide.setTextColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.white
                )
            )
            binding.buttonMultiply.setTextColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.white
                )
            )
            binding.buttonAdd.setTextColor(ContextCompat.getColor(requireActivity(), R.color.white))
            binding.buttonModulas.setTextColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.white
                )
            )
            binding.buttonSubtract.setTextColor(
                ContextCompat.getColor(
                    requireActivity(),
                    R.color.white
                )
            )


            binding.btnCorrect.setBackgroundResource(R.drawable.select_blue_button)
            binding.btnCheck.setBackgroundResource(R.drawable.select_blue_button)
            binding.btnGST.setBackgroundResource(R.drawable.select_blue_button)
        } else {
            binding.btnCorrect.setBackgroundResource(functionDrawable)
            binding.btnCheck.setBackgroundResource(functionDrawable)
            binding.btnGST.setBackgroundResource(functionDrawable)
        }

        binding.buttonClear.setBackgroundResource(functionDrawable)
        binding.buttonEquals.setBackgroundResource(functionDrawable)
    }

    fun SettextColorBlack(color1: Int, color2: Int) {
        binding.button0.setTextColor(color1)
        binding.button1.setTextColor(color1)
        binding.button2.setTextColor(color1)
        binding.button3.setTextColor(color1)
        binding.button4.setTextColor(color1)
        binding.button5.setTextColor(color1)
        binding.button6.setTextColor(color1)
        binding.button7.setTextColor(color1)
        binding.button8.setTextColor(color1)
        binding.button9.setTextColor(color1)

        binding.buttongst12.setTextColor(color1)
        binding.buttongst18.setTextColor(color1)
        binding.buttongst28.setTextColor(color1)
        binding.buttongst5.setTextColor(color1)
        binding.buttongst3.setTextColor(color1)
        binding.buttongstsub12.setTextColor(color1)
        binding.buttongstsub18.setTextColor(color1)
        binding.buttongstsub28.setTextColor(color1)
        binding.buttongstsub3.setTextColor(color1)
        binding.buttongstsub5.setTextColor(color1)

        binding.buttonAddToMemory.setTextColor(color1)
        binding.buttonSubtractFromMemory.setTextColor(color1)
        binding.buttonRecallMemory.setTextColor(color1)
        binding.buttonRoot.setTextColor(color1)
        binding.buttonGT.setTextColor(color1)
        binding.buttonMU.setTextColor(color1)
        binding.buttonDecimalPoint.setTextColor(color1)
        binding.buttonToggleSign.setTextColor(color1)


        binding.buttonDivide.setTextColor(color2)
        binding.buttonMultiply.setTextColor(color2)
        binding.buttonAdd.setTextColor(color2)
        binding.buttonModulas.setTextColor(color2)
        binding.buttonSubtract.setTextColor(color2)
    }

    override fun onPurchasesUpdated(
        billingResult: BillingResult,
        purchases: MutableList<Purchase>?
    ) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            val skuListData = tbSkuDao.getData()
            if (!skuListData.isNullOrEmpty())
                for (purchase in purchases) {
                    val gson = Gson()
                    PURCHASE = gson.toJson(purchase.originalJson)

                    val originalJson = JSONObject(purchase.originalJson)
                    val productId = originalJson.getString("productId")
                    skuListData.forEach { itSub ->
                        if (productId == itSub.sku) {
                            val order = RoomOrder()
                            order.orderId = productId
                            order.purchaseTime = purchase.purchaseTime
                            order.month = itSub.validity.toInt() * 30
                            roomOrderDao.insertRoomOrder(order)
                        }
                    }
                }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            // Handle an error caused by a user cancelling the purchase flow.
        }
    }


    fun isLoadingAds(): Boolean {
        return binding.adsPorgress.visibility == View.VISIBLE
    }

    fun showProgress(visible:Int){
        binding.adsPorgress.visibility=visible
    }
}