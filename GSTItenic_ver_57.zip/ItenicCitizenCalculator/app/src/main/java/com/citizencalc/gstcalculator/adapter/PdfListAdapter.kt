package com.citizencalc.gstcalculator.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.citizencalc.gstcalculator.BuildConfig
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.activity.ShowPdf

import java.io.File

class PdfListAdapter(): RecyclerView.Adapter<PdfListHolder>() {
    var data_list: ArrayList<File>? = null
    var context: Context? = null

    constructor(data_list: ArrayList<File>?, context: Context?) : this() {
        this.data_list = data_list
        this.context = context
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PdfListHolder {
        val view: View
        val layoutInflater = LayoutInflater.from(parent.context)
        view = layoutInflater.inflate(R.layout.pdf_list_item, null)
        return PdfListHolder(view)
    }

    override fun onBindViewHolder(holder: PdfListHolder, position: Int) {
        holder.textView.text = data_list?.get(position).toString().substring(data_list?.get(position).toString().lastIndexOf("/") + 1)
        holder.layout.setOnClickListener(View.OnClickListener {

            val photoURI: Uri = FileProvider.getUriForFile(
                holder.layout.context,
                BuildConfig.APPLICATION_ID+ ".gstcalculator",
                data_list!![position]
            )
            val intent = Intent(context, ShowPdf::class.java)
            intent.putExtra("URI", photoURI.toString())
            context!!.startActivity(intent)
        })
    }

    override fun getItemCount(): Int {
        return data_list!!.size
    }


}
class PdfListHolder(itemView: View) :RecyclerView.ViewHolder(itemView) {
    var textView: TextView = itemView.findViewById(R.id.pdf_name)
    var layout: LinearLayout = itemView.findViewById(R.id.layout_back)
}