package com.citizencalc.gstcalculator.Classes.common;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import com.citizencalc.gstcalculator.R;
import com.citizencalc.gstcalculator.database.DatabaseGst;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class DialogCalss extends Dialog implements View.OnFocusChangeListener {

    final int[] ids = {R.id.et_plus_one, R.id.et_plus_two, R.id.et_plus_three, R.id.et_plus_four, R.id.et_plus_five, R.id.et_minus_one, R.id.et_minus_two, R.id.et_minus_three, R.id.et_minus_four, R.id.et_minus_five};
    final String[] defaul_val = {"+3", "+5", "+12", "+18", "+28", "-3", "-5", "-12", "-18", "-28"};
    private boolean is_plus = false, is_eror = false;
    SharedPreferences slab_prefr,theme_Shared;
    List<String> pref_values;
    int count = 0;
    //RelativeLayout ad_tax;
    SharedPreferences preferences;

    public EditText edit_p1, edit_p2, edit_p3, edit_p4, edit_p5, edit_m1, edit_m2, edit_m3, edit_m4, edit_m5;
    public static String slab_p1 = "", slab_p2 = "", slab_p3 = "", slab_p4 = "", slab_p5 = "", slab_m1 = "", slab_m2 = "", slab_m3 = "", slab_m4 = "", slab_m5 = "";
    DatabaseGst databaseGst;
    TextView btn_done, btn_Cancle;
    Dialogdismiss dialogdismiss;
    public LinearLayout layout_add,layout_sub;

    public DialogCalss(Context context, Dialogdismiss dialogdismiss) {
        super(context);
        this.dialogdismiss = dialogdismiss;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.slab_dialog_layout);

        layout_add = findViewById(R.id.layout_add);
        layout_sub = findViewById(R.id.layout_sub);
        btn_done = findViewById(R.id.btn_done);
        btn_Cancle = findViewById(R.id.btn_cancel);

        preferences = getContext().getSharedPreferences("update", MODE_PRIVATE);
        slab_prefr = getContext().getSharedPreferences("slab_values", MODE_PRIVATE);
        theme_Shared = getContext().getSharedPreferences("AppPref", Context.MODE_PRIVATE);
        setThemeStyle(theme_Shared.getInt("Theme", 0));
        pref_values = new ArrayList<>();
        setpref();
        new AppUtility().is_gst_button = false;


        edit_p1 = findViewById(ids[0]);
        edit_p2 = findViewById(ids[1]);
        edit_p3 = findViewById(ids[2]);
        edit_p4 = findViewById(ids[3]);
        edit_p5 = findViewById(ids[4]);
        edit_m1 = findViewById(ids[5]);
        edit_m2 = findViewById(ids[6]);
        edit_m3 = findViewById(ids[7]);
        edit_m4 = findViewById(ids[8]);
        edit_m5 = findViewById(ids[9]);

        btn_Cancle.setOnClickListener(v -> dismiss());
        init();
        btn_done.setOnClickListener(v -> {
            count = 0;
            if (!reapet_slab()) {
                for (int i = 0; i < ids.length; i++) {
                    Check_constarins(ids[i]);
                }
            }
        });
    }

    public void init() {
        for (int i = 0; i < ids.length; i++) {
            findViewById(ids[i]).setOnFocusChangeListener(this);
            setValues(ids[i], i);
            selection_last(ids[i]);
            ET_TaxtChange(ids[i]);
        }
    }

    private void selection_last(int i) {
        EditText editText = findViewById(i);
        editText.setSelection(editText.getText().length());
    }

    private void ET_TaxtChange(int i) {
        final EditText editText = findViewById(i);

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                editText.setSelection(editText.getText().length());
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    if (s.length() == 0) {
                        if (is_plus) {
                            editText.setText("+");
                            editText.setSelection(editText.getText().length());
                        } else {
                            editText.setText("-");
                            editText.setSelection(editText.getText().length());
                        }

                    } else if (s.length() == 2) {
                        editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);

                        if (editText.getText().toString().contains("."))
                            setzero(editText);

                    } else if (s.length() == 3) {
                        editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);

                        if (editText.getText().toString().equals("+00") || editText.getText().toString().equals("-00"))
                            setzero(editText);
                    } else if (s.length() == 6) {
                        editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
                    } else if (s.length() == 7) {
                        editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);

                        if (editText.getText().toString().equals("+0.0000") || editText.getText().toString().equals("-0.0000"))
                            setzero(editText);
                    } else {
                        editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
                    }
                } catch (NullPointerException | IndexOutOfBoundsException | NumberFormatException  e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void Check_constarins(int id) {
        EditText editText = findViewById(id);

        if (editText.getText().toString().length() == 1 || Double.valueOf(editText.getText().toString().substring(1, editText.getText().toString().length())) > 999.99) {
            // Toast.makeText(this, "Enter Correct value", Toast.LENGTH_SHORT).show();
            is_eror = true;
        } else {
            count++;

            if (ids[0] == id)
                store_shared(0, id);

            if (ids[1] == id)
                store_shared(1, id);

            if (ids[2] == id)
                store_shared(2, id);

            if (ids[3] == id)
                store_shared(3, id);

            if (ids[4] == id)
                store_shared(4, id);

            if (ids[5] == id)
                store_shared(5, id);

            if (ids[6] == id)
                store_shared(6, id);

            if (ids[7] == id)
                store_shared(7, id);

            if (ids[8] == id)
                store_shared(8, id);

            if (ids[9] == id)
                store_shared(9, id);

            if (count == 10) {

                slab_p1 = edit_p1.getText().toString() + "%";
                slab_p2 = edit_p2.getText().toString() + "%";
                slab_p3 = edit_p3.getText().toString() + "%";
                slab_p4 = edit_p4.getText().toString() + "%";
                slab_p5 = edit_p5.getText().toString() + "%";
                slab_m1 = edit_m1.getText().toString() + "%";
                slab_m2 = edit_m2.getText().toString() + "%";
                slab_m3 = edit_m3.getText().toString() + "%";
                slab_m4 = edit_m4.getText().toString() + "%";
                slab_m5 = edit_m5.getText().toString() + "%";
                AppUtility.is_done = true;

                dialogdismiss.onDismiss(true);
                dismiss();
            }
        }
    }

    private void setzero(EditText editText) {
        if (is_plus) {
            editText.setText("+0");
            editText.setSelection(editText.getText().length());
        } else {
            editText.setText("-0");
            editText.setSelection(editText.getText().length());
        }
    }

    private void setpref() {
        for (int i = 0; i < ids.length; i++) {
            pref_values.add(slab_prefr.getString("slab_" + i, defaul_val[i]));
        }
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        int action_id = v.getId();
        EditText editText = findViewById(action_id);

        if (action_id == ids[0]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[0]);
            }
        } else if (action_id == ids[1]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[1]);
            }
        } else if (action_id == ids[2]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[2]);
            }
        } else if (action_id == ids[3]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[3]);
            }
        } else if (action_id == ids[4]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[4]);
            }
        } else if (action_id == ids[5]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[5]);
            }
        } else if (action_id == ids[6]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[6]);
            }
        } else if (action_id == ids[7]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[7]);
            }
        } else if (action_id == ids[8]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[8]);
            }
        } else if (action_id == ids[9]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[9]);
            }
        }
    }

    private void setValues(int id, int i) {
        EditText editText = findViewById(id);
        if (ids[i] == id) editText.setText(pref_values.get(i));
    }

    private void store_shared(int i, int id) {
        SharedPreferences.Editor editor_slab = slab_prefr.edit();
        EditText editText = findViewById(id);

        if (editText.getText().toString().substring(editText.getText().toString().length() - 1).equals(".")) {
            editor_slab.putString("slab_" + i, editText.getText().toString().substring(0, editText.getText().toString().length() - 1));
        } else if (i <= 4) {
            if (!editText.getText().toString().contains("+")) {
                editor_slab.putString("slab_" + i, "+" + editText.getText().toString());
            } else {
                editor_slab.putString("slab_" + i, editText.getText().toString());
            }
        } else if (i >= 5) {
            if (!editText.getText().toString().contains("-")) {
                editor_slab.putString("slab_" + i, "-" + editText.getText().toString());
            } else {
                editor_slab.putString("slab_" + i, editText.getText().toString());
            }
        }
        editor_slab.apply();
    }

    private boolean reapet_slab() {
        EditText plus_one, plus_two, plus_three, plus_four, plus_five, minus_one, minus_two, minus_three, minus_four, minus_five;
        plus_one = findViewById(ids[0]);
        String add_one = plus_one.getText().toString();
        plus_two = findViewById(ids[1]);
        plus_three = findViewById(ids[2]);
        plus_four = findViewById(ids[3]);
        plus_five = findViewById(ids[4]);
        minus_one = findViewById(ids[5]);
        minus_two = findViewById(ids[6]);
        minus_three = findViewById(ids[7]);
        minus_four = findViewById(ids[8]);
        minus_five = findViewById(ids[9]);

        if (plus_one.getText().toString().equals(plus_two.getText().toString()) || plus_one.getText().toString().equals(plus_three.getText().toString()) || plus_one.getText().toString().equals(plus_four.getText().toString()) || plus_one.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_two.getText().toString().equals(plus_one.getText().toString()) || plus_two.getText().toString().equals(plus_three.getText().toString()) || plus_two.getText().toString().equals(plus_four.getText().toString()) || plus_two.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_three.getText().toString().equals(plus_two.getText().toString()) || plus_three.getText().toString().equals(plus_one.getText().toString()) || plus_three.getText().toString().equals(plus_four.getText().toString()) || plus_three.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_four.getText().toString().equals(plus_two.getText().toString()) || plus_four.getText().toString().equals(plus_three.getText().toString()) || plus_four.getText().toString().equals(plus_one.getText().toString()) || plus_four.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_five.getText().toString().equals(plus_two.getText().toString()) || plus_five.getText().toString().equals(plus_three.getText().toString()) || plus_five.getText().toString().equals(plus_four.getText().toString()) || plus_five.getText().toString().equals(plus_one.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_one.getText().toString().equals(minus_two.getText().toString()) || minus_one.getText().toString().equals(minus_three.getText().toString()) || minus_one.getText().toString().equals(minus_four.getText().toString()) || minus_one.getText().toString().equals(minus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_two.getText().toString().equals(minus_one.getText().toString()) || minus_two.getText().toString().equals(minus_three.getText().toString()) || minus_two.getText().toString().equals(plus_four.getText().toString()) || minus_two.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_three.getText().toString().equals(minus_two.getText().toString()) || minus_three.getText().toString().equals(minus_one.getText().toString()) || minus_three.getText().toString().equals(minus_four.getText().toString()) || minus_three.getText().toString().equals(minus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_four.getText().toString().equals(minus_two.getText().toString()) || minus_four.getText().toString().equals(minus_three.getText().toString()) || minus_four.getText().toString().equals(minus_one.getText().toString()) || minus_four.getText().toString().equals(minus_five.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_five.getText().toString().equals(minus_two.getText().toString()) || minus_five.getText().toString().equals(minus_three.getText().toString()) || minus_five.getText().toString().equals(plus_four.getText().toString()) || minus_five.getText().toString().equals(minus_one.getText().toString())) {
            Toast.makeText(getContext(), "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }
    private void setThemeStyle(int currentTheme) {
        switch (currentTheme) {
            case 0 : {
                layout_add.setBackgroundColor(getContext().getResources().getColor(R.color.App_light));
                layout_sub.setBackgroundColor(getContext().getResources().getColor(R.color.App_light));
                setTextViewDrawableColor(btn_done,R.color.App_dark);
                setTextViewDrawableColor(btn_Cancle,R.color.App_dark);
                break;
            }
            case 1 : {
                layout_add.setBackgroundColor(getContext().getResources().getColor(R.color.theme1_ColorPrimary));
                layout_sub.setBackgroundColor(getContext().getResources().getColor(R.color.theme1_ColorPrimary));
                setTextViewDrawableColor(btn_done,R.color.theme1_ColorPrimaryDark);
                setTextViewDrawableColor(btn_Cancle,R.color.theme1_ColorPrimaryDark);
                break;
            }
            case 2 : {
                layout_add.setBackgroundColor(getContext().getResources().getColor(R.color.theme2_ColorPrimaryDark));
                layout_sub.setBackgroundColor(getContext().getResources().getColor(R.color.theme2_ColorPrimaryDark));
                setTextViewDrawableColor(btn_done,R.color.theme2_ColorPrimary);
                setTextViewDrawableColor(btn_Cancle,R.color.theme2_ColorPrimary);
                break;
            }
            case 3 : {
                layout_add.setBackgroundColor(getContext().getResources().getColor(R.color.theme3_ColorPrimaryDark));
                layout_sub.setBackgroundColor(getContext().getResources().getColor(R.color.theme3_ColorPrimaryDark));
                setTextViewDrawableColor(btn_done,R.color.theme3_ColorPrimary);
                setTextViewDrawableColor(btn_Cancle,R.color.theme3_ColorPrimary);
                break;
            }
            case 4 : {
                layout_add.setBackgroundColor(getContext().getResources().getColor(R.color.theme4_ColorPrimaryDark));
                layout_sub.setBackgroundColor(getContext().getResources().getColor(R.color.theme4_ColorPrimaryDark));
                setTextViewDrawableColor(btn_done,R.color.theme4_ColorPrimary);
                setTextViewDrawableColor(btn_Cancle,R.color.theme4_ColorPrimary);
                break;
            }
            case 5 : {
                layout_add.setBackgroundColor(getContext().getResources().getColor(R.color.theme5_ColorPrimaryDark));
                layout_sub.setBackgroundColor(getContext().getResources().getColor(R.color.theme5_ColorPrimaryDark));
                setTextViewDrawableColor(btn_done,R.color.theme5_ButtonBG);
                setTextViewDrawableColor(btn_Cancle,R.color.theme5_ButtonBG);
                break;
            }
            case 6 : {
                layout_add.setBackgroundColor(getContext().getResources().getColor(R.color.theme6_ColorPrimaryDark));
                layout_sub.setBackgroundColor(getContext().getResources().getColor(R.color.theme6_ColorPrimaryDark));
                setTextViewDrawableColor(btn_done,R.color.theme6_ColorPrimary);
                setTextViewDrawableColor(btn_Cancle,R.color.theme6_ColorPrimary);
                break;
            }
        }
    }

    private void setTextViewDrawableColor(TextView textView, int color) {
        DrawableCompat.setTint(
                DrawableCompat.wrap(textView.getBackground()),
                ContextCompat.getColor(getContext(), color)
        );
    }
}