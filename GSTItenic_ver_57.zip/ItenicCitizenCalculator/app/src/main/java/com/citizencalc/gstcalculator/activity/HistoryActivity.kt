package com.citizencalc.gstcalculator.activity

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.databinding.ActivityHistoryBinding
import com.citizencalc.gstcalculator.databinding.CustomActionbarHistoryBinding
import com.citizencalc.gstcalculator.fragment.GstCalculator.Companion.historylog_list
import com.citizencalc.gstcalculator.model.HistoryData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    var listAdepters: ListAdepters? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        window.addFlags(1024)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mPrefs = getSharedPreferences("myVal", MODE_PRIVATE)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val customActionBinding = CustomActionbarHistoryBinding.inflate(layoutInflater)
        supportActionBar?.customView = customActionBinding.root

        customActionBinding.actionBarTitle.text = "History"
        binding.dailogRecycleview.layoutManager = LinearLayoutManager(applicationContext)

        val json: String? = mPrefs.getString("MyObject", "")
        if (json !== "") {
            val listOfHistoryType = object : TypeToken<ArrayList<HistoryData>>() {}.type
            val myhistory: ArrayList<HistoryData>? =
                Gson().fromJson<ArrayList<HistoryData>>(json, listOfHistoryType)
            customActionBinding.removeAll.setOnClickListener { v1: View? ->
                val builder = AlertDialog.Builder(this@HistoryActivity)
                builder.setMessage("Are you sure want to clear History?")
                builder.setTitle("Clear History !")
                builder.setCancelable(false)
                builder.setPositiveButton("Yes") { dialog: DialogInterface?, which: Int ->
                    myhistory?.clear()
                    customActionBinding.removeAll.visibility = View.GONE
                    binding.noHistory.visibility = View.VISIBLE

                    historylog_list.clear()
                    val editor: SharedPreferences.Editor = mPrefs.edit()
                    editor.putString("MyObject", "")
                    editor.apply()

                    listAdepters?.notifyDataSetChanged()
                    binding.noHistory.visibility = View.VISIBLE
                }
                builder.setNegativeButton("No") { dialog: DialogInterface, which: Int -> dialog.cancel() }
                val alertDialog = builder.create()
                alertDialog.setOnShowListener {
                    alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.BLACK)
                    alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.BLACK)
                }
                alertDialog.show()
            }
            if (myhistory != null) {
                customActionBinding.removeAll.visibility = View.VISIBLE
                listAdepters = ListAdepters(this@HistoryActivity, myhistory)
                binding.dailogRecycleview.adapter = listAdepters
                binding.noHistory.visibility = View.GONE
            } else {
                customActionBinding.removeAll.visibility = View.GONE
                binding.noHistory.visibility = View.VISIBLE
            }
        } else {
            customActionBinding.removeAll.visibility = View.GONE
            binding.noHistory.visibility = View.VISIBLE
        }

//        historylog_list.clear();
//        historylog_list.add(obj);
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    class ListAdepters(var context: Context, datalist: List<HistoryData>) :
        RecyclerView.Adapter<ListAdepters.ListHolder>() {
        var datalist: List<HistoryData>

        init {
            this.datalist = datalist
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListHolder {
            val view: View
            val layoutInflater = LayoutInflater.from(parent.context)
            view = layoutInflater.inflate(R.layout.recycle_item_new, null)
            return ListHolder(view)
        }

        override fun onBindViewHolder(holder: ListHolder, position: Int) {
//            holder.textOprand.setText(datalist.get(position).getFirst_oprand());
            holder.textOprand.text = datalist[position].first_oprand
            holder.whatsaap.setOnClickListener { view: View? ->
                val pm: PackageManager = holder.whatsaap.context.packageManager
                try {
                    val intent = Intent(Intent.ACTION_SEND)
                    intent.type = "text/plain"
                    val info = pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA)
                    intent.setPackage("com.whatsapp")
                    intent.putExtra(Intent.EXTRA_TEXT, holder.textOprand.text.toString())
                    holder.whatsaap.context.startActivity(intent)
                } catch (e: PackageManager.NameNotFoundException) {
                    Toast.makeText(
                        holder.whatsaap.context,
                        "Whatsapp is not installed",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            holder.share.setOnClickListener { view: View? ->
                val shareBody = holder.textOprand.text.toString()
                val sharingIntent = Intent(Intent.ACTION_SEND)
                sharingIntent.type = "text/plain"
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here")
                sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody)
                holder.share.context.startActivity(
                    Intent.createChooser(
                        sharingIntent,
                        "Share With:"
                    )
                )
            }
        }

        override fun getItemCount(): Int {
            return datalist.size
        }

        inner class ListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            var textOprand: TextView
            var textOprator: TextView? = null
            var textResult: TextView? = null
            var whatsaap: ImageView
            var share: ImageView

            init {
                textOprand = itemView.findViewById(R.id.operandTextView)
                whatsaap = itemView.findViewById(R.id.whatsaap)
                share = itemView.findViewById(R.id.share)
            }
        }
    }
}