package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.util.List;
@Keep
public class Result {

    @SerializedName("sku")
    private List<Sku> sku;


    public List<Sku> getSku() {
        return sku;
    }

    public void setSku(List<Sku> sku) {
        this.sku = sku;
    }

}
