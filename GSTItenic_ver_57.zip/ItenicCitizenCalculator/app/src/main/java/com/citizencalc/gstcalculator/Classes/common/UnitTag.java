package com.citizencalc.gstcalculator.Classes.common;

import android.app.Activity;
import android.content.Context;

import com.citizencalc.gstcalculator.R;

public class UnitTag {
    Context activity;

    public final static String lenth_arrey[] = new String[]{"Micrometer", "Millimeter", "centimeter", "decimeter", "Meter", "Kilometer", "Mile", "Inch", "Foot", "Yard"};


    public static final String Area = "Area";
    public static final String Length = "Length";
    public static final String Weight = "Weight";
    public static final String Time = "Time";
    public static final String Tempreture = "Tempreture";
    public static final String Speed = "Speed";
    public static final String Volume = "Volume";
    public static final String Energy = "Energy";
    public static final String Fuel = "Fuel";
    public static final String Presure = "Presure";
    public static final String Storage = "Storage";


    public UnitTag(Context activity) {
        this.activity = activity;

    }

    //------------------------------------------------Area Tag ------------------------------------------------------------

    // mm2 to other unit
    public static final String Area_1_1 = "mm2-cm2";
    public static final String Area_1_2 = "cm2-mm2";
    public static final String Area_1_3 = "mm2-m2";
    public static final String Area_1_4 = "m2-mm2";
    public static final String Area_1_5 = "mm2-km2";
    public static final String Area_1_6 = "km2-mm2";
    public static final String Area_1_7 = "mm2-mi2";
    public static final String Area_1_8 = "mi2-mm2";
    public static final String Area_1_9 = "mm2-in2";
    public static final String Area_1_10 = "in2-mm2";
    public static final String Area_1_11 = "mm2-ft2";
    public static final String Area_1_12 = "ft2-mm2";
    public static final String Area_1_13 = "mm2-yd2";
    public static final String Area_1_14 = "yd2-mm2";
    public static final String Area_1_15 = "mm2-ha";
    public static final String Area_1_16 = "ha-mm2";
    public static final String Area_1_17 = "mm2-ac";
    public static final String Area_1_18 = "ac-mm2";
    public static final String Area_1_19 = "mm2-mm2";


    // cm2 to other unit
    public static final String Area_2_3 = "cm2-m2";
    public static final String Area_2_4 = "m2-cm2";
    public static final String Area_2_5 = "cm2-km2";
    public static final String Area_2_6 = "km2-cm2";
    public static final String Area_2_7 = "cm2-mi2";
    public static final String Area_2_8 = "mi2-cm2";
    public static final String Area_2_9 = "cm2-in2";
    public static final String Area_2_10 = "in2-cm2";
    public static final String Area_2_11 = "cm2-ft2";
    public static final String Area_2_12 = "ft2-cm2";
    public static final String Area_2_13 = "cm2-yd2";
    public static final String Area_2_14 = "yd2-cm2";
    public static final String Area_2_15 = "cm2-ha";
    public static final String Area_2_16 = "ha-cm2";
    public static final String Area_2_17 = "cm2-ac";
    public static final String Area_2_18 = "ac-cm2";
    public static final String Area_2_19 = "cm2-cm2";


    //m2 to other unit
    public static final String Area_3_5 = "m2-km2";
    public static final String Area_3_6 = "km2-m2";
    public static final String Area_3_7 = "m2-mi2";
    public static final String Area_3_8 = "mi2-m2";
    public static final String Area_3_9 = "m2-in2";
    public static final String Area_3_10 = "in2-m2";
    public static final String Area_3_11 = "m2-ft2";
    public static final String Area_3_12 = "ft2-m2";
    public static final String Area_3_13 = "m2-yd2";
    public static final String Area_3_14 = "yd2-m2";
    public static final String Area_3_15 = "m2-ha";
    public static final String Area_3_16 = "ha-m2";
    public static final String Area_3_17 = "m2-ac";
    public static final String Area_3_18 = "ac-m2";
    public static final String Area_3_19 = "m2-m2";


    //km2 to other unit
    public static final String Area_4_7 = "km2-mi2";
    public static final String Area_4_8 = "mi2-km2";
    public static final String Area_4_9 = "km2-in2";
    public static final String Area_4_10 = "in2-km2";
    public static final String Area_4_11 = "km2-ft2";
    public static final String Area_4_12 = "ft2-km2";
    public static final String Area_4_13 = "km2-yd2";
    public static final String Area_4_14 = "yd2-km2";
    public static final String Area_4_15 = "km2-ha";
    public static final String Area_4_16 = "ha-km2";
    public static final String Area_4_17 = "km2-ac";
    public static final String Area_4_18 = "ac-km2";
    public static final String Area_4_19 = "km2-km2";


    //mi2 to other unit
    public static final String Area_5_9 = "mi2-in2";
    public static final String Area_5_10 = "in2-mi2";
    public static final String Area_5_11 = "mi2-ft2";
    public static final String Area_5_12 = "ft2-mi2";
    public static final String Area_5_13 = "mi2-yd2";
    public static final String Area_5_14 = "yd2-mi2";
    public static final String Area_5_15 = "mi2-ha";
    public static final String Area_5_16 = "ha-mi2";
    public static final String Area_5_17 = "mi2-ac";
    public static final String Area_5_18 = "ac-mi2";
    public static final String Area_5_19 = "mi2-mi2";


    //in2 to other unit
    public static final String Area_6_11 = "in2-ft2";
    public static final String Area_6_12 = "ft2-in2";
    public static final String Area_6_13 = "in2-yd2";
    public static final String Area_6_14 = "yd2-in2";
    public static final String Area_6_15 = "in2-ha";
    public static final String Area_6_16 = "ha-in2";
    public static final String Area_6_17 = "in2-ac";
    public static final String Area_6_18 = "ac-in2";
    public static final String Area_6_19 = "in2-in2";


    //ft2 to other unit
    public static final String Area_7_13 = "ft2-yd2";
    public static final String Area_7_14 = "yd2-ft2";
    public static final String Area_7_15 = "ft2-ha";
    public static final String Area_7_16 = "ha-ft2";
    public static final String Area_7_17 = "ft2-ac";
    public static final String Area_7_18 = "ac-ft2";
    public static final String Area_7_19 = "ft2-ft2";

    //yd2 to other unit
    public static final String Area_8_15 = "yd2-ha";
    public static final String Area_8_16 = "ha-yd2";
    public static final String Area_8_17 = "yd2-ac";
    public static final String Area_8_18 = "ac-yd2";
    public static final String Area_8_19 = "yd2-yd2";


    //ha to other unit
    public static final String Area_9_17 = "ha-ac";
    public static final String Area_9_18 = "ac-ha";
    public static final String Area_9_19 = "ha-ha";
    public static final String Area_10_20 = "ac-ac";


    //------------------------------------------------Area Tag over------------------------------------------------------------


    //------------------------------------------------Length Tag ------------------------------------------------------------
    // μm to other unit
    public static final String Leanth_1_1 = "μm-mm";
    public static final String Leanth_1_2 = "mm-μm";
    public static final String Leanth_1_3 = "μm-cm";
    public static final String Leanth_1_4 = "cm-μm";
    public static final String Leanth_1_5 = "μm-dm";
    public static final String Leanth_1_6 = "dm-μm";
    public static final String Leanth_1_7 = "μm-m";
    public static final String Leanth_1_8 = "m-μm";
    public static final String Leanth_1_9 = "μm-km";
    public static final String Leanth_1_10 = "km-μm";
    public static final String Leanth_1_11 = "μm-mi";
    public static final String Leanth_1_12 = "mi-μm";
    public static final String Leanth_1_13 = "μm-in";
    public static final String Leanth_1_14 = "in-μm";
    public static final String Leanth_1_15 = "μm-ft";
    public static final String Leanth_1_16 = "ft-μm";
    public static final String Leanth_1_17 = "μm-yd";
    public static final String Leanth_1_18 = "yd-μm";
    public static final String Leanth_1_19 = "μm-μm";

    //mm to other unit
    public static final String Leanth_2_3 = "mm-cm";
    public static final String Leanth_2_4 = "cm-mm";
    public static final String Leanth_2_5 = "mm-dm";
    public static final String Leanth_2_6 = "dm-mm";
    public static final String Leanth_2_7 = "mm-m";
    public static final String Leanth_2_8 = "m-mm";
    public static final String Leanth_2_9 = "mm-km";
    public static final String Leanth_2_10 = "km-mm";
    public static final String Leanth_2_11 = "mm-mi";
    public static final String Leanth_2_12 = "mi-mm";
    public static final String Leanth_2_13 = "mm-in";
    public static final String Leanth_2_14 = "in-mm";
    public static final String Leanth_2_15 = "mm-ft";
    public static final String Leanth_2_16 = "ft-mm";
    public static final String Leanth_2_17 = "mm-yd";
    public static final String Leanth_2_18 = "yd-mm";
    public static final String Leanth_2_19 = "mm-mm";

    //cm to other unit
    public static final String Leanth_3_5 = "cm-dm";
    public static final String Leanth_3_6 = "dm-cm";
    public static final String Leanth_3_7 = "cm-m";
    public static final String Leanth_3_8 = "m-cm";
    public static final String Leanth_3_9 = "cm-km";
    public static final String Leanth_3_10 = "km-cm";
    public static final String Leanth_3_11 = "cm-mi";
    public static final String Leanth_3_12 = "mi-cm";
    public static final String Leanth_3_13 = "cm-in";
    public static final String Leanth_3_14 = "in-cm";
    public static final String Leanth_3_15 = "cm-ft";
    public static final String Leanth_3_16 = "ft-cm";
    public static final String Leanth_3_17 = "cm-yd";
    public static final String Leanth_3_18 = "yd-cm";
    public static final String Leanth_3_19 = "cm-cm";

    //dm to other unit
    public static final String Leanth_4_7 = "dm-m";
    public static final String Leanth_4_8 = "m-dm";
    public static final String Leanth_4_9 = "dm-km";
    public static final String Leanth_4_10 = "km-dm";
    public static final String Leanth_4_11 = "dm-mi";
    public static final String Leanth_4_12 = "mi-dm";
    public static final String Leanth_4_13 = "dm-in";
    public static final String Leanth_4_14 = "in-dm";
    public static final String Leanth_4_15 = "dm-ft";
    public static final String Leanth_4_16 = "ft-dm";
    public static final String Leanth_4_17 = "dm-yd";
    public static final String Leanth_4_18 = "yd-dm";
    public static final String Leanth_4_19 = "dm-dm";

    //m to other unit
    public static final String Leanth_5_9 = "m-km";
    public static final String Leanth_5_10 = "km-m";
    public static final String Leanth_5_11 = "m-mi";
    public static final String Leanth_5_12 = "mi-m";
    public static final String Leanth_5_13 = "m-in";
    public static final String Leanth_5_14 = "in-m";
    public static final String Leanth_5_15 = "m-ft";
    public static final String Leanth_5_16 = "ft-m";
    public static final String Leanth_5_17 = "m-yd";
    public static final String Leanth_5_18 = "yd-m";
    public static final String Leanth_5_19 = "m-m";

    //km to other unit
    public static final String Leanth_6_11 = "km-mi";
    public static final String Leanth_6_12 = "mi-km";
    public static final String Leanth_6_13 = "km-in";
    public static final String Leanth_6_14 = "in-km";
    public static final String Leanth_6_15 = "km-ft";
    public static final String Leanth_6_16 = "ft-km";
    public static final String Leanth_6_17 = "km-yd";
    public static final String Leanth_6_18 = "yd-km";
    public static final String Leanth_6_19 = "km-km";

    //in to other unit
    public static final String Leanth_7_13 = "in-mi";
    public static final String Leanth_7_14 = "mi-in";
    public static final String Leanth_7_15 = "in-ft";
    public static final String Leanth_7_16 = "ft-in";
    public static final String Leanth_7_17 = "in-yd";
    public static final String Leanth_7_18 = "yd-in";
    public static final String Leanth_7_19 = "in-in";

    //ft to other unit
    public static final String Leanth_8_15 = "ft-mi";
    public static final String Leanth_8_16 = "mi-ft";
    public static final String Leanth_8_17 = "ft-yd";
    public static final String Leanth_8_18 = "yd-ft";
    public static final String Leanth_8_19 = "ft-ft";

    //yd to all
    public static final String Leanth_9_17 = "mi-yd";
    public static final String Leanth_9_18 = "yd-mi";
    public static final String Leanth_9_19 = "yd-yd";
    public static final String Leanth_9_20 = "mi-mi";

    //------------------------------------------------Length Tag over------------------------------------------------------------
    //------------------------------------------------Weight Tag ------------------------------------------------------------

    // μg to other unit
    public static final String Weight_1_1 = "μg-mg";
    public static final String Weight_1_2 = "mg-μg";
    public static final String Weight_1_3 = "μg-g";
    public static final String Weight_1_4 = "g-μg";
    public static final String Weight_1_5 = "μg-kg";
    public static final String Weight_1_6 = "kg-μg";
    public static final String Weight_1_7 = "μg-lb";
    public static final String Weight_1_8 = "lb-μg";
    public static final String Weight_1_9 = "μg-oz";
    public static final String Weight_1_10 = "oz-μg";
    public static final String Weight_1_11 = "μg-gr";
    public static final String Weight_1_12 = "gr-μg";
    public static final String Weight_1_13 = "μg-t";
    public static final String Weight_1_14 = "t-μg";
    public static final String Weight_1_15 = "μg-t(US)";
    public static final String Weight_1_16 = "t(US)-μg";
    public static final String Weight_1_17 = "μg-t(UK)";
    public static final String Weight_1_18 = "t(UK)-μg";
    public static final String Weight_1_19 = "μg-st";
    public static final String Weight_1_20 = "st-μg";
    public static final String Weight_1_21 = "μg-μg";

    // mg to other unit
    public static final String Weight_2_3 = "mg-g";
    public static final String Weight_2_4 = "g-mg";
    public static final String Weight_2_5 = "mg-kg";
    public static final String Weight_2_6 = "kg-mg";
    public static final String Weight_2_7 = "mg-lb";
    public static final String Weight_2_8 = "lb-mg";
    public static final String Weight_2_9 = "mg-oz";
    public static final String Weight_2_10 = "oz-mg";
    public static final String Weight_2_11 = "mg-gr";
    public static final String Weight_2_12 = "gr-mg";
    public static final String Weight_2_13 = "mg-t";
    public static final String Weight_2_14 = "t-mg";
    public static final String Weight_2_15 = "mg-t(US)";
    public static final String Weight_2_16 = "t(US)-mg";
    public static final String Weight_2_17 = "mg-t(UK)";
    public static final String Weight_2_18 = "t(UK)-mg";
    public static final String Weight_2_19 = "mg-st";
    public static final String Weight_2_20 = "st-mg";
    public static final String Weight_2_21 = "mg-mg";

    // g to other unit
    public static final String Weight_3_5 = "g-kg";
    public static final String Weight_3_6 = "kg-g";
    public static final String Weight_3_7 = "g-lb";
    public static final String Weight_3_8 = "lb-g";
    public static final String Weight_3_9 = "g-oz";
    public static final String Weight_3_10 = "oz-g";
    public static final String Weight_3_11 = "g-gr";
    public static final String Weight_3_12 = "gr-g";
    public static final String Weight_3_13 = "g-t";
    public static final String Weight_3_14 = "t-g";
    public static final String Weight_3_15 = "g-t(US)";
    public static final String Weight_3_16 = "t(US)-g";
    public static final String Weight_3_17 = "g-t(UK)";
    public static final String Weight_3_18 = "t(UK)-g";
    public static final String Weight_3_19 = "g-st";
    public static final String Weight_3_20 = "st-g";
    public static final String Weight_3_21 = "g-g";

    // kg to other unit
    public static final String Weight_4_7 = "kg-lb";
    public static final String Weight_4_8 = "lb-kg";
    public static final String Weight_4_9 = "kg-oz";
    public static final String Weight_4_10 = "oz-kg";
    public static final String Weight_4_11 = "kg-gr";
    public static final String Weight_4_12 = "gr-kg";
    public static final String Weight_4_13 = "kg-t";
    public static final String Weight_4_14 = "t-kg";
    public static final String Weight_4_15 = "kg-t(US)";
    public static final String Weight_4_16 = "t(US)-kg";
    public static final String Weight_4_17 = "kg-t(UK)";
    public static final String Weight_4_18 = "t(UK)-kg";
    public static final String Weight_4_19 = "kg-st";
    public static final String Weight_4_20 = "st-kg";
    public static final String Weight_4_21 = "kg-kg";

    // lb to other unit
    public static final String Weight_5_9 = "lb-oz";
    public static final String Weight_5_10 = "oz-lb";
    public static final String Weight_5_11 = "lb-gr";
    public static final String Weight_5_12 = "gr-lb";
    public static final String Weight_5_13 = "lb-t";
    public static final String Weight_5_14 = "t-lb";
    public static final String Weight_5_15 = "lb-t(US)";
    public static final String Weight_5_16 = "t(US)-lb";
    public static final String Weight_5_17 = "lb-t(UK)";
    public static final String Weight_5_18 = "t(UK)-lb";
    public static final String Weight_5_19 = "lb-st";
    public static final String Weight_5_20 = "st-lb";
    public static final String Weight_5_21 = "lb-lb";

    // oz to other unit
    public static final String Weight_6_11 = "oz-gr";
    public static final String Weight_6_12 = "gr-oz";
    public static final String Weight_6_13 = "oz-t";
    public static final String Weight_6_14 = "t-oz";
    public static final String Weight_6_15 = "oz-t(US)";
    public static final String Weight_6_16 = "t(US)-oz";
    public static final String Weight_6_17 = "oz-t(UK)";
    public static final String Weight_6_18 = "t(UK)-oz";
    public static final String Weight_6_19 = "oz-st";
    public static final String Weight_6_20 = "st-oz";
    public static final String Weight_6_21 = "oz-oz";

    // oz to other unit
    public static final String Weight_7_13 = "gr-t";
    public static final String Weight_7_14 = "t-gr";
    public static final String Weight_7_15 = "gr-t(US)";
    public static final String Weight_7_16 = "t(US)-gr";
    public static final String Weight_7_17 = "gr-t(UK)";
    public static final String Weight_7_18 = "t(UK)-gr";
    public static final String Weight_7_19 = "gr-st";
    public static final String Weight_7_20 = "st-gr";
    public static final String Weight_7_21 = "gr-gr";

    //t to other unit
    public static final String Weight_8_15 = "t-t(US)";
    public static final String Weight_8_16 = "t(US)-t";
    public static final String Weight_8_17 = "t-t(UK)";
    public static final String Weight_8_18 = "t(UK)-t";
    public static final String Weight_8_19 = "t-st";
    public static final String Weight_8_20 = "st-t";
    public static final String Weight_8_21 = "t-t";

    //t(US) to other unit
    public static final String Weight_9_17 = "t(US)-t(UK)";
    public static final String Weight_9_18 = "t(UK)-t(US)";
    public static final String Weight_9_19 = "t(US)-st";
    public static final String Weight_9_20 = "st-t(US)";
    public static final String Weight_9_21 = "t(US)-t(US)";

    //t(UK) to other unit
    public static final String Weight_10_19 = "t(UK)-st";
    public static final String Weight_10_20 = "st-t(UK)";
    public static final String Weight_10_21 = "t(UK)-t(UK)";
    public static final String Weight_10_22 = "st-st";


    //ct to other unit

    public static final String Weight_11_1 = "ct-mg";
    public static final String Weight_11_2 = "mg-ct";
    public static final String Weight_11_3 = "ct-g";
    public static final String Weight_11_4 = "g-ct";
    public static final String Weight_11_5 = "ct-kg";
    public static final String Weight_11_6 = "kg-ct";
    public static final String Weight_11_7 = "ct-lb";
    public static final String Weight_11_8 = "lb-ct";
    public static final String Weight_11_9 = "ct-oz";
    public static final String Weight_11_10 = "oz-ct";
    public static final String Weight_11_11 = "ct-gr";
    public static final String Weight_11_12 = "gr-ct";
    public static final String Weight_11_13 = "ct-t";
    public static final String Weight_11_14 = "t-ct";
    public static final String Weight_11_15 = "ct-t(US)";
    public static final String Weight_11_16 = "t(US)-ct";
    public static final String Weight_11_17 = "ct-t(UK)";
    public static final String Weight_11_18 = "t(UK)-ct";
    public static final String Weight_11_19 = "ct-st";
    public static final String Weight_11_20 = "st-ct";
    public static final String Weight_11_21 = "ct-μg";
    public static final String Weight_11_22 = "μg-ct";
    public static final String Weight_11_23 = "ct-ct";


    // ------------------------------------------------Weight Tag over------------------------------------------------------------
    // ------------------------------------------------Time Tag ------------------------------------------------------------

    //ms to other unit
    public static final String Time_1_1 = "ms-s";
    public static final String Time_1_2 = "s-ms";
    public static final String Time_1_3 = "ms-min";
    public static final String Time_1_4 = "min-ms";
    public static final String Time_1_5 = "ms-h";
    public static final String Time_1_6 = "h-ms";
    public static final String Time_1_7 = "ms-d";
    public static final String Time_1_8 = "d-ms";
    public static final String Time_1_9 = "ms-wk";
    public static final String Time_1_10 = "wk-ms";
    public static final String Time_1_11 = "ms-mon";
    public static final String Time_1_12 = "mon-ms";
    public static final String Time_1_13 = "ms-y";
    public static final String Time_1_14 = "y-ms";
    public static final String Time_1_15 = "ms-ms";

    //s to other unit
    public static final String Time_2_3 = "s-min";
    public static final String Time_2_4 = "min-s";
    public static final String Time_2_5 = "s-h";
    public static final String Time_2_6 = "h-s";
    public static final String Time_2_7 = "s-d";
    public static final String Time_2_8 = "d-s";
    public static final String Time_2_9 = "s-wk";
    public static final String Time_2_10 = "wk-s";
    public static final String Time_2_11 = "s-mon";
    public static final String Time_2_12 = "mon-s";
    public static final String Time_2_13 = "s-y";
    public static final String Time_2_14 = "y-s";
    public static final String Time_2_15 = "s-s";

    //min to other unit
    public static final String Time_3_5 = "min-h";
    public static final String Time_3_6 = "h-min";
    public static final String Time_3_7 = "min-d";
    public static final String Time_3_8 = "d-min";
    public static final String Time_3_9 = "min-wk";
    public static final String Time_3_10 = "wk-min";
    public static final String Time_3_11 = "min-mon";
    public static final String Time_3_12 = "mon-min";
    public static final String Time_3_13 = "min-y";
    public static final String Time_3_14 = "y-min";
    public static final String Time_3_15 = "min-min";

    //h to other unit
    public static final String Time_4_7 = "h-d";
    public static final String Time_4_8 = "d-h";
    public static final String Time_4_9 = "h-wk";
    public static final String Time_4_10 = "wk-h";
    public static final String Time_4_11 = "h-mon";
    public static final String Time_4_12 = "mon-h";
    public static final String Time_4_13 = "h-y";
    public static final String Time_4_14 = "y-h";
    public static final String Time_4_15 = "h-h";

    //d to all othe units
    public static final String Time_5_9 = "d-wk";
    public static final String Time_5_10 = "wk-d";
    public static final String Time_5_11 = "d-mon";
    public static final String Time_5_12 = "mon-d";
    public static final String Time_5_13 = "d-y";
    public static final String Time_5_14 = "y-d";
    public static final String Time_5_15 = "d-d";

    //wk to other units
    public static final String Time_6_11 = "wk-mon";
    public static final String Time_6_12 = "mon-wk";
    public static final String Time_6_13 = "wk-y";
    public static final String Time_6_14 = "y-wk";
    public static final String Time_6_15 = "wk-wk";

    //mon to other units
    public static final String Time_7_13 = "mon-y";
    public static final String Time_7_14 = "y-mon";
    public static final String Time_7_15 = "y-y";
    public static final String Time_7_16 = "mon-mon";


    // ------------------------------------------------Time Tag over------------------------------------------------------------
    // ------------------------------------------------Temprature Tag ------------------------------------------------------------

    //°C yo other units
    public static final String Temprature_1_1 = "°C-°F";
    public static final String Temprature_1_2 = "°F-°C";
    public static final String Temprature_1_3 = "°C-K";
    public static final String Temprature_1_4 = "K-°C";
    public static final String Temprature_1_5 = "°C-°C";


    //K yo other units
    public static final String Temprature_2_3 = "K-°F";
    public static final String Temprature_2_4 = "°F-K";
    public static final String Temprature_2_5 = "°F-°F";
    public static final String Temprature_2_6 = "K-K";


    // ------------------------------------------------Temprature Tag over------------------------------------------------------------
    // ------------------------------------------------Speed Tag ------------------------------------------------------------

    //m/s to other units
    public static final String Speed_1_1 = "m/s-ft/s";
    public static final String Speed_1_2 = "ft/s-m/s";
    public static final String Speed_1_3 = "m/s-m/min";
    public static final String Speed_1_4 = "m/min-m/s";
    public static final String Speed_1_5 = "m/s-ft/m";
    public static final String Speed_1_6 = "ft/m-m/s";
    public static final String Speed_1_7 = "m/s-km/min";
    public static final String Speed_1_8 = "km/min-m/s";
    public static final String Speed_1_9 = "m/s-km/h";
    public static final String Speed_1_10 = "km/h-m/s";
    public static final String Speed_1_11 = "m/s-mi/h";
    public static final String Speed_1_12 = "mi/h-m/s";
    public static final String Speed_1_13 = "m/s-kt";
    public static final String Speed_1_14 = "kt-m/s";
    public static final String Speed_1_15 = "m/s-ma";
    public static final String Speed_1_16 = "ma-m/s";
    public static final String Speed_1_17 = "m/s-m/h";
    public static final String Speed_1_18 = "m/h-m/s";
    public static final String Speed_1_19 = "m/s-c";
    public static final String Speed_1_20 = "c-m/s";
    public static final String Speed_1_21 = "m/s-m/s";

    //ft/s to other units
    public static final String Speed_2_3 = "ft/s-m/min";
    public static final String Speed_2_4 = "m/min-ft/s";
    public static final String Speed_2_5 = "ft/s-ft/m";
    public static final String Speed_2_6 = "ft/m-ft/s";
    public static final String Speed_2_7 = "ft/s-km/min";
    public static final String Speed_2_8 = "km/min-ft/s";
    public static final String Speed_2_9 = "ft/s-km/h";
    public static final String Speed_2_10 = "km/h-ft/s";
    public static final String Speed_2_11 = "ft/s-mi/h";
    public static final String Speed_2_12 = "mi/h-ft/s";
    public static final String Speed_2_13 = "ft/s-kt";
    public static final String Speed_2_14 = "kt-ft/s";
    public static final String Speed_2_15 = "ft/s-ma";
    public static final String Speed_2_16 = "ma-ft/s";
    public static final String Speed_2_17 = "ft/s-m/h";
    public static final String Speed_2_18 = "m/h-ft/s";
    public static final String Speed_2_19 = "ft/s-c";
    public static final String Speed_2_20 = "c-ft/s";
    public static final String Speed_2_21 = "ft/s-ft/s";

    //m/min to other units
    public static final String Speed_3_5 = "m/min-ft/m";
    public static final String Speed_3_6 = "ft/m-m/min";
    public static final String Speed_3_7 = "m/min-km/min";
    public static final String Speed_3_8 = "km/min-m/min";
    public static final String Speed_3_9 = "m/min-km/h";
    public static final String Speed_3_10 = "km/h-m/min";
    public static final String Speed_3_11 = "m/min-mi/h";
    public static final String Speed_3_12 = "mi/h-m/min";
    public static final String Speed_3_13 = "m/min-kt";
    public static final String Speed_3_14 = "kt-m/min";
    public static final String Speed_3_15 = "m/min-ma";
    public static final String Speed_3_16 = "ma-m/min";
    public static final String Speed_3_17 = "m/min-m/h";
    public static final String Speed_3_18 = "m/h-m/min";
    public static final String Speed_3_19 = "m/min-c";
    public static final String Speed_3_20 = "c-m/min";
    public static final String Speed_3_21 = "m/min-m/min";


    //ft/m  to onther units
    public static final String Speed_4_7 = "ft/m-km/min";
    public static final String Speed_4_8 = "km/min-ft/m";
    public static final String Speed_4_9 = "ft/m-km/h";
    public static final String Speed_4_10 = "km/h-ft/m";
    public static final String Speed_4_11 = "ft/m-mi/h";
    public static final String Speed_4_12 = "mi/h-ft/m";
    public static final String Speed_4_13 = "ft/m-kt";
    public static final String Speed_4_14 = "kt-ft/m";
    public static final String Speed_4_15 = "ft/m-ma";
    public static final String Speed_4_16 = "ma-ft/m";
    public static final String Speed_4_17 = "ft/m-m/h";
    public static final String Speed_4_18 = "m/h-ft/m";
    public static final String Speed_4_19 = "ft/m-c";
    public static final String Speed_4_20 = "c-ft/m";
    public static final String Speed_4_21 = "ft/m-ft/m";


    // km/min  to onther units
    public static final String Speed_5_9 = "km/min-km/h";
    public static final String Speed_5_10 = "km/h-km/min";
    public static final String Speed_5_11 = "km/min-mi/h";
    public static final String Speed_5_12 = "mi/h-km/min";
    public static final String Speed_5_13 = "km/min-kt";
    public static final String Speed_5_14 = "kt-km/min";
    public static final String Speed_5_15 = "km/min-ma";
    public static final String Speed_5_16 = "ma-km/min";
    public static final String Speed_5_17 = "km/min-m/h";
    public static final String Speed_5_18 = "m/h-km/min";
    public static final String Speed_5_19 = "km/min-c";
    public static final String Speed_5_20 = "c-km/min";
    public static final String Speed_5_21 = "km/min-km/min";

    // km/h  to onther units
    public static final String Speed_6_11 = "km/h-mi/h";
    public static final String Speed_6_12 = "mi/h-km/h";
    public static final String Speed_6_13 = "km/h-kt";
    public static final String Speed_6_14 = "kt-km/h";
    public static final String Speed_6_15 = "km/h-ma";
    public static final String Speed_6_16 = "ma-km/h";
    public static final String Speed_6_17 = "km/h-m/h";
    public static final String Speed_6_18 = "m/h-km/h";
    public static final String Speed_6_19 = "km/h-c";
    public static final String Speed_6_20 = "c-km/h";
    public static final String Speed_6_21 = "km/h-km/h";

    // mi/h  to onther units
    public static final String Speed_7_13 = "mi/h-kt";
    public static final String Speed_7_14 = "kt-mi/h";
    public static final String Speed_7_15 = "mi/h-ma";
    public static final String Speed_7_16 = "ma-mi/h";
    public static final String Speed_7_17 = "mi/h-m/h";
    public static final String Speed_7_18 = "m/h-mi/h";
    public static final String Speed_7_19 = "mi/h-c";
    public static final String Speed_7_20 = "c-mi/h";
    public static final String Speed_7_21 = "mi/h-mi/h";

    // kt  to onther units
    public static final String Speed_8_15 = "kt-ma";
    public static final String Speed_8_16 = "ma-kt";
    public static final String Speed_8_17 = "kt-m/h";
    public static final String Speed_8_18 = "m/h-kt";
    public static final String Speed_8_19 = "kt-c";
    public static final String Speed_8_20 = "c-kt";
    public static final String Speed_8_21 = "kt-kt";

    // ma  to onther units
    public static final String Speed_9_17 = "ma-m/h";
    public static final String Speed_9_18 = "m/h-ma";
    public static final String Speed_9_19 = "ma-c";
    public static final String Speed_9_20 = "c-ma";
    public static final String Speed_9_21 = "ma-ma";

    // m/h  to onther units
    public static final String Speed_10_19 = "m/h-c";
    public static final String Speed_10_20 = "c-m/h";
    public static final String Speed_10_21 = "c-c";
    public static final String Speed_10_22 = "m/h-m/h";


    // ------------------------------------------------Speed Tag over------------------------------------------------------------
    // ------------------------------------------------Volume Tag ------------------------------------------------------------


    // tsp to other unit
    public static final String Volume_1_1 = "tsp-tb/sp";
    public static final String Volume_1_2 = "tb/sp-tsp";
    public static final String Volume_1_3 = "tsp-c";
    public static final String Volume_1_4 = "c-tsp";
    public static final String Volume_1_5 = "tsp-mL";
    public static final String Volume_1_6 = "mL-tsp";
    public static final String Volume_1_7 = "tsp-L";
    public static final String Volume_1_8 = "L-tsp";
    public static final String Volume_1_9 = "tsp-pt(US)";
    public static final String Volume_1_10 = "pt(US)-tsp";
    public static final String Volume_1_11 = "tsp-pt(UK)";
    public static final String Volume_1_12 = "pt(UK)-tsp";
    public static final String Volume_1_13 = "tsp-qt(US)";
    public static final String Volume_1_14 = "qt(US)-tsp";
    public static final String Volume_1_15 = "tsp-qt(UK)";
    public static final String Volume_1_16 = "qt(UK)-tsp";
    public static final String Volume_1_17 = "tsp-gal(US)";
    public static final String Volume_1_18 = "gal(US)-tsp";
    public static final String Volume_1_19 = "tsp-gal(UK)";
    public static final String Volume_1_20 = "gal(UK)-tsp";
    public static final String Volume_1_21 = "tsp-bbl(US))";
    public static final String Volume_1_22 = "bbl(US)-tsp";
    public static final String Volume_1_23 = "tsp-cm3";
    public static final String Volume_1_24 = "cm3-tsp";
    public static final String Volume_1_25 = "tsp-m3";
    public static final String Volume_1_26 = "m3-tsp";
    public static final String Volume_1_27 = "tsp-inch3";
    public static final String Volume_1_28 = "inch3-tsp";
    public static final String Volume_1_29 = "tsp-ft3";
    public static final String Volume_1_30 = "ft3-tsp";
    public static final String Volume_1_31 = "tsp-yd3";
    public static final String Volume_1_32 = "yd3-tsp";
    public static final String Volume_1_33 = "tsp-tsp";

    // tb/sp to other unit
    public static final String Volume_2_3 = "tb/sp-c";
    public static final String Volume_2_4 = "c-tb/sp";
    public static final String Volume_2_5 = "tb/sp-mL";
    public static final String Volume_2_6 = "mL-tb/sp";
    public static final String Volume_2_7 = "tb/sp-L";
    public static final String Volume_2_8 = "L-tb/sp";
    public static final String Volume_2_9 = "tb/sp-pt(US)";
    public static final String Volume_2_10 = "pt(US)-tb/sp";
    public static final String Volume_2_11 = "tb/sp-pt(UK)";
    public static final String Volume_2_12 = "pt(UK)-tb/sp";
    public static final String Volume_2_13 = "tb/sp-qt(US)";
    public static final String Volume_2_14 = "qt(US)-tb/sp";
    public static final String Volume_2_15 = "tb/sp-qt(UK)";
    public static final String Volume_2_16 = "qt(UK)-tb/sp";
    public static final String Volume_2_17 = "tb/sp-gal(US)";
    public static final String Volume_2_18 = "gal(US)-tb/sp";
    public static final String Volume_2_19 = "tb/sp-gal(UK)";
    public static final String Volume_2_20 = "gal(UK)-tb/sp";
    public static final String Volume_2_21 = "tb/sp-bbl(US))";
    public static final String Volume_2_22 = "bbl(US)-tb/sp";
    public static final String Volume_2_23 = "tb/sp-cm3";
    public static final String Volume_2_24 = "cm3-tb/sp";
    public static final String Volume_2_25 = "tb/sp-m3";
    public static final String Volume_2_26 = "m3-tb/sp";
    public static final String Volume_2_27 = "tb/sp-inch3";
    public static final String Volume_2_28 = "inch3-tb/sp";
    public static final String Volume_2_29 = "tb/sp-ft3";
    public static final String Volume_2_30 = "ft3-tb/sp";
    public static final String Volume_2_31 = "tb/sp-yd3";
    public static final String Volume_2_32 = "yd3-tb/sp";
    public static final String Volume_2_33 = "tb/sp-tb/sp";


    // c to other unit
    public static final String Volume_3_5 = "c-mL";
    public static final String Volume_3_6 = "mL-c";
    public static final String Volume_3_7 = "c-L";
    public static final String Volume_3_8 = "L-c";
    public static final String Volume_3_9 = "c-pt(US)";
    public static final String Volume_3_10 = "pt(US)-c";
    public static final String Volume_3_11 = "c-pt(UK)";
    public static final String Volume_3_12 = "pt(UK)-c";
    public static final String Volume_3_13 = "c-qt(US)";
    public static final String Volume_3_14 = "qt(US)-c";
    public static final String Volume_3_15 = "c-qt(UK)";
    public static final String Volume_3_16 = "qt(UK)-c";
    public static final String Volume_3_17 = "c-gal(US)";
    public static final String Volume_3_18 = "gal(US)-c";
    public static final String Volume_3_19 = "c-gal(UK)";
    public static final String Volume_3_20 = "gal(UK)-c";
    public static final String Volume_3_21 = "c-bbl(US))";
    public static final String Volume_3_22 = "bbl(US)-c";
    public static final String Volume_3_23 = "c-cm3";
    public static final String Volume_3_24 = "cm3-c";
    public static final String Volume_3_25 = "c-m3";
    public static final String Volume_3_26 = "m3-c";
    public static final String Volume_3_27 = "c-inch3";
    public static final String Volume_3_28 = "inch3-c";
    public static final String Volume_3_29 = "c-ft3";
    public static final String Volume_3_30 = "ft3-c";
    public static final String Volume_3_31 = "c-yd3";
    public static final String Volume_3_32 = "yd3-c";
    public static final String Volume_3_33 = "c-c";

    // mL to other unit
    public static final String Volume_4_7 = "mL-L";
    public static final String Volume_4_8 = "L-mL";
    public static final String Volume_4_9 = "mL-pt(US)";
    public static final String Volume_4_10 = "pt(US)-mL";
    public static final String Volume_4_11 = "mL-pt(UK)";
    public static final String Volume_4_12 = "pt(UK)-mL";
    public static final String Volume_4_13 = "mL-qt(US)";
    public static final String Volume_4_14 = "qt(US)-mL";
    public static final String Volume_4_15 = "mL-qt(UK)";
    public static final String Volume_4_16 = "qt(UK)-mL";
    public static final String Volume_4_17 = "mL-gal(US)";
    public static final String Volume_4_18 = "gal(US)-mL";
    public static final String Volume_4_19 = "mL-gal(UK)";
    public static final String Volume_4_20 = "gal(UK)-mL";
    public static final String Volume_4_21 = "mL-bbl(US))";
    public static final String Volume_4_22 = "bbl(US)-mL";
    public static final String Volume_4_23 = "mL-cm3";
    public static final String Volume_4_24 = "cm3-mL";
    public static final String Volume_4_25 = "mL-m3";
    public static final String Volume_4_26 = "m3-mL";
    public static final String Volume_4_27 = "mL-inch3";
    public static final String Volume_4_28 = "inch3-mL";
    public static final String Volume_4_29 = "mL-ft3";
    public static final String Volume_4_30 = "ft3-mL";
    public static final String Volume_4_31 = "mL-yd3";
    public static final String Volume_4_32 = "yd3-mL";
    public static final String Volume_4_33 = "mL-mL";


    // L to other unit
    public static final String Volume_5_9 = "L-pt(US)";
    public static final String Volume_5_10 = "pt(US)-L";
    public static final String Volume_5_11 = "L-pt(UK)";
    public static final String Volume_5_12 = "pt(UK)-L";
    public static final String Volume_5_13 = "L-qt(US)";
    public static final String Volume_5_14 = "qt(US)-L";
    public static final String Volume_5_15 = "L-qt(UK)";
    public static final String Volume_5_16 = "qt(UK)-L";
    public static final String Volume_5_17 = "L-gal(US)";
    public static final String Volume_5_18 = "gal(US)-L";
    public static final String Volume_5_19 = "L-gal(UK)";
    public static final String Volume_5_20 = "gal(UK)-L";
    public static final String Volume_5_21 = "L-bbl(US))";
    public static final String Volume_5_22 = "bbl(US)-L";
    public static final String Volume_5_23 = "L-cm3";
    public static final String Volume_5_24 = "cm3-L";
    public static final String Volume_5_25 = "L-m3";
    public static final String Volume_5_26 = "m3-L";
    public static final String Volume_5_27 = "L-inch3";
    public static final String Volume_5_28 = "inch3-L";
    public static final String Volume_5_29 = "L-ft3";
    public static final String Volume_5_30 = "ft3-L";
    public static final String Volume_5_31 = "L-yd3";
    public static final String Volume_5_32 = "yd3-L";
    public static final String Volume_5_33 = "L-L";


    // pt(US) to other unit
    public static final String Volume_6_11 = "pt(US)-pt(UK)";
    public static final String Volume_6_12 = "pt(UK)-pt(US)";
    public static final String Volume_6_13 = "pt(US)-qt(US)";
    public static final String Volume_6_14 = "qt(US)-pt(US)";
    public static final String Volume_6_15 = "pt(US)-qt(UK)";
    public static final String Volume_6_16 = "qt(UK)-pt(US)";
    public static final String Volume_6_17 = "pt(US)-gal(US)";
    public static final String Volume_6_18 = "gal(US)-pt(US)";
    public static final String Volume_6_19 = "pt(US)-gal(UK)";
    public static final String Volume_6_20 = "gal(UK)-pt(US)";
    public static final String Volume_6_21 = "pt(US)-bbl(US))";
    public static final String Volume_6_22 = "bbl(US)-pt(US)";
    public static final String Volume_6_23 = "pt(US)-cm3";
    public static final String Volume_6_24 = "cm3-pt(US)";
    public static final String Volume_6_25 = "pt(US)-m3";
    public static final String Volume_6_26 = "m3-pt(US)";
    public static final String Volume_6_27 = "pt(US)-inch3";
    public static final String Volume_6_28 = "inch3-pt(US)";
    public static final String Volume_6_29 = "pt(US)-ft3";
    public static final String Volume_6_30 = "ft3-pt(US)";
    public static final String Volume_6_31 = "pt(US)-yd3";
    public static final String Volume_6_32 = "yd3-pt(US)";
    public static final String Volume_6_33 = "pt(US)-pt(US)";


    // pt(UK) to other unit
    public static final String Volume_7_13 = "pt(UK)-qt(US)";
    public static final String Volume_7_14 = "qt(US)-pt(UK)";
    public static final String Volume_7_15 = "pt(UK)-qt(UK)";
    public static final String Volume_7_16 = "qt(UK)-pt(UK)";
    public static final String Volume_7_17 = "pt(UK)-gal(US)";
    public static final String Volume_7_18 = "gal(US)-pt(UK)";
    public static final String Volume_7_19 = "pt(UK)-gal(UK)";
    public static final String Volume_7_20 = "gal(UK)-pt(UK)";
    public static final String Volume_7_21 = "pt(UK)-bbl(US))";
    public static final String Volume_7_22 = "bbl(US)-pt(UK)";
    public static final String Volume_7_23 = "pt(UK)-cm3";
    public static final String Volume_7_24 = "cm3-pt(UK)";
    public static final String Volume_7_25 = "pt(UK)-m3";
    public static final String Volume_7_26 = "m3-pt(UK)";
    public static final String Volume_7_27 = "pt(UK)-inch3";
    public static final String Volume_7_28 = "inch3-pt(UK)";
    public static final String Volume_7_29 = "pt(UK)-ft3";
    public static final String Volume_7_30 = "ft3-pt(UK)";
    public static final String Volume_7_31 = "pt(UK)-yd3";
    public static final String Volume_7_32 = "yd3-pt(UK)";
    public static final String Volume_7_33 = "pt(UK)-pt(UK)";


    // qt(US) to other unit
    public static final String Volume_8_15 = "qt(US)-qt(UK)";
    public static final String Volume_8_16 = "qt(UK)-qt(US)";
    public static final String Volume_8_17 = "qt(US)-gal(US)";
    public static final String Volume_8_18 = "gal(US)-qt(US)";
    public static final String Volume_8_19 = "qt(US)-gal(UK)";
    public static final String Volume_8_20 = "gal(UK)-qt(US)";
    public static final String Volume_8_21 = "qt(US)-bbl(US))";
    public static final String Volume_8_22 = "bbl(US)-qt(US)";
    public static final String Volume_8_23 = "qt(US)-cm3";
    public static final String Volume_8_24 = "cm3-qt(US)";
    public static final String Volume_8_25 = "qt(US)-m3";
    public static final String Volume_8_26 = "m3-qt(US)";
    public static final String Volume_8_27 = "qt(US)-inch3";
    public static final String Volume_8_28 = "inch3-qt(US)";
    public static final String Volume_8_29 = "qt(US)-ft3";
    public static final String Volume_8_30 = "ft3-qt(US)";
    public static final String Volume_8_31 = "qt(US)-yd3";
    public static final String Volume_8_32 = "yd3-qt(US)";
    public static final String Volume_8_33 = "qt(US)-qt(US)";


    // qt(UK) to other unit
    public static final String Volume_9_17 = "qt(UK)-gal(US)";
    public static final String Volume_9_18 = "gal(US)-qt(UK)";
    public static final String Volume_9_19 = "qt(UK)-gal(UK)";
    public static final String Volume_9_20 = "gal(UK)-qt(UK)";
    public static final String Volume_9_21 = "qt(UK)-bbl(US))";
    public static final String Volume_9_22 = "bbl(US)-qt(UK)";
    public static final String Volume_9_23 = "qt(UK)-cm3";
    public static final String Volume_9_24 = "cm3-qt(UK)";
    public static final String Volume_9_25 = "qt(UK)-m3";
    public static final String Volume_9_26 = "m3-qt(UK)";
    public static final String Volume_9_27 = "qt(UK)-inch3";
    public static final String Volume_9_28 = "inch3-qt(UK)";
    public static final String Volume_9_29 = "qt(UK)-ft3";
    public static final String Volume_9_30 = "ft3-qt(UK)";
    public static final String Volume_9_31 = "qt(UK)-yd3";
    public static final String Volume_9_32 = "yd3-qt(UK)";
    public static final String Volume_9_33 = "qt(UK)-qt(UK)";


    // gal(US) to other unit
    public static final String Volume_10_19 = "gal(US)-gal(UK)";
    public static final String Volume_10_20 = "gal(UK)-gal(US)";
    public static final String Volume_10_21 = "gal(US)-bbl(US))";
    public static final String Volume_10_22 = "bbl(US)-gal(US)";
    public static final String Volume_10_23 = "gal(US)-cm3";
    public static final String Volume_10_24 = "cm3-gal(US)";
    public static final String Volume_10_25 = "gal(US)-m3";
    public static final String Volume_10_26 = "m3-gal(US)";
    public static final String Volume_10_27 = "gal(US)-inch3";
    public static final String Volume_10_28 = "inch3-gal(US)";
    public static final String Volume_10_29 = "gal(US)-ft3";
    public static final String Volume_10_30 = "ft3-gal(US)";
    public static final String Volume_10_31 = "gal(US)-yd3";
    public static final String Volume_10_32 = "yd3-gal(US)";
    public static final String Volume_10_33 = "gal(US)-gal(US)";

    // gal(UK) to other unit
    public static final String Volume_11_21 = "gal(UK)-bbl(US))";
    public static final String Volume_11_22 = "bbl(US)-gal(UK)";
    public static final String Volume_11_23 = "gal(UK)-cm3";
    public static final String Volume_11_24 = "cm3-gal(UK)";
    public static final String Volume_11_25 = "gal(UK)-m3";
    public static final String Volume_11_26 = "m3-gal(UK)";
    public static final String Volume_11_27 = "gal(UK)-inch3";
    public static final String Volume_11_28 = "inch3-gal(UK)";
    public static final String Volume_11_29 = "gal(UK)-ft3";
    public static final String Volume_11_30 = "ft3-gal(UK)";
    public static final String Volume_11_31 = "gal(UK)-yd3";
    public static final String Volume_11_32 = "yd3-gal(UK)";
    public static final String Volume_11_33 = "gal(UK)-gal(UK)";

    // bbl(US) to other unit
    public static final String Volume_12_23 = "bbl(US)-cm3";
    public static final String Volume_12_24 = "cm3-bbl(US)";
    public static final String Volume_12_25 = "bbl(US)-m3";
    public static final String Volume_12_26 = "m3-bbl(US)";
    public static final String Volume_12_27 = "bbl(US)-inch3";
    public static final String Volume_12_28 = "inch3-bbl(US)";
    public static final String Volume_12_29 = "bbl(US)-ft3";
    public static final String Volume_12_30 = "ft3-bbl(US)";
    public static final String Volume_12_31 = "bbl(US)-yd3";
    public static final String Volume_12_32 = "yd3-bbl(US)";
    public static final String Volume_12_33 = "bbl(US)-bbl(US)";

    // cm3 to other unit
    public static final String Volume_13_25 = "cm3-m3";
    public static final String Volume_13_26 = "m3-cm3";
    public static final String Volume_13_27 = "cm3-inch3";
    public static final String Volume_13_28 = "inch3-cm3";
    public static final String Volume_13_29 = "cm3-ft3";
    public static final String Volume_13_30 = "ft3-cm3";
    public static final String Volume_13_31 = "cm3-yd3";
    public static final String Volume_13_32 = "yd3-cm3";
    public static final String Volume_13_33 = "cm3-cm3";

    // m3 to other unit
    public static final String Volume_14_27 = "m3-inch3";
    public static final String Volume_14_28 = "inch3-m3";
    public static final String Volume_14_29 = "m3-ft3";
    public static final String Volume_14_30 = "ft3-m3";
    public static final String Volume_14_31 = "m3-yd3";
    public static final String Volume_14_32 = "yd3-m3";
    public static final String Volume_14_33 = "m3-m3";

    // inch3 to other unit
    public static final String Volume_15_29 = "inch3-ft3";
    public static final String Volume_15_30 = "ft3-inch3";
    public static final String Volume_15_31 = "inch3-yd3";
    public static final String Volume_15_32 = "yd3-inch3";
    public static final String Volume_15_33 = "inch3-inch3";

    // ft3 to other unit
    public static final String Volume_16_31 = "ft3-yd3";
    public static final String Volume_16_32 = "yd3-ft3";
    public static final String Volume_16_33 = "ft3-ft3";
    public static final String Volume_16_34 = "yd3-yd3";


    // ------------------------------------------------Volume Tag over------------------------------------------------------------
    // ------------------------------------------------Energy ------------------------------------------------------------

    // J UNIT TO OTHER
    public static final String Energy_1_1 = "J-KJ";
    public static final String Energy_1_2 = "KJ-J";
    public static final String Energy_1_3 = "J-cal";
    public static final String Energy_1_4 = "cal-J";
    public static final String Energy_1_5 = "J-Kcal";
    public static final String Energy_1_6 = "Kcal-J";
    public static final String Energy_1_7 = "J-kW-h";
    public static final String Energy_1_8 = "kW-h-J";
    public static final String Energy_1_9 = "J-kgf-m";
    public static final String Energy_1_10 = "kgf-m-J";
    public static final String Energy_1_11 = "J-in-lb";
    public static final String Energy_1_12 = "in-lb-J";
    public static final String Energy_1_13 = "J-ft-lb";
    public static final String Energy_1_14 = "ft-lb-J";
    public static final String Energy_1_15 = "J-BTU";
    public static final String Energy_1_16 = "BTU-J";
    public static final String Energy_1_17 = "J-J";

    // KJ UNIT TO OTHER
    public static final String Energy_2_3 = "KJ-cal";
    public static final String Energy_2_4 = "cal-KJ";
    public static final String Energy_2_5 = "KJ-Kcal";
    public static final String Energy_2_6 = "Kcal-KJ";
    public static final String Energy_2_7 = "KJ-kW-h";
    public static final String Energy_2_8 = "kW-h-KJ";
    public static final String Energy_2_9 = "KJ-kgf-m";
    public static final String Energy_2_10 = "kgf-m-KJ";
    public static final String Energy_2_11 = "KJ-in-lb";
    public static final String Energy_2_12 = "in-lb-KJ";
    public static final String Energy_2_13 = "KJ-ft-lb";
    public static final String Energy_2_14 = "ft-lb-KJ";
    public static final String Energy_2_15 = "KJ-BTU";
    public static final String Energy_2_16 = "BTU-KJ";
    public static final String Energy_2_17 = "KJ-KJ";

    // cal UNIT TO OTHER
    public static final String Energy_3_5 = "cal-Kcal";
    public static final String Energy_3_6 = "Kcal-cal";
    public static final String Energy_3_7 = "cal-kW-h";
    public static final String Energy_3_8 = "kW-h-cal";
    public static final String Energy_3_9 = "cal-kgf-m";
    public static final String Energy_3_10 = "kgf-m-cal";
    public static final String Energy_3_11 = "cal-in-lb";
    public static final String Energy_3_12 = "in-lb-cal";
    public static final String Energy_3_13 = "cal-ft-lb";
    public static final String Energy_3_14 = "ft-lb-cal";
    public static final String Energy_3_15 = "cal-BTU";
    public static final String Energy_3_16 = "BTU-cal";
    public static final String Energy_3_17 = "cal-cal";

    // Kcal UNIT TO OTHER
    public static final String Energy_4_7 = "Kcal-kW-h";
    public static final String Energy_4_8 = "kW-h-Kcal";
    public static final String Energy_4_9 = "Kcal-kgf-m";
    public static final String Energy_4_10 = "kgf-m-Kcal";
    public static final String Energy_4_11 = "Kcal-in-lb";
    public static final String Energy_4_12 = "in-lb-Kcal";
    public static final String Energy_4_13 = "Kcal-ft-lb";
    public static final String Energy_4_14 = "ft-lb-Kcal";
    public static final String Energy_4_15 = "Kcal-BTU";
    public static final String Energy_4_16 = "BTU-Kcal";
    public static final String Energy_4_17 = "Kcal-Kcal";

    // kW-h UNIT TO OTHER
    public static final String Energy_5_9 = "kW-h-kgf-m";
    public static final String Energy_5_10 = "kgf-m-kW-h";
    public static final String Energy_5_11 = "kW-h-in-lb";
    public static final String Energy_5_12 = "in-lb-kW-h";
    public static final String Energy_5_13 = "kW-h-ft-lb";
    public static final String Energy_5_14 = "ft-lb-kW-h";
    public static final String Energy_5_15 = "kW-h-BTU";
    public static final String Energy_5_16 = "BTU-kW-h";
    public static final String Energy_5_17 = "kW-h-kW-h";

    // kgf-m UNIT TO OTHER
    public static final String Energy_6_11 = "kgf-m-in-lb";
    public static final String Energy_6_12 = "in-lb-kgf-m";
    public static final String Energy_6_13 = "kgf-m-ft-lb";
    public static final String Energy_6_14 = "ft-lb-kgf-m";
    public static final String Energy_6_15 = "kgf-m-BTU";
    public static final String Energy_6_16 = "BTU-kgf-m";
    public static final String Energy_6_17 = "kgf-m-kgf-m";


    // kgf-m UNIT TO OTHER
    public static final String Energy_7_13 = "in-lb-ft-lb";
    public static final String Energy_7_14 = "ft-lb-in-lb";
    public static final String Energy_7_15 = "in-lb-BTU";
    public static final String Energy_7_16 = "BTU-in-lb";
    public static final String Energy_7_17 = "in-lb-in-lb";

    // ft-lb UNIT TO OTHER
    public static final String Energy_8_15 = "ft-lb-BTU";
    public static final String Energy_8_16 = "BTU-ft-lb";
    public static final String Energy_8_17 = "ft-lb-ft-lb";
    public static final String Energy_8_18 = "BTU-BTU";


    // ------------------------------------------------Energy Tag over------------------------------------------------------------
    // ------------------------------------------------Fuel Tag ------------------------------------------------------------

    // km/L to other unit
    public static final String Fuel_1_1 = "km/L-mi/L";
    public static final String Fuel_1_2 = "mi/L-km/L";
    public static final String Fuel_1_3 = "km/L-km/gl";
    public static final String Fuel_1_4 = "km/gl-km/L";
    public static final String Fuel_1_5 = "km/L-mi/gal(US)";
    public static final String Fuel_1_6 = "mi/gal(US)-km/L";
    public static final String Fuel_1_7 = "km/L-mi/gal(UK)";
    public static final String Fuel_1_8 = "mi/gal(UK)-km/L";
    public static final String Fuel_1_9 = "km/L-L/km";
    public static final String Fuel_1_10 = "L/km-km/L";
    public static final String Fuel_1_11 = "km/L-km/L";

    // mi/L to other unit
    public static final String Fuel_2_3 = "mi/L-km/gl";
    public static final String Fuel_2_4 = "km/gl-mi/L";
    public static final String Fuel_2_5 = "mi/L-mi/gal(US)";
    public static final String Fuel_2_6 = "mi/gal(US)-mi/L";
    public static final String Fuel_2_7 = "mi/L-mi/gal(UK)";
    public static final String Fuel_2_8 = "mi/gal(UK)-mi/L";
    public static final String Fuel_2_9 = "mi/L-L/km";
    public static final String Fuel_2_10 = "L/km-mi/L";
    public static final String Fuel_2_11 = "mi/L-mi/L";

    //km/gl to other unit
    public static final String Fuel_3_5 = "km/gl-mi/gal(US)";
    public static final String Fuel_3_6 = "mi/gal(US)-km/gl";
    public static final String Fuel_3_7 = "km/gl-mi/gal(UK)";
    public static final String Fuel_3_8 = "mi/gal(UK)-km/gl";
    public static final String Fuel_3_9 = "km/gl-L/km";
    public static final String Fuel_3_10 = "L/km-km/gl";
    public static final String Fuel_3_11 = "km/gl-km/gl";

    //mi/gal(US) to other unit
    public static final String Fuel_4_7 = "mi/gal(US)/gal(UK)";
    public static final String Fuel_4_8 = "mi/gal(UK)-mi/gal(US)";
    public static final String Fuel_4_9 = "mi/gal(US)-L/km";
    public static final String Fuel_4_10 = "L/km-mi/gal(US)";
    public static final String Fuel_4_11 = "mi/gal(US)-mi/gal(US)";

    //mi/gal(UK) to other unit
    public static final String Fuel_5_9 = "mi/gal(UK)-L/km";
    public static final String Fuel_5_10 = "L/km-mi/gal(UK)";
    public static final String Fuel_5_11 = "mi/gal(UK)-mi/gal(UK)";
    public static final String Fuel_5_12 = "L/km-L/km";


    // ------------------------------------------------Fuel Tag over------------------------------------------------------------
    // ------------------------------------------------Presure ------------------------------------------------------------

    // atm to other unit
    public static final String Presure_1_1 = "atm-pa";
    public static final String Presure_1_2 = "pa-atm";
    public static final String Presure_1_3 = "atm-kPa";
    public static final String Presure_1_4 = "kPa-atm";
    public static final String Presure_1_5 = "atm-Mpa";
    public static final String Presure_1_6 = "Mpa-atm";
    public static final String Presure_1_7 = "atm-bar";
    public static final String Presure_1_8 = "bar-atm";
    public static final String Presure_1_9 = "atm-kgf/cm2";
    public static final String Presure_1_10 = "kgf/cm2-atm";
    public static final String Presure_1_11 = "atm-kgf/m2";
    public static final String Presure_1_12 = "kgf/m2-atm";
    public static final String Presure_1_13 = "atm-psi";
    public static final String Presure_1_14 = "psi-atm";
    public static final String Presure_1_15 = "atm-Ksi";
    public static final String Presure_1_16 = "Ksi-atm";
    public static final String Presure_1_17 = "atm-Torr";
    public static final String Presure_1_18 = "Torr-atm";
    public static final String Presure_1_19 = "atm-inchHg";
    public static final String Presure_1_20 = "inchHg-atm";
    public static final String Presure_1_21 = "atm-mmH2o";
    public static final String Presure_1_22 = "mmH2o-atm";
    public static final String Presure_1_23 = "atm-cmH2o";
    public static final String Presure_1_24 = "cmH2o-atm";
    public static final String Presure_1_25 = "atm-inchH2o";
    public static final String Presure_1_26 = "inchH2o-atm";
    public static final String Presure_1_27 = "atm-atm";

    // pa to other unit
    public static final String Presure_2_3 = "pa-kPa";
    public static final String Presure_2_4 = "kPa-pa";
    public static final String Presure_2_5 = "pa-Mpa";
    public static final String Presure_2_6 = "Mpa-pa";
    public static final String Presure_2_7 = "pa-bar";
    public static final String Presure_2_8 = "bar-pa";
    public static final String Presure_2_9 = "pa-kgf/cm2";
    public static final String Presure_2_10 = "kgf/cm2-pa";
    public static final String Presure_2_11 = "pa-kgf/m2";
    public static final String Presure_2_12 = "kgf/m2-pa";
    public static final String Presure_2_13 = "pa-psi";
    public static final String Presure_2_14 = "psi-pa";
    public static final String Presure_2_15 = "pa-Ksi";
    public static final String Presure_2_16 = "Ksi-pa";
    public static final String Presure_2_17 = "pa-Torr";
    public static final String Presure_2_18 = "Torr-pa";
    public static final String Presure_2_19 = "pa-inchHg";
    public static final String Presure_2_20 = "inchHg-pa";
    public static final String Presure_2_21 = "pa-mmH2o";
    public static final String Presure_2_22 = "mmH2o-pa";
    public static final String Presure_2_23 = "pa-cmH2o";
    public static final String Presure_2_24 = "cmH2o-pa";
    public static final String Presure_2_25 = "pa-inchH2o";
    public static final String Presure_2_26 = "inchH2o-pa";
    public static final String Presure_2_27 = "pa-pa";

    // kPa to other unit
    public static final String Presure_3_5 = "kPa-Mpa";
    public static final String Presure_3_6 = "Mpa-kPa";
    public static final String Presure_3_7 = "kPa-bar";
    public static final String Presure_3_8 = "bar-kPa";
    public static final String Presure_3_9 = "kPa-kgf/cm2";
    public static final String Presure_3_10 = "kgf/cm2-kPa";
    public static final String Presure_3_11 = "kPa-kgf/m2";
    public static final String Presure_3_12 = "kgf/m2-kPa";
    public static final String Presure_3_13 = "kPa-psi";
    public static final String Presure_3_14 = "psi-kPa";
    public static final String Presure_3_15 = "kPa-Ksi";
    public static final String Presure_3_16 = "Ksi-kPa";
    public static final String Presure_3_17 = "kPa-Torr";
    public static final String Presure_3_18 = "Torr-kPa";
    public static final String Presure_3_19 = "kPa-inchHg";
    public static final String Presure_3_20 = "inchHg-kPa";
    public static final String Presure_3_21 = "kPa-mmH2o";
    public static final String Presure_3_22 = "mmH2o-kPa";
    public static final String Presure_3_23 = "kPa-cmH2o";
    public static final String Presure_3_24 = "cmH2o-kPa";
    public static final String Presure_3_25 = "kPa-inchH2o";
    public static final String Presure_3_26 = "inchH2o-kPa";
    public static final String Presure_3_27 = "kPa-kPa";


    // Mpa to other unit
    public static final String Presure_4_7 = "Mpa-bar";
    public static final String Presure_4_8 = "bar-Mpa";
    public static final String Presure_4_9 = "Mpa-kgf/cm2";
    public static final String Presure_4_10 = "kgf/cm2-Mpa";
    public static final String Presure_4_11 = "Mpa-kgf/m2";
    public static final String Presure_4_12 = "kgf/m2-Mpa";
    public static final String Presure_4_13 = "Mpa-psi";
    public static final String Presure_4_14 = "psi-Mpa";
    public static final String Presure_4_15 = "Mpa-Ksi";
    public static final String Presure_4_16 = "Ksi-Mpa";
    public static final String Presure_4_17 = "Mpa-Torr";
    public static final String Presure_4_18 = "Torr-Mpa";
    public static final String Presure_4_19 = "Mpa-inchHg";
    public static final String Presure_4_20 = "inchHg-Mpa";
    public static final String Presure_4_21 = "Mpa-mmH2o";
    public static final String Presure_4_22 = "mmH2o-Mpa";
    public static final String Presure_4_23 = "Mpa-cmH2o";
    public static final String Presure_4_24 = "cmH2o-Mpa";
    public static final String Presure_4_25 = "Mpa-inchH2o";
    public static final String Presure_4_26 = "inchH2o-Mpa";
    public static final String Presure_4_27 = "Mpa-Mpa";

    // bar to other unit
    public static final String Presure_5_9 = "bar-kgf/cm2";
    public static final String Presure_5_10 = "kgf/cm2-bar";
    public static final String Presure_5_11 = "bar-kgf/m2";
    public static final String Presure_5_12 = "kgf/m2-bar";
    public static final String Presure_5_13 = "bar-psi";
    public static final String Presure_5_14 = "psi-bar";
    public static final String Presure_5_15 = "bar-Ksi";
    public static final String Presure_5_16 = "Ksi-bar";
    public static final String Presure_5_17 = "bar-Torr";
    public static final String Presure_5_18 = "Torr-bar";
    public static final String Presure_5_19 = "bar-inchHg";
    public static final String Presure_5_20 = "inchHg-bar";
    public static final String Presure_5_21 = "bar-mmH2o";
    public static final String Presure_5_22 = "mmH2o-bar";
    public static final String Presure_5_23 = "bar-cmH2o";
    public static final String Presure_5_24 = "cmH2o-bar";
    public static final String Presure_5_25 = "bar-inchH2o";
    public static final String Presure_5_26 = "inchH2o-bar";
    public static final String Presure_5_27 = "bar-bar";

    // kgf/cm2 to other unit
    public static final String Presure_6_11 = "kgf/cm2-kgf/m2";
    public static final String Presure_6_12 = "kgf/m2-kgf/cm2";
    public static final String Presure_6_13 = "kgf/cm2-psi";
    public static final String Presure_6_14 = "psi-kgf/cm2";
    public static final String Presure_6_15 = "kgf/cm2-Ksi";
    public static final String Presure_6_16 = "Ksi-kgf/cm2";
    public static final String Presure_6_17 = "kgf/cm2-Torr";
    public static final String Presure_6_18 = "Torr-kgf/cm2";
    public static final String Presure_6_19 = "kgf/cm2-inchHg";
    public static final String Presure_6_20 = "inchHg-kgf/cm2";
    public static final String Presure_6_21 = "kgf/cm2-mmH2o";
    public static final String Presure_6_22 = "mmH2o-kgf/cm2";
    public static final String Presure_6_23 = "kgf/cm2-cmH2o";
    public static final String Presure_6_24 = "cmH2o-kgf/cm2";
    public static final String Presure_6_25 = "kgf/cm2-inchH2o";
    public static final String Presure_6_26 = "inchH2o-kgf/cm2";
    public static final String Presure_6_27 = "kgf/cm2-kgf/cm2";

    // kgf/m2 to other unit
    public static final String Presure_7_13 = "kgf/m2-psi";
    public static final String Presure_7_14 = "psi-kgf/m2";
    public static final String Presure_7_15 = "kgf/m2-Ksi";
    public static final String Presure_7_16 = "Ksi-kgf/m2";
    public static final String Presure_7_17 = "kgf/m2-Torr";
    public static final String Presure_7_18 = "Torr-kgf/m2";
    public static final String Presure_7_19 = "kgf/m2-inchHg";
    public static final String Presure_7_20 = "inchHg-kgf/m2";
    public static final String Presure_7_21 = "kgf/m2-mmH2o";
    public static final String Presure_7_22 = "mmH2o-kgf/m2";
    public static final String Presure_7_23 = "kgf/m2-cmH2o";
    public static final String Presure_7_24 = "cmH2o-kgf/m2";
    public static final String Presure_7_25 = "kgf/m2-inchH2o";
    public static final String Presure_7_26 = "inchH2o-kgf/m2";
    public static final String Presure_7_27 = "kgf/m2-kgf/m2";

    // psi to other unit
    public static final String Presure_8_15 = "psi-Ksi";
    public static final String Presure_8_16 = "Ksi-psi";
    public static final String Presure_8_17 = "psi-Torr";
    public static final String Presure_8_18 = "Torr-psi";
    public static final String Presure_8_19 = "psi-inchHg";
    public static final String Presure_8_20 = "inchHg-psi";
    public static final String Presure_8_21 = "psi-mmH2o";
    public static final String Presure_8_22 = "mmH2o-psi";
    public static final String Presure_8_23 = "psi-cmH2o";
    public static final String Presure_8_24 = "cmH2o-psi";
    public static final String Presure_8_25 = "psi-inchH2o";
    public static final String Presure_8_26 = "inchH2o-psi";
    public static final String Presure_8_27 = "psi-psi";

    // Ksi to other unit
    public static final String Presure_9_17 = "Ksi-Torr";
    public static final String Presure_9_18 = "Torr-Ksi";
    public static final String Presure_9_19 = "Ksi-inchHg";
    public static final String Presure_9_20 = "inchHg-Ksi";
    public static final String Presure_9_21 = "Ksi-mmH2o";
    public static final String Presure_9_22 = "mmH2o-Ksi";
    public static final String Presure_9_23 = "Ksi-cmH2o";
    public static final String Presure_9_24 = "cmH2o-Ksi";
    public static final String Presure_9_25 = "Ksi-inchH2o";
    public static final String Presure_9_26 = "inchH2o-Ksi";
    public static final String Presure_9_27 = "Ksi-Ksi";

    // Torr to other unit
    public static final String Presure_10_19 = "Torr-inchHg";
    public static final String Presure_10_20 = "inchHg-Torr";
    public static final String Presure_10_21 = "Torr-mmH2o";
    public static final String Presure_10_22 = "mmH2o-Torr";
    public static final String Presure_10_23 = "Torr-cmH2o";
    public static final String Presure_10_24 = "cmH2o-Torr";
    public static final String Presure_10_25 = "Torr-inchH2o";
    public static final String Presure_10_26 = "inchH2o-Torr";
    public static final String Presure_10_27 = "Torr-Torr";

    // inchHg to other unit
    public static final String Presure_11_21 = "inchHg-mmH2o";
    public static final String Presure_11_22 = "mmH2o-inchHg";
    public static final String Presure_11_23 = "inchHg-cmH2o";
    public static final String Presure_11_24 = "cmH2o-inchHg";
    public static final String Presure_11_25 = "inchHg-inchH2o";
    public static final String Presure_11_26 = "inchH2o-inchHg";
    public static final String Presure_11_27 = "inchHg-inchHg";

    // mmH2o to other unit
    public static final String Presure_12_23 = "mmH2o-cmH2o";
    public static final String Presure_12_24 = "cmH2o-mmH2o";
    public static final String Presure_12_25 = "mmH2o-inchH2o";
    public static final String Presure_12_26 = "inchH2o-mmH2o";
    public static final String Presure_12_27 = "mmH2o-mmH2o";

    // cmH2o to other unit
    public static final String Presure_13_25 = "cmH2o-inchH2o";
    public static final String Presure_13_26 = "inchH2o-cmH2o";
    public static final String Presure_13_27 = "cmH2o-cmH2o";
    public static final String Presure_13_28 = "inchH2o-inchH2o";


    // ------------------------------------------------Presure Tag over------------------------------------------------------------
    // ------------------------------------------------Storage ------------------------------------------------------------

    // b to other unit
    public static final String Storage_1_1 = "b-B";
    public static final String Storage_1_2 = "B-b";
    public static final String Storage_1_3 = "b-KB";
    public static final String Storage_1_4 = "KB-b";
    public static final String Storage_1_5 = "b-MB";
    public static final String Storage_1_6 = "MB-b";
    public static final String Storage_1_7 = "b-GB";
    public static final String Storage_1_8 = "GB-b";
    public static final String Storage_1_9 = "b-TB";
    public static final String Storage_1_10 = "TB-b";
    public static final String Storage_1_11 = "b-PB";
    public static final String Storage_1_12 = "PB-b";
    public static final String Storage_1_13 = "b-kb";
    public static final String Storage_1_14 = "kb-b";
    public static final String Storage_1_15 = "b-Mb";
    public static final String Storage_1_16 = "Mb-b";
    public static final String Storage_1_17 = "b-Gb";
    public static final String Storage_1_18 = "Gb-b";
    public static final String Storage_1_19 = "b-Tb";
    public static final String Storage_1_20 = "Tb-b";
    public static final String Storage_1_21 = "b-block";
    public static final String Storage_1_22 = "block-b";
    public static final String Storage_1_23 = "b-b";

    // B to other uni
    public static final String Storage_2_3 = "B-KB";
    public static final String Storage_2_4 = "KB-B";
    public static final String Storage_2_5 = "B-MB";
    public static final String Storage_2_6 = "MB-B";
    public static final String Storage_2_7 = "B-GB";
    public static final String Storage_2_8 = "GB-B";
    public static final String Storage_2_9 = "B-TB";
    public static final String Storage_2_10 = "TB-B";
    public static final String Storage_2_11 = "B-PB";
    public static final String Storage_2_12 = "PB-B";
    public static final String Storage_2_13 = "B-kb";
    public static final String Storage_2_14 = "kb-B";
    public static final String Storage_2_15 = "B-Mb";
    public static final String Storage_2_16 = "Mb-B";
    public static final String Storage_2_17 = "B-Gb";
    public static final String Storage_2_18 = "Gb-B";
    public static final String Storage_2_19 = "B-Tb";
    public static final String Storage_2_20 = "Tb-B";
    public static final String Storage_2_21 = "B-block";
    public static final String Storage_2_22 = "block-B";
    public static final String Storage_2_23 = "B-B";

    // KB to other uni
    public static final String Storage_3_5 = "KB-MB";
    public static final String Storage_3_6 = "MB-KB";
    public static final String Storage_3_7 = "KB-GB";
    public static final String Storage_3_8 = "GB-KB";
    public static final String Storage_3_9 = "KB-TB";
    public static final String Storage_3_10 = "TB-KB";
    public static final String Storage_3_11 = "KB-PB";
    public static final String Storage_3_12 = "PB-KB";
    public static final String Storage_3_13 = "KB-kb";
    public static final String Storage_3_14 = "kb-KB";
    public static final String Storage_3_15 = "KB-Mb";
    public static final String Storage_3_16 = "Mb-KB";
    public static final String Storage_3_17 = "KB-Gb";
    public static final String Storage_3_18 = "Gb-KB";
    public static final String Storage_3_19 = "KB-Tb";
    public static final String Storage_3_20 = "Tb-KB";
    public static final String Storage_3_21 = "KB-block";
    public static final String Storage_3_22 = "block-KB";
    public static final String Storage_3_23 = "KB-KB";


    // MB to other uni
    public static final String Storage_4_7 = "MB-GB";
    public static final String Storage_4_8 = "GB-MB";
    public static final String Storage_4_9 = "MB-TB";
    public static final String Storage_4_10 = "TB-MB";
    public static final String Storage_4_11 = "MB-PB";
    public static final String Storage_4_12 = "PB-MB";
    public static final String Storage_4_13 = "MB-kb";
    public static final String Storage_4_14 = "kb-MB";
    public static final String Storage_4_15 = "MB-Mb";
    public static final String Storage_4_16 = "Mb-MB";
    public static final String Storage_4_17 = "MB-Gb";
    public static final String Storage_4_18 = "Gb-MB";
    public static final String Storage_4_19 = "MB-Tb";
    public static final String Storage_4_20 = "Tb-MB";
    public static final String Storage_4_21 = "MB-block";
    public static final String Storage_4_22 = "block-MB";
    public static final String Storage_4_23 = "MB-MB";


    // GB to other uni
    public static final String Storage_5_9 = "GB-TB";
    public static final String Storage_5_10 = "TB-GB";
    public static final String Storage_5_11 = "GB-PB";
    public static final String Storage_5_12 = "PB-GB";
    public static final String Storage_5_13 = "GB-kb";
    public static final String Storage_5_14 = "kb-GB";
    public static final String Storage_5_15 = "GB-Mb";
    public static final String Storage_5_16 = "Mb-GB";
    public static final String Storage_5_17 = "GB-Gb";
    public static final String Storage_5_18 = "Gb-GB";
    public static final String Storage_5_19 = "GB-Tb";
    public static final String Storage_5_20 = "Tb-GB";
    public static final String Storage_5_21 = "GB-block";
    public static final String Storage_5_22 = "block-GB";
    public static final String Storage_5_23 = "GB-GB";

    // TB to other uni
    public static final String Storage_6_11 = "TB-PB";
    public static final String Storage_6_12 = "PB-TB";
    public static final String Storage_6_13 = "TB-kb";
    public static final String Storage_6_14 = "kb-TB";
    public static final String Storage_6_15 = "TB-Mb";
    public static final String Storage_6_16 = "Mb-TB";
    public static final String Storage_6_17 = "TB-Gb";
    public static final String Storage_6_18 = "Gb-TB";
    public static final String Storage_6_19 = "TB-Tb";
    public static final String Storage_6_20 = "Tb-TB";
    public static final String Storage_6_21 = "TB-block";
    public static final String Storage_6_22 = "block-TB";
    public static final String Storage_6_23 = "TB-TB";

    // PB to other uni
    public static final String Storage_7_13 = "PB-kb";
    public static final String Storage_7_14 = "kb-PB";
    public static final String Storage_7_15 = "PB-Mb";
    public static final String Storage_7_16 = "Mb-PB";
    public static final String Storage_7_17 = "PB-Gb";
    public static final String Storage_7_18 = "Gb-PB";
    public static final String Storage_7_19 = "PB-Tb";
    public static final String Storage_7_20 = "Tb-PB";
    public static final String Storage_7_21 = "PB-block";
    public static final String Storage_7_22 = "block-PB";
    public static final String Storage_7_23 = "PB-PB";


    // kb to other uni
    public static final String Storage_8_15 = "kb-Mb";
    public static final String Storage_8_16 = "Mb-kb";
    public static final String Storage_8_17 = "kb-Gb";
    public static final String Storage_8_18 = "Gb-kb";
    public static final String Storage_8_19 = "kb-Tb";
    public static final String Storage_8_20 = "Tb-kb";
    public static final String Storage_8_21 = "kb-block";
    public static final String Storage_8_22 = "block-kb";
    public static final String Storage_8_23 = "kb-kb";

    // Mb to other uni
    public static final String Storage_9_17 = "Mb-Gb";
    public static final String Storage_9_18 = "Gb-Mb";
    public static final String Storage_9_19 = "Mb-Tb";
    public static final String Storage_9_20 = "Tb-Mb";
    public static final String Storage_9_21 = "Mb-block";
    public static final String Storage_9_22 = "block-Mb";
    public static final String Storage_9_23 = "Mb-Mb";

    // Gb to other uni
    public static final String Storage_10_19 = "Gb-Tb";
    public static final String Storage_10_20 = "Tb-Gb";
    public static final String Storage_10_21 = "Gb-block";
    public static final String Storage_10_22 = "block-Gb";
    public static final String Storage_10_23 = "Gb-Gb";

    // Tb to other uni
    public static final String Storage_11_21 = "Tb-block";
    public static final String Storage_11_22 = "block-Tb";
    public static final String Storage_11_23 = "Tb-Tb";
    public static final String Storage_11_24 = "block-block";


    // ------------------------------------------------Storage Tag over------------------------------------------------------------


    public static String GetConversation(String... s) {

        switch (s[2]) {
            case Area:
                switch (s[0]) {

                    case Area_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.01d));
                    case Area_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 100d));
                    case Area_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Area_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Area_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 1.E-12d));
                    case Area_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000000000d));
                    case Area_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 3.861021585E-13d));
                    case Area_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 2589988110336d));
                    case Area_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0015500031d));
                    case Area_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 645.16d));
                    case Area_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000107639d));
                    case Area_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 92903.04d));
                    case Area_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001196d));
                    case Area_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 836127.36d));
                    case Area_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1.E-10d));
                    case Area_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 10000000000d));
                    case Area_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 2.471053814E-10d));
                    case Area_1_18:
                        return String.valueOf((Double.valueOf(s[1]) * 4046856422.4d));
                    case Area_1_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Area_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001d));
                    case Area_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 10000d));
                    case Area_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Area_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 10000000000d));
                    case Area_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 3.861021585E-11d));
                    case Area_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 25899881103d));
                    case Area_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.15500031d));
                    case Area_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 6.4516d));
                    case Area_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001076391d));
                    case Area_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 929.0304d));
                    case Area_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000119599d));
                    case Area_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 8361.2736d));
                    case Area_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1.E-8d));
                    case Area_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 100000000d));
                    case Area_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 2.471053814E-8d));
                    case Area_2_18:
                        return String.valueOf((Double.valueOf(s[1]) * 40468564.224d));
                    case Area_2_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Area_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Area_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Area_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 3.861021585E-7d));
                    case Area_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 2589988.1103d));
                    case Area_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1550.0031d));
                    case Area_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00064516d));
                    case Area_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 10.763910417d));
                    case Area_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.09290304d));
                    case Area_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 1.1959900463d));
                    case Area_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.83612736d));
                    case Area_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001d));
                    case Area_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 10000d));
                    case Area_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002471054d));
                    case Area_3_18:
                        return String.valueOf((Double.valueOf(s[1]) * 4046.8564224d));
                    case Area_3_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Area_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3861021585d));
                    case Area_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 2.5899881103d));
                    case Area_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1550003100d));
                    case Area_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 6.4516E-10d));
                    case Area_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 10763910.417d));
                    case Area_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 9.290303999E-8d));
                    case Area_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 1195990.0463d));
                    case Area_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 8.361273599E-7d));
                    case Area_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 100d));
                    case Area_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.01d));
                    case Area_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 247.10538147d));
                    case Area_4_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0040468564d));
                    case Area_4_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Area_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 4014489600d));
                    case Area_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 2.490976686E-10d));
                    case Area_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 27878400d));
                    case Area_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 3.587006427E-8d));
                    case Area_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 3097600d));
                    case Area_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 3.228305785E-7d));
                    case Area_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 258.99881103d));
                    case Area_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0038610216d));
                    case Area_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 640d));
                    case Area_5_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0015625d));
                    case Area_5_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Area_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0069444444d));
                    case Area_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 144d));
                    case Area_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0007716049d));
                    case Area_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1296d));
                    case Area_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1.594225079E-7d));
                    case Area_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 15500031d));
                    case Area_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1.594225079E-7d));
                    case Area_6_18:
                        return String.valueOf((Double.valueOf(s[1]) * 6272640d));
                    case Area_6_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Area_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1111111111d));
                    case Area_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 9d));
                    case Area_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000092903d));
                    case Area_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 107639.10417d));
                    case Area_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000229568d));
                    case Area_7_18:
                        return String.valueOf((Double.valueOf(s[1]) * 43560d));
                    case Area_7_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Area_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000836127d));
                    case Area_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 11959.900463d));
                    case Area_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002066116d));
                    case Area_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 4840d));
                    case Area_8_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Area_9_17:
                        return String.valueOf((Double.valueOf(s[1]) * 2.4710538147d));
                    case Area_9_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.4046856422d));
                    case Area_9_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Area_10_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    default:
                        return s[1];
                }
            case Length:
                switch (s[0]) {

                    case Leanth_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Leanth_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Leanth_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001d));
                    case Leanth_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 10000d));
                    case Leanth_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00001d));
                    case Leanth_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 100000d));
                    case Leanth_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Leanth_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Leanth_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1.E-9d));
                    case Leanth_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000000d));
                    case Leanth_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 6.213711922E-10d));
                    case Leanth_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1609344000d));
                    case Leanth_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000393701d));
                    case Leanth_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 25400d));
                    case Leanth_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000032808d));
                    case Leanth_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 304800d));
                    case Leanth_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000010936d));
                    case Leanth_1_18:
                        return String.valueOf((Double.valueOf(s[1]) * 914400d));
                    case Leanth_1_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Leanth_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1d));
                    case Leanth_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 10d));
                    case Leanth_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.01d));
                    case Leanth_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 100d));
                    case Leanth_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Leanth_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Leanth_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Leanth_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Leanth_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 6.213711922E-7d));
                    case Leanth_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1609344d));
                    case Leanth_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0393700787d));
                    case Leanth_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 25.4d));
                    case Leanth_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0032808399d));
                    case Leanth_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 304.8d));
                    case Leanth_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0010936133d));
                    case Leanth_2_18:
                        return String.valueOf((Double.valueOf(s[1]) * 914.4d));
                    case Leanth_2_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Leanth_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1d));
                    case Leanth_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 10d));
                    case Leanth_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.01d));
                    case Leanth_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 100d));
                    case Leanth_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00001d));
                    case Leanth_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 100000d));
                    case Leanth_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000062137d));
                    case Leanth_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 160934.4d));
                    case Leanth_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3937007874d));
                    case Leanth_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 2.54d));
                    case Leanth_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.032808399d));
                    case Leanth_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 30.48d));
                    case Leanth_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.010936133d));
                    case Leanth_3_18:
                        return String.valueOf((Double.valueOf(s[1]) * 91.44d));
                    case Leanth_3_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Leanth_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1d));
                    case Leanth_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 10d));
                    case Leanth_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001d));
                    case Leanth_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 10000d));
                    case Leanth_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000621371d));
                    case Leanth_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 16093.44d));
                    case Leanth_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 3.937007874d));
                    case Leanth_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.254d));
                    case Leanth_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3280839895d));
                    case Leanth_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 3.048d));
                    case Leanth_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1093613298d));
                    case Leanth_4_18:
                        return String.valueOf((Double.valueOf(s[1]) * 9.144d));
                    case Leanth_4_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Leanth_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Leanth_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Leanth_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0006213712d));
                    case Leanth_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1609.344d));
                    case Leanth_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 39.37007874d));
                    case Leanth_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0254d));
                    case Leanth_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 3.280839895d));
                    case Leanth_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3048d));
                    case Leanth_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1.0936132983d));
                    case Leanth_5_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.9144d));
                    case Leanth_5_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Leanth_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.6213711922d));
                    case Leanth_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1.609344d));
                    case Leanth_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 39370.07874d));
                    case Leanth_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000254d));
                    case Leanth_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 3280.839895d));
                    case Leanth_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0003048d));
                    case Leanth_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1093.6132983d));
                    case Leanth_6_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009144d));
                    case Leanth_6_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Leanth_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000157828d));
                    case Leanth_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 63360d));
                    case Leanth_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0833333333d));
                    case Leanth_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 12d));
                    case Leanth_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0277777778d));
                    case Leanth_7_18:
                        return String.valueOf((Double.valueOf(s[1]) * 36d));
                    case Leanth_7_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Leanth_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001893939d));
                    case Leanth_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 5280d));
                    case Leanth_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3333333333d));
                    case Leanth_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 3d));
                    case Leanth_8_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Leanth_9_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1760d));
                    case Leanth_9_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0005681818d));
                    case Leanth_9_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Leanth_9_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    default:
                        return s[1];
                }
            case Weight:
                switch (s[0]) {

                    case Weight_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Weight_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Weight_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Weight_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Weight_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 1.E-9d));
                    case Weight_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000000d));
                    case Weight_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 2.204622621E-9d));
                    case Weight_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 453592370d));
                    case Weight_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 3.527396194E-8d));
                    case Weight_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 28349523.125d));
                    case Weight_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000154324d));
                    case Weight_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 64798.91d));
                    case Weight_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 1.E-12d));
                    case Weight_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000000000d));
                    case Weight_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1.10231131E-12d));
                    case Weight_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 907184740000d));
                    case Weight_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 9.842065276E-13d));
                    case Weight_1_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1016046908800d));
                    case Weight_1_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1.763698097E-10d));
                    case Weight_1_20:
                        return String.valueOf((Double.valueOf(s[1]) * 5669904625d));
                    case Weight_1_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Weight_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Weight_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Weight_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Weight_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000022046d));
                    case Weight_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 453592.37d));
                    case Weight_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000035274d));
                    case Weight_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 28349.523125d));
                    case Weight_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0154323584d));
                    case Weight_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 64.79891d));
                    case Weight_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 1.E-9d));
                    case Weight_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000000d));
                    case Weight_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1.10231131E-9d));
                    case Weight_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 907184740d));
                    case Weight_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 9.842065276E-10d));
                    case Weight_2_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1016046908.8d));
                    case Weight_2_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1.763698097E-7d));
                    case Weight_2_20:
                        return String.valueOf((Double.valueOf(s[1]) * 5669904.625d));
                    case Weight_2_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Weight_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Weight_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0022046226d));
                    case Weight_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 453.59237d));
                    case Weight_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0352739619d));
                    case Weight_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 28.349523125d));
                    case Weight_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 15.432358353d));
                    case Weight_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.06479891d));
                    case Weight_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Weight_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Weight_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000011023d));
                    case Weight_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 907184.74d));
                    case Weight_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 9.842065276E-7d));
                    case Weight_3_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1016046.9088d));
                    case Weight_3_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001763698d));
                    case Weight_3_20:
                        return String.valueOf((Double.valueOf(s[1]) * 5669.904625d));
                    case Weight_3_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 2.2046226218d));
                    case Weight_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 0.45359237d));
                    case Weight_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 35.27396195d));
                    case Weight_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0283495231d));
                    case Weight_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 15432.358353d));
                    case Weight_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000647989d));
                    case Weight_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Weight_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Weight_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0011023113d));
                    case Weight_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 907.18474d));
                    case Weight_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009842065d));
                    case Weight_4_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1016.0469088d));
                    case Weight_4_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1763698097d));
                    case Weight_4_20:
                        return String.valueOf((Double.valueOf(s[1]) * 5.669904625d));
                    case Weight_4_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 16d));
                    case Weight_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0625d));
                    case Weight_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 7000d));
                    case Weight_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001428571d));
                    case Weight_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0004535924d));
                    case Weight_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 2204.6226218d));
                    case Weight_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0005d));
                    case Weight_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 2000d));
                    case Weight_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0004464286d));
                    case Weight_5_18:
                        return String.valueOf((Double.valueOf(s[1]) * 2240d));
                    case Weight_5_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.08d));
                    case Weight_5_20:
                        return String.valueOf((Double.valueOf(s[1]) * 12.5d));
                    case Weight_5_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 437.5d));
                    case Weight_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0022857143d));
                    case Weight_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000283495d));
                    case Weight_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 35273.96195d));
                    case Weight_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00003125d));
                    case Weight_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 32000d));
                    case Weight_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000279018d));
                    case Weight_6_18:
                        return String.valueOf((Double.valueOf(s[1]) * 35840d));
                    case Weight_6_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.005d));
                    case Weight_6_20:
                        return String.valueOf((Double.valueOf(s[1]) * 200d));
                    case Weight_6_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 6.479891E-8d));
                    case Weight_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 15432358.353d));
                    case Weight_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 7.142857142E-8d));
                    case Weight_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 14000000d));
                    case Weight_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 6.37755102E-8d));
                    case Weight_7_18:
                        return String.valueOf((Double.valueOf(s[1]) * 15680000d));
                    case Weight_7_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000114286d));
                    case Weight_7_20:
                        return String.valueOf((Double.valueOf(s[1]) * 87500d));
                    case Weight_7_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1.1023113109d));
                    case Weight_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.90718474d));
                    case Weight_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.9842065276d));
                    case Weight_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1.0160469088d));
                    case Weight_8_19:
                        return String.valueOf((Double.valueOf(s[1]) * 176.36980975d));
                    case Weight_8_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0056699046d));
                    case Weight_8_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_9_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8928571429d));
                    case Weight_9_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1.12d));
                    case Weight_9_19:
                        return String.valueOf((Double.valueOf(s[1]) * 160d));
                    case Weight_9_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00625d));
                    case Weight_9_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Weight_10_19:
                        return String.valueOf((Double.valueOf(s[1]) * 179.2d));
                    case Weight_10_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0055803571d));
                    case Weight_10_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Weight_10_22:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Weight_11_1:
                        return String.valueOf((Double.valueOf(s[1]) * 200d));
                    case Weight_11_2:
                        return String.valueOf((Double.valueOf(s[1]) * 0.005d));
                    case Weight_11_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2d));
                    case Weight_11_4:
                        return String.valueOf((Double.valueOf(s[1]) * 5d));
                    case Weight_11_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002d));
                    case Weight_11_6:
                        return String.valueOf((Double.valueOf(s[1]) * 5000d));
                    case Weight_11_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0004409245d));
                    case Weight_11_8:
                        return String.valueOf((Double.valueOf(s[1]) * 2267.96185d));
                    case Weight_11_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0070547924d));
                    case Weight_11_10:
                        return String.valueOf((Double.valueOf(s[1]) * 141.74761563d));
                    case Weight_11_11:
                        return String.valueOf((Double.valueOf(s[1]) * 3.0864716706d));
                    case Weight_11_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.32399455d));
                    case Weight_11_13:
                        return String.valueOf((Double.valueOf(s[1]) * 2.E-7d));
                    case Weight_11_14:
                        return String.valueOf((Double.valueOf(s[1]) * 5000000d));
                    case Weight_11_15:
                        return String.valueOf((Double.valueOf(s[1]) * 2.204622621E-7d));
                    case Weight_11_16:
                        return String.valueOf((Double.valueOf(s[1]) * 4535923.7d));
                    case Weight_11_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1.968413055E-7d));
                    case Weight_11_18:
                        return String.valueOf((Double.valueOf(s[1]) * 5080234.544d));
                    case Weight_11_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000035274d));
                    case Weight_11_20:
                        return String.valueOf((Double.valueOf(s[1]) * 28349.523125d));
                    case Weight_11_21:
                        return String.valueOf((Double.valueOf(s[1]) * 200000d));
                    case Weight_11_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000005d));
                    case Weight_11_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    default:
                        return s[1];
                }
            case Time:
                switch (s[0]) {

                    case Time_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Time_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Time_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000166667d));
                    case Time_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 60000d));
                    case Time_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 2.777777777E-7d));
                    case Time_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 3600000d));
                    case Time_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 1.157407407E-8d));
                    case Time_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 86400000d));
                    case Time_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1.653439153E-9d));
                    case Time_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 604800000d));
                    case Time_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 3.805175038E-10d));
                    case Time_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 2628000000d));
                    case Time_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 3.170979198E-11d));
                    case Time_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 31536000000d));
                    case Time_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Time_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0166666667d));
                    case Time_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 60d));
                    case Time_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002777778d));
                    case Time_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 3600d));
                    case Time_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000115741d));
                    case Time_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 86400d));
                    case Time_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000016534d));
                    case Time_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 604800d));
                    case Time_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 3.805175038E-7d));
                    case Time_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 2628000d));
                    case Time_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 3.170979198E-8d));
                    case Time_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 31536000d));
                    case Time_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Time_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0166666667d));
                    case Time_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 60d));
                    case Time_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0006944444d));
                    case Time_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1440d));
                    case Time_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000992063d));
                    case Time_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 10080d));
                    case Time_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000228311d));
                    case Time_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 43800d));
                    case Time_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000019026d));
                    case Time_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 525600d));
                    case Time_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Time_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0416666667d));
                    case Time_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 24d));
                    case Time_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.005952381d));
                    case Time_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 168d));
                    case Time_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001369863d));
                    case Time_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 730d));
                    case Time_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001141553d));
                    case Time_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 8760d));
                    case Time_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Time_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1428571429d));
                    case Time_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 7d));
                    case Time_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0328767123d));
                    case Time_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 30.416666667d));
                    case Time_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.002739726d));
                    case Time_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 365d));
                    case Time_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Time_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2301369863d));
                    case Time_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 4.3452380952d));
                    case Time_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0191780822d));
                    case Time_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 52.142857143d));
                    case Time_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Time_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0833333333d));
                    case Time_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 12d));
                    case Time_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Time_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    default:
                        return s[1];
                }
            case Tempreture:
                switch (s[0]) {

                    case Temprature_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * (9d / 5d)) + 32d);
                    case Temprature_1_2:
                        return String.valueOf((Double.valueOf(s[1]) - 32d) * (5d / 9d));
                    case Temprature_1_3:
                        return String.valueOf((Double.valueOf(s[1]) + 273.15d));
                    case Temprature_1_4:
                        return String.valueOf((Double.valueOf(s[1]) - 272.15d));
                    case Temprature_1_5:
                        return s[1];

                    case Temprature_2_3:
                        return String.valueOf((Double.valueOf(s[1]) - 273.15d) * (9d / 5d) + 32d);
                    case Temprature_2_4:
                        return String.valueOf((Double.valueOf(s[1]) - 32d) * (5d / 9d) + 273.15d);
                    case Temprature_2_5:
                        return s[1];
                    case Temprature_2_6:
                        return s[1];


                    default:
                        return s[1];
                }
            case Speed:
                switch (s[0]) {

                    case Speed_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 3.280839895d));
                    case Speed_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3048d));
                    case Speed_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 60d));
                    case Speed_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0166666667d));
                    case Speed_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 196.8503937d));
                    case Speed_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00508d));
                    case Speed_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.06d));
                    case Speed_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 16.666666667d));
                    case Speed_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 3.6d));
                    case Speed_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2777777778d));
                    case Speed_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 2.2369362921d));
                    case Speed_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.44704d));
                    case Speed_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 1.9438444924d));
                    case Speed_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.5144444444d));
                    case Speed_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0033892974d));
                    case Speed_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 295.0464d));
                    case Speed_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 3600d));
                    case Speed_1_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002777778d));
                    case Speed_1_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000335965d));
                    case Speed_1_20:
                        return String.valueOf((Double.valueOf(s[1]) * 29765d));
                    case Speed_1_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 18.288d));
                    case Speed_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0182268883d));
                    case Speed_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 60d));
                    case Speed_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 5.08d));
                    case Speed_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.018288d));
                    case Speed_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 54.680664917d));
                    case Speed_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1.09728d));
                    case Speed_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.9113444153d));
                    case Speed_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.6818181818d));
                    case Speed_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1.4666666667d));
                    case Speed_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.5924838013d));
                    case Speed_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1.6878098571d));
                    case Speed_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0010330579d));
                    case Speed_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 573.52431965d));
                    case Speed_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1097.28d));
                    case Speed_2_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009113444d));
                    case Speed_2_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000102402d));
                    case Speed_2_20:
                        return String.valueOf((Double.valueOf(s[1]) * 97654.199475d));
                    case Speed_2_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 3.280839895d));
                    case Speed_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3048d));
                    case Speed_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Speed_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Speed_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.06d));
                    case Speed_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 16.666666667d));
                    case Speed_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0372822715d));
                    case Speed_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 26.8224d));
                    case Speed_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0323974082d));
                    case Speed_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 30.866666667d));
                    case Speed_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000564883d));
                    case Speed_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 17702.784d));
                    case Speed_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 60d));
                    case Speed_3_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0166666667d));
                    case Speed_3_19:
                        return String.valueOf((Double.valueOf(s[1]) * 5.59941766E-7d));
                    case Speed_3_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1785900d));
                    case Speed_3_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0003048d));
                    case Speed_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 3280.839895d));
                    case Speed_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.018288d));
                    case Speed_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 54.680664917d));
                    case Speed_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0113636364d));
                    case Speed_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 88d));
                    case Speed_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00987473d));
                    case Speed_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 101.26859143d));
                    case Speed_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000172176d));
                    case Speed_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 58080d));
                    case Speed_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 18.288d));
                    case Speed_4_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0546806649d));
                    case Speed_4_19:
                        return String.valueOf((Double.valueOf(s[1]) * 1.706702502E-7d));
                    case Speed_4_20:
                        return String.valueOf((Double.valueOf(s[1]) * 5859251.9685d));
                    case Speed_4_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 60d));
                    case Speed_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0166666667d));
                    case Speed_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 37.282271534d));
                    case Speed_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0268224d));
                    case Speed_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0323974082d));
                    case Speed_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0308666667d));
                    case Speed_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0564882902d));
                    case Speed_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 17.702784d));
                    case Speed_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 60000d));
                    case Speed_5_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000166667d));
                    case Speed_5_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0005599418d));
                    case Speed_5_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1785.9d));
                    case Speed_5_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.6213711922d));
                    case Speed_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1.609344d));
                    case Speed_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.5399568035d));
                    case Speed_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1.852d));
                    case Speed_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009414715d));
                    case Speed_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1062.16704d));
                    case Speed_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Speed_6_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Speed_6_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000093324d));
                    case Speed_6_20:
                        return String.valueOf((Double.valueOf(s[1]) * 107154d));
                    case Speed_6_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8689762419d));
                    case Speed_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1.150779448d));
                    case Speed_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0015151515d));
                    case Speed_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 660d));
                    case Speed_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1609.344d));
                    case Speed_7_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0006213712d));
                    case Speed_7_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000114286d));
                    case Speed_7_20:
                        return String.valueOf((Double.valueOf(s[1]) * 66582.408733d));
                    case Speed_7_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0017436052d));
                    case Speed_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 573.52431965d));
                    case Speed_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1853.184d));
                    case Speed_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0005399568d));
                    case Speed_8_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000172835d));
                    case Speed_8_20:
                        return String.valueOf((Double.valueOf(s[1]) * 57858.531317d));
                    case Speed_8_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Speed_9_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1062167.04d));
                    case Speed_9_18:
                        return String.valueOf((Double.valueOf(s[1]) * 9.414715033E-7d));
                    case Speed_9_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0099125281d));
                    case Speed_9_20:
                        return String.valueOf((Double.valueOf(s[1]) * 100.88243747d));
                    case Speed_9_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Speed_10_19:
                        return String.valueOf((Double.valueOf(s[1]) * 9.332362767E-9d));
                    case Speed_10_20:
                        return String.valueOf((Double.valueOf(s[1]) * 107154000d));
                    case Speed_10_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Speed_10_22:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    default:
                        return s[1];
                }
            case Volume:
                switch (s[0]) {

                    case Volume_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3333333333d));
                    case Volume_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 3d));
                    case Volume_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0208333333d));
                    case Volume_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 48d));
                    case Volume_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 4.9289215937d));
                    case Volume_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2028841362d));
                    case Volume_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0049289216d));
                    case Volume_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 202.88413621d));
                    case Volume_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0104166667d));
                    case Volume_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 28349523.125d));
                    case Volume_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 96d));
                    case Volume_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 115.29119285d));
                    case Volume_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0052083333d));
                    case Volume_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 192d));
                    case Volume_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0043368447d));
                    case Volume_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 230.5823857d));
                    case Volume_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0013020833d));
                    case Volume_1_18:
                        return String.valueOf((Double.valueOf(s[1]) * 768d));
                    case Volume_1_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0010842112d));
                    case Volume_1_20:
                        return String.valueOf((Double.valueOf(s[1]) * 922.32954279d));
                    case Volume_1_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000041336d));
                    case Volume_1_22:
                        return String.valueOf((Double.valueOf(s[1]) * 24192d));
                    case Volume_1_23:
                        return String.valueOf((Double.valueOf(s[1]) * 5d));
                    case Volume_1_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2028841362d));
                    case Volume_1_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000049289d));
                    case Volume_1_26:
                        return String.valueOf((Double.valueOf(s[1]) * 202884.13621d));
                    case Volume_1_27:
                        return String.valueOf((Double.valueOf(s[1]) * 0.30078125d));
                    case Volume_1_28:
                        return String.valueOf((Double.valueOf(s[1]) * 3.3246753247d));
                    case Volume_1_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001740632d));
                    case Volume_1_30:
                        return String.valueOf((Double.valueOf(s[1]) * 5745.038961d));
                    case Volume_1_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000064468d));
                    case Volume_1_32:
                        return String.valueOf((Double.valueOf(s[1]) * 155116.05195d));
                    case Volume_1_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0625d));
                    case Volume_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 16d));
                    case Volume_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 14.786764781d));
                    case Volume_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0676280454d));
                    case Volume_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0147867648d));
                    case Volume_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 67.628045404d));
                    case Volume_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.03125d));
                    case Volume_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 32d));
                    case Volume_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0154323584d));
                    case Volume_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 38.430397616d));
                    case Volume_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.015625d));
                    case Volume_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 64d));
                    case Volume_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0130105341d));
                    case Volume_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 76.860795232d));
                    case Volume_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00390625d));
                    case Volume_2_18:
                        return String.valueOf((Double.valueOf(s[1]) * 256d));
                    case Volume_2_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0032526335d));
                    case Volume_2_20:
                        return String.valueOf((Double.valueOf(s[1]) * 307.44318093d));
                    case Volume_2_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001240079d));
                    case Volume_2_22:
                        return String.valueOf((Double.valueOf(s[1]) * 504d));
                    case Volume_2_23:
                        return String.valueOf((Double.valueOf(s[1]) * 14.786764781d));
                    case Volume_2_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0676280454d));
                    case Volume_2_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000147868d));
                    case Volume_2_26:
                        return String.valueOf((Double.valueOf(s[1]) * 67628.045404d));
                    case Volume_2_27:
                        return String.valueOf((Double.valueOf(s[1]) * 0.90234375d));
                    case Volume_2_28:
                        return String.valueOf((Double.valueOf(s[1]) * 1.1082251082));
                    case Volume_2_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0005221897d));
                    case Volume_2_30:
                        return String.valueOf((Double.valueOf(s[1]) * 1915.012987d));
                    case Volume_2_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000193404d));
                    case Volume_2_32:
                        return String.valueOf((Double.valueOf(s[1]) * 51705.350649d));
                    case Volume_2_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 236.5882365d));
                    case Volume_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0042267528d));
                    case Volume_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2365882365d));
                    case Volume_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 4.2267528377d));
                    case Volume_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.5d));
                    case Volume_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 2d));
                    case Volume_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.4163370923d));
                    case Volume_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 2.401899851d));
                    case Volume_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.25d));
                    case Volume_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 4d));
                    case Volume_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2081685462d));
                    case Volume_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 4.803799702d));
                    case Volume_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0625d));
                    case Volume_3_18:
                        return String.valueOf((Double.valueOf(s[1]) * 16d));
                    case Volume_3_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0520421365d));
                    case Volume_3_20:
                        return String.valueOf((Double.valueOf(s[1]) * 19.215198808d));
                    case Volume_3_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001984127d));
                    case Volume_3_22:
                        return String.valueOf((Double.valueOf(s[1]) * 504d));
                    case Volume_3_23:
                        return String.valueOf((Double.valueOf(s[1]) * 236.5882365d));
                    case Volume_3_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0042267528d));
                    case Volume_3_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002365882d));
                    case Volume_3_26:
                        return String.valueOf((Double.valueOf(s[1]) * 4226.7528377d));
                    case Volume_3_27:
                        return String.valueOf((Double.valueOf(s[1]) * 14.4375d));
                    case Volume_3_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0692640693d));
                    case Volume_3_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0083550347d));
                    case Volume_3_30:
                        return String.valueOf((Double.valueOf(s[1]) * 119.68831169d));
                    case Volume_3_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0003094457d));
                    case Volume_3_32:
                        return String.valueOf((Double.valueOf(s[1]) * 3231.5844156d));
                    case Volume_3_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Volume_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Volume_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0021133764d));
                    case Volume_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 473.176473d));
                    case Volume_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001759754d));
                    case Volume_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 568.26125d));
                    case Volume_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0010566882d));
                    case Volume_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 946.352946d));
                    case Volume_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000879877d));
                    case Volume_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1136.5225d));
                    case Volume_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002641721d));
                    case Volume_4_18:
                        return String.valueOf((Double.valueOf(s[1]) * 3785.411784d));
                    case Volume_4_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002199692d));
                    case Volume_4_20:
                        return String.valueOf((Double.valueOf(s[1]) * 4546.09d));
                    case Volume_4_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000083864d));
                    case Volume_4_22:
                        return String.valueOf((Double.valueOf(s[1]) * 119240.4712d));
                    case Volume_4_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Volume_4_24:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Volume_4_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Volume_4_26:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Volume_4_27:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0610237441d));
                    case Volume_4_28:
                        return String.valueOf((Double.valueOf(s[1]) * 16.387064d));
                    case Volume_4_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000353147d));
                    case Volume_4_30:
                        return String.valueOf((Double.valueOf(s[1]) * 28316.846592d));
                    case Volume_4_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001308d));
                    case Volume_4_32:
                        return String.valueOf((Double.valueOf(s[1]) * 764554.85798d));
                    case Volume_4_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 2.1133764189d));
                    case Volume_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 473.176473d));
                    case Volume_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 1.7597539864d));
                    case Volume_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.56826125d));
                    case Volume_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 1.0566882094d));
                    case Volume_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.946352946d));
                    case Volume_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8798769932d));
                    case Volume_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1.1365225d));
                    case Volume_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2641720524d));
                    case Volume_5_18:
                        return String.valueOf((Double.valueOf(s[1]) * 3.785411784d));
                    case Volume_5_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2199692483d));
                    case Volume_5_20:
                        return String.valueOf((Double.valueOf(s[1]) * 4.54609d));
                    case Volume_5_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0083864144d));
                    case Volume_5_22:
                        return String.valueOf((Double.valueOf(s[1]) * 119.2404712d));
                    case Volume_5_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Volume_5_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Volume_5_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Volume_5_26:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Volume_5_27:
                        return String.valueOf((Double.valueOf(s[1]) * 61.023744095d));
                    case Volume_5_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.016387064d));
                    case Volume_5_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0353146667d));
                    case Volume_5_30:
                        return String.valueOf((Double.valueOf(s[1]) * 28.316846592d));
                    case Volume_5_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0013079506d));
                    case Volume_5_32:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0013079506d));
                    case Volume_5_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8326741846d));
                    case Volume_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1.2009499255d));
                    case Volume_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8326741846d));
                    case Volume_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 2d));
                    case Volume_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.5d));
                    case Volume_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 2.401899851d));
                    case Volume_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.125d));
                    case Volume_6_18:
                        return String.valueOf((Double.valueOf(s[1]) * 8d));
                    case Volume_6_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1040842731d));
                    case Volume_6_20:
                        return String.valueOf((Double.valueOf(s[1]) * 9.607599404d));
                    case Volume_6_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.003968254d));
                    case Volume_6_22:
                        return String.valueOf((Double.valueOf(s[1]) * 252d));
                    case Volume_6_23:
                        return String.valueOf((Double.valueOf(s[1]) * 473.176473d));
                    case Volume_6_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0021133764d));
                    case Volume_6_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0004731765d));
                    case Volume_6_26:
                        return String.valueOf((Double.valueOf(s[1]) * 2113.3764189d));
                    case Volume_6_27:
                        return String.valueOf((Double.valueOf(s[1]) * 28.875d));
                    case Volume_6_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0346320346d));
                    case Volume_6_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0167100694d));
                    case Volume_6_30:
                        return String.valueOf((Double.valueOf(s[1]) * 59.844155844d));
                    case Volume_6_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0006188915d));
                    case Volume_6_32:
                        return String.valueOf((Double.valueOf(s[1]) * 1615.7922078d));
                    case Volume_6_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.6004749628d));
                    case Volume_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1.6653483693d));
                    case Volume_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.5d));
                    case Volume_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 2d));
                    case Volume_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1501187407d));
                    case Volume_7_18:
                        return String.valueOf((Double.valueOf(s[1]) * 6.661393477d));
                    case Volume_7_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.125d));
                    case Volume_7_20:
                        return String.valueOf((Double.valueOf(s[1]) * 8d));
                    case Volume_7_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0047656743d));
                    case Volume_7_22:
                        return String.valueOf((Double.valueOf(s[1]) * 209.83389453d));
                    case Volume_7_23:
                        return String.valueOf((Double.valueOf(s[1]) * 568.26125d));
                    case Volume_7_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001759754d));
                    case Volume_7_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0005682613d));
                    case Volume_7_26:
                        return String.valueOf((Double.valueOf(s[1]) * 907184740000d));
                    case Volume_7_27:
                        return String.valueOf((Double.valueOf(s[1]) * 34.677429099d));
                    case Volume_7_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0288372012d));
                    case Volume_7_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0200679567d));
                    case Volume_7_30:
                        return String.valueOf((Double.valueOf(s[1]) * 49.830683672d));
                    case Volume_7_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0007432577d));
                    case Volume_7_32:
                        return String.valueOf((Double.valueOf(s[1]) * 1345.4284592d));
                    case Volume_7_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8326741846d));
                    case Volume_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1.2009499255d));
                    case Volume_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.25d));
                    case Volume_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 4d));
                    case Volume_8_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2081685462d));
                    case Volume_8_20:
                        return String.valueOf((Double.valueOf(s[1]) * 4.803799702d));
                    case Volume_8_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0079365079d));
                    case Volume_8_22:
                        return String.valueOf((Double.valueOf(s[1]) * 126d));
                    case Volume_8_23:
                        return String.valueOf((Double.valueOf(s[1]) * 946.352946d));
                    case Volume_8_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0010566882d));
                    case Volume_8_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009463529d));
                    case Volume_8_26:
                        return String.valueOf((Double.valueOf(s[1]) * 1056.6882094d));
                    case Volume_8_27:
                        return String.valueOf((Double.valueOf(s[1]) * 57.75d));
                    case Volume_8_28:
                        return String.valueOf((Double.valueOf(s[1]) * 1016046908800d));
                    case Volume_8_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0334201389d));
                    case Volume_8_30:
                        return String.valueOf((Double.valueOf(s[1]) * 29.922077922d));
                    case Volume_8_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0012377829d));
                    case Volume_8_32:
                        return String.valueOf((Double.valueOf(s[1]) * 807.8961039d));
                    case Volume_8_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_9_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3002374814d));
                    case Volume_9_18:
                        return String.valueOf((Double.valueOf(s[1]) * 3.3306967385d));
                    case Volume_9_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.25d));
                    case Volume_9_20:
                        return String.valueOf((Double.valueOf(s[1]) * 4d));
                    case Volume_9_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0095313486d));
                    case Volume_9_22:
                        return String.valueOf((Double.valueOf(s[1]) * 104.91694726d));
                    case Volume_9_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1136.5225d));
                    case Volume_9_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000879877d));
                    case Volume_9_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0011365225d));
                    case Volume_9_26:
                        return String.valueOf((Double.valueOf(s[1]) * 879.8769932d));
                    case Volume_9_27:
                        return String.valueOf((Double.valueOf(s[1]) * 69.354858198d));
                    case Volume_9_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0144186006d));
                    case Volume_9_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0401359133d));
                    case Volume_9_30:
                        return String.valueOf((Double.valueOf(s[1]) * 24.915341836d));
                    case Volume_9_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0014865153d));
                    case Volume_9_32:
                        return String.valueOf((Double.valueOf(s[1]) * 672.71422958d));
                    case Volume_9_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_10_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8326741846d));
                    case Volume_10_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1.2009499255d));
                    case Volume_10_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0317460317d));
                    case Volume_10_22:
                        return String.valueOf((Double.valueOf(s[1]) * 31.5d));
                    case Volume_10_23:
                        return String.valueOf((Double.valueOf(s[1]) * 3785.411784d));
                    case Volume_10_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002641721d));
                    case Volume_10_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0037854118d));
                    case Volume_10_26:
                        return String.valueOf((Double.valueOf(s[1]) * 264.17205236d));
                    case Volume_10_27:
                        return String.valueOf((Double.valueOf(s[1]) * 231d));
                    case Volume_10_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0043290043d));
                    case Volume_10_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1336805556d));
                    case Volume_10_30:
                        return String.valueOf((Double.valueOf(s[1]) * 7.4805194805d));
                    case Volume_10_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0049511317d));
                    case Volume_10_32:
                        return String.valueOf((Double.valueOf(s[1]) * 201.97402597d));
                    case Volume_10_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_11_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0381253945d));
                    case Volume_11_22:
                        return String.valueOf((Double.valueOf(s[1]) * 26.229236816d));
                    case Volume_11_23:
                        return String.valueOf((Double.valueOf(s[1]) * 4546.09d));
                    case Volume_11_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002199692d));
                    case Volume_11_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00454609d));
                    case Volume_11_26:
                        return String.valueOf((Double.valueOf(s[1]) * 219.9692483d));
                    case Volume_11_27:
                        return String.valueOf((Double.valueOf(s[1]) * 277.41943279d));
                    case Volume_11_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0036046501d));
                    case Volume_11_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1605436532d));
                    case Volume_11_30:
                        return String.valueOf((Double.valueOf(s[1]) * 6.228835459d));
                    case Volume_11_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0059460612d));
                    case Volume_11_32:
                        return String.valueOf((Double.valueOf(s[1]) * 168.17855739d));
                    case Volume_11_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Volume_12_23:
                        return String.valueOf((Double.valueOf(s[1]) * 119240.4712d));
                    case Volume_12_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000083864d));
                    case Volume_12_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1192404712d));
                    case Volume_12_26:
                        return String.valueOf((Double.valueOf(s[1]) * 8.3864143606d));
                    case Volume_12_27:
                        return String.valueOf((Double.valueOf(s[1]) * 7276.5d));
                    case Volume_12_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001374287d));
                    case Volume_12_29:
                        return String.valueOf((Double.valueOf(s[1]) * 4.2109375d));
                    case Volume_12_30:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2374768089d));
                    case Volume_12_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1559606481d));
                    case Volume_12_32:
                        return String.valueOf((Double.valueOf(s[1]) * 6.4118738404d));
                    case Volume_12_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Volume_13_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Volume_13_26:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Volume_13_27:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0610237441d));
                    case Volume_13_28:
                        return String.valueOf((Double.valueOf(s[1]) * 16.387064d));
                    case Volume_13_29:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000353147d));
                    case Volume_13_30:
                        return String.valueOf((Double.valueOf(s[1]) * 28316.846592d));
                    case Volume_13_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001308d));
                    case Volume_13_32:
                        return String.valueOf((Double.valueOf(s[1]) * 764554.85798d));
                    case Volume_13_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Volume_14_27:
                        return String.valueOf((Double.valueOf(s[1]) * 61023.744095d));
                    case Volume_14_28:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000163871d));
                    case Volume_14_29:
                        return String.valueOf((Double.valueOf(s[1]) * 35.314666721d));
                    case Volume_14_30:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0283168466d));
                    case Volume_14_31:
                        return String.valueOf((Double.valueOf(s[1]) * 1.3079506193d));
                    case Volume_14_32:
                        return String.valueOf((Double.valueOf(s[1]) * 0.764554858d));
                    case Volume_14_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Volume_15_29:
                        return String.valueOf((Double.valueOf(s[1]) * 10.0005787037d));
                    case Volume_15_30:
                        return String.valueOf((Double.valueOf(s[1]) * 1728d));
                    case Volume_15_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000214335d));
                    case Volume_15_32:
                        return String.valueOf((Double.valueOf(s[1]) * 46656d));
                    case Volume_15_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Volume_16_31:
                        return String.valueOf((Double.valueOf(s[1]) * 0.037037037d));
                    case Volume_16_32:
                        return String.valueOf((Double.valueOf(s[1]) * 27d));
                    case Volume_16_33:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Volume_16_34:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    default:
                        return s[1];
                }
            case Energy:
                switch (s[0]) {

                    case Energy_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Energy_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Energy_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002388459d));
                    case Energy_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 4186.8d));
                    case Energy_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002388459d));
                    case Energy_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 4186.8d));
                    case Energy_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 2.777777777E-7d));
                    case Energy_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 3600000d));
                    case Energy_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1019716213d));
                    case Energy_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 9.8066499997d));
                    case Energy_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 8.8507457916d));
                    case Energy_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.112984829d));
                    case Energy_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.7375621493d));
                    case Energy_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1.3558179483d));
                    case Energy_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009484517d));
                    case Energy_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1054.35d));
                    case Energy_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Energy_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2388458966d));
                    case Energy_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 4186.8d));
                    case Energy_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2388458966d));
                    case Energy_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 4.184d));
                    case Energy_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002777778d));
                    case Energy_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 3600d));
                    case Energy_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 101.9716213d));
                    case Energy_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00980665d));
                    case Energy_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 8850.7457916d));
                    case Energy_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001129848d));
                    case Energy_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 737.5621493d));
                    case Energy_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0013558179d));
                    case Energy_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000032808d));
                    case Energy_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1.05435d));
                    case Energy_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Energy_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 1.0006692161d));
                    case Energy_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Energy_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001163d));
                    case Energy_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 859.84522786d));
                    case Energy_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 426.93478406d));
                    case Energy_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0023422781d));
                    case Energy_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 37056.30248d));
                    case Energy_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000026986d));
                    case Energy_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 3088.0252067d));
                    case Energy_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0003238316d));
                    case Energy_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 3.9709773795d));
                    case Energy_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 30.2518271711d));
                    case Energy_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Energy_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001163d));
                    case Energy_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 859.84522786d));
                    case Energy_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 426.93478406d));
                    case Energy_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0023422781d));
                    case Energy_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 37056.30248d));
                    case Energy_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000026986d));
                    case Energy_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 3088.0252067d));
                    case Energy_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0003238316d));
                    case Energy_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 3.9709773795d));
                    case Energy_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2518271711d));
                    case Energy_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Energy_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 367097.83668d));
                    case Energy_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000027241d));
                    case Energy_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 31862684.85d));
                    case Energy_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 3.138467472E-8d));
                    case Energy_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 2655223.7375d));
                    case Energy_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 3.766160967E-7d));
                    case Energy_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 3414.4259497d));
                    case Energy_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000292875d));
                    case Energy_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Energy_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 86.796166215d));
                    case Energy_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0115212462d));
                    case Energy_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 7.2330138512d));
                    case Energy_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1382549544d));
                    case Energy_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0093011334d));
                    case Energy_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 107.51377892d));
                    case Energy_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Energy_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0833333333d));
                    case Energy_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 12d));
                    case Energy_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001071606d));
                    case Energy_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 9331.7838251d));
                    case Energy_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Energy_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0012859278d));
                    case Energy_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 777.6486521d));
                    case Energy_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Energy_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    default:
                        return s[1];
                }
            case Fuel:
                switch (s[0]) {

                    case Fuel_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.6213711922d));
                    case Fuel_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 1.609344d));
                    case Fuel_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 3.7854117834d));
                    case Fuel_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2641720524d));
                    case Fuel_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 2.3521458329d));
                    case Fuel_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 0.4251437075d));
                    case Fuel_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 2.8248093628d));
                    case Fuel_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 0.35400619d));
                    case Fuel_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 100d));
                    case Fuel_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 100d));
                    case Fuel_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Fuel_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 6.0920297411d));
                    case Fuel_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1641489032d));
                    case Fuel_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 3.7854117834d));
                    case Fuel_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2641720524d));
                    case Fuel_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 4.5460899992d));
                    case Fuel_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2199692483d));
                    case Fuel_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 62.137119224d));
                    case Fuel_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 62.137119224d));
                    case Fuel_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Fuel_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.6213711922d));
                    case Fuel_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1.609344d));
                    case Fuel_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.746235687d));
                    case Fuel_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1.340059203d));
                    case Fuel_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 378.54117834d));
                    case Fuel_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 378.54117834d));
                    case Fuel_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Fuel_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 1.2009499255d));
                    case Fuel_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 0.8326741846d));
                    case Fuel_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 235.21458329d));
                    case Fuel_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 235.21458329d));
                    case Fuel_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Fuel_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 282.48093628d));
                    case Fuel_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 282.48093628d));
                    case Fuel_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    default:
                        return s[1];
                }
            case Presure:
                switch (s[0]) {

                    case Presure_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 101325d));
                    case Presure_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000098692d));
                    case Presure_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 101.325d));
                    case Presure_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0098692327d));
                    case Presure_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.101325d));
                    case Presure_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 9.8692326672d));
                    case Presure_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 1.01325d));
                    case Presure_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 0.9869232667d));
                    case Presure_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1.0332274528d));
                    case Presure_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.9678411054d));
                    case Presure_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 10332.274528d));
                    case Presure_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000967841d));
                    case Presure_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 14.695948775d));
                    case Presure_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0680459639d));
                    case Presure_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0146959488d));
                    case Presure_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 68.04596391d));
                    case Presure_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 760d));
                    case Presure_1_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0013157895d));
                    case Presure_1_19:
                        return String.valueOf((Double.valueOf(s[1]) * 29.921331924d));
                    case Presure_1_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0334209721d));
                    case Presure_1_21:
                        return String.valueOf((Double.valueOf(s[1]) * 10332.559008d));
                    case Presure_1_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000967814d));
                    case Presure_1_23:
                        return String.valueOf((Double.valueOf(s[1]) * 76.000210018d));
                    case Presure_1_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0131578584d));
                    case Presure_1_25:
                        return String.valueOf((Double.valueOf(s[1]) * 406.79374664d));
                    case Presure_1_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0024582482d));
                    case Presure_1_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Presure_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Presure_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000001d));
                    case Presure_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1000000d));
                    case Presure_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00001d));
                    case Presure_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 100000d));
                    case Presure_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000101972d));
                    case Presure_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 98066.5d));
                    case Presure_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1019716213d));
                    case Presure_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 9.80665d));
                    case Presure_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001450377d));
                    case Presure_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 6894.7572932d));
                    case Presure_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 1.450377377E-7d));
                    case Presure_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 6894757.2932d));
                    case Presure_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0075006168d));
                    case Presure_2_18:
                        return String.valueOf((Double.valueOf(s[1]) * 133.32236842d));
                    case Presure_2_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002953006d));
                    case Presure_2_20:
                        return String.valueOf((Double.valueOf(s[1]) * 3386.38d));
                    case Presure_2_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1019744289d));
                    case Presure_2_22:
                        return String.valueOf((Double.valueOf(s[1]) * 9.80638d));
                    case Presure_2_23:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0101974429d));
                    case Presure_2_24:
                        return String.valueOf((Double.valueOf(s[1]) * 98.0638d));
                    case Presure_2_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0040147421d));
                    case Presure_2_26:
                        return String.valueOf((Double.valueOf(s[1]) * 249.082d));
                    case Presure_2_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Presure_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Presure_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.01d));
                    case Presure_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 100d));
                    case Presure_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0101971621d));
                    case Presure_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 9806.65d));
                    case Presure_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 101.9716213d));
                    case Presure_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00980665d));
                    case Presure_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1450377377d));
                    case Presure_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 6.8947572932d));
                    case Presure_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001450377d));
                    case Presure_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 6894.7572932d));
                    case Presure_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 7.500616827d));
                    case Presure_3_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1333223684d));
                    case Presure_3_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.2953005865d));
                    case Presure_3_20:
                        return String.valueOf((Double.valueOf(s[1]) * 3.38638d));
                    case Presure_3_21:
                        return String.valueOf((Double.valueOf(s[1]) * 101.97442889d));
                    case Presure_3_22:
                        return String.valueOf((Double.valueOf(s[1]) * 9.80638d));
                    case Presure_3_23:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0101974429d));
                    case Presure_3_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0980638d));
                    case Presure_3_25:
                        return String.valueOf((Double.valueOf(s[1]) * 4.0147421331d));
                    case Presure_3_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.249082d));
                    case Presure_3_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 10d));
                    case Presure_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1d));
                    case Presure_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 10.19716213d));
                    case Presure_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0980665d));
                    case Presure_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 101971.6213d));
                    case Presure_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000098067d));
                    case Presure_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 145.03773773d));
                    case Presure_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0068947573d));
                    case Presure_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000879877d));
                    case Presure_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 6.8947572932d));
                    case Presure_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 7500.616827d));
                    case Presure_4_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001333224d));
                    case Presure_4_19:
                        return String.valueOf((Double.valueOf(s[1]) * 295.30058647d));
                    case Presure_4_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00338638d));
                    case Presure_4_21:
                        return String.valueOf((Double.valueOf(s[1]) * 101974.42889d));
                    case Presure_4_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000098064d));
                    case Presure_4_23:
                        return String.valueOf((Double.valueOf(s[1]) * 10197.442889d));
                    case Presure_4_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000980638d));
                    case Presure_4_25:
                        return String.valueOf((Double.valueOf(s[1]) * 4018.5980719d));
                    case Presure_4_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000249082d));
                    case Presure_4_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1.019716213d));
                    case Presure_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 0.980665d));
                    case Presure_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 10197.16213d));
                    case Presure_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000980665d));
                    case Presure_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 14.503773773d));
                    case Presure_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0689475729d));
                    case Presure_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0145037738d));
                    case Presure_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 68.947572932d));
                    case Presure_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 750.0616827d));
                    case Presure_5_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0013332237d));
                    case Presure_5_19:
                        return String.valueOf((Double.valueOf(s[1]) * 29.530058647d));
                    case Presure_5_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0338638d));
                    case Presure_5_21:
                        return String.valueOf((Double.valueOf(s[1]) * 10197.442889d));
                    case Presure_5_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000980638d));
                    case Presure_5_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1019.7442889d));
                    case Presure_5_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000980638d));
                    case Presure_5_25:
                        return String.valueOf((Double.valueOf(s[1]) * 401.47421331d));
                    case Presure_5_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00249082d));
                    case Presure_5_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 10000d));
                    case Presure_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001d));
                    case Presure_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 14.223343307d));
                    case Presure_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.6894757293d));
                    case Presure_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0142233433d));
                    case Presure_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 689.47572932d));
                    case Presure_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 735.55924007d));
                    case Presure_6_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0013595098d));
                    case Presure_6_19:
                        return String.valueOf((Double.valueOf(s[1]) * 28.959094963d));
                    case Presure_6_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0345314659d));
                    case Presure_6_21:
                        return String.valueOf((Double.valueOf(s[1]) * 10000.275331d));
                    case Presure_6_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000999972d));
                    case Presure_6_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1000.0275331d));
                    case Presure_6_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009999725d));
                    case Presure_6_25:
                        return String.valueOf((Double.valueOf(s[1]) * 393.7117094d));
                    case Presure_6_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0025399295d));
                    case Presure_6_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0014223343d));
                    case Presure_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 703.06957964d));
                    case Presure_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000014223d));
                    case Presure_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 703069.57964d));
                    case Presure_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.073555924d));
                    case Presure_7_18:
                        return String.valueOf((Double.valueOf(s[1]) * 13.595098063d));
                    case Presure_7_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0028959095d));
                    case Presure_7_20:
                        return String.valueOf((Double.valueOf(s[1]) * 345.31465893d));
                    case Presure_7_21:
                        return String.valueOf((Double.valueOf(s[1]) * 1.0000275331d));
                    case Presure_7_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.9999724677d));
                    case Presure_7_23:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1000027533d));
                    case Presure_7_24:
                        return String.valueOf((Double.valueOf(s[1]) * 9.9997246766d));
                    case Presure_7_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0393711709d));
                    case Presure_7_26:
                        return String.valueOf((Double.valueOf(s[1]) * 25.399295376d));
                    case Presure_7_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Presure_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001d));
                    case Presure_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1000d));
                    case Presure_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 51.714932572d));
                    case Presure_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0193367747d));
                    case Presure_8_19:
                        return String.valueOf((Double.valueOf(s[1]) * 2.0360258722d));
                    case Presure_8_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.4911528943d));
                    case Presure_8_21:
                        return String.valueOf((Double.valueOf(s[1]) * 703.08893732d));
                    case Presure_8_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0014222952d));
                    case Presure_8_23:
                        return String.valueOf((Double.valueOf(s[1]) * 70.308893732d));
                    case Presure_8_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0142229517d));
                    case Presure_8_25:
                        return String.valueOf((Double.valueOf(s[1]) * 27.680672603d));
                    case Presure_8_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0361262898d));
                    case Presure_8_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_9_17:
                        return String.valueOf((Double.valueOf(s[1]) * 51714.932572d));
                    case Presure_9_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000193368d));
                    case Presure_9_19:
                        return String.valueOf((Double.valueOf(s[1]) * 2036.0258722d));
                    case Presure_9_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0004911529d));
                    case Presure_9_21:
                        return String.valueOf((Double.valueOf(s[1]) * 703088.93732d));
                    case Presure_9_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000014223d));
                    case Presure_9_23:
                        return String.valueOf((Double.valueOf(s[1]) * 70308.893732d));
                    case Presure_9_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.000014223d));
                    case Presure_9_25:
                        return String.valueOf((Double.valueOf(s[1]) * 27680.672603d));
                    case Presure_9_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000361263d));
                    case Presure_9_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_10_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0393701736d));
                    case Presure_10_20:
                        return String.valueOf((Double.valueOf(s[1]) * 25.399938811d));

                    case Presure_10_21:
                        return String.valueOf((Double.valueOf(s[1]) * 13.595472378d));
                    case Presure_10_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0735538988d));
                    case Presure_10_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1.3595472378d));
                    case Presure_10_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.7355389884d));
                    case Presure_10_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.5352549298d));
                    case Presure_10_26:
                        return String.valueOf((Double.valueOf(s[1]) * 1.8682686405d));
                    case Presure_10_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_11_21:
                        return String.valueOf((Double.valueOf(s[1]) * 345.32416651d));
                    case Presure_11_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0028958298d));
                    case Presure_11_23:
                        return String.valueOf((Double.valueOf(s[1]) * 34.532416651d));
                    case Presure_11_24:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0289582977d));
                    case Presure_11_25:
                        return String.valueOf((Double.valueOf(s[1]) * 13.595442465d));
                    case Presure_11_26:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0735540607d));
                    case Presure_11_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Presure_12_23:
                        return String.valueOf((Double.valueOf(s[1]) * 0.1d));
                    case Presure_12_24:
                        return String.valueOf((Double.valueOf(s[1]) * 10d));
                    case Presure_12_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.039370087d));
                    case Presure_12_26:
                        return String.valueOf((Double.valueOf(s[1]) * 25.399994697d));
                    case Presure_12_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Presure_13_25:
                        return String.valueOf((Double.valueOf(s[1]) * 0.3937008696d));
                    case Presure_13_26:
                        return String.valueOf((Double.valueOf(s[1]) * 2.5399994697d));
                    case Presure_13_27:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Presure_13_28:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    default:
                        return s[1];
                }
            case Storage:
                switch (s[0]) {

                    case Storage_1_1:
                        return String.valueOf((Double.valueOf(s[1]) * 0.125d));
                    case Storage_1_2:
                        return String.valueOf((Double.valueOf(s[1]) * 8d));
                    case Storage_1_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001220703d));
                    case Storage_1_4:
                        return String.valueOf((Double.valueOf(s[1]) * 8192d));
                    case Storage_1_5:
                        return String.valueOf((Double.valueOf(s[1]) * 1.192092895E-7d));
                    case Storage_1_6:
                        return String.valueOf((Double.valueOf(s[1]) * 8388608d));
                    case Storage_1_7:
                        return String.valueOf((Double.valueOf(s[1]) * 1.164153218E-10d));
                    case Storage_1_8:
                        return String.valueOf((Double.valueOf(s[1]) * 8589934592d));
                    case Storage_1_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1.136868377E-13d));
                    case Storage_1_10:
                        return String.valueOf((Double.valueOf(s[1]) * 8796093022208d));
                    case Storage_1_11:
                        return String.valueOf((Double.valueOf(s[1]) * 1.110223024E-16d));
                    case Storage_1_12:
                        return String.valueOf((Double.valueOf(s[1]) * 8000000000000000d));
                    case Storage_1_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_1_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_1_15:
                        return String.valueOf((Double.valueOf(s[1]) * 9.536743164E-7d));
                    case Storage_1_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1048576d));
                    case Storage_1_17:
                        return String.valueOf((Double.valueOf(s[1]) * 9.313225746E-10d));
                    case Storage_1_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1073741824d));
                    case Storage_1_19:
                        return String.valueOf((Double.valueOf(s[1]) * 9.094947017E-13d));
                    case Storage_1_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1099511627776d));
                    case Storage_1_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0002441406d));
                    case Storage_1_22:
                        return String.valueOf((Double.valueOf(s[1]) * 4096));
                    case Storage_1_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Storage_2_3:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_2_4:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_2_5:
                        return String.valueOf((Double.valueOf(s[1]) * 9.536743164E-7d));
                    case Storage_2_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1048576d));
                    case Storage_2_7:
                        return String.valueOf((Double.valueOf(s[1]) * 9.313225746E-10d));
                    case Storage_2_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1073741824d));
                    case Storage_2_9:
                        return String.valueOf((Double.valueOf(s[1]) * 9.094947017E-13d));
                    case Storage_2_10:
                        return String.valueOf((Double.valueOf(s[1]) * 1099511627776d));
                    case Storage_2_11:
                        return String.valueOf((Double.valueOf(s[1]) * 8.881784197E-16d));
                    case Storage_2_12:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000967841d));
                    case Storage_2_13:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0078125d));
                    case Storage_2_14:
                        return String.valueOf((Double.valueOf(s[1]) * 128d));
                    case Storage_2_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000076294d));
                    case Storage_2_16:
                        return String.valueOf((Double.valueOf(s[1]) * 131072d));
                    case Storage_2_17:
                        return String.valueOf((Double.valueOf(s[1]) * 7.450580596E-9d));
                    case Storage_2_18:
                        return String.valueOf((Double.valueOf(s[1]) * 134217728d));
                    case Storage_2_19:
                        return String.valueOf((Double.valueOf(s[1]) * 7.275957614E-12d));
                    case Storage_2_20:
                        return String.valueOf((Double.valueOf(s[1]) * 137438953472d));
                    case Storage_2_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.001953125d));
                    case Storage_2_22:
                        return String.valueOf((Double.valueOf(s[1]) * 512d));
                    case Storage_2_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Storage_3_5:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_3_6:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_3_7:
                        return String.valueOf((Double.valueOf(s[1]) * 9.536743164E-7d));
                    case Storage_3_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1048576d));
                    case Storage_3_9:
                        return String.valueOf((Double.valueOf(s[1]) * 1.024E-9d));
                    case Storage_3_10:
                        return String.valueOf((Double.valueOf(s[1]) * 1073741824d));
                    case Storage_3_11:
                        return String.valueOf((Double.valueOf(s[1]) * 9.094947017E-13d));
                    case Storage_3_12:
                        return String.valueOf((Double.valueOf(s[1]) * 976562500000d));
                    case Storage_3_13:
                        return String.valueOf((Double.valueOf(s[1]) * 8d));
                    case Storage_3_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.125d));
                    case Storage_3_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0078125d));
                    case Storage_3_16:
                        return String.valueOf((Double.valueOf(s[1]) * 128d));
                    case Storage_3_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000076294d));
                    case Storage_3_18:
                        return String.valueOf((Double.valueOf(s[1]) * 131072d));
                    case Storage_3_19:
                        return String.valueOf((Double.valueOf(s[1]) * 7.275957614E-9d));
                    case Storage_3_20:
                        return String.valueOf((Double.valueOf(s[1]) * 134217728d));
                    case Storage_3_21:
                        return String.valueOf((Double.valueOf(s[1]) * 7.105427357E-12d));
                    case Storage_3_22:
                        return String.valueOf((Double.valueOf(s[1]) * 137438953472d));
                    case Storage_3_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Storage_4_7:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_4_8:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_4_9:
                        return String.valueOf((Double.valueOf(s[1]) * 9.536743164E-7d));
                    case Storage_4_10:
                        return String.valueOf((Double.valueOf(s[1]) * 1048576d));
                    case Storage_4_11:
                        return String.valueOf((Double.valueOf(s[1]) * 9.313225746E-10d));
                    case Storage_4_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1073741824d));
                    case Storage_4_13:
                        return String.valueOf((Double.valueOf(s[1]) * 8192d));
                    case Storage_4_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001220703d));
                    case Storage_4_15:
                        return String.valueOf((Double.valueOf(s[1]) * 8d));
                    case Storage_4_16:
                        return String.valueOf((Double.valueOf(s[1]) * 0.125d));
                    case Storage_4_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0078125d));
                    case Storage_4_18:
                        return String.valueOf((Double.valueOf(s[1]) * 128d));
                    case Storage_4_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000076294d));
                    case Storage_4_20:
                        return String.valueOf((Double.valueOf(s[1]) * 131072d));
                    case Storage_4_21:
                        return String.valueOf((Double.valueOf(s[1]) * 2048d));
                    case Storage_4_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0004882812d));
                    case Storage_4_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Storage_5_9:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_5_10:
                        return String.valueOf((Double.valueOf(s[1]) * 8192d));
                    case Storage_5_11:
                        return String.valueOf((Double.valueOf(s[1]) * 9.536743164E-7d));
                    case Storage_5_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1048576d));
                    case Storage_5_13:
                        return String.valueOf((Double.valueOf(s[1]) * 8388608d));
                    case Storage_5_14:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0680459639d));
                    case Storage_5_15:
                        return String.valueOf((Double.valueOf(s[1]) * 8192d));
                    case Storage_5_16:
                        return String.valueOf((Double.valueOf(s[1]) * 68.04596391d));
                    case Storage_5_17:
                        return String.valueOf((Double.valueOf(s[1]) * 8d));
                    case Storage_5_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.125d));
                    case Storage_5_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0078125d));
                    case Storage_5_20:
                        return String.valueOf((Double.valueOf(s[1]) * 128d));
                    case Storage_5_21:
                        return String.valueOf((Double.valueOf(s[1]) * 2097152d));
                    case Storage_5_22:
                        return String.valueOf((Double.valueOf(s[1]) * 4.768371582E-7d));
                    case Storage_5_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Storage_6_11:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_6_12:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_6_13:
                        return String.valueOf((Double.valueOf(s[1]) * 8589934592d));
                    case Storage_6_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1.164153218E-10d));
                    case Storage_6_15:
                        return String.valueOf((Double.valueOf(s[1]) * 8388608d));
                    case Storage_6_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1.192092895E-7d));
                    case Storage_6_17:
                        return String.valueOf((Double.valueOf(s[1]) * 8192d));
                    case Storage_6_18:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001220703d));
                    case Storage_6_19:
                        return String.valueOf((Double.valueOf(s[1]) * 8d));
                    case Storage_6_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.125d));
                    case Storage_6_21:
                        return String.valueOf((Double.valueOf(s[1]) * 2147483648d));
                    case Storage_6_22:
                        return String.valueOf((Double.valueOf(s[1]) * 4.656612873E-10d));
                    case Storage_6_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Storage_7_13:
                        return String.valueOf((Double.valueOf(s[1]) * 8796093022208d));
                    case Storage_7_14:
                        return String.valueOf((Double.valueOf(s[1]) * 1.136868377E-13d));
                    case Storage_7_15:
                        return String.valueOf((Double.valueOf(s[1]) * 8589934592d));
                    case Storage_7_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1.164153218E-10d));
                    case Storage_7_17:
                        return String.valueOf((Double.valueOf(s[1]) * 8388608d));
                    case Storage_7_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1.192092895E-7d));
                    case Storage_7_19:
                        return String.valueOf((Double.valueOf(s[1]) * 8192d));
                    case Storage_7_20:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0001220703d));
                    case Storage_7_21:
                        return String.valueOf((Double.valueOf(s[1]) * 2199023255552d));
                    case Storage_7_22:
                        return String.valueOf((Double.valueOf(s[1]) * 4.547473508E-13d));
                    case Storage_7_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Storage_8_15:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_8_16:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_8_17:
                        return String.valueOf((Double.valueOf(s[1]) * 9.536743164E-7d));
                    case Storage_8_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1048576d));
                    case Storage_8_19:
                        return String.valueOf((Double.valueOf(s[1]) * 9.313225746E-10d));
                    case Storage_8_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1073741824d));
                    case Storage_8_21:
                        return String.valueOf((Double.valueOf(s[1]) * 0.25d));
                    case Storage_8_22:
                        return String.valueOf((Double.valueOf(s[1]) * 4d));
                    case Storage_8_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    case Storage_9_17:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_9_18:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_9_19:
                        return String.valueOf((Double.valueOf(s[1]) * 9.536743164E-7d));
                    case Storage_9_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1048576d));
                    case Storage_9_21:
                        return String.valueOf((Double.valueOf(s[1]) * 256d));
                    case Storage_9_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.00390625d));
                    case Storage_9_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Storage_10_19:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0009765625d));
                    case Storage_10_20:
                        return String.valueOf((Double.valueOf(s[1]) * 1024d));
                    case Storage_10_21:
                        return String.valueOf((Double.valueOf(s[1]) * 262144d));
                    case Storage_10_22:
                        return String.valueOf((Double.valueOf(s[1]) * 0.0000038147d));
                    case Storage_10_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));

                    case Storage_11_21:
                        return String.valueOf((Double.valueOf(s[1]) * 268435456d));
                    case Storage_11_22:
                        return String.valueOf((Double.valueOf(s[1]) * 3.725290298E-9d));
                    case Storage_11_23:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));
                    case Storage_11_24:
                        return String.valueOf((Double.valueOf(s[1]) * 1d));


                    default:
                        return s[1];
                }
            default:
                return s[1];


        }


    }


}
