package com.citizencalc.gstcalculator.Classes.common

class AppConstUtility {

    companion object{
        const val Text_0 : String = "0"
        const val Text_00 : String = "00"
        const val Text_1 : String = "1"
        const val Text_2 : String = "2"
        const val Text_3 : String = "3"
        const val Text_4 : String = "4"
        const val Text_5 : String = "5"
        const val Text_6 : String = "6"
        const val Text_7 : String = "7"
        const val Text_8 : String = "8"
        const val Text_9 : String = "9"
        const val Text_Correct : String = "Correct"
        const val Text_Check : String = "Check"
        const val Text_Auto_Replay : String = "Auto Replay"
        const val Text_Dot : String = "."
        const val Text_C : String = "C"
        const val Text_CE : String = "CE"
        const val Text_root : String = "√x"
        const val Text_MC : String = "MC"
        const val Text_mPlus : String = "M+"
        const val Text_mMins : String = "M-"
        const val Text_MR : String = "MR"
        const val Text_GT : String = "GT"
        const val Text_MU : String = "MU"
        const val Text_Plus : String = "+"
        const val Text_Mines : String = "-"
        const val Text_Devide : String = "÷"
        const val Text_Multiple : String = "x"
        const val Text_Module : String = "%"
        const val Text_equal : String = "="

        const val Text_Plus_Char : Char = '+'
        const val Text_Mines_Char : Char = '-'
        const val Text_Devide_Char : Char = '÷'
        const val Text_Multiple_Char : Char = 'x'
        const val Text_Module_Char : Char = '%'
        const val Text_equal_Char : Char = '='
        const val Text_M_Char : Char = 'M'
        const val Text_plus : String = "Plus"
        const val Text_minus : String = "Minus"
        const val Tag_Vibrate : String = "is_vibrate"
        const val Tag_Sound : String = "is_sound"
        const val Tag_Round : String = "is_round"

        const val Pattern : String = "##,##,##,##,###"
        const val TEXT_MAIL : String = "itenicapps@gmail.com"
        const val TEXT_MAIL_TO : String = "mailto:"
        const val TEXT_FEEDBACK : String = "Feedback About "
        const val TEXT_SENDMAIL : String = "Send mail"

        var THEME_NUMBER = 0;

    }
}