package com.citizencalc.gstcalculator.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
@Keep
public class Menu implements Serializable
{
    @SerializedName("menu_icon")
    public int menu_icon;

    @SerializedName("menu_name")
    public String menu_name;

    public int getMenu_icon() {
        return menu_icon;
    }

    public void setMenu_icon(int menu_icon) {
        this.menu_icon = menu_icon;
    }

    public String getMenu_name ()
    {
        return menu_name;
    }

    public void setMenu_name (String menu_name)
    {
        this.menu_name = menu_name;
    }


}