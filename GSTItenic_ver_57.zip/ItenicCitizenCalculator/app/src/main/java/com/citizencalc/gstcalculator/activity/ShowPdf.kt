package com.citizencalc.gstcalculator.activity

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.SnapHelper
import com.citizencalc.gstcalculator.R
import com.citizencalc.gstcalculator.adapter.PageAdapter
import com.citizencalc.gstcalculator.databinding.ActivityShowpdfBinding
import java.io.IOException

class ShowPdf : AppCompatActivity() {

    private lateinit var binding : ActivityShowpdfBinding
    private val snapperCarr: SnapHelper = PagerSnapHelper()
    private var adapter: PageAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(1024, 1024)
        binding = ActivityShowpdfBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarShow)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val v: View = layoutInflater.inflate(R.layout.custom_actionbar, null)
        v.findViewById<TextView>(R.id.action_bar_title).text = resources.getString(R.string.app_label)

        supportActionBar?.customView = v
        binding.pager.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        snapperCarr.attachToRecyclerView(binding.pager)

        if (!TextUtils.isEmpty(intent.getStringExtra("URI"))) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                show(Uri.parse(intent.getStringExtra("URI")))
                v.findViewById<TextView>(R.id.action_bar_title).text = intent.getStringExtra("URI").toString().substring(intent.getStringExtra("URI").toString().lastIndexOf("/") + 1)
            } else {
                val target = Intent(Intent.ACTION_VIEW)
                target.setDataAndType(Uri.parse(intent.getStringExtra("URI")), "application/pdf")
                target.flags = Intent.FLAG_ACTIVITY_NO_HISTORY
                val intent = Intent.createChooser(target, "Open File")
                try {
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
        }

        binding.sharePDF.clickWithDebounce {
            val sharingIntent = Intent(Intent.ACTION_SEND)
            val screenshotUri = Uri.parse(Uri.parse(intent.getStringExtra("URI")).toString())
            sharingIntent.type = "*/*"
            sharingIntent.putExtra(Intent.EXTRA_STREAM, screenshotUri)
            startActivity(Intent.createChooser(sharingIntent, "Share using"))
        }

    }

    fun View.clickWithDebounce(debounceTime: Long = 600L, action: () -> Unit) {
        this.setOnClickListener(object : View.OnClickListener {
            private var lastClickTime: Long = 0

            override fun onClick(v: View) {
                if (SystemClock.elapsedRealtime() - lastClickTime < debounceTime) return
                else action()

                lastClickTime = SystemClock.elapsedRealtime()
            }
        })
    }

    private fun show(uri: Uri) {
        try {
            adapter = PageAdapter(contentResolver.openFileDescriptor(uri, "r")!!)
            binding.pager.adapter = adapter
        } catch (e: IOException) {
        }
    }

    override fun onDestroy() {
        if (adapter != null) {
            adapter?.close()
        }
        super.onDestroy()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}