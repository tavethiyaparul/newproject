package com.citizencalc.gstcalculator.CustomAd.sync;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;


import com.citizencalc.gstcalculator.CustomAd.callback.AdsLoaded;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import static android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY;

import static com.citizencalc.gstcalculator.CustomAd.CustomAdsUtil.ASSERT_LOCATION;


public class AdsLoadingSync extends AsyncTask<String, Integer, ArrayList<String>> {
    @SuppressLint("StaticFieldLeak")
    private Context context;
    private ArrayList<String> paths;
    private AdsLoaded adsLoaded;
    private int pos;

    public AdsLoadingSync(Context context, ArrayList<String> paths, AdsLoaded adsLoaded, int pos) {
        this.context = context;
        this.paths = paths;
        this.adsLoaded = adsLoaded;
        this.pos = pos;
    }

    @Override
    protected ArrayList<String> doInBackground(String... strings) {
        android.os.Process.setThreadPriority(THREAD_PRIORITY_URGENT_DISPLAY);
        ArrayList<String> arrayList = new ArrayList<>();
        for (int i = 0; i < paths.size(); i++) {
            if (download(paths.get(i), paths.get(i).substring(paths.get(i).lastIndexOf('/') + 1))) {
                arrayList.add(paths.get(i));
            }
        }
        return arrayList;
    }

    @Override
    protected void onPostExecute(ArrayList<String> strings) {
        super.onPostExecute(strings);
        if (strings.size() != 0)
            adsLoaded.onLoaded(strings, pos);
        else adsLoaded.onFailed();
    }

    private boolean download(String downloadUrl, String imageName) {
        try {
            URL url = new URL(downloadUrl);
            File mLocationDir = null;
            String sdCard = context.getFilesDir().toString();
            mLocationDir = new File(sdCard, ASSERT_LOCATION);
            if (!mLocationDir.exists()) {
                mLocationDir.mkdir();
            }

            File file = new File(mLocationDir, imageName);
            if (file.exists()) {
                return true;
            }
            URLConnection ucon = url.openConnection();
            InputStream inputStream = null;
            HttpURLConnection httpConn = (HttpURLConnection) ucon;
            httpConn.setRequestMethod("GET");
            httpConn.connect();

            if (httpConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                inputStream = httpConn.getInputStream();
            }

            FileOutputStream fos = new FileOutputStream(file);
            byte[] buffer = new byte[64000];
            int bufferLength = 0;
            if (inputStream != null) {
                while ((bufferLength = inputStream.read(buffer)) > 0) {
                    fos.write(buffer, 0, bufferLength);
                }
            }

            fos.close();
            return true;
        } catch (IndexOutOfBoundsException|IOException|NullPointerException e) {
            e.printStackTrace();
            return false;
        }   catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
