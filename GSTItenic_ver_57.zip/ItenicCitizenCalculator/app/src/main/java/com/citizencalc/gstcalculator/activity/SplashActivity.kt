package com.citizencalc.gstcalculator.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.WindowManager
import com.citizencalc.gstcalculator.*
import com.citizencalc.gstcalculator.Classes.common.*
import com.citizencalc.gstcalculator.database.table.CaAds
import com.citizencalc.gstcalculator.database.table.TbSku
import com.citizencalc.gstcalculator.databinding.ActivitySplashBinding
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentDebugSettings
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.FormError
import com.google.android.ump.UserMessagingPlatform
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import java.lang.NullPointerException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.log

@SuppressLint("CustomSplashScreen")
class SplashActivity : RootClass() {
    private var consentInformation: ConsentInformation? = null
    private val isMobileAdsInitializeCalled = AtomicBoolean(false)
    var binding: ActivitySplashBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            window.decorView.systemUiVisibility =
                (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        } catch (e: NullPointerException) {
            e.printStackTrace()
        }
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE") {
            requestConsentFrom()
        } else
            TrasitActvity()
    }

    var count = 0
    val handler = Handler(Looper.getMainLooper())
    private val runnable = object : Runnable {
        override fun run() {
            if (4 < count) {
                showAds()
            } else {
                count += 1
                handler.postDelayed(this, 1000)
            }
        }
    }

    private fun bannerLoading(binding: ActivitySplashBinding) {
        val adView = AdView(this)
        adView.setAdSize(
            AdSize.getInlineAdaptiveBannerAdSize(
                WindowManager.LayoutParams.MATCH_PARENT,
                maxHeightBanner
            )
        )
        adView.adUnitId =
            if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/9214589741" else "ca-app-pub-4244031033574393/4131551661"
        adView.loadAd(AdRequest.Builder().build())
        adView.adListener = object : AdListener() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                super.onAdFailedToLoad(adError)
                binding.googleLayout.removeAllViews()
            }

            override fun onAdLoaded() {
                super.onAdLoaded()
                binding.googleLayout.removeAllViews()
                binding.googleLayout.addView(adView)
            }
        }
        loadingFull(splashBuilderAds())
    }


    private fun TrasitActvity() {
        if (!isFinishing) {
            if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE")
                handler.removeCallbacks(runnable)
//            Log.d("activityTXN", "${this@SplashActivity.localClassName} ending")
            val sharedPref: SharedPreferences =
                getSharedPreferences("AppPref", Context.MODE_PRIVATE)
            if (sharedPref.all.isNotEmpty()) startActivity(
                Intent(
                    this@SplashActivity,
                    MainActivity::class.java
                )
            )
            else startActivity(Intent(this@SplashActivity, SelectTheme::class.java))

//            overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
            finish()
        }
    }


    private fun showAds() {
        if (interstitialAdSplash != null) {
            interstitialAdSplash?.show(this@SplashActivity)
            interstitialAdSplash?.fullScreenContentCallback = object :
                FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    super.onAdDismissedFullScreenContent()
                    TrasitActvity()
                }
            }
        } else
            TrasitActvity()
    }


    var interstitialAdSplash: InterstitialAd? = null
    private fun loadingFull(id: String) {
        if (id != "") {
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(this@SplashActivity,
                id,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        interstitialAdSplash = interstitialAd
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        interstitialAdSplash = null
                    }
                })
        }
    }

    private fun requestConsentFrom() {
        /*val debugSettings = ConsentDebugSettings.Builder(this)
            .setDebugGeography(ConsentDebugSettings.DebugGeography.DEBUG_GEOGRAPHY_EEA)
            .addTestDeviceHashedId("C1B61805AC49BBB052F41418DAB58A94")
            .build()*/
        consentInformation = UserMessagingPlatform.getConsentInformation(this)
        if (ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
            == (consentInformation?.privacyOptionsRequirementStatus ?: -1)
        ) {
            consentInformation?.requestConsentInfoUpdate(
                this,
                ConsentRequestParameters
                    .Builder()
//                    .setConsentDebugSettings(debugSettings)
                    .setTagForUnderAgeOfConsent(false)
                    .build(),
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                        this
                    ) { error: FormError? ->
                        Log.e("UserMessagingPlatform", "******************* ${error?.message}")
                        if (consentInformation?.canRequestAds() == true) {
                            initializeMobileAdsSdk()
                        } else TrasitActvity()
                    }
                },
                { error: FormError ->
                    Log.e("UserMessagingPlatform", " 1 ******************* ${error.message}")
                    if (consentInformation?.canRequestAds() == true) {
                        initializeMobileAdsSdk()
                    } else TrasitActvity()
                })
//            consentInformation?.reset()
        } else {
            MobileAds.initialize(this)
            CoroutineScope(Dispatchers.Main).launch {
                handler.postDelayed(runnable, 1000)
                binding?.let {
                    bannerLoading(it)
                }
            }
        }
    }

    private fun initializeMobileAdsSdk() {
        if (isMobileAdsInitializeCalled.getAndSet(true)) {
            return
        }
        MobileAds.initialize(this)
        CoroutineScope(Dispatchers.Main).launch {
            handler.postDelayed(runnable, 1000)
            binding?.let {
                bannerLoading(it)
            }
        }

    }

}