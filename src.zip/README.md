## Openshop Analytics Dashboard

A demo React Analytics Dashboard with clean and beautiful UI. This is made for a YouTube Playlist - https://www.youtube.com/watch?v=Ou-rZsXRciI&list=PLwHsNjmBZ-MJnVNyiaVYHW_dDA5n3mbVk
