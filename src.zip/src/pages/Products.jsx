import React from 'react'

export default function Products() {
	return <div>company page</div>
}
