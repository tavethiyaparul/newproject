package com.divinesoftech.calculator.mongodb;


import static com.divinesoftech.calculator.Common.Utilty.Cuontry_Flag_Response;

import android.os.AsyncTask;

import com.divinesoftech.calculator.Classes.Model.Country;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class CountryFlagSync extends AsyncTask<String, Integer, String> {

    DatabaseGst databaseGst;
    OnResponseData onResponse;

    public CountryFlagSync(DatabaseGst databaseGst, OnResponseData onResponse) {
        this.databaseGst = databaseGst;
        this.onResponse = onResponse;
    }

    @Override
    protected void onPreExecute() {

        super.onPreExecute();
    }


    @Override
    protected String doInBackground(String... strings) {
        /*try {

            MongoClientURI mongoClientURI = new MongoClientURI(strings[0]);
            mongoClient = new MongoClient(mongoClientURI);
            MongoDatabase mongoDatabase = mongoClient.getDatabase(DATABASE);


            MongoCollection<Document> collection = mongoDatabase.getCollection(TABLE_DEVINE_COUNTRY);
            Document myDoc = collection.find().first();

            return myDoc.toJson();
        } catch (NullPointerException
                | MongoSocketClosedException
                | MongoExecutionTimeoutException
                | MongoSocketReadException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (mongoClient != null) {
                mongoClient.close();
            }
        }*/
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);


        if (s != null) {

            if (databaseGst.getResponse(Cuontry_Flag_Response) != null) {
                databaseGst.setResponse(Cuontry_Flag_Response, s.trim(), "true");
            } else {
                databaseGst.setResponse(Cuontry_Flag_Response, s.trim(), "false");
            }


            try {


                JSONObject object = new JSONObject(s);
                String data = object.getString("country");
                MongodbUtility.countrylist = new Gson().fromJson(data, new TypeToken<ArrayList<Country>>() {
                }.getType());

                onResponse.onResponse();


            } catch (JSONException | NullPointerException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }


    }
}
