package com.divinesoftech.calculator.CustomAd.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.StrictMode;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.InflateException;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.divinesoftech.calculator.BuildConfig;
import com.divinesoftech.calculator.CustomAd.callback.AdsLoaded;
import com.divinesoftech.calculator.CustomAd.callback.InterstitialCustom;
import com.divinesoftech.calculator.CustomAd.model.Data;
import com.divinesoftech.calculator.CustomAd.model.GetAdsData;
import com.divinesoftech.calculator.CustomAd.sync.AdsLoadingSync;
import com.divinesoftech.calculator.R;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static com.divinesoftech.calculator.CustomAd.CustomAdsUtil.ASSERT_LOCATION;
import static com.divinesoftech.calculator.CustomAd.CustomAdsUtil.PACKAGE_NAME;
import static com.divinesoftech.calculator.CustomAd.CustomAdsUtil.getLaunchIntent;
import static com.divinesoftech.calculator.CustomAd.CustomAdsUtil.isNetworkConnected;


public class AdsInit {
    public ArrayList<Data> mAdsList(String response) {
        ArrayList<Data> arrayList = new ArrayList<>();
        //DatabaseHelperCustomAds databaseHelper = new DatabaseHelperCustomAds(context);
        if (response != null) {
            try {
                JSONObject object = new JSONObject(response);
                if (object.has("data")) {
                    arrayList = new ArrayList<>();
                    final GetAdsData thumbnail = new Gson().fromJson(response, GetAdsData.class);
                    arrayList = thumbnail.getData();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return arrayList;
    }

    public static int mAdsMax = 0;
    public static int getApkcount = 0;

    public static int getApk(Context context, ArrayList<Data> list) {

        int pos = 0;
        if (mAdsMax >= list.size()) {
            mAdsMax = 0;
        }
        int mAdsAnswer = mAdsMax;

        pos = mAdsAnswer;
        if (PACKAGE_NAME.equals("testing")) {
            mAdsMax++;
            return pos;
        }
        String app = list.get(mAdsAnswer).getInstall();
        String Apk = app.substring(app.indexOf("=") + 1);
        if (Apk.equals(PACKAGE_NAME) || getLaunchIntent(context, Apk) != null) {
            getApkcount++;
            mAdsMax++;
            if (getApkcount == list.size()) {
                getApkcount = 0;
                return -1;
            }
            return getApk(context, list);
        }
        mAdsMax++;
        getApkcount = 0;


        return pos;
    }

    public void AdsRequest(Context context, boolean isInterstitial, ArrayList<Data> arrayList, AdsLoaded adsLoaded) {

        try {
            ExecutorService executor = new ThreadPoolExecutor(3, 3, 0L,
                    TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(15));

            int pos = getApk(context, arrayList);
            if (pos != -1) {
                ArrayList<String> stringArrayList = new ArrayList<>();
                String sdCard = context.getFilesDir().toString();
                File mLocationDir = new File(sdCard, ASSERT_LOCATION);

                if (isInterstitial) {
                    String icon = arrayList.get(pos).getIcon();
                    String Banner = arrayList.get(pos).getBanner();
                    String iconMulti = arrayList.get(pos).getIcon_download();
                    String BannerMulti = arrayList.get(pos).getBanner_download();

                    stringArrayList.add(icon);
                    stringArrayList.add(Banner);
                    stringArrayList.add(iconMulti);
                    stringArrayList.add(BannerMulti);

                    File iconFile = new File(mLocationDir, icon.substring(icon.lastIndexOf('/') + 1));
                    File bannerFile = new File(mLocationDir, Banner.substring(Banner.lastIndexOf('/') + 1));
                    File iconFileMulti = new File(mLocationDir, iconMulti.substring(iconMulti.lastIndexOf('/') + 1));
                    File bannerFileMulti = new File(mLocationDir, BannerMulti.substring(BannerMulti.lastIndexOf('/') + 1));
                    if (iconFile.exists() && bannerFile.exists() && iconFileMulti.exists() && bannerFileMulti.exists()) {
                        adsLoaded.onLoaded(stringArrayList, pos);
                    } else if (isNetworkConnected(context)) {
                        if (stringArrayList != null && stringArrayList.size() > 0)
                            new AdsLoadingSync(context, stringArrayList, adsLoaded, pos).executeOnExecutor(executor);
                        else
                            adsLoaded.onFailed();
                    } else {

                        adsLoaded.onFailed();
                    }
                } else if (mLocationDir.exists()) {

                    String icon = arrayList.get(pos).getIcon();
                    String Banner = arrayList.get(pos).getBanner();
                    stringArrayList.add(icon);
                    stringArrayList.add(Banner);

                    File iconFile = new File(mLocationDir, icon.substring(icon.lastIndexOf('/') + 1));
                    File bannerFile = new File(mLocationDir, Banner.substring(Banner.lastIndexOf('/') + 1));

                    if (iconFile.exists() && bannerFile.exists()) {
                        adsLoaded.onLoaded(stringArrayList, pos);
                    } else if (isNetworkConnected(context)) {
                        new AdsLoadingSync(context, stringArrayList, adsLoaded, pos).executeOnExecutor(executor);
                    } else {
                        adsLoaded.onFailed();
                    }

                } else {
                    if (isNetworkConnected(context)) {
                        String icon = arrayList.get(pos).getIcon();
                        String Banner = arrayList.get(pos).getBanner();
                        stringArrayList.add(icon);
                        stringArrayList.add(Banner);

                        if (stringArrayList != null && stringArrayList.size() > 0)
                            new AdsLoadingSync(context, stringArrayList, adsLoaded, pos).executeOnExecutor(executor);
                        else
                            adsLoaded.onFailed();

                    } else {
                        adsLoaded.onFailed();
                    }
                }
                executor.shutdown();
            } else {

                if (BuildConfig.DEBUG)
                    Log.e("onFaled", "willl b ");

                adsLoaded.onFailed();
            }
        } catch (IndexOutOfBoundsException | NullPointerException e) {
            e.printStackTrace();
            adsLoaded.onFailed();
        } catch (Exception e) {
            e.printStackTrace();
            adsLoaded.onFailed();
        }
    }


    @SuppressLint("SetJavaScriptEnabled")
    public void InterstitialCustomAds(Activity context, Data data, InterstitialCustom interstitialCustom) {
        if (context != null && !context.isFinishing()) {
            try {

                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.setVmPolicy(builder.build());

                WebView webview;
                String utl = data.getDesign_page();
                final Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.ads_network_dialog_custom);
                Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawableResource(R.drawable.ads_network_intertitial_bg);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(true);
                dialog.findViewById(R.id.ads_close_ads_network).setOnClickListener(view -> {
                    dialog.dismiss();
                    interstitialCustom.onInterstitialCustomClose();
                });

                dialog.setOnCancelListener(dialogInterface -> interstitialCustom.onInterstitialCustomClose());

                webview = dialog.findViewById(R.id.webview_ads_close_ads_network);


                WebSettings settings = webview.getSettings();
                settings.setJavaScriptCanOpenWindowsAutomatically(true);
                settings.setSupportMultipleWindows(true);
                settings.setBuiltInZoomControls(true);
                settings.setJavaScriptEnabled(true);
//                settings.setAppCacheEnabled(true);
//                settings.setAppCachePath("");
                settings.setDatabaseEnabled(true);
                settings.setDomStorageEnabled(true);
                settings.setGeolocationEnabled(true);
                settings.setSaveFormData(false);


                webview.setBackgroundColor(0);
                webview.setAlpha(0f);
                webview.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        webview.setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        if (!context.isFinishing())
                            interstitialCustom.onAdsClick(data.getCadid());

                        view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));

                        return true;
                    }
                });
                webview.setWebChromeClient(new WebChromeClient() {
                    boolean didShow = false;

                    @Override
                    public void onProgressChanged(WebView view, int newProgress) {
                        // if (newProgress == 100 && !didShow) {
                        //didShow = true;
                        //  holde.progress.setVisibility(View.GONE);
                        view.animate().alpha(1).setDuration(300).setInterpolator(new DecelerateInterpolator()).start();
                        // }
                    }
                });
                try {
                    //
                    // int pos = getApk(context, arrayList);


                    String sdCard = context.getFilesDir().toString();
                    File mLocationDir = new File(sdCard, ASSERT_LOCATION);
                    String fileName = mLocationDir + File.separator + utl.substring(utl.lastIndexOf('/') + 1);

                    try {
                        Document doc = Jsoup.parse(new File(fileName), "utf-8");
                        for (int i = 0; i < data.getValue().size(); i++) {
                            if (data.getAttr().get(i).equals("innerHTML")) {
                                /*doc.select("i[id=title1]").html("<span class='red'>Hello <b>Again</b></span>");*/
                                doc.select(data.getId().get(i)).html(data.getValue().get(i));
                            } else
                                doc.select(data.getId().get(i)).attr(data.getAttr().get(i), data.getValue().get(i));
                        }

                        webview.loadDataWithBaseURL("file://" + mLocationDir + File.separator, doc.outerHtml(), "text/html", "utf-8", null);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    interstitialCustom.onInterstitialCustomLoaded(dialog);

                } catch (IndexOutOfBoundsException | NullPointerException e) {
                    e.printStackTrace();
                }


                WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
                Display display = wm.getDefaultDisplay();
                DisplayMetrics metrics = new DisplayMetrics();
                display.getMetrics(metrics);
                Window win = dialog.getWindow();
                win.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            } catch (InflateException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
