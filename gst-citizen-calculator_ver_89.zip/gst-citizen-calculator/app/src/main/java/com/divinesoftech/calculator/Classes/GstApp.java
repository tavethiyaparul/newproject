package com.divinesoftech.calculator.Classes;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;


public class GstApp {
    @SuppressLint("StaticFieldLeak")
    public static Context context;
    @SuppressLint("StaticFieldLeak")
    public static Activity currentActivity;

}
