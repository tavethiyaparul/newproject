package com.divinesoftech.calculator.Fragments;

import android.app.DatePickerDialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.divinesoftech.calculator.Common.Utilty.hideSoftKeyboard;
import static com.divinesoftech.calculator.Common.Utilty.isLeapYear;

public class CompoundIntrest extends Fragment {
    View view;
    Spinner spinner;
    List<String> options;
    private String PRICIPLE = "", RATE = "", FROM_DATE = "", TO_DATE = "", INTREST_PER = "";
    AppCompatEditText ET_PRINCIPLE, ET_RATE, ET_FROM_DATE, ET_TO_DATE;
    AppCompatTextView TV_CALCULATE, TV_RESET, TV_PRINCIPLE_DTL, TV_INTREST_DTL, TV_PERIOD_DTL, TV_TOTAL_DTL, TV_INTREST_PER;
    LinearLayout linearLayout;
     Calendar selected_date = Calendar.getInstance();

    RelativeLayout FROM_LAYOUT, TO_LAYOUT;
    public CompoundIntrest() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.compound_fragment,container,false);
        spinner = view.findViewById(R.id.cmd_spinner);
        ET_PRINCIPLE = view.findViewById(R.id.cmd_amount);
        ET_RATE =  view.findViewById(R.id.cmd_rate);
        ET_FROM_DATE =  view.findViewById(R.id.cmd_from_date);
        ET_TO_DATE = view.findViewById(R.id.cmd_to_date);
        TV_CALCULATE = view.findViewById(R.id.cmd_calculate);
        TV_RESET =  view.findViewById(R.id.cmd_reset);
        FROM_LAYOUT = view.findViewById(R.id.cmd_from_date_layout);
        TO_LAYOUT =  view.findViewById(R.id.cmd_to_date_layout);

        TV_PRINCIPLE_DTL =  view.findViewById(R.id.cmd_dtl_priciple);
        TV_INTREST_DTL = view.findViewById(R.id.cmd_dtl_intrest);
        TV_PERIOD_DTL =  view.findViewById(R.id.cmd_dtl_duration);
        TV_TOTAL_DTL =view.findViewById(R.id.cmd_dtl_total);
        TV_INTREST_PER = view.findViewById(R.id.cmd_dtl_intrest_type);
        linearLayout = view.findViewById(R.id.cmd_intrest_details);

        CheckTexTCondtions(ET_PRINCIPLE);
        CheckTexTCondtions(ET_RATE);

        options = new ArrayList<String>();
        options.add("Monthly");
        options.add("Quarterly");
        options.add("Half Yearly");
        options.add("Yearly");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, options);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                INTREST_PER = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        PRICIPLE = ET_PRINCIPLE.getText().toString();
        RATE = ET_RATE.getText().toString();
        FROM_DATE = ET_FROM_DATE.getText().toString();
        TO_DATE = ET_TO_DATE.getText().toString();

        FROM_LAYOUT.setOnClickListener(v -> {
            hideSoftKeyboard(v);
            openCalender(ET_FROM_DATE);
        });
        TO_LAYOUT.setOnClickListener(v -> {

            hideSoftKeyboard(v);
            ToCalender(ET_TO_DATE);

        });


        TV_CALCULATE.setOnClickListener(v -> {
            hideSoftKeyboard(v);

            PRICIPLE = ET_PRINCIPLE.getText().toString();
            RATE = ET_RATE.getText().toString();
            FROM_DATE = ET_FROM_DATE.getText().toString();
            TO_DATE = ET_TO_DATE.getText().toString();

            if(!TextUtils.isEmpty(PRICIPLE) && !TextUtils.isEmpty(RATE) && !TextUtils.isEmpty(FROM_DATE) && !TextUtils.isEmpty(TO_DATE))
            {
                ET_PRINCIPLE.setError(null);
                ET_RATE.setError(null);
                ET_FROM_DATE.setError(null);
                ET_TO_DATE.setError(null);

                if(INTREST_PER.equals("Monthly"))
                {
                    if(Double.valueOf(RATE) > 30)
                    {
                        ET_RATE.setError("Enter Valid Interest Rate");
                    }
                    else
                    {
                        simpleIntrest(ET_PRINCIPLE.getText().toString(), ET_RATE.getText().toString(), ET_FROM_DATE.getText().toString(), ET_TO_DATE.getText().toString(), INTREST_PER);
                    }


                }
                else
                {
                    if(Double.valueOf(RATE) > 120)
                    {
                        ET_RATE.setError("Enter Valid Interest Rate");
                    }
                    else
                    {
                        simpleIntrest(ET_PRINCIPLE.getText().toString(), ET_RATE.getText().toString(), ET_FROM_DATE.getText().toString(), ET_TO_DATE.getText().toString(), INTREST_PER);
                    }
                }



            }
            else
            {

                if(TextUtils.isEmpty(PRICIPLE))
                    ET_PRINCIPLE.setError("Enter Amount");

                if(TextUtils.isEmpty(RATE))
                    ET_RATE.setError("Enter Interest Rate");


                if(TextUtils.isEmpty(FROM_DATE))
                    ET_FROM_DATE.setError("Enter From Date");


                if(TextUtils.isEmpty(TO_DATE))
                    ET_TO_DATE.setError("Enter To Date");


            }


        });
        TV_RESET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();
            }
        });

        /*try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/

        return view;
    }

    private void CheckTexTCondtions(final EditText editText)
    {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().length() == 1 && s.toString().equals("."))
                {
                    editText.setText("");
                    editText.setSelection(editText.length());
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void openCalender(final EditText editText) {


        int mYear = selected_date.get(Calendar.YEAR);
        int mMonth = selected_date.get(Calendar.MONTH);
        int mDay = selected_date.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(getContext(), android.R.style.Theme_Holo_Light_Dialog, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {


                 month = month + 1;
                editText.setText(dayOfMonth + "/" + month  + "/" + year);//+" "+"12:00:00"
                selected_date.set(year,month -1 ,dayOfMonth);
            }
        }, mYear, mMonth, mDay);


        dialog.show();
    }
    private void ToCalender(final EditText editText) {

        Calendar cal= Calendar.getInstance();
        int mYear = cal.get(Calendar.YEAR);
        int mMonth = cal.get(Calendar.MONTH);
        int mDay = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(getContext(), android.R.style.Theme_Holo_Light_Dialog, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                editText.setText(dayOfMonth + "/" + month + "/" + year);//+" "+"12:00:00"
                //  selected_date.set(year,month - 1 ,dayOfMonth);
            }
        }, mYear, mMonth, mDay);
        dialog.show();
    }


    private void simpleIntrest(String... strings) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        try {
            double principle = Double.valueOf(strings[0]);
            double rate = Double.valueOf(strings[1]);
            int n = 0;


            rate = rate / 100;
            Date date1 = simpleDateFormat.parse(strings[2] + " 00:00:00");
            Date date2 = simpleDateFormat.parse(strings[3] + " 00:00:00");

            String diff = printDifference(date1, date2);
            if(!TextUtils.isEmpty(diff))
            {
                double time = Double.valueOf(diff);

                String duration = String.valueOf(time);
                if (strings[4].equals("Monthly")) {

                    time = time * 0.0328767;
                    time = time / 12;
                    n = 12;
                }
                else if(strings[4].equals("Quarterly"))
                {
                    time = time * 0.0328767;
                    time = time / 12;
                    n = 4;
                }
                else if(strings[4].equals("Half Yearly"))
                {
                    time = time * 0.0328767;
                    time = time / 12;
                    n = 2;
                }
                else if(strings[4].equals("Yearly"))
                {
                    time = time * 0.0328767;
                    time = time / 12;
                    n = 1;
                }

                double ans1 = n * time;
                double ans2 = rate / n;
                // ans2 = Math.round(ans2 * 100000d) / 100000d;
                double ans3 = 1 + ans2;
             //   ans3 = Math.round(ans3 * 10000d) / 10000d;
                double ans4 = Math.pow(ans3, ans1);
                //  ans4 = Math.round(ans4 * 1000d) / 1000d;
                double ans5 = principle * ans4;
             //   ans5 = Math.round(ans5 * 100d) / 100d;

                setDetails(strings[0], String.valueOf(ans5), TotalDetails(date1, date2), strings[1], strings[4]);
            }
            else
            {

            }




        } catch (ParseException e) {
            e.printStackTrace();
        }


    }


    private String printDifference(Date startDate, Date endDate) {

        String dayes = "";

        if(!startDate.after(endDate))
        {
            String start_year = startDate.toString().substring(Math.max(startDate.toString().length() - 4, 0));
            String end_year = endDate.toString().substring(Math.max(endDate.toString().length() - 4, 0));
            int sy = Integer.parseInt(start_year);
            long different = endDate.getTime() - startDate.getTime();

            long secondsInMilli = 1000;
            long minutesInMilli = secondsInMilli * 60;
            long hoursInMilli = minutesInMilli * 60;
            long daysInMilli = hoursInMilli * 24;


            long elapsedDays = different / daysInMilli;
            different = different % daysInMilli;

            long elapsedHours = different / hoursInMilli;
            different = different % hoursInMilli;

            long elapsedMinutes = different / minutesInMilli;
            different = different % minutesInMilli;

            long elapsedSeconds = different / secondsInMilli;



            int total = (int) elapsedDays;
            if (elapsedDays < 365) {
                for (int i = 0; i < 12; i++) {
                    if (total >= 30) {
                        total = total - 30;

                    }
                }

            }

            int n= 0;

            for (int i = 0; i < 4 ; i++) {

                if(isLeapYear(sy))
                    break;

                sy++;
                n++;

            }

            dayes = String.valueOf((elapsedDays - ((n+(((Integer.parseInt(end_year) - Integer.parseInt(start_year) - n) /4)) - 1))));
            return dayes;
        }
        else
        {
            ET_TO_DATE.setError("Set valid To Date");
            Toast.makeText(getActivity(), "Enter Valid Date", Toast.LENGTH_SHORT).show();
            return "";
        }

    }

    private String TotalDetails(Date startDate, Date endDate) throws ParseException {
        Calendar cal_start = Calendar.getInstance();
        Calendar cal_end = Calendar.getInstance();
        cal_start.setTime(startDate);
        cal_end.setTime(endDate);
        long different = endDate.getTime() - startDate.getTime();
        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;


        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;

        long elapsedSeconds = different / secondsInMilli;


        int total = (int) elapsedDays;


        if (cal_start.get(Calendar.YEAR) == cal_end.get(Calendar.YEAR)) {
            if (cal_start.get(Calendar.MONTH) == cal_end.get(Calendar.MONTH)) {
                return String.valueOf(total);
            } else if (cal_start.get(Calendar.MONTH) < cal_end.get(Calendar.MONTH)) {
                for (int i = cal_start.get(Calendar.MONTH) + 1; i <= cal_end.get(Calendar.MONTH) + 1; i++) {

                    if (i == 2) {
                        if (isLeapYear(cal_start.get(Calendar.YEAR))) {
                            total = total + 1;
                        } else {
                            total = total + 2;
                        }
                    }

                    if (i % 2 != 0 && i != 2) {
                        total = total - 1;
                    }

                }

                return String.valueOf(total);

            }


        } else if (cal_start.get(Calendar.YEAR) < cal_end.get(Calendar.YEAR)) {

            Calendar c = Calendar.getInstance();
            int monthMaxDays = cal_start.getActualMaximum(Calendar.DAY_OF_MONTH);

            int SY = cal_start.get(Calendar.YEAR);
            int EY = cal_end.get(Calendar.YEAR);


            for (int i = SY; i <= EY; i++) {

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/M/yyyy hh:mm:ss");
                Date date1 = simpleDateFormat.parse("10/8/" + i + " 00:00:00");
                Calendar d1_d = Calendar.getInstance();
                d1_d.setTime(date1);

                if (isLeapYear(i)) {
                    int start = 1;
                    if (i == SY)
                        start = cal_start.get(Calendar.MONTH) + 1;
                    int end_date = 12;
                    if (i == EY)
                        end_date = cal_end.get(Calendar.MONTH);

                    for (int j = start; j <= end_date; j++) {

                        if (checkMonth(j) == 31) {
                            total = total ;
                        } else if (checkMonth(j) == 28) {
                            total = total ;
                        }

                    }

                } else {

                    if(total == 365)
                    {
                        return String.valueOf(total);
                    }
                    int start = 1;
                    if (i == SY)
                        start = cal_start.get(Calendar.MONTH) + 1;


                    int end_date = 12;
                    if (i == EY)
                        end_date = cal_end.get(Calendar.MONTH);


                    for (int j = start; j <= end_date; j++) {

                        if (checkMonth(j) == 31) {
                            total = total;
                        } else if (checkMonth(j) == 28) {
                            total = total;
                        }

                    }
                }

            }

            total = total - 1;

            return String.valueOf(total);
        } else {
            return String.valueOf(total);
        }


        return String.valueOf(total);

    }

    private void setDetails(String... str) {
        double period = Double.valueOf(str[2]);
        int duration = (int) period;
        double intrest_rs =  Math.round((Double.valueOf(str[1]) - Double.valueOf(str[0])) * 100d) / 100d;
        double total_itr = Math.round((Double.valueOf(str[1])) * 100d) / 100d;

        TV_PRINCIPLE_DTL.setText(str[0]);
      //  TV_INTREST_DTL.setText(intrest_rs+ "");
        TV_PERIOD_DTL.setText(details(duration));
      //  TV_TOTAL_DTL.setText(total_itr+"");
        TV_INTREST_PER.setText(str[3] + "%  " + str[4]);
        linearLayout.setVisibility(View.VISIBLE);

        TV_INTREST_DTL.setText(String.format("%.2f",intrest_rs));

        TV_TOTAL_DTL.setText(String.format("%.2f",total_itr));


    }

    private String details(int day) {
        String duretion = "";

        long l = day;
        int months = 0;
        long diffInMilliSec = TimeUnit.DAYS.toMillis(l);
        long seconds = (diffInMilliSec / 1000) % 60;
        long minutes = (diffInMilliSec / (1000 * 60)) % 60;
        long hours = (diffInMilliSec / (1000 * 60 * 60)) % 24;
        long days = (diffInMilliSec / (1000 * 60 * 60 * 24)) % 365;
        long years = (diffInMilliSec / (1000l * 60 * 60 * 24 * 365));


        int total = (int) days;
        if (days < 365) {
            for (int i = 0; i < 12; i++) {
                if (total >= 30) {
                    total = total - 30;
                    months = months + 1;
                }
            }

            if(total >= 28)
            {
                months = months + 1;
                total = 0;

            }

            if (years > 0) {
                return duretion = years + " Years " + months + " Months \n" + total + " Days ";
            } else if (months > 0) {
                return duretion = months + " Months " + total + " Days ";
            } else if (total > 0) {
                return duretion = total + " Days ";
            } else {
                duretion = total + " Days ";
            }

        }

        return duretion = days + " Days ";
    }

    private void reset()
    {
        Calendar c = Calendar.getInstance();
        selected_date.set(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));

        ET_PRINCIPLE.setError(null);
        ET_RATE.setError(null);
        ET_FROM_DATE.setError(null);
        ET_TO_DATE.setError(null);


        ET_PRINCIPLE.setText("");
        ET_RATE.setText("");
        ET_FROM_DATE.setText("");
        ET_TO_DATE.setText("");

        TV_PRINCIPLE_DTL.setText("");
        TV_INTREST_DTL.setText("");
        TV_PERIOD_DTL.setText("");
        TV_TOTAL_DTL.setText("");
        TV_INTREST_PER.setText("");
        linearLayout.setVisibility(View.INVISIBLE);
    }

    private int checkMonth(int month) {

        switch (month) {
            case 1:
                return 31;
            case 2:
                return 28;
            case 3:
                return 31;
            case 4:
                return 30;
            case 5:
                return 31;
            case 6:
                return 30;
            case 7:
                return 31;
            case 8:
                return 31;
            case 9:
                return 30;
            case 10:
                return 31;
            case 11:
                return 30;
            case 12:
                return 31;


        }

        return 0;
    }

}
