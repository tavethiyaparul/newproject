package com.divinesoftech.calculator.mongodb;

public interface OnResponseData {
    void onResponse();

    void onFailed();
}