package com.divinesoftech.calculator.Common

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.widget.RelativeLayout
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle.Event.ON_RESUME
import androidx.lifecycle.Lifecycle.Event.ON_START
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import com.bumptech.glide.Glide
import com.divinesoftech.calculator.Activities.SplashActivity
import com.divinesoftech.calculator.BuildConfig
import com.divinesoftech.calculator.Classes.GstApp.context
import com.divinesoftech.calculator.Classes.GstApp.currentActivity
import com.divinesoftech.calculator.Common.Utilty.*
import com.divinesoftech.calculator.CustomAd.callback.AdsLoaded
import com.divinesoftech.calculator.CustomAd.callback.appOpenCallback
import com.divinesoftech.calculator.R
import com.divinesoftech.calculator.database.*
import com.divinesoftech.calculator.database.room.RoomAdvertisement
import com.divinesoftech.isPrime
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import kotlinx.android.synthetic.main.gst_custom_banner_ads.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*


class AppOpenManager : LifecycleObserver {
    init {
        //activity.registerActivityLifecycleCallbacks(this)
        try {
            ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        } catch (e: RuntimeException) {
        }

    }

    public var isShowingAd = false
    public val TAG = "AppOpenManager"
    public var appOpenAd: AppOpenAd? = null
    public var loadCallback: AppOpenAd.AppOpenAdLoadCallback? = null
    public var loadTime: Long = 0
    public var ischeckcustomshow = false


    /** LifecycleObserver methods  */
    @OnLifecycleEvent(ON_RESUME)
    fun onStart() {
        try {
            if (currentActivity is SplashActivity) {

            } else {
                if (!isPrime() && isAdsLibsLoad()) {
                    showAdIfAvailable()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }


    /** Request an ad  */
    public fun fetchAd(type: ArrayList<String>) {
        if (isAdAvailable()) {
            return
        }
        loadAds(type)
    }

    public fun loadAds(type: ArrayList<String>) {
        CoroutineScope(Dispatchers.Main).launch {
            if (type.size > 0) {
                when (type[0]) {

                    NO_DATA_FOUND -> {
                    }

                    GOOGLE_AD -> {
                        //Log.e("type[1]", "${type[0]} ${type[1]}")
                        val request = getAdRequest()
                        AppOpenAd.load(context,
                            if (BuildConfig.DEBUG) "/6499/example/app-open" else type[1],
                            request!!,
                            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                            object : AppOpenAd.AppOpenAdLoadCallback() {

                                override fun onAdLoaded(ad: AppOpenAd) {
                                    super.onAdLoaded(ad)
                                    deleteRecord(APP_OPEN)
                                    appOpenAd = ad
                                    loadTime = Date().time

                                }

                                override fun onAdFailedToLoad(p0: LoadAdError) {
                                    super.onAdFailedToLoad(p0)

                                    loadAds(
                                        context.adsFailToLoads(APP_OPEN)
                                    )
                                }
                            })
                    }

                    CUSTOM_AD -> {

                    }
                }
            }
        }
    }

    /** Creates and returns ad request.  */
    public fun getAdRequest(): AdRequest? {
        return AdRequest.Builder().build()
    }

    /** Utility method that checks if ad exists and can be shown.  */
    public fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4);
    }

    /** Utility method to check if ad was loaded more than n hours ago.  */
    public fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference = Date().time - loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * numHours
    }


    private fun showAdIfAvailable() {

        if (!isPrime() && isAdsLibsLoad()) {
            if (currentActivity != null && !isShowingAd && isAdAvailable()) {

                val fullScreenContentCallback: FullScreenContentCallback =
                    object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            appOpenAd = null
                            isShowingAd = false
                            fetchAd(context.builderAds(APP_OPEN))
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {

                        }

                        override fun onAdShowedFullScreenContent() {
                            isShowingAd = true
                        }
                    }
                when {
                    currentActivity is SplashActivity -> Log.e(
                        TAG, "----------------- *** for splash ads *** -----------------"
                    )

                    isClickGames -> {
                        isClickGames = false
                    }

                    else -> {
                        appOpenAd?.show(currentActivity)
                        appOpenAd?.fullScreenContentCallback = fullScreenContentCallback
                    }
                }
            } else {
                fetchAd(context.builderAds(APP_OPEN))
            }
        }
    }
}