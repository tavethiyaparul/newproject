package com.divinesoftech.calculator.database.room

import android.content.Context
import androidx.room.*
import com.divinesoftech.calculator.database.RoomConnection
import com.divinesoftech.calculator.database.room.dao.*

var DB_NAME = "gst_room.db"

@JvmField
var instances: RoomDatabaseGst? = null

@Database(
    entities = arrayOf(
        RoomVersion::class,
        RoomSku::class,
        RoomAdsChild::class,
        RoomAdsLoaded::class,
        RoomAdvertisement::class,
        RoomTags::class,
        RoomConnection::class,
        RoomMainAdRecords::class,
        RoomOrder::class,
        RoomRecords::class,
        RoomGame::class
    ),
    exportSchema = false,
    version = 4
)
@TypeConverters(Converters::class)
abstract class RoomDatabaseGst : RoomDatabase() {
    companion object {
        fun getInstance(context: Context): RoomDatabaseGst? {
            if (instances == null) {
                instances = Room.databaseBuilder(context, RoomDatabaseGst::class.java, DB_NAME)
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build()
            }
            return instances
        }
    }

    abstract fun versionDao(): RoomVersionDao
    abstract fun skuDao(): RoomSkuDao
    abstract fun roomAdsLoadedDao(): RoomAdsLoadedDao
    abstract fun roomAdvertisementDao(): RoomAdvertisementDao
    abstract fun roomTagsDao(): RoomTagsDao
    abstract fun roomGamesDao(): RoomGameDao
    abstract fun roomConnectionDao(): RoomConnectionDao
    abstract fun roomOrderDao(): RoomOrderDao
    abstract fun roomRoomRecords(): RoomRecordsDao
    abstract fun roomRoomMainAd(): RoomMainAd
}