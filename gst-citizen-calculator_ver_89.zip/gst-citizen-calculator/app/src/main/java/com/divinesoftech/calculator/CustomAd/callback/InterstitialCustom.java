package com.divinesoftech.calculator.CustomAd.callback;

import android.app.Dialog;

public interface InterstitialCustom {
    void onInterstitialCustomClose();

    void onInterstitialCustomLoaded(Dialog dialog);

    void onInterstitialCustomFailed();

    void onAdsClick(String cadid);
}
