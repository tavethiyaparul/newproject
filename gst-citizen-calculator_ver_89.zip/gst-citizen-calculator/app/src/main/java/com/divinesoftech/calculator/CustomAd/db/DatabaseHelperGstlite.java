package com.divinesoftech.calculator.CustomAd.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelperGstlite extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "citizenlite.db";
    public static final String TABLE_RESPONSE = "response";
    public static final String ID = "id";
    public static final String RESPONSE = "store_response";

    public static final String CREATE_TABLE_RESPONSE = "CREATE TABLE " + TABLE_RESPONSE
            + "(" + ID + " INTEGER  PRIMARY KEY NOT NULL, "
            + RESPONSE + " TEXT" + ")";

    public DatabaseHelperGstlite(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_RESPONSE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESPONSE);
    }


    public void setResponse(String ids, String value, String isUpdate) throws SQLiteException {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ID, ids);
        cv.put(RESPONSE, value);
        if (isUpdate.equals("true")) {
            db.update(TABLE_RESPONSE, cv, ID + "= ?", new String[]{ids});
        } else {
            db.insert(TABLE_RESPONSE, null, cv);
        }
        db.close();
    }

    public String getResponse(String ids) {
        String response = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor rawQuery = db.rawQuery("SELECT " + RESPONSE + " FROM " + TABLE_RESPONSE + " WHERE " + ID + " = ?",
                new String[]{ids});

        if (rawQuery.moveToFirst()) {
            do {
                response = rawQuery.getString(rawQuery.getColumnIndex(RESPONSE));
            }
            while (rawQuery.moveToNext());
        }
        rawQuery.close();
        db.close();
        return response;
    }
}
