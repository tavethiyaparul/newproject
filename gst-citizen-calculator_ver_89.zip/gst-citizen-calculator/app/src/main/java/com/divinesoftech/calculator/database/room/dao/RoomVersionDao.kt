package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomVersion

@Dao
interface RoomVersionDao {
    @Query("Select * from RoomVersion where placement_name=:name and enable=:enable")
    fun getVersionData(name: String, enable: Int): RoomVersion

    @Query("Select * from RoomVersion where placement_name=:name")
    fun getAdsAvailable(name: String): RoomVersion?

    @Query("Select enable from RoomVersion where placement_name=:name")
    fun adsEnable(name: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertVersionData(roomVersion: RoomVersion)

    @Update
    fun updateVersionData(roomVersion: RoomVersion)

    @Delete
    fun deleteVersionData(roomVersion: RoomVersion)
}