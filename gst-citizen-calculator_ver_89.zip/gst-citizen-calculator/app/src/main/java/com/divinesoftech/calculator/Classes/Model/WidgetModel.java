package com.divinesoftech.calculator.Classes.Model;

import java.io.Serializable;

public class WidgetModel implements Serializable {

    String fromCountry;
    String toCountry;
    String fromAmount;
    String toAmount;
    String from_shared_label;
    String to_shared_label;
    String from_country_name;
    String to_country_name;

    public String getFrom_country_name() {
        return from_country_name;
    }

    public void setFrom_country_name(String from_country_name) {
        this.from_country_name = from_country_name;
    }

    public String getTo_country_name() {
        return to_country_name;
    }

    public void setTo_country_name(String to_country_name) {
        this.to_country_name = to_country_name;
    }

    public String getFrom_shared_label() {
        return from_shared_label;
    }

    public void setFrom_shared_label(String from_shared_label) {
        this.from_shared_label = from_shared_label;
    }

    public String getTo_shared_label() {
        return to_shared_label;
    }

    public void setTo_shared_label(String to_shared_label) {
        this.to_shared_label = to_shared_label;
    }



    public String getFromCountry() {
        return fromCountry;
    }

    public void setFromCountry(String fromCountry) {
        this.fromCountry = fromCountry;
    }

    public String getToCountry() {
        return toCountry;
    }

    public void setToCountry(String toCountry) {
        this.toCountry = toCountry;
    }

    public String getFromAmount() {
        return fromAmount;
    }

    public void setFromAmount(String fromAmount) {
        this.fromAmount = fromAmount;
    }

    public String getToAmount() {
        return toAmount;
    }

    public void setToAmount(String toAmount) {
        this.toAmount = toAmount;
    }
}
