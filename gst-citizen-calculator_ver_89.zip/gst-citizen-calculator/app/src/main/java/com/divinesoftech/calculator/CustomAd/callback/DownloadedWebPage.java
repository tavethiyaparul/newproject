package com.divinesoftech.calculator.CustomAd.callback;

public interface DownloadedWebPage {
    void onSuccess();
    void onFailed();
}
