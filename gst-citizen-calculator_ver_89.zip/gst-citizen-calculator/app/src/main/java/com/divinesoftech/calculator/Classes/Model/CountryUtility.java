package com.divinesoftech.calculator.Classes.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CountryUtility implements Serializable
{
    @SerializedName("currancy")
    private Currancy currancy;

    public Currancy getCurrancy ()
    {
        return currancy;
    }

    public void setCurrancy (Currancy currancy)
    {
        this.currancy = currancy;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [currancy = "+currancy+"]";
    }
}

