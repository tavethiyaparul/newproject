package com.divinesoftech.calculator.Activities


import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.divinesoftech.calculator.Adapter.SlidingImageAdapter
import com.divinesoftech.calculator.Classes.GstApp
import com.divinesoftech.calculator.Classes.THEME_NUMBER
import com.divinesoftech.calculator.Common.OnSetTheme
import com.divinesoftech.calculator.R
import kotlinx.android.synthetic.main.custom_actionbar.view.*
import kotlinx.android.synthetic.main.theme_select.*

public class SelectTheme : AppCompatActivity() {
    lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GstApp.currentActivity = this
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.theme_select)
        sharedPref = getSharedPreferences("change_view", Context.MODE_PRIVATE)


        var ThemeList = arrayOf(
            resources.getDrawable(R.drawable.simple_calculator, null),
            resources.getDrawable(R.drawable.citizen_calculator, null),
            resources.getDrawable(R.drawable.gst_calculator, null),
            resources.getDrawable(R.drawable.gst_citizen_calculator, null)
        )
        var ThemeName = arrayOf(
            "Simple Calculator",
            "Citizen Calculator",
            "GST Calculator",
            "GST & Citizen Calculator"
        )


        var adapter =
            SlidingImageAdapter(this@SelectTheme, ThemeList, ThemeName, object : OnSetTheme {
                override fun setTheme(pos: Int) {


                }
            })
        View_Pager.adapter = adapter
        View_Pager.currentItem = sharedPref.getInt("view_type", 0)

        if (View_Pager.currentItem == 0)
            btn_Prev.visibility = View.GONE
        else
            btn_Prev.visibility = View.VISIBLE

        if (View_Pager.currentItem == (ThemeList.size - 1))
            btn_Next.visibility = View.GONE
        else
            btn_Next.visibility = View.VISIBLE


        View_Pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {}
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                if (position == 0)
                    btn_Prev.visibility = View.GONE
                else
                    btn_Prev.visibility = View.VISIBLE

                if (position == (ThemeList.size - 1))
                    btn_Next.visibility = View.GONE
                else
                    btn_Next.visibility = View.VISIBLE


            }
        })

        BtnApplyTheme.setOnClickListener {

            var editor = sharedPref.edit()
            THEME_NUMBER = View_Pager.currentItem
            editor.putInt("view_type", View_Pager.currentItem)
            editor.apply()
            startActivity(Intent(this@SelectTheme, MainActivity::class.java))
            finish()
            Toast.makeText(this@SelectTheme, "Theme Changed Successfully", Toast.LENGTH_SHORT)
                .show()

        }

        btn_Prev.setOnClickListener(View.OnClickListener {

            if (View_Pager.currentItem != 0)
                View_Pager.currentItem = View_Pager.currentItem - 1


        })
        btn_Next.setOnClickListener(View.OnClickListener {

            if (View_Pager.currentItem > -1 && View_Pager.currentItem != (ThemeList.size - 1))
                View_Pager.currentItem = View_Pager.currentItem + 1

        })

    }
}