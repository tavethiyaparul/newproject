package com.divinesoftech.calculator.Classes

import android.util.Log
import com.divinesoftech.calculator.BuildConfig

object LogUtils {

  open fun setLog(vararg str: String) {
        if (BuildConfig.DEBUG)
            Log.e(str[0], "------------> ")
    }

}