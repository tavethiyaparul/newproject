package com.divinesoftech.calculator.ads;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Chield implements Serializable
{
    @SerializedName("AD_ID")
    private String AD_ID;

    @SerializedName("AD_KEYWORD")
    private String AD_KEYWORD;

    public String getAD_ID ()
    {
        return AD_ID;
    }

    public void setAD_ID (String AD_ID)
    {
        this.AD_ID = AD_ID;
    }

    public String getAD_KEYWORD ()
    {
        return AD_KEYWORD;
    }

    public void setAD_KEYWORD (String AD_KEYWORD)
    {
        this.AD_KEYWORD = AD_KEYWORD;
    }


}