

package com.divinesoftech.calculator.Adapter;

import android.graphics.pdf.PdfRenderer;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.divinesoftech.calculator.R;

import java.io.IOException;

public class PageAdapter extends RecyclerView.Adapter<PageController> {
  private final LayoutInflater inflater;
  private final PdfRenderer renderer;

  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  public PageAdapter(LayoutInflater inflater, ParcelFileDescriptor pfd)
    throws IOException {
    this.inflater=inflater;
    renderer=new PdfRenderer(pfd);
  }

  @Override
  public PageController onCreateViewHolder(ViewGroup parent, int viewType) {
    return(new PageController(inflater.inflate(R.layout.page, parent, false)));
  }

  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  @Override
  public void onBindViewHolder(PageController holder, int position) {
    PdfRenderer.Page page=renderer.openPage(position);

    holder.setPage(page);
    page.close();
  }

  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  @Override
  public int getItemCount() {
    return(renderer.getPageCount());
  }

  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  public void close() {
    renderer.close();
  }
}
