package com.divinesoftech.calculator.Activities;

import static com.divinesoftech.SocketKt.bannerInlineAdaptiveAds;
import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;
import static com.divinesoftech.calculator.Common.Utilty.ADAPTIVE_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.BACKUP_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.COMMON_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.CUSTOM_AD;
import static com.divinesoftech.calculator.Common.Utilty.GAME_AD;
import static com.divinesoftech.calculator.Common.Utilty.GOOGLE_AD;
import static com.divinesoftech.calculator.Common.Utilty.IS_ADFREE;
import static com.divinesoftech.calculator.Common.Utilty.isNetworkAvailable;
import static com.divinesoftech.calculator.Common.Utilty.is_history_button;
import static com.divinesoftech.calculator.Fragments.GSTCalculator.historylog_list;
import static com.divinesoftech.calculator.database.ApiKt.builderAds;
import static com.divinesoftech.calculator.database.ApiKt.isAdsLibsLoad;
import static com.divinesoftech.calculator.database.ApiKt.showCustomBanner;
import static com.divinesoftech.calculator.database.ApiKt.showGameBanner;
import static com.divinesoftech.calculator.database.room.RoomDatabaseGstKt.instances;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.divinesoftech.calculator.Classes.HistoryData;
import com.divinesoftech.calculator.Common.Utilty;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.AdsFailToLoad;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.divinesoftech.calculator.database.room.RoomVersion;
import com.google.android.gms.ads.AdRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;

public class HistoryActivity extends AppCompatActivity {

    ArrayList<Double> operandArray;
    ArrayList<Character> operatorArray;
    ArrayList<Double> resultArray;


    int isAdlodstate = 0;
    int intval;

    SimpleAdapter sa;
    transient
    DecimalFormat df;


    RecyclerView list_recycle;
    RecyclerView.LayoutManager layoutManager;
    ListAdepters listAdepters;
    RelativeLayout no_history_msg, ad;

    AdRequest adRequest;
    SharedPreferences preferences;

    SharedPreferences sharedPreferences;
    TextView ActionBarTitle;
    AppCompatImageView removeAll;
    FrameLayout frameLayout;
    RelativeLayout ad_layout;
    LinearLayout google_layout;
    DatabaseGst databaseGst;
    SharedPreferences mPrefs;

    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);

        setContentView(R.layout.activity_history);
        currentActivity = this;
//        GSTCalculator.isCheckHistoryClick = false;

        mPrefs = getSharedPreferences("myVal", MODE_PRIVATE);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        preferences = getSharedPreferences("update", MODE_PRIVATE);
        databaseGst = new DatabaseGst(HistoryActivity.this);
        ad_layout = findViewById(R.id.ad_layout);
        google_layout = findViewById(R.id.google_layout);
        is_history_button = false;
        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = v.findViewById(R.id.action_bar_title);
        removeAll = v.findViewById(R.id.removeAll);

        getSupportActionBar().setCustomView(v);
        ActionBarTitle.setText("History");
        // v.findViewById(R.id.gift_layout).setVisibility(View.GONE);
        list_recycle = findViewById(R.id.dailog_recycleview);
        no_history_msg = findViewById(R.id.no_history);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        list_recycle.setLayoutManager(layoutManager);

        Gson gson = new Gson();
        String json = mPrefs.getString("MyObject", "");


        if (json != "") {
            Type listOfHistoryType = new TypeToken<List<HistoryData>>() {
            }.getType();
            ArrayList<HistoryData> myhistory = gson.fromJson(json, listOfHistoryType);


            removeAll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    AlertDialog.Builder builder
                            = new AlertDialog
                            .Builder(HistoryActivity.this);

                    // Set the message show for the Alert time
                    builder.setMessage("Are you sure want to clear History?");

                    // Set Alert Title
                    builder.setTitle("Clear History !");

                    // Set Cancelable false
                    // for when the user clicks on the outside
                    // the Dialog Box then it will remain show
                    builder.setCancelable(false);

                    // Set the positive button with yes name
                    // OnClickListener method is use of
                    // DialogInterface interface.

                    builder
                            .setPositiveButton(
                                    "Yes",
                                    new DialogInterface
                                            .OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                            // When the user click yes button
                                            // then app will close
                                            myhistory.clear();
                                            historylog_list.clear();

                                            removeAll.setVisibility(View.GONE);
                                            no_history_msg.setVisibility(View.VISIBLE);

                                            SharedPreferences.Editor editor = mPrefs.edit();
                                            editor.clear();
                                            editor.commit();
                                            listAdepters.notifyDataSetChanged();
                                            no_history_msg.setVisibility(View.VISIBLE);
                                        }
                                    });

                    // Set the Negative button with No name
                    // OnClickListener method is use
                    // of DialogInterface interface.
                    builder
                            .setNegativeButton(
                                    "No",
                                    new DialogInterface
                                            .OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog,
                                                            int which) {

                                            // If user click no
                                            // then dialog box is canceled.
                                            dialog.cancel();
                                        }
                                    });

                    // Create the Alert dialog
                    AlertDialog alertDialog = builder.create();

                    // Show the Alert Dialog box
                    alertDialog.show();


                }
            });


            if (myhistory != null) {
                removeAll.setVisibility(View.VISIBLE);

                listAdepters = new ListAdepters(HistoryActivity.this, myhistory);
                list_recycle.setAdapter(listAdepters);

            } else {
                removeAll.setVisibility(View.GONE);
//            Toast.makeText(this, "History not found", Toast.LENGTH_LONG).show();
                no_history_msg.setVisibility(View.VISIBLE);
            }

        } else {
            removeAll.setVisibility(View.GONE);
//            Toast.makeText(this, "History not found", Toast.LENGTH_LONG).show();
            no_history_msg.setVisibility(View.VISIBLE);
        }

//        historylog_list.clear();
//        historylog_list.add(obj);


        if (isNetworkAvailable(HistoryActivity.this) && !databaseGst.getResponse(IS_ADFREE).equals("YES") && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
        }
    }


    public class ListAdepters extends RecyclerView.Adapter<ListAdepters.ListHolder> {
        Context context;

        List<HistoryData> datalist;


        public ListAdepters(Context context, List<HistoryData> datalist) {
            this.context = context;
            this.datalist = datalist;

        }


        @Override
        public ListHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            view = layoutInflater.inflate(R.layout.recycle_item_new, null);

            return new ListHolder(view);
        }

        @Override
        public void onBindViewHolder(final ListHolder holder, int position) {


//            holder.textOprand.setText(datalist.get(position).getFirst_oprand());
            holder.textOprand.setText(datalist.get(position).getFirst_oprand());
            holder.whatsaap.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PackageManager pm = getPackageManager();

                    try {
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        PackageInfo info = pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);
                        intent.setPackage("com.whatsapp");
                        intent.putExtra(Intent.EXTRA_TEXT, holder.textOprand.getText().toString());

                        startActivity(intent);

                    } catch (PackageManager.NameNotFoundException e) {


                        Toast.makeText(getApplicationContext(), "Whatsapp is not installed", Toast.LENGTH_SHORT).show();

                    }
                }
            });

            holder.share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String shareBody = holder.textOprand.getText().toString();
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "Share With:"));

                }
            });


        }

        @Override
        public int getItemCount() {
            return datalist.size();
        }

        class ListHolder extends RecyclerView.ViewHolder {

            TextView textOprand, textOprator, textResult;
            ImageView whatsaap, share;

            public ListHolder(View itemView) {
                super(itemView);
                textOprand = itemView.findViewById(R.id.operandTextView);
                whatsaap = itemView.findViewById(R.id.whatsaap);
                share = itemView.findViewById(R.id.share);


            }
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();

    }


    void AdsLoadings() {
        RoomVersion roomVersion = instances.versionDao().getAdsAvailable(COMMON_BANNER);
        if (roomVersion == null) {
            bannerInlineAdaptiveAds(this, google_layout, BACKUP_BANNER, () -> {
                showCustomBanner(google_layout);
                return null;
            });
        } else {
            ArrayList<String> type = builderAds(this, COMMON_BANNER);
            if (type.size() > 0) {
                switch (type.get(0)) {
                    case GOOGLE_AD:
                        new Utilty().GoogleBannerAdvance(false, HistoryActivity.this, type.get(1), google_layout, new AdsFailToLoad() {
                            @Override
                            public void onFailed() {
                                showCustomBanner(google_layout);
                            }
                        });
                        break;

                    case ADAPTIVE_BANNER:
                        bannerInlineAdaptiveAds(this, google_layout, type.get(1), new Function0<Unit>() {
                            @Override
                            public Unit invoke() {
                                showCustomBanner(google_layout);
                                return null;
                            }
                        });
                        break;
                    case CUSTOM_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        showCustomBanner(google_layout);
                        break;

                    case GAME_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        showGameBanner(google_layout);
                        break;
                }
            }
        }
    }


}
