package com.divinesoftech.calculator.Fragments;

import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.calculator.Common.Utilty.hideSoftKeyboard;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.Adapter.ViewPagerAdapter;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.google.android.material.tabs.TabLayout;

public class IntrestCalculator extends Fragment {
    View view;
    TabLayout tabLayout;
    ViewPager viewPager;
    ViewPagerAdapter adapter;
    FrameLayout frameLayout;
    SharedPreferences preferences;
    RelativeLayout ad_layout;
//    LinearLayout google_layout;
    DatabaseGst databaseGst;

    public IntrestCalculator() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.intrest_calculator, container, false);
        setHasOptionsMenu(true);
        try {
            databaseGst = ((MainActivity) requireActivity()).databaseGst;

        } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //  ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Interest Calculator");
        // frameLayout =(FrameLayout)view.findViewById(R.id.fl_adplaceholder_intr);
        tabLayout = view.findViewById(R.id.intrest_tabs);
        viewPager = view.findViewById(R.id.intrest_view_pager);
        addTabs(viewPager);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#FFFFFF"));
        preferences = getActivity().getSharedPreferences("update", MODE_PRIVATE);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                hideSoftKeyboard(viewPager);

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        ad_layout = view.findViewById(R.id.ad_layout);
//        google_layout = view.findViewById(R.id.google_layout);

        /*if (isNetworkAvailable(getActivity()) && !isPrime() && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
            //((MainActivity)getActivity()).Game_btn.setVisibility(View.GONE);
        }*/

        /*try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/

        return view;
    }

    private void addTabs(ViewPager viewPager) {
        FragmentManager childFragMan = getChildFragmentManager();

        adapter = new ViewPagerAdapter(childFragMan);
        adapter.addFrag(new SimpleIntrest(), getResources().getString(R.string.simple));
        adapter.addFrag(new CompoundIntrest(), getResources().getString(R.string.compound));
        // setCustomFont();
        viewPager.setAdapter(adapter);
    }


/*
    void AdsLoadings() {
        ArrayList<String> type = builderAds(requireContext(), COMMON_BANNER);
        if (type.size() > 0) {

            switch (type.get(0)) {
                case GOOGLE_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    new Utilty().GoogleBannerAdvance(requireActivity(), type.get(1), google_layout, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;


                case ADAPTIVE_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().GoogleAdaptiveBanner(requireActivity(), type.get(1), google_layout, false, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;
                case SMART_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().mSmartBanner(requireActivity(), type.get(1), ad_layout, google_layout);
                    break;

                case CUSTOM_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showCustomBanner(google_layout);
                    break;

               case GAME_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showGameBanner(google_layout);
                    break;
            }
        }
    }
*/


}
