package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class RoomAdvertisement {
    @PrimaryKey
    var ID: String = ""
    var ADDDESCD: String = ""
    var ADDTITLE: String = ""
    var CUSTOMMULTI: String = ""
    var BANNER: String = ""
    var COLOR: String = ""
    var DATE: String = ""
    var DESIGNPAGE: String = ""
    var DOWNLOAD: String = ""
    var ENABLE: Int = 0
    var ICON: String = ""
    var INSTALL: String = ""
    var RATING: String = ""
    var REVIEW: String = ""
}