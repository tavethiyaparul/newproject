package com.divinesoftech.calculator.Classes.Model;

import com.google.gson.annotations.SerializedName;

public class UpdateData {

    @SerializedName("result")
    private Result result;

    @SerializedName("dataCount")
    private String dataCount;

    public Result getResult ()
    {
        return result;
    }

    public void setResult (Result result)
    {
        this.result = result;
    }

    public String getDataCount ()
    {
        return dataCount;
    }

    public void setDataCount (String dataCount)
    {
        this.dataCount = dataCount;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [result = "+result+", dataCount = "+dataCount+"]";
    }
}
