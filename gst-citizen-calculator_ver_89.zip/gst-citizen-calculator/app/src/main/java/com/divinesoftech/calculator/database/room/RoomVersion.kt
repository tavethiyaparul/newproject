package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class RoomVersion {
    @PrimaryKey
    var placement_name: String = "null"
    var count: Int = 0
    var enable: Int = 0
    var adsChild: ArrayList<RoomAdsChild> = ArrayList()
}