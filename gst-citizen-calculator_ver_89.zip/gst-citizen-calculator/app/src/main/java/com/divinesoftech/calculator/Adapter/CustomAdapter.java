package com.divinesoftech.calculator.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.divinesoftech.calculator.R;

import java.util.List;

public class CustomAdapter extends BaseAdapter {

    Context context;
    List<String> spin_list;
    LayoutInflater inflter;

    public CustomAdapter(Context context, List<String> spin_list ) {
        this.context = context;
        this.spin_list = spin_list;

        inflter = (LayoutInflater.from(context));
    }


    @Override
    public int getCount() {

       return spin_list.size();


    }

    @Override
    public Object getItem(int position) {


        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        convertView = inflter.inflate(R.layout.spinner_row_item, null);
        LinearLayout linearLayout = (LinearLayout) convertView.findViewById(R.id.selct_spin);
        TextView names = (TextView) convertView.findViewById(R.id.item_name);
        names.setText(spin_list.get(position));

        return convertView;
    }


}