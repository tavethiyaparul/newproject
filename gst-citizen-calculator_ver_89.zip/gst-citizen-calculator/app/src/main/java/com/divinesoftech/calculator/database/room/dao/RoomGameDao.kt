package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomAdsLoaded
import com.divinesoftech.calculator.database.room.RoomGame
import com.divinesoftech.calculator.database.room.RoomTags

@Dao
interface RoomGameDao {
    @Query("Select * from RoomGame order by id ASC ")
    fun getRoomGameLoaded(): List<RoomGame>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomGameLoaded(roomGame: RoomGame)

    @Update
    fun updateRoomGameLoaded(roomGame: RoomAdsLoaded)

    @Delete
    fun deleteRoomGameLoaded(roomGame: RoomAdsLoaded)
}