package com.divinesoftech.calculator.Activities

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.annotation.Nullable
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import com.divinesoftech.AB_SPLASH_BANNER
import com.divinesoftech.SOCKET_CONNECTION
import com.divinesoftech.calculator.BuildConfig
import com.divinesoftech.calculator.Classes.GstApp
import com.divinesoftech.calculator.Classes.GstApp.context
import com.divinesoftech.calculator.Common.AppOpenManager
import com.divinesoftech.calculator.JobSechedual.FULL_HISTORY
import com.divinesoftech.calculator.JobSechedual.appOpenManager
import com.divinesoftech.calculator.JobSechedual.isDeviceRootedOrEmulator
import com.divinesoftech.calculator.R
import com.divinesoftech.calculator.database.initialize
import com.divinesoftech.calculator.database.isAdsLibsLoad
import com.divinesoftech.calculator.database.room.RoomDatabaseGst
import com.divinesoftech.calculator.database.room.instances
import com.divinesoftech.calculator.database.splashBuilderAds
import com.divinesoftech.isPrime
import com.divinesoftech.splashBannerInlineAdaptiveAds
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentDebugSettings
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.FormError
import com.google.android.ump.UserMessagingPlatform
import kotlinx.android.synthetic.main.activity_splash.adsContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.system.exitProcess


@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private var consentInformation: ConsentInformation? = null
    private val isMobileAdsInitializeCalled = AtomicBoolean(false)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            window.decorView.systemUiVisibility =
                (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        } catch (e: NullPointerException) {
            e.printStackTrace()
        }
        instances = RoomDatabaseGst.getInstance(this@SplashActivity)
        System.gc()
        GstApp.currentActivity = this
        context = this@SplashActivity
        setContentView(R.layout.activity_splash)
        if (java.lang.Boolean.parseBoolean(BuildConfig.TEST_MODE)) {
            callMainApp()
        } else {
            if (isDeviceRootedOrEmulator()) {
                showDevDialog()
            } else {
                val developerOptions = Settings.Secure.getInt(
                    contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0
                )
                if (developerOptions == 1) {
                    showDevDialog()
                } else callMainApp()
            }
        }
    }

    private fun callMainApp() {
        CoroutineScope(Dispatchers.Main).launch {
            if (!isPrime()) {
                requestConsentFrom()
                if (SOCKET_CONNECTION.contains("http")) {
                    val preferences = getSharedPreferences("ADS_ALTERNATIVE", Context.MODE_PRIVATE)

                    @SuppressLint("CommitPrefEdits") val editor = preferences.edit()
                    editor.putInt("${FULL_HISTORY}_count", 0)
                    editor.apply()
                    if (!isPrime() && isAdsLibsLoad()) appOpenManager = AppOpenManager()
                }
            } else goHome()
        }
    }

    var count = 0
    val handler = Handler(Looper.getMainLooper())
    val runnable = object : Runnable {
        override fun run() {
            if (4 <= count) {
                showAds()
            } else {
                count += 1
                handler.postDelayed(this, 1000)
            }
        }
    }

    private fun splashBanner() {
        if (!isPrime()) {
            handler.postDelayed(runnable, 1000)
            splashBannerInlineAdaptiveAds(adsContainer, AB_SPLASH_BANNER) {
            }
            CoroutineScope(Dispatchers.Main).launch {
                delay(1000)
                loadingFull(splashBuilderAds())
            }
        } else {
            goHome()
        }
    }

    private fun showAds() {
        if (interstitialAdSplash != null) {
            interstitialAdSplash?.show(this@SplashActivity)
            interstitialAdSplash?.fullScreenContentCallback = object :
                FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    super.onAdDismissedFullScreenContent()
                    goHome()
                }
            }
        } else
            goHome()
    }

    private fun goHome() {
        if (isAdsLibsLoad()) {
            context.initialize()
        }

        if (this.isFinishing) return
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun checkDeveloper(): Int {
        return Settings.Secure.getInt(
            contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0
        )
    }

    private fun showRootsDialog() {
        val parentView: View = LayoutInflater.from(this).inflate(R.layout.dialog_queen_res, null)
        val dialog = Dialog(this)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setContentView(parentView)
        val okay: AppCompatTextView = parentView.findViewById(R.id.okay)
        okay.setOnClickListener {
            dialog.dismiss()
            System.exit(0)
        }
        dialog.show()
    }


    private fun showDevDialog() {
        val parentView: View =
            LayoutInflater.from(this).inflate(R.layout.dialog_queen_restrict, null)
        val dialog = Dialog(this)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setContentView(parentView)
        val yes = dialog.findViewById<AppCompatTextView>(R.id.yes)
        val okay = dialog.findViewById<AppCompatTextView>(R.id.okay)
        yes.setOnClickListener {
            dialog.dismiss()
            try {
                startActivityForResult(
                    Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS), 1500
                )
            } catch (e: ActivityNotFoundException) {

            }
        }
        okay.setOnClickListener {
            dialog.dismiss()
            exitProcess(0)
        }
        dialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, @Nullable data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1500) {
            if (checkDeveloper() == 1) {
                showDevDialog()
            } else {
                goHome()
            }
        } else if (requestCode == 1001) {
            if (resultCode != RESULT_OK) {
                Log.e("MY_APP", "Update flow failed! Result code: $resultCode")
            }
        }
    }


    var interstitialAdSplash: InterstitialAd? = null
    private fun loadingFull(id: String) {
        Log.e("splashBuilderAds", "****************************************** $id")
        if (id != "") {
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(this@SplashActivity,
                id,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        interstitialAdSplash = interstitialAd
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        interstitialAdSplash = null
                    }
                })
        }
    }

    private fun requestConsentFrom() {
        /*val debugSettings = ConsentDebugSettings.Builder(this)
            .setDebugGeography(ConsentDebugSettings.DebugGeography.DEBUG_GEOGRAPHY_EEA)
            .addTestDeviceHashedId("3368FFB4CE8D4A153E6A429CC9F34695")
            .build()*/
        consentInformation = UserMessagingPlatform.getConsentInformation(this)
        if (ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
            == (consentInformation?.privacyOptionsRequirementStatus ?: -1)
        ) {
            consentInformation?.requestConsentInfoUpdate(
                this,
                ConsentRequestParameters
                    .Builder()
//                .setConsentDebugSettings(debugSettings)
                    .setTagForUnderAgeOfConsent(false)
                    .build(),
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                        this
                    ) { error: FormError? ->
                        Log.e("UserMessagingPlatform", "******************* ${error?.message}")
                        if (consentInformation?.canRequestAds() == true) {
                            initializeMobileAdsSdk()
                        } else goHome()
                    }
                },
                { error: FormError ->
                    Log.e("UserMessagingPlatform", " 1 ******************* ${error.message}")
                    if (consentInformation?.canRequestAds() == true) {
                        initializeMobileAdsSdk()
                    } else goHome()
                })
//            consentInformation?.reset()
        } else {
            MobileAds.initialize(this)
            CoroutineScope(Dispatchers.Main).launch {
                splashBanner()
            }
        }
    }

    private fun initializeMobileAdsSdk() {
        if (isMobileAdsInitializeCalled.getAndSet(true)) {
            return
        }
        MobileAds.initialize(this)
        CoroutineScope(Dispatchers.Main).launch {
            splashBanner()
        }

    }


}
