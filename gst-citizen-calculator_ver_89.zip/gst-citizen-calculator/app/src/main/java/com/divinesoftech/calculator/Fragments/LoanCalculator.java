package com.divinesoftech.calculator.Fragments;


import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.SocketKt.isPrime;
import static com.divinesoftech.calculator.Common.Utilty.isNetworkAvailable;
import static com.divinesoftech.calculator.database.ApiKt.isAdsLibsLoad;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.divinesoftech.calculator.Activities.DetailsActivity;
import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.Activities.PdflistActivtity;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.google.android.gms.ads.AdRequest;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.math.BigDecimal;

public class LoanCalculator extends Fragment implements View.OnClickListener {
    View view;

    EditText Loan_Amount, Intrest, YEAR, MONTH, EMI;
    RelativeLayout Loan_tab, Emi_tab, Intrest_rate_tab, Period_tab, summery, details_relative;
    LinearLayout layout;
    AppCompatImageView loan_icon, emi_icon, intrest_icon, period_icon;
    AppCompatTextView loan_text, emi_text, intrest_text, period_text; //--------------->tab text view
    AppCompatTextView dtl_loan_text, dtl_emi_text, dtl_intrest_text, dtl_period_text, dtl_total_intrest, dtl_total_payment;  // -------------------detail text view
    AppCompatTextView dtl_loan_text_label, dtl_emi_text__label, dtl_intrest_text_label, dtl_period_text_label, dtl_total_intrest_label, dtl_total_payment_label; // ---------detail text view label
    AppCompatButton Calculate, reset, details;
    ScrollView sv;
    Handler handler;
    InputMethodManager inputMethodManager;

    String detail_loan_amount, detail_emi, detail_month, detail_intrest, detail_total_intrest, details_total_Amount;

    Double principle = 0.0, intrest_rate = 0.0, loan_emi = 0.0;
    int loan_duration = 0, years = 0, months = 0;
    int focus = 0, is_calculate = 0;
    public static File iconFile;
    Boolean calculate_on = false;
    int PERMISSION_CODE = 117;
    SharedPreferences preferences;
    RelativeLayout ad_layout;
//    LinearLayout google_layout;


    AdRequest adRequest;

    private FirebaseAnalytics fireBase;
    FrameLayout frameLayout;
    DatabaseGst databaseGst;


    public LoanCalculator() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_emi_calculator, container, false);
        setHasOptionsMenu(true);
        databaseGst = ((MainActivity) requireActivity()).databaseGst;

        preferences = getActivity().getSharedPreferences("update", MODE_PRIVATE);
        inputMethodManager = (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
        fireBase = FirebaseAnalytics.getInstance(getActivity());
        fireBase.setCurrentScreen(getActivity(), getFragmentManager().getClass().getSimpleName(), "Loan - calculator - fragment");

        ad_layout = view.findViewById(R.id.ad_layout);
//        google_layout = view.findViewById(R.id.google_layout);

        /*if (isNetworkAvailable(getActivity()) && !isPrime() && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
            //((MainActivity)getActivity()).Game_btn.setVisibility(View.GONE);
        }*/


        loan_icon = view.findViewById(R.id.loan_imag);
        emi_icon = view.findViewById(R.id.Emi_imag);
        intrest_icon = view.findViewById(R.id.intrest_imag);
        period_icon = view.findViewById(R.id.duration_imag);

        loan_text = view.findViewById(R.id.loan_text);
        emi_text = view.findViewById(R.id.emi_text);
        intrest_text = view.findViewById(R.id.intrest_text);
        period_text = view.findViewById(R.id.period_text);

        sv = view.findViewById(R.id.scroll_view);
        sv.setSmoothScrollingEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            sv.setOnScrollChangeListener(new View.OnScrollChangeListener() {
                @Override
                public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                }
            });
        }


        dtl_loan_text = view.findViewById(R.id.dtl_loan_amount);
        dtl_emi_text = view.findViewById(R.id.dtl_monthley_emi);
        dtl_intrest_text = view.findViewById(R.id.dtl_interest);
        dtl_period_text = view.findViewById(R.id.dtl_total_duration);
        dtl_total_intrest = view.findViewById(R.id.dtl_total_interest);
        dtl_total_payment = view.findViewById(R.id.dtl_total_payment);


        dtl_loan_text_label = view.findViewById(R.id.dtl_loan_amount_label);
        dtl_emi_text__label = view.findViewById(R.id.dtl_monthley_emi_label);
        dtl_intrest_text_label = view.findViewById(R.id.dtl_interest_label);
        dtl_period_text_label = view.findViewById(R.id.dtl_total_duration_label);
        dtl_total_intrest_label = view.findViewById(R.id.dtl_total_interest_label);
        dtl_total_payment_label = view.findViewById(R.id.dtl_total_payment_label);


        Calculate = view.findViewById(R.id.calculate);
        reset = view.findViewById(R.id.reset);
        details = view.findViewById(R.id.details);
        Calculate.setOnClickListener(this);
        reset.setOnClickListener(this);
        details.setOnClickListener(this);


        Loan_Amount = view.findViewById(R.id.loan_amount);
        Intrest = view.findViewById(R.id.intrest);
        YEAR = view.findViewById(R.id.year);
        MONTH = view.findViewById(R.id.month);
        EMI = view.findViewById(R.id.emi);
        layout = view.findViewById(R.id.linear3);


        Loan_tab = view.findViewById(R.id.tab_loan_amount);
        Emi_tab = view.findViewById(R.id.tab_emi);
        Intrest_rate_tab = view.findViewById(R.id.tab_intrest_rate);
        Period_tab = view.findViewById(R.id.tab_period);
        summery = view.findViewById(R.id.calculated_details);
        details_relative = view.findViewById(R.id.detail_button_layout);

        focus = 2;
        Loan_Amount.setVisibility(View.VISIBLE);
        Intrest.setVisibility(View.VISIBLE);
        layout.setVisibility(View.VISIBLE);
        // EMI.setVisibility(View.VISIBLE);
        emi_text.setTextColor(getResources().getColor(R.color.tab_background));
        emi_icon.setColorFilter(getResources().getColor(R.color.tab_background));
        Emi_tab.setBackgroundColor(getResources().getColor(R.color.layout_background));
        // Intrest.setFocusable(true);

        Loan_tab.setOnClickListener(this);
        Emi_tab.setOnClickListener(this);
        Intrest_rate_tab.setOnClickListener(this);
        Period_tab.setOnClickListener(this);
        CheckTexTCondtions(Loan_Amount);
        CheckTexTCondtions(Intrest);
        CheckTexTCondtions(EMI);


       /* try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/

        return view;
    }

    private void CheckTexTCondtions(final EditText editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().length() == 1 && s.toString().equals(".")) {
                    editText.setText("");
                    editText.setSelection(editText.length());
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }


    @Override
    public void onClick(View v) {

//        Loan_Amount.setVisibility(View.VISIBLE);
//        EMI.setVisibility(View.VISIBLE);
//        Intrest.setVisibility(View.VISIBLE);
//        layout.setVisibility(View.VISIBLE);

       /* Loan_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));
        Emi_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));
        Intrest_rate_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));
        Period_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        loan_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        emi_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        intrest_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        period_icon.setColorFilter(getResources().getColor(R.color.layout_background));

        loan_text.setTextColor(getResources().getColor(R.color.layout_background));
        emi_text.setTextColor(getResources().getColor(R.color.layout_background));
        intrest_text.setTextColor(getResources().getColor(R.color.layout_background));
        period_text.setTextColor(getResources().getColor(R.color.layout_background));*/


        switch (v.getId()) {
            case R.id.tab_loan_amount:

                EMI.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                Intrest.setVisibility(View.VISIBLE);

                focus = 1;
                clear_fields();
                Intrest.requestFocus();
                loan_tab();
                focus_null();

                break;
            case R.id.tab_emi:

                Loan_Amount.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                Intrest.setVisibility(View.VISIBLE);


                clear_fields();
                focus = 2;
                Loan_Amount.requestFocus();
                emi_tab();
                focus_null();

                break;
            case R.id.tab_intrest_rate:

                Loan_Amount.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                EMI.setVisibility(View.VISIBLE);

                clear_fields();
                focus = 3;
                Loan_Amount.requestFocus();
                intrest_tab();
                focus_null();
                break;
            case R.id.tab_period:

                Loan_Amount.setVisibility(View.VISIBLE);
                EMI.setVisibility(View.VISIBLE);
                Intrest.setVisibility(View.VISIBLE);

                clear_fields();
                focus = 4;
                Loan_Amount.requestFocus();
                period_tab();
                focus_null();

                break;
            case R.id.calculate:

                if (!calculate_on) {

                    if (TextUtils.isEmpty(Loan_Amount.getText().toString())) {
                        Loan_Amount.setError("Please Enter Loan Amount");
                        Loan_Amount.requestFocus();
                    }

                    Log.e("=================", "onClick focus: " + focus);

                    if (focus == 1) {
                        loan_tab();
                    } else if (focus == 2) {
                        emi_tab();
                    } else if (focus == 3) {
                        intrest_tab();
                    } else if (focus == 4) {
                        period_tab();
                    }


                    get_field_text(); // ---------------------------get all fileld text


                    if (intrest_rate != 0 && loan_emi != 0 && loan_duration != 0) {

                        if (intrest_rate >= 100) {
                            Intrest.setError("Please Insert valid Interest Rate");
                        } else if (loan_duration >= 1200) {
                            check_time_validation();
                        } else {
                            summery_visiblity();
                            dtl_loan_text_label.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            dtl_loan_text.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            Loan_Amount.setVisibility(View.GONE);


                            principle = loan_amount_total(loan_emi, intrest_rate, loan_duration);
                            displaySummery();
                        }

                    } else if (principle != 0 && intrest_rate != 0 && loan_duration != 0) {
                        if (intrest_rate >= 100) {
                            Intrest.setError("Please Insert valid Interest Rate");
                        } else if (loan_duration >= 1200) {
                            check_time_validation();
                        } else {
                            summery_visiblity();
                            dtl_emi_text__label.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            dtl_emi_text.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            loan_emi = emi_cal(principle, intrest_rate, loan_duration);
                            displaySummery();
                        }

                    } else if (principle != 0 && intrest_rate != 0 && loan_emi != 0) {
                        if (intrest_rate >= 100) {
                            Intrest.setError("Please Insert valid Interest Rate");
                        } else {

                            layout.setVisibility(View.GONE);
                            dtl_period_text_label.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            dtl_period_text.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            loan_duration = turnre(principle, intrest_rate, loan_emi);

                            if (loan_duration < 1) {
                                Toast.makeText(getActivity(), "Enter Valid Data", Toast.LENGTH_SHORT).show();
                            } else {
                                summery_visiblity();
                                displaySummery();
                            }


                        }

                    } else if (principle != 0 && loan_duration != 0 && loan_emi != 0) {
                        if (loan_duration >= 1200) {
                            check_time_validation();
                        } else {

                            dtl_intrest_text_label.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            dtl_intrest_text.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            Intrest.setVisibility(View.GONE);
                            float intr = intrest_rate_tot(principle, loan_emi, loan_duration);
                            intrest_rate = (double) intr;


                            if (intrest_rate < 1) {
                                Toast.makeText(getActivity(), "Enter Valid Data", Toast.LENGTH_SHORT).show();
                                intrest_rate = 0.0;
                            } else {
                                displaySummery();
                                summery_visiblity();
                            }


                        }
                    } else {

                        summery.setVisibility(View.GONE);
                        details_relative.setVisibility(View.GONE);
                        requierd();

                    }

                    calculate_on = true;
                }

                break;
            case R.id.reset:
                reset_all();
                break;
            case R.id.details:
                //   storeIcon();

                Intent intent = new Intent(getActivity(), DetailsActivity.class);
                intent.putExtra("loan_amount", detail_loan_amount);
                intent.putExtra("loan_intrest", detail_intrest);
                intent.putExtra("loan_emi", detail_emi);
                intent.putExtra("loan_period", detail_month);
                intent.putExtra("total_intrest", detail_total_intrest);
                intent.putExtra("total_amount", details_total_Amount);
                startActivity(intent);
                break;
        }


    }

    @Override
    public void onCreateOptionsMenu(final Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.loan_calculator_frag, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.pdf_list:
                Intent intent = new Intent(getActivity(), PdflistActivtity.class);
                startActivity(intent);
                return true;

        }

        return super.onOptionsItemSelected(item);
    }


    public void loan_tab() {
        loan_text.setTextColor(getResources().getColor(R.color.tab_background));
        loan_icon.setColorFilter(getResources().getColor(R.color.tab_background));
        Loan_tab.setBackgroundColor(getResources().getColor(R.color.layout_background));

        emi_text.setTextColor(getResources().getColor(R.color.layout_background));
        emi_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Emi_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        intrest_text.setTextColor(getResources().getColor(R.color.layout_background));
        intrest_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Intrest_rate_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        period_text.setTextColor(getResources().getColor(R.color.layout_background));
        period_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Period_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        Loan_Amount.setVisibility(View.GONE);

    }

    public void emi_tab() {

        emi_text.setTextColor(getResources().getColor(R.color.tab_background));
        emi_icon.setColorFilter(getResources().getColor(R.color.tab_background));
        Emi_tab.setBackgroundColor(getResources().getColor(R.color.layout_background));

        loan_text.setTextColor(getResources().getColor(R.color.layout_background));
        loan_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Loan_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        intrest_text.setTextColor(getResources().getColor(R.color.layout_background));
        intrest_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Intrest_rate_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        period_text.setTextColor(getResources().getColor(R.color.layout_background));
        period_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Period_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));


        EMI.setVisibility(View.GONE);
    }

    public void intrest_tab() {
        intrest_text.setTextColor(getResources().getColor(R.color.tab_background));
        intrest_icon.setColorFilter(getResources().getColor(R.color.tab_background));
        Intrest_rate_tab.setBackgroundColor(getResources().getColor(R.color.layout_background));

        emi_text.setTextColor(getResources().getColor(R.color.layout_background));
        emi_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Emi_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        loan_text.setTextColor(getResources().getColor(R.color.layout_background));
        loan_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Loan_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        period_text.setTextColor(getResources().getColor(R.color.layout_background));
        period_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Period_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        Intrest.setVisibility(View.GONE);

    }

    public void period_tab() {
        period_text.setTextColor(getResources().getColor(R.color.tab_background));
        period_icon.setColorFilter(getResources().getColor(R.color.tab_background));
        Period_tab.setBackgroundColor(getResources().getColor(R.color.layout_background));

        intrest_text.setTextColor(getResources().getColor(R.color.layout_background));
        intrest_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Intrest_rate_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        emi_text.setTextColor(getResources().getColor(R.color.layout_background));
        emi_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Emi_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        loan_text.setTextColor(getResources().getColor(R.color.layout_background));
        loan_icon.setColorFilter(getResources().getColor(R.color.layout_background));
        Loan_tab.setBackgroundColor(getResources().getColor(R.color.tab_background));

        layout.setVisibility(View.GONE);
    }

    public void summery_visiblity() {
        try {
            inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
            summery.setVisibility(View.VISIBLE);
            details_relative.setVisibility(View.VISIBLE);
            handler = new Handler();
            final Runnable r = new Runnable() {
                public void run() {
                    sv.scrollTo(0, 320);
                    // handler.postDelayed(this, 1000);
                }
            };
            handler.postDelayed(r, 1000);
            is_calculate = 1;
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void check_time_validation() {

        if (!YEAR.getText().toString().equals("") && MONTH.getText().toString().equals("")) {
            YEAR.setError("Please Enter Valid Year");
        } else if (!MONTH.getText().toString().equals("") && YEAR.getText().toString().equals("")) {
            MONTH.setError("Please Enter Valid Year");
        } else if (!YEAR.getText().toString().equals("") && !MONTH.getText().toString().equals("")) {
            YEAR.setError("Please Enter Valid Year");
            MONTH.setError("Please Enter Valid Year");
        }

    }


    public void requierd() {
        if (TextUtils.isEmpty(Loan_Amount.getText())) {
            Loan_Amount.setError("Please enter Loan Amount");
            Loan_Amount.requestFocus();
        }

        if (TextUtils.isEmpty(Intrest.getText())) {
            Intrest.setError("Please enter Intrest");
            Intrest.requestFocus();
        }

        if (TextUtils.isEmpty(YEAR.getText()) && TextUtils.isEmpty(MONTH.getText())) {
            YEAR.setError("Please enter Loan Year");
            MONTH.setError("Please enter Loan Month");
            YEAR.requestFocus();
            MONTH.requestFocus();
        }

        if (TextUtils.isEmpty(EMI.getText())) {
            EMI.setError("Please enter Emi");
            EMI.requestFocus();
        }

    }

    public void focus_null() {
        Loan_Amount.setError(null);
        Intrest.setError(null);
        YEAR.setError(null);
        MONTH.setError(null);
        EMI.setError(null);
    }

    public void reset_all() {
        if (TextUtils.isEmpty(Loan_Amount.getText().toString())) {
            Loan_Amount.setError(null);
            Loan_Amount.requestFocus();
        }

        if (focus == 1) {
            loan_tab();
            focus_null();
        } else if (focus == 2) {
            emi_tab();
            focus_null();
        } else if (focus == 3) {
            intrest_tab();
            focus_null();
        } else if (focus == 4) {
            period_tab();
            focus_null();
        } else {
            emi_tab();
            focus_null();
        }


        clear_fields();


    }

    private void clear_fields() {
        calculate_on = false;

        Loan_Amount.setText("");
        Intrest.setText("");
        YEAR.setText("");
        MONTH.setText("");
        EMI.setText("");


        dtl_loan_text.setText("");
        dtl_emi_text.setText("");
        dtl_intrest_text.setText("");
        dtl_period_text.setText("");
        dtl_total_intrest.setText("");
        dtl_total_payment.setText("");

        dtl_loan_text.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        dtl_emi_text.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        dtl_intrest_text.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        dtl_period_text.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        dtl_emi_text__label.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        dtl_loan_text_label.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        dtl_intrest_text_label.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        dtl_period_text_label.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

        principle = 0.0;
        intrest_rate = 0.0;
        loan_duration = 0;
        loan_emi = 0.0;

        years = 0;
        months = 0;

        summery.setVisibility(View.GONE);
        details_relative.setVisibility(View.GONE);
    }

    public void get_field_text() {


        if (!Loan_Amount.getText().toString().equals("")) {
            principle = Double.parseDouble(Loan_Amount.getText().toString());
        }
        if (!Intrest.getText().toString().equals("")) {
            intrest_rate = Double.parseDouble(Intrest.getText().toString());
        }
        if (!YEAR.getText().toString().equals("")) {
            loan_duration = Integer.parseInt(YEAR.getText().toString());

            years = loan_duration;


        }
        if (!MONTH.getText().toString().equals("")) {
            loan_duration = Integer.parseInt(MONTH.getText().toString());
            months = loan_duration;
        }
        if (!EMI.getText().toString().equals("")) {
            loan_emi = Double.parseDouble(EMI.getText().toString());
        }

        if (years == 0 && months != 0) {
            loan_duration = months;
        } else if (years != 0 && months == 0) {
            loan_duration = years * 12;
        } else if (years != 0 && months != 0) {
            years = years * 12;
            loan_duration = years + months;
        }
    }


    public Double emi_cal(double princi_ple, double roi, int duration) {
        Double Calculated_emi = 0.0, temp_one = 0.0;
        float temp_three_dur = (float) roi;
        temp_three_dur = calInt(temp_three_dur);

        temp_one = Math.pow((double) (1.0f + temp_three_dur), duration);
        Calculated_emi = princi_ple * ((((double) temp_three_dur) * temp_one) / (temp_one - 1));


        return Calculated_emi;
    }

    public float calInt(float i) {
        return (i / 12.0f) / 100.0f;
    }

    public int turnre(double princi_ple, double roi, double emi) {

    /*                                  -n
            PRINCIPLE = EMI[1-(1 + ROI)  ]
                               -------              time period formula
                                 ROI
    */
        int turn = 0;
        try {


            Double temp_one = 0.0, temp_one_main = 0.0, temp_two_main = 0.0, temp_two = 0.0, temp_three = 0.0, Amount_Accrued = 0.0;
            roi = roi / 12 / 100;

            temp_one = princi_ple * roi;
            temp_one_main = temp_one / emi;
            temp_two = 1 + roi;
            temp_two_main = 1 - temp_one_main;
            temp_three = Math.log(temp_two_main) / Math.log(temp_two);
            String demo = String.valueOf(Math.round(temp_three));
            if (demo.contains("-")) {
                demo = demo.replace("-", "");
            }
            turn = Integer.parseInt(demo);
        } catch (NumberFormatException e) {
        }

        return turn;

    }

    public Double loan_amount_total(double emi, double roi, int duration) {
        Double tot_principle = 0.0, temp_one = 0.0, temp_two = 0.0, temp_three = 0.0, temp_two_dur = 0.0, temp_three_dur = 0.0;
        roi = roi / 12 / 100;
        // roi = roi * 100;
        temp_one = emi / roi;
        temp_two = 1 + roi;
        temp_two_dur = Math.pow(temp_two, duration);
        temp_three = 1 / temp_two_dur;
        temp_three_dur = 1 - temp_three;
        tot_principle = temp_one * temp_three_dur;


        return tot_principle;
    }

    public float intrest_rate_tot(double principle, double emi, int duration) {
        float tot_intrest = 0;
        double maxIntRate = Double.parseDouble(calcMaxIntRate(String.valueOf(emi), String.valueOf(principle)));
        String intRate = calcIntRate(String.valueOf(emi), String.valueOf(principle), String.valueOf(duration));
        tot_intrest = Float.valueOf(intRate);


        return tot_intrest;
    }

    public void displaySummery() {
        //round_val = Math.round(round_val * 100.0) / 100.0;
        Double show_emi = 0.0, show_loanAmount = 0.0, total_Amount = 0.0, total_intrest = 0.0;
        float show_intrest = 0;
        int show_duration = 0;
        if (YEAR.getText().toString().equals("") && MONTH.getText().toString().equals("")) {
            show_duration = turnre(principle, intrest_rate, loan_emi);
        } else {
            if (YEAR.getText().toString().equals("") && !MONTH.getText().toString().equals("")) {
                show_duration = Integer.parseInt(MONTH.getText().toString());
            } else if (!YEAR.getText().toString().equals("") && MONTH.getText().toString().equals("")) {
                int period = Integer.parseInt(YEAR.getText().toString());
                show_duration = period * 12;
            } else if (!YEAR.getText().toString().equals("") && !MONTH.getText().toString().equals("")) {
                int period = ((Integer.parseInt(YEAR.getText().toString()) * 12) + (Integer.parseInt(MONTH.getText().toString())));
                show_duration = period;
            }

        }
        if (Loan_Amount.getText().toString().equals("")) {
            show_loanAmount = Math.round(loan_amount_total(loan_emi, intrest_rate, loan_duration) * 100.0) / 100.0;
        } else {
            show_loanAmount = Double.valueOf(Loan_Amount.getText().toString());
        }


        show_emi = Math.round(emi_cal(principle, intrest_rate, loan_duration) * 100.0) / 100.0;

        show_intrest = intrest_rate_tot(principle, loan_emi, loan_duration);


        BigDecimal round_intrest = new BigDecimal(Float.toString(show_intrest));
        round_intrest = round_intrest.setScale(2, BigDecimal.ROUND_HALF_UP);

        total_Amount = show_emi * show_duration;
        total_intrest = total_Amount - show_loanAmount;


        if (focus == 1) {
            dtl_loan_text.setText(show_loanAmount + " " + getResources().getString(R.string.ruppee));
            dtl_intrest_text.setText(Intrest.getText().toString() + "" + " %");
            dtl_emi_text.setText(EMI.getText().toString() + " " + getResources().getString(R.string.ruppee));

            detail_loan_amount = show_loanAmount.toString();
            detail_intrest = Intrest.getText().toString();
            detail_emi = EMI.getText().toString();

        } else if (focus == 2) {
            dtl_loan_text.setText(Loan_Amount.getText().toString() + " " + getResources().getString(R.string.ruppee));
            dtl_intrest_text.setText(Intrest.getText().toString() + "" + " %");
            dtl_emi_text.setText(show_emi + " " + getResources().getString(R.string.ruppee));

            detail_loan_amount = Loan_Amount.getText().toString();
            detail_intrest = Intrest.getText().toString();
            detail_emi = show_emi.toString();

        } else if (focus == 3) {
            dtl_loan_text.setText(Loan_Amount.getText().toString() + " " + getResources().getString(R.string.ruppee));
            dtl_intrest_text.setText(round_intrest + "" + " %");
            dtl_emi_text.setText(EMI.getText().toString() + " " + getResources().getString(R.string.ruppee));

            detail_loan_amount = Loan_Amount.getText().toString();
            detail_intrest = round_intrest.toString();
            detail_emi = EMI.getText().toString();

        } else if (focus == 4) {
            dtl_loan_text.setText(Loan_Amount.getText().toString() + " " + getResources().getString(R.string.ruppee));
            dtl_intrest_text.setText(Intrest.getText().toString() + "" + " %");
            dtl_emi_text.setText(EMI.getText().toString() + " " + getResources().getString(R.string.ruppee));

            detail_loan_amount = Loan_Amount.getText().toString();
            detail_intrest = Intrest.getText().toString();
            detail_emi = EMI.getText().toString();

        } else {
            dtl_loan_text.setText(Loan_Amount.getText().toString() + " " + getResources().getString(R.string.ruppee));
            dtl_intrest_text.setText(Intrest.getText().toString() + "" + " %");
            dtl_emi_text.setText(show_emi + " " + getResources().getString(R.string.ruppee));

            detail_loan_amount = Loan_Amount.getText().toString();
            detail_intrest = Intrest.getText().toString();
            detail_emi = show_emi.toString();
        }

        detail_month = show_duration + "";
        detail_total_intrest = Math.round(total_intrest * 100.0) / 100.0 + "";
        details_total_Amount = Math.round(total_Amount * 100.0) / 100.0 + "";

        dtl_period_text.setText(show_duration + "");
        dtl_total_payment.setText(details_total_Amount + " " + getResources().getString(R.string.ruppee));
        dtl_total_intrest.setText(detail_total_intrest + " " + getResources().getString(R.string.ruppee));


     /* dtl_loan_text.setText(show_loanAmount + " " + getResources().getString(R.string.ruppee));
        dtl_emi_text.setText(show_emi + " " + getResources().getString(R.string.ruppee));
        dtl_period_text.setText(show_duration + "");
        dtl_intrest_text.setText(round_intrest+ "" + " %");
        dtl_total_payment.setText(total_Amount+" "+ getResources().getString(R.string.ruppee));
        dtl_total_intrest.setText(Math.round(total_intrest * 100.0) / 100.0+" "+ getResources().getString(R.string.ruppee));*/


    }

    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if ((getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) && (getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {

                return true;
            } else {


                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 2);
                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation

            return true;
        }
    }

    public String calcMaxIntRate(String emi, String Loan) throws NumberFormatException, ArithmeticException {
        double maxIntRate;
        try {
            maxIntRate = ((12.0d * Double.parseDouble(emi)) / Double.parseDouble(Loan)) * 100.0d;
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            maxIntRate = 0.0d;
        } catch (ArithmeticException ae) {
            ae.printStackTrace();
            maxIntRate = 0.0d;
        }
        return Double.toString(maxIntRate);
    }


    public String calcIntRate(String emi, String Loan, String terms) throws NumberFormatException, ArithmeticException {
        double minRate = 0.0d;
        double maxRate = 1.0E7d;
        double midRate = 0.0d;
        try {
            double monthlyPayment = Double.parseDouble(emi);
            double loanTerm = Double.parseDouble(terms);
            double loanAmt = Double.parseDouble(Loan);
            if (monthlyPayment * loanTerm < loanAmt) {
                return "-1";
            }
            double actual_payment = monthlyPayment;
            while (minRate < maxRate - 1.0E-4d) {
                midRate = (minRate + maxRate) / 2.0d;
                double intRate = midRate / 1200.0d;
                if ((loanAmt * intRate) / (1.0d - Math.pow(1.0d + intRate, -loanTerm)) > actual_payment) {
                    maxRate = midRate;
                } else {
                    minRate = midRate;
                }
            }
            midRate = ((double) Math.round(100.0d * midRate)) / 100.0d;
            return Double.toString(midRate);
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            return Double.toString(midRate);
        } catch (ArithmeticException ae) {
            ae.printStackTrace();
            return Double.toString(midRate);
        }

    }


/*
    void AdsLoadings() {
        ArrayList<String> type = builderAds(requireContext(), COMMON_BANNER);
        if (type.size() > 0) {

            switch (type.get(0)) {
                case GOOGLE_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    new Utilty().GoogleBannerAdvance(requireActivity(), type.get(1), google_layout, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;

                case ADAPTIVE_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().GoogleAdaptiveBanner(requireActivity(), type.get(1), google_layout, false, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;

                case CUSTOM_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showCustomBanner(google_layout);
                    break;

                case GAME_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showGameBanner(google_layout);
                    break;
            }
        }
    }
*/


}
