package com.divinesoftech.calculator.Fragments;

import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.calculator.Common.Utilty.hideSoftKeyboard;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;

import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.BuildConfig;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class AgeCalculator extends Fragment {

    public AgeCalculator() {
    }

    View view;
    LinearLayout BIRTH_DATE;
    AppCompatTextView Years1, Months, Dayes, Next_month, first_title, second_title, third_title, four_title, five_title, six_title, seven_title;
    AppCompatButton Calculate, Clear;
    AppCompatEditText dd, mm, yyyy;
    FrameLayout frameLayout;
    SharedPreferences preferences;
    RelativeLayout relativeLayout;
    // private EmojiRainLayout mContainer;

    private String DATE_FORMAT = "yy-MM-dd HH:mm:ss";
    Calendar birthDay, today;
    SimpleDateFormat simpleDateFormat, sdf;
    RelativeLayout ad_layout;
//    LinearLayout google_layout;
    DatabaseGst databaseGst;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.age_fragment, container, false);
        setHasOptionsMenu(true);


        databaseGst = ((MainActivity) requireActivity()).databaseGst;


        sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date birthDate = null;
        try {
            birthDate = sdf.parse("24/1/2019");

        } catch (ParseException e) {
            e.printStackTrace();
        }


        BIRTH_DATE = view.findViewById(R.id.birth_date);
        Calculate = view.findViewById(R.id.calculate_age);
        Clear = view.findViewById(R.id.clear_age);
        Years1 = view.findViewById(R.id.years);
        Months = view.findViewById(R.id.months);
        Dayes = view.findViewById(R.id.Dayes);
        first_title = view.findViewById(R.id.first_title);
        second_title = view.findViewById(R.id.second_title);
        third_title = view.findViewById(R.id.third_title);
        four_title = view.findViewById(R.id.four_title);
        five_title = view.findViewById(R.id.five_title);
        six_title = view.findViewById(R.id.six_title);
        seven_title = view.findViewById(R.id.seven_title);
        Next_month = view.findViewById(R.id.next_month);
        // frameLayout = (FrameLayout) view.findViewById(R.id.fl_adplaceholder_age);
        preferences = getActivity().getSharedPreferences("update", MODE_PRIVATE);
        dd = view.findViewById(R.id.dd);
        mm = view.findViewById(R.id.mm);
        yyyy = view.findViewById(R.id.yyyy);
        relativeLayout = view.findViewById(R.id.hbirth);


        ad_layout = view.findViewById(R.id.ad_layout);
//        google_layout = view.findViewById(R.id.google_layout);


        /*if (isNetworkAvailable(getActivity()) && !isPrime() && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
        }*/


        BIRTH_DATE.setOnClickListener(v -> {
            hideSoftKeyboard(v);
            openCalender(dd, mm, yyyy);
        });

        Clear.setOnClickListener(v -> {
            hideSoftKeyboard(v);
            clear_all_fields();
        });
        Calculate.setOnClickListener(v -> {
            hideSoftKeyboard(v);
            clear_results();
            if (!TextUtils.isEmpty(dd.getText().toString()) && !TextUtils.isEmpty(mm.getText().toString()) && !TextUtils.isEmpty(yyyy.getText().toString())) {


                if ((Integer.parseInt(dd.getText().toString()) <= 31) && (Integer.parseInt(mm.getText().toString()) <= 12)) {

                    simpleDateFormat = new SimpleDateFormat("dd/M/yyyy hh:mm:ss");
                    sdf = new SimpleDateFormat("dd/MM/yyyy");
                    birthDay = new GregorianCalendar(Integer.parseInt(yyyy.getText().toString()), Integer.parseInt(mm.getText().toString()), Integer.parseInt(dd.getText().toString()));
                    today = new GregorianCalendar();

                    if ((Integer.valueOf(yyyy.getText().toString()) == today.get(Calendar.YEAR))) {
                        if (Integer.parseInt(mm.getText().toString()) < today.get(Calendar.MONTH) + 1) {

                            try {
                                data(today.get(Calendar.DAY_OF_MONTH), (today.get(Calendar.MONTH) + 1), today.get(Calendar.YEAR), Integer.parseInt(dd.getText().toString()), Integer.parseInt(mm.getText().toString()), Integer.parseInt(yyyy.getText().toString()));

                                countDownStart();
                            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                                e.printStackTrace();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        } else if (Integer.parseInt(mm.getText().toString()) == today.get(Calendar.MONTH) + 1) {
                            if (Integer.parseInt(dd.getText().toString()) <= today.get(Calendar.DAY_OF_MONTH)) {
                                // age_calculation();


                                int birth_day = Day_of_month(Integer.parseInt(dd.getText().toString()), birthDay.get(Calendar.DAY_OF_MONTH));
                                Years1.setText(remove_minus("0"));
                                Months.setText(remove_minus("0"));
                                Dayes.setText(remove_minus(remove_minus(String.valueOf(today.get(Calendar.DAY_OF_MONTH) - birth_day))));

                                if ((Integer.parseInt(mm.getText().toString()) == (today.get(Calendar.MONTH) + 1)) && (today.get(Calendar.DAY_OF_MONTH) == birthDay.get(Calendar.DAY_OF_MONTH))) {

                                    relativeLayout.setVisibility(View.VISIBLE);
                                } else {
                                    relativeLayout.setVisibility(View.GONE);
                                }

                                // details();//next Birthday
                                countDownStart();
                            } else {

                                if (relativeLayout.getVisibility() == View.VISIBLE)
                                    relativeLayout.setVisibility(View.GONE);

                                Toast.makeText(getActivity(), "Enter Past Date Day", Toast.LENGTH_SHORT).show();
                            }

                        } else {

                            if (relativeLayout.getVisibility() == View.VISIBLE)
                                relativeLayout.setVisibility(View.GONE);

                            Toast.makeText(getActivity(), "Enter Past Date month", Toast.LENGTH_SHORT).show();
                        }
                    } else if ((Integer.valueOf(yyyy.getText().toString()) < today.get(Calendar.YEAR))) {


                        try {
                            data(today.get(Calendar.DAY_OF_MONTH), (today.get(Calendar.MONTH) + 1), today.get(Calendar.YEAR), Integer.parseInt(dd.getText().toString()), Integer.parseInt(mm.getText().toString()), Integer.parseInt(yyyy.getText().toString()));

                            countDownStart();
                        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {

                        if (relativeLayout.getVisibility() == View.VISIBLE)
                            relativeLayout.setVisibility(View.GONE);
                        Toast.makeText(getActivity(), "Enter Past year", Toast.LENGTH_SHORT).show();

                    }

                } else {
                    if (relativeLayout.getVisibility() == View.VISIBLE)
                        relativeLayout.setVisibility(View.GONE);
                    Toast.makeText(getActivity(), "Enter Proper Date", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getActivity(), "Enter Date", Toast.LENGTH_SHORT).show();
            }


        });

        /*try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/

        return view;

    }


    private int Day_of_month(int day, int birt) {
        if (day > 28)
            return 28 + birt;
        else
            return day;

    }

    private String remove_minus(String str) {
        if (str.contains("-"))
            return str = str.replace("-", "");

        return str;
    }

    private void clear_all_fields() {

        dd.setText("");
        mm.setText("");
        yyyy.setText("");
        clear_results();
        if (relativeLayout.getVisibility() == View.VISIBLE)
            relativeLayout.setVisibility(View.GONE);

    }

    private void clear_results() {
        Years1.setText("000");
        Months.setText("00");
        Dayes.setText("00");
        Next_month.setText("00");
    }

    private void openCalender(final EditText dd, final EditText mm, final EditText yyyy) {

        final Calendar selected_date = Calendar.getInstance();
        int mYear = selected_date.get(Calendar.YEAR);
        int mMonth = selected_date.get(Calendar.MONTH);
        int mDay = selected_date.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(getContext(), android.R.style.Theme_Holo_Light_Dialog, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                //editText.setText(dayOfMonth + "/" + month + "/" + year);//+" "+"12:00:00"
                dd.setText(dayOfMonth + "");
                mm.setText(month + "");
                yyyy.setText(year + "");
                selected_date.set(year, month - 1, dayOfMonth);
            }
        }, mYear, mMonth, mDay);
        dialog.show();
    }


    public void countDownStart() {
        String date = (today.get(Calendar.YEAR) + 1) + "-" + mm.getText().toString() + "-" + dd.getText().toString() + " 00:00:00";
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
            Date futureDate = dateFormat.parse(date);
            Date currentDate = new Date();


            long diff = futureDate.getTime() - currentDate.getTime();


            long days = diff / (24 * 60 * 60 * 1000);
            diff -= days * (24 * 60 * 60 * 1000);
            long hours = diff / (60 * 60 * 1000) % 24;
            diff -= hours * (60 * 60 * 1000);
            long minutes = diff / (60 * 1000) % 60;

            diff -= minutes * (60 * 1000);
            long seconds = diff / 1000 % 60;


            if (days > 365)
                Next_month.setText(remove_minus(String.valueOf(365 - days)));
            else
                Next_month.setText(remove_minus(String.valueOf(days)));
            // Log.e("Days","Dayes---> "+daysDiff);

            if (days == 365)
                relativeLayout.setVisibility(View.VISIBLE);
            else
                relativeLayout.setVisibility(View.GONE);


        } catch (Exception e) {
            e.printStackTrace();

        }

    }

    private void data(int current_date, int current_month,
                      int current_year, int birth_date,
                      int birth_month, int birth_year) {
        int month[] = {31, 28, 31, 30, 31, 30, 31,
                31, 30, 31, 30, 31};

        if (birth_date > current_date) {
            current_month = current_month - 1;
            current_date = current_date + month[birth_month - 1];
        } else if (birth_date == current_date) {
            relativeLayout.setVisibility(View.VISIBLE);

        }

        // if birth month exceeds current month,
        // then do not count this year and add
        // 12 to the month so that we can subtract
        // and find out the difference
        if (birth_month > current_month) {
            current_year = current_year - 1;
            current_month = current_month + 12;
        }

        // calculate date, month, year
        int calculated_date = current_date - birth_date;
        int calculated_month = current_month - birth_month;
        int calculated_year = current_year - birth_year;

        Years1.setText(remove_minus(String.valueOf(calculated_year)));
        Months.setText(remove_minus(String.valueOf(calculated_month)));
        Dayes.setText(remove_minus(String.valueOf(calculated_date)));

        // print the present age
        System.out.println("Present Age");
        System.out.println("Years: " + calculated_year +
                " Months: " + calculated_month + " Days: " +
                calculated_date);
        if (BuildConfig.DEBUG) {
            Log.e("Real ", "XXXXXXXXX---> " + "Years: " + calculated_year +
                    " Months: " + calculated_month + " Days: " +
                    calculated_date);
        }

    }


/*
    void AdsLoadings() {
        ArrayList<String> type = builderAds(requireContext(), COMMON_BANNER);
        if (type.size() > 0) {
            switch (type.get(0)) {
                case GOOGLE_AD:
                    new Utilty().GoogleBannerAdvance(getActivity(), type.get(1), google_layout, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;

                case ADAPTIVE_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().GoogleAdaptiveBanner(getActivity(), type.get(1), google_layout, false, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;
                case SMART_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().mSmartBanner(getActivity(), type.get(1), ad_layout, google_layout);
                    break;

                case CUSTOM_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showCustomBanner(google_layout);
                    break;


              case GAME_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showGameBanner(google_layout);
                    break;
            }
        }
    }
*/


}
