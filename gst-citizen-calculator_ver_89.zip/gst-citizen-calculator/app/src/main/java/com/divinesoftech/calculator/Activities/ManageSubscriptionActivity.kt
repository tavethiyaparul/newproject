package com.divinesoftech.calculator.Activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.divinesoftech.calculator.R
import kotlinx.android.synthetic.main.activity_managesubscription.*


class ManageSubscriptionActivity : AppCompatActivity() {

    var ActionBarTitle: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_managesubscription)


        val toolbar = findViewById<View>(R.id.toolbar_changeview) as Toolbar
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayShowCustomEnabled(true)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        val decorView = window.decorView
        val uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN
        decorView.systemUiVisibility = uiOptions
        window.addFlags(1024)
        val inflator = LayoutInflater.from(this)
        val v = inflator.inflate(R.layout.custom_actionbar, null)
        ActionBarTitle = v.findViewById<View>(R.id.action_bar_title) as TextView
        supportActionBar!!.customView = v
        ActionBarTitle!!.text = "Manage Subscription"

        layCancelSubscription.setOnClickListener {
            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/account/subscriptions")
            )
            startActivity(browserIntent)
        }
        layUndo.setOnClickListener {
            onBackPressed()
        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}
