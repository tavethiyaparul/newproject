package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomAdsLoaded
import com.divinesoftech.calculator.database.room.RoomTags
@Dao
interface RoomTagsDao {
    @Query("Select * from RoomTags order by orderTag ASC ")
    fun getRoomAdsLoaded(): List<RoomTags>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomAdsLoaded(roomVersion: RoomTags)

    @Update
    fun updateRoomAdsLoaded(roomVersion: RoomAdsLoaded)

    @Delete
    fun deleteRoomAdsLoaded(roomVersion: RoomAdsLoaded)
}