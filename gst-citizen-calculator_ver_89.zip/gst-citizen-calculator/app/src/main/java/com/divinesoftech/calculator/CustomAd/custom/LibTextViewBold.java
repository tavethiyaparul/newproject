package com.divinesoftech.calculator.CustomAd.custom;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

import static com.divinesoftech.calculator.CustomAd.CustomAdsUtil.ASSERT_FONTS_BOLD;


public class LibTextViewBold extends AppCompatTextView {
    public LibTextViewBold(Context context) {
        super(context);
        init(context);
    }

    public LibTextViewBold(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public LibTextViewBold(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);

    }

    public void init(Context context) {
        if (!ASSERT_FONTS_BOLD.equals(""))
            if (!isInEditMode()) {

                setTypeface(Typeface.createFromAsset(context.getAssets(), ASSERT_FONTS_BOLD));
            }
    }
}
