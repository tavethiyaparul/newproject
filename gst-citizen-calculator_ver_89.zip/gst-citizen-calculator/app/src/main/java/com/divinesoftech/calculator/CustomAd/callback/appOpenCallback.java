package com.divinesoftech.calculator.CustomAd.callback;

import java.util.ArrayList;

public interface appOpenCallback {
    void onClose();
    void onFail();
}
