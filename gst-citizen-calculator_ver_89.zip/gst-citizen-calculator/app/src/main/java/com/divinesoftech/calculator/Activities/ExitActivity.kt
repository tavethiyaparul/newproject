package com.divinesoftech.calculator.Activities

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.RatingBar
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatRatingBar
import androidx.constraintlayout.widget.ConstraintLayout
import com.divinesoftech.calculator.BuildConfig
import com.divinesoftech.calculator.R
import com.divinesoftech.idInAppRated
import com.divinesoftech.idInAppValueRated
import com.divinesoftech.idRateFirstOpen
import com.divinesoftech.idRateVersion
import com.google.android.gms.tasks.Task
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import kotlinx.android.synthetic.main.theme_select.View_Pager

class ExitActivity : AppCompatActivity() {
    var mRateValue = 0f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exit)

        val rating: AppCompatRatingBar = findViewById(R.id.rating)
        val btnRetry: AppCompatButton = findViewById(R.id.btnRetry)
        val layout: ConstraintLayout = findViewById(R.id.layout)

        btnRetry.setOnClickListener {
            idInAppRated = "true"
            idRateVersion = BuildConfig.VERSION_NAME
            showRateIn()
            idInAppValueRated = mRateValue.toString()
        }

        rating.onRatingBarChangeListener =
            RatingBar.OnRatingBarChangeListener { ratingBar: RatingBar, v: Float, b: Boolean ->
                mRateValue = ratingBar.rating
            }

        if (idRateFirstOpen == "true" && idInAppRated == "false") {
            layout.visibility = View.VISIBLE
        } else if (idRateVersion != "" && idRateVersion != BuildConfig.VERSION_NAME && idInAppValueRated.toFloat() < 4.0) {
            layout.visibility = View.VISIBLE
        } else idRateFirstOpen = "true"

    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }

    private fun showRateIn() {
        val manager: ReviewManager = ReviewManagerFactory.create(this)
        val request: com.google.android.play.core.tasks.Task<ReviewInfo> =
            manager.requestReviewFlow()
        request.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val reviewInfo: ReviewInfo = task.result
                val flow: com.google.android.play.core.tasks.Task<Void> =
                    manager.launchReviewFlow(this, reviewInfo)
                flow.addOnCompleteListener { it ->
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)
                        )
                    )
                }
                flow.addOnFailureListener { it -> }
            } else {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)
                    )
                )
            }
        }
    }


}