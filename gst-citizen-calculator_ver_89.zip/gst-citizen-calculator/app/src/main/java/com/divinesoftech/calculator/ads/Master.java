package com.divinesoftech.calculator.ads;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class Master implements Serializable {

    @SerializedName("chield")
    ArrayList<Chield> chield;

    @SerializedName("AD_COUNT")
    private String AD_COUNT;

    @SerializedName("AD_VISIBLE")
    private String AD_VISIBLE;

    @SerializedName("AD_NAME")
    private String AD_NAME;

    public ArrayList<Chield> getChield() {
        return chield;
    }

    public void setChield(ArrayList<Chield> chield) {
        this.chield = chield;
    }

    public String getAD_COUNT() {
        return AD_COUNT;
    }

    public void setAD_COUNT(String AD_COUNT) {
        this.AD_COUNT = AD_COUNT;
    }

    public String getAD_VISIBLE() {
        return AD_VISIBLE;
    }

    public void setAD_VISIBLE(String AD_VISIBLE) {
        this.AD_VISIBLE = AD_VISIBLE;
    }

    public String getAD_NAME() {
        return AD_NAME;
    }

    public void setAD_NAME(String AD_NAME) {
        this.AD_NAME = AD_NAME;
    }


}