package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.RoomConnection
@Dao
interface RoomConnectionDao {
    @Query("Select data from RoomConnection where id=:id ")
    fun getRoomConnection(id:Int): String

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomConnection(roomVersion: RoomConnection)

    @Update
    fun updateRoomConnection(roomVersion: RoomConnection)

    @Delete
    fun deleteRoomConnection(roomVersion: RoomConnection)
}