package com.divinesoftech.calculator.Fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.divinesoftech.calculator.Activities.AddClock;
import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.Adapter.SelectedClockAdapter;
import com.divinesoftech.calculator.BuildConfig;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static android.content.Context.MODE_PRIVATE;


public class WorldClock extends Fragment implements WorldItemTouchHelper.RecyclerItemTouchHelperListener {
    View view;
    FrameLayout frameLayout;
    SharedPreferences preferences;
    SharedPreferences.Editor save_editor;
    SelectedClockAdapter clockAdapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    TextView current_time_zone, current_date;
    TextClock current_time;
    List<String> arrayList, temlist;
    String json = "";
    private Handler handler;
    private Runnable runnable;


    @Override
    public void onResume() {
        super.onResume();
        temlist.clear();
        Gson gson = new Gson();
        json = preferences.getString("clock_shared", "");
        Type type = new TypeToken<List<String>>() {
        }.getType();
        if (!TextUtils.isEmpty(json))
            temlist = gson.fromJson(json, type);
        handler = new Handler();


        if (!TextUtils.isEmpty(json)) {
            arrayList = new ArrayList<>(temlist);
            clockAdapter = new SelectedClockAdapter(arrayList, getActivity());
            recyclerView.setAdapter(clockAdapter);
        }
    }
    DatabaseGst databaseGst;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.worl_clock_layout, container, false);
        setHasOptionsMenu(true);
        databaseGst = new DatabaseGst(getActivity());
        preferences = getActivity().getSharedPreferences("update", MODE_PRIVATE);
        save_editor = preferences.edit();
        frameLayout = (FrameLayout) view.findViewById(R.id.fl_adplaceholder_world);

        recyclerView = view.findViewById(R.id.recyclview);
        layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        current_time = view.findViewById(R.id.current_time);
        current_time_zone = view.findViewById(R.id.current_time_zone);
        current_date = view.findViewById(R.id.current_date);
        chamgeFont(current_time);
        chamgeFont(current_date);


        temlist = new ArrayList<>();


        // TimeZone tz = TimeZone.getTimeZone("GMT+05:30");
        // Calendar c = Calendar.getInstance(tz);
        //  String time = String.format("%02d" , c.get(Calendar.HOUR_OF_DAY))+":"+String.format("%02d" , c.get(Calendar.MINUTE))+":"+ String.format("%02d" , c.get(Calendar.SECOND))+":"+String.format("%03d" , c.get(Calendar.MILLISECOND));

        Date currentTime = Calendar.getInstance().getTime();


        TimeZone timeZone = TimeZone.getDefault();
        Calendar cal = Calendar.getInstance(timeZone);
        Date currentLocalTime = cal.getTime();

        DateFormat clock = new SimpleDateFormat("HH:mm:ss a");
        DateFormat date = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
// you can get seconds by adding  "...:ss" to it
        clock.setTimeZone(timeZone);
        date.setTimeZone(timeZone);
        dateFormat.setTimeZone(timeZone);
        String localDate = date.format(currentLocalTime);
        String localTime = clock.format(currentLocalTime);
        String lTime = dateFormat.format(currentLocalTime);
        //  current_time.setText(localTime);
        current_time_zone.setText(timeZone.getID());
        current_date.setText(localDate);

        try {
            Date futureDate = dateFormat.parse(lTime);
            countDownStart(futureDate.getTime());

        } catch (ParseException e) {
            e.printStackTrace();
        }


        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new WorldItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);


        /*try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/

        return view;

    }

    public void countDownStart(final long time) {


        handler = new Handler();
        runnable = new Runnable() {
            //  long hours = time_hrs,minutes = time_mins;
            @Override
            public void run() {
                handler.postDelayed(this, 1000);
                try {
                    long diff = time;


                    long days = diff / (24 * 60 * 60 * 1000);
                    diff += days * (24 * 60 * 60 * 1000);
                    long hours = diff / (60 * 60 * 1000) % 24;
                    diff += hours * (60 * 60 * 1000);
                    long minutes = diff / (60 * 1000) % 60;

                    diff += minutes * (60 * 1000);
                    long seconds = diff / 1000 % 60;

                    if (BuildConfig.DEBUG)
                    Log.e("-->", "this is time--> " + String.format("%02d", hours) + ":" + String.format("%02d", minutes) + ":" + String.format("%02d", seconds));

                    //   day.setText("" + String.format("%02d", days));
                    //   HRS.setText("" + String.format("%02d", hours));
                    //   MINS.setText("" + String.format("%02d", minutes));
                    //  sec.setText("" + String.format("%02d", seconds));

                       /* tvEventStart.setVisibility(View.VISIBLE);
                        tvEventStart.setText("The event started!");
                        textView }Gone();*/

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        handler.postDelayed(runnable, 1 * 1000);
    }


    @Override
    public void onCreateOptionsMenu(final Menu menu, MenuInflater inflater) {


        inflater.inflate(R.menu.world_clock_menu, menu);
    }

    private void chamgeFont(TextView textView) {
        textView.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_clock:
                startActivity(new Intent(getActivity(), AddClock.class));

                return true;

        }

        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position) {

        if (viewHolder instanceof SelectedClockAdapter.SelectedClockHolder) {
            final int deletedIndex = viewHolder.getAdapterPosition();
            clockAdapter.removeItem(viewHolder.getAdapterPosition());
            temlist.remove(deletedIndex);

            Gson gson = new Gson();
            String shared_list = gson.toJson(arrayList);
            save_editor.putString("clock_shared", shared_list);
            save_editor.apply();

        }
    }
}
