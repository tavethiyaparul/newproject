package com.divinesoftech.calculator.database;

public class Helper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "GstCalculator.db";

    //TableName
    public static final String TABLE_RESPONSE = "response";




    //field table 1
    public static final String ID = "id";
    public static final String RESPONSE = "store_response";

    public static final int ID_MAIN_STATUS = 1;
    public static final int ID_FORCEFULLY = 2;
    public static final int ID_GAME= 3;





}
