package com.divinesoftech.calculator.mongodb;

public class CitizenAdsUtility {


    public static final String CALCULATOR_ACTIVITY_TAG = "calculator_activity";
    public static final String CALCULATOR_FRAGMENT_TAG = "Gst_Fragment";
    public static final String UNIT_FRAGMENT_TAG = "Unit_Fragment";

    public static final String MODE_BANNER_AD = "banner";
    public static final String MODE_FULL_AD_EXIT = "full_exit_mode";


    public static final String EXIT_AD_TAG = "Full_Exit";
    public static final String HOME_BANNER_TAG = "Bottom_Banner";
    public static final String UNIT_BANNER_TAG = "Banner_Converter";


    public static final String GOOGLE_AD = "Google";
    public static final String CUSTOM_AD = "CUSTOM";
    private static final String ALTERNATIVE = "ALTERNATIVE";





   

}
