package com.divinesoftech.calculator.Classes.Model;


import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Result implements Serializable {

    @SerializedName("timestamp")
    private String timestamp;

    @SerializedName("source")
    private String source;

    @SerializedName("data")
    private List<Data> data;

    @SerializedName("features")
    private String features;

    @SerializedName("sku")
    private List<Sku> sku;

    @SerializedName("vname")
    private String vname;

    @SerializedName("vcode")
    private String vcode;


    public List<Data> getData() {
        return data;
    }

    public void setData(List<Data> data) {
        this.data = data;
    }


    public String getTimestamp ()
    {
        return timestamp;
    }


    public void setTimestamp (String timestamp)
    {
        this.timestamp = timestamp;
    }


    public String getSource ()
    {
        return source;
    }


    public void setSource (String source)
    {
        this.source = source;
    }


    public String getFeatures ()
    {
        return features;
    }

    public void setFeatures (String features)
    {
        this.features = features;
    }

    public List<Sku> getSku() {
        return sku;
    }

    public void setSku(List<Sku> sku) {
        this.sku = sku;
    }

    public String getVname ()
    {
        return vname;
    }

    public void setVname (String vname)
    {
        this.vname = vname;
    }

    public String getVcode ()
    {
        return vcode;
    }

    public void setVcode (String vcode)
    {
        this.vcode = vcode;
    }


}
