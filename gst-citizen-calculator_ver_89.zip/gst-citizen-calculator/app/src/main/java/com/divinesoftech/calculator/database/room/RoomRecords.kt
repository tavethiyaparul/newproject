package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class RoomRecords {
    @PrimaryKey
    var id: Int = 0
    var data: String = ""
}