package com.citizencalc.gstcalculator.Classes.common

import android.content.Context
import com.divinesoftech.calculator.Classes.GstApp
import com.divinesoftech.calculator.Common.Utilty.IS_ADFREE
import com.divinesoftech.calculator.Common.Utilty.SHARED_PERF
import com.divinesoftech.calculator.CustomAd.db.DatabaseHelperGstlite
import com.divinesoftech.calculator.database.DatabaseGst


fun builder(adsName: String, cont: Int, isShow: Boolean): Array<String?>? {
    /*val sharedPreferences = GstApp.appInstance.getSharedPreferences(SHARED_PERF, Context.MODE_PRIVATE)

    // return adsIds(adsName, sharedPreferences, cont, isShow,false)

    if (!DatabaseGst(GstApp.appInstance).getResponse(IS_ADFREE).equals("YES"))
        return adsIds(adsName, sharedPreferences, cont, isShow, false)
    else*/
    return setNoDataFound()
}


fun builderFacebookId(adsName: String): Array<String?>? {
    /*val sharedPreferences =
            contex.getSharedPreferences(
                    SHARED_PERF, Context.MODE_PRIVATE
            )*/
    return setNoDataFound()
}


