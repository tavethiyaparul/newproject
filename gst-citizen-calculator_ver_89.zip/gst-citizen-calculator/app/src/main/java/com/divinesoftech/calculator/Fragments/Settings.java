package com.divinesoftech.calculator.Fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.billingclient.api.Purchase;
import com.divinesoftech.calculator.Activities.ChangeViewActivity;
import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.Activities.TaxSlabs;
import com.divinesoftech.calculator.BuildConfig;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DataBase_Constant;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;

import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.calculator.database.room.RoomDatabaseGstKt.instances;

public class Settings extends Fragment {

    View view;

    SwitchCompat switch_sound, switch_vibration, switch_Bottom;

    public boolean btn_sound, btn_vibration, btn_bottom_navigation;
    public String btn_round;
    int radio_id = 0;


    RelativeLayout rate, share_app, about, radio_layout, change_view, tax_slab, layHelp;
    private FirebaseAnalytics fireBase;


    ImageView btn_back;
    TextView suggest, version;

    PackageManager packageManager;
    PackageInfo packageInfo;
    SharedPreferences bottom_prefs;


    public Settings() {
    }

    private RadioGroup radioGroup;
//    Purchase yourObject;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_settings, container, false);
        radioGroup = (RadioGroup) view.findViewById(R.id.radio_group);
        radio_layout = (RelativeLayout) view.findViewById(R.id.R_Round);
        version = (TextView) view.findViewById(R.id.version_name);
        change_view = (RelativeLayout) view.findViewById(R.id.R_view);
        tax_slab = (RelativeLayout) view.findViewById(R.id.R_slab);


//        Gson gson = new Gson();
//        yourObject = gson.fromJson(MyConstKt.getPURCHASE(), Purchase.class);

        // ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Settings");
        //((AppCompatActivity) getActivity()).getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.App_light)));


        fireBase = FirebaseAnalytics.getInstance(getActivity());

        fireBase.setCurrentScreen(getActivity(), getFragmentManager().getClass().getSimpleName(), "Settings  - fragment");

       /* if (((MainActivity) getActivity()).fragments_settings == 1 || ((MainActivity) getActivity()).flag == 0) {
            radio_layout.setVisibility(View.VISIBLE);
        } else if (((MainActivity) getActivity()).fragments_settings == 2 || ((MainActivity) getActivity()).flag == 1) {
            radio_layout.setVisibility(View.GONE);
        } else {
            radio_layout.setVisibility(View.VISIBLE);
        }*/

        PackageInfo pinfo = null;
        try {
            pinfo = getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String versionName = pinfo.versionName;
        version.setText(versionName);


        switch_sound = (SwitchCompat) view.findViewById(R.id.sw_sound);
        switch_vibration = (SwitchCompat) view.findViewById(R.id.sw_vibration);
        switch_Bottom = (SwitchCompat) view.findViewById(R.id.sw_fullScreen);

        rate = (RelativeLayout) view.findViewById(R.id.R_rate);
        share_app = (RelativeLayout) view.findViewById(R.id.R_share);
        about = (RelativeLayout) view.findViewById(R.id.R_about);
        layHelp = (RelativeLayout) view.findViewById(R.id.layHelp);
        //   btn_back = (ImageView)view.findViewById(R.id.setting_back);
        suggest = (TextView) view.findViewById(R.id.suggetion);


        SharedPreferences prefs = getActivity().getSharedPreferences("MyPref", MODE_PRIVATE);
        btn_sound = prefs.getBoolean("is_sound", true);
        switch_sound.setChecked(btn_sound);

        SharedPreferences vibrate_prefs = getActivity().getApplicationContext().getSharedPreferences("MyPref_vibrstion", MODE_PRIVATE);
        btn_vibration = vibrate_prefs.getBoolean("is_vibrate", true);
        switch_vibration.setChecked(btn_vibration);

        bottom_prefs = getActivity().getApplicationContext().getSharedPreferences("update", MODE_PRIVATE);
        btn_bottom_navigation = bottom_prefs.getBoolean("is_bottom", true);
        switch_Bottom.setChecked(btn_bottom_navigation);

      /*  SharedPreferences gst_prefs = getActivity().getApplicationContext().getSharedPreferences("MyPref_gst_panel", MODE_PRIVATE);
        btn_gstpanel = gst_prefs.getBoolean("is_gst_panel",true);*/
        //  switch_gst_panel.setChecked(btn_gstpanel);

        SharedPreferences prefs_round = getActivity().getApplicationContext().getSharedPreferences("MyPref_round", MODE_PRIVATE);
        final SharedPreferences.Editor editor_round = prefs_round.edit();
        btn_round = prefs_round.getString("is_round", "");

        SharedPreferences prefs_radio_id = getActivity().getApplicationContext().getSharedPreferences("MyPref_radio_id", MODE_PRIVATE);
        final SharedPreferences.Editor editor_radio_id = prefs_radio_id.edit();
        radio_id = prefs_radio_id.getInt("is_radio_id", 0);


        if (radio_id == 0) {
            radio_id = R.id.round3;
        }

        radioGroup.check(radio_id);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {

                RadioButton rb = (RadioButton) radioGroup.findViewById(checkedId);
                if (null != rb && checkedId > -1) {


                    String round_value = rb.getText().toString();
                    editor_round.putString("is_round", round_value);
                    editor_round.commit();


                    editor_radio_id.putInt("is_radio_id", rb.getId());
                    editor_radio_id.commit();


                }

            }
        });


        switch_sound.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean ischecked) {


                SharedPreferences prefs = getActivity().getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putBoolean("is_sound", ischecked);
                editor.commit();
                btn_sound = prefs.getBoolean("is_sound", true);


            }
        });
        switch_vibration.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean ischecked) {

                SharedPreferences vibrate_prefs = getActivity().getApplicationContext().getSharedPreferences("MyPref_vibrstion", MODE_PRIVATE);
                SharedPreferences.Editor editor_vibration = vibrate_prefs.edit();
                editor_vibration.putBoolean("is_vibrate", ischecked);
                editor_vibration.commit();
                btn_vibration = vibrate_prefs.getBoolean("is_vibrate", true);

            }
        });

        switch_Bottom.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean ischecked) {


                SharedPreferences.Editor editor_vibration = bottom_prefs.edit();
                editor_vibration.putBoolean("is_bottom", ischecked);
                editor_vibration.commit();
                btn_bottom_navigation = bottom_prefs.getBoolean("is_bottom", true);

            }
        });


        change_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ChangeViewActivity.class);
                startActivity(intent);
            }
        });


        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)));
            }
        });

        share_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1 = "http://play.google.com/store/apps/details?id="
                        + getActivity().getPackageName();
                //dialog1.dismiss();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, s1);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });


        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    String[] recipients = {"indianinfotechsurat@gmail.com"};
                    intent.setData(Uri.parse("mailto:"));
                    intent.putExtra(Intent.EXTRA_EMAIL, recipients);
                    intent.putExtra(Intent.EXTRA_CC, "indianinfotechsurat@gmail.com");
                    intent.putExtra(Intent.EXTRA_SUBJECT, "Feedback About " + BuildConfig.VERSION_CODE);
                    //  intent.putExtra(Intent.EXTRA_TEXT,"Body of the content here...");

                    // intent.setType("text/html");
                    // intent.setPackage("com.google.android.gm");
                    //  startActivity(Intent.createChooser(intent, "Send mail"));
                    if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                        startActivity(Intent.createChooser(intent, "Send mail"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });

        layHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setType("text/plain");
                String[] recipients = {"indianinfotechsurat@gmail.com"};
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL, recipients);
                intent.putExtra(Intent.EXTRA_CC, "indianinfotechsurat@gmail.com");
                intent.putExtra(Intent.EXTRA_SUBJECT, "Purchase issue " + BuildConfig.VERSION_CODE);

                try {
                    intent.putExtra(Intent.EXTRA_TEXT, instances.roomConnectionDao().getRoomConnection(DataBase_Constant.SUBSCRIPTION_STATE_ID));
                } catch (NullPointerException e) {
                }
                //  intent.putExtra(Intent.EXTRA_TEXT,"Body of the content here...");

                // intent.setType("text/html");
                // intent.setPackage("com.google.android.gm");
                //  startActivity(Intent.createChooser(intent, "Send mail"));
                if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivity(Intent.createChooser(intent, "Send mail"));
                }


            }
        });

        tax_slab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TaxSlabs.class);
                startActivity(intent);
            }
        });
      /*  view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if( keyCode == KeyEvent.KEYCODE_BACK )
                {

                    Toast.makeText(getActivity(), "helooo", Toast.LENGTH_SHORT).show();
                    getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    return true;
                }
                return false;

            }
        });*/

        /*try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/


        return view;
    }


}
