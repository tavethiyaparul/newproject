package com.divinesoftech.calculator.Adapter

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.ImageView
import androidx.viewpager.widget.ViewPager

class GstViewpager:ViewPager{
    constructor(context: Context) : super(context) {}
    constructor(
            context: Context,
            attrs: AttributeSet?
    ) : super(context, attrs) { //this.isPagingEnabled = true;
    }

    override fun canScroll(
            v: View,
            checkV: Boolean,
            dx: Int,
            x: Int,
            y: Int
    ): Boolean {
        return if (v is ImageView) {
            v.canScrollHorizontally(dx)
        } else super.canScroll(v, checkV, dx, x, y)
    }
}