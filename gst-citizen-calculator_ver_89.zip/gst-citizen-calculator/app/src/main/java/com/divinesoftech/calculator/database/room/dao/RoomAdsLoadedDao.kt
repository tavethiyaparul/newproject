package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomAdsLoaded

@Dao
interface RoomAdsLoadedDao {
    @Query("Select * from RoomAdsLoaded where placement_name=:placementName and id=:id")
    fun getRoomAdsLoaded(id:String,placementName:String): RoomAdsLoaded

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomAdsLoaded(roomVersion: RoomAdsLoaded)

    @Update
    fun updateRoomAdsLoaded(roomVersion: RoomAdsLoaded)

    @Query("DELETE FROM RoomAdsLoaded WHERE placement_name = :placementName")
    fun deleteRoomAdsLoaded(placementName: String)
}