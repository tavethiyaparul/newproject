package com.divinesoftech.calculator.CustomAd.custom;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

import static com.divinesoftech.calculator.CustomAd.CustomAdsUtil.ASSERT_FONTS;


public class LibTextView extends AppCompatTextView {
    public LibTextView(Context context) {
        super(context);
        init(context);
    }

    public LibTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public LibTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);

    }

    public void init(Context context) {
        if (!ASSERT_FONTS.equals(""))
            if (!isInEditMode()) {
                setTypeface(Typeface.createFromAsset(context.getAssets(), ASSERT_FONTS));
            }
    }
}
