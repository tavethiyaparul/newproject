package com.divinesoftech.calculator.Adapter;



import android.content.Context;
import android.graphics.Typeface;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextClock;
import android.widget.TextView;

import com.divinesoftech.calculator.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class SelectedClockAdapter extends RecyclerView.Adapter<SelectedClockAdapter.SelectedClockHolder> {

    List<String> data_list;
    Context context;



    public SelectedClockAdapter(List<String> data_list,Context context) {
        this.data_list = data_list;
        this.context = context;
    }

    @NonNull
    @Override
    public SelectedClockHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.world_clock_item_frag, null);
        return new SelectedClockHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SelectedClockHolder holder, final int position) {

        TimeZone timeZone = TimeZone.getTimeZone(data_list.get(position));
        Calendar cal = Calendar.getInstance(timeZone);
        cal.setTimeZone(timeZone);
        Date currentLocalTime = cal.getTime();
        DateFormat clock = new SimpleDateFormat("HH:mm:ss a");
        clock.setTimeZone(timeZone);
        String localTime = clock.format(currentLocalTime);

        if (data_list.get(position).contains("/")) {
            String[] parts = data_list.get(position).split("/");
            String part1 = parts[0];
            String part2 = parts[1];
            holder.city.setText(part2);
            holder.region.setText(part1);
        }


        // holder.time.setText(calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND));
       holder.time.setTimeZone(data_list.get(position));
       // holder.time.setText(localTime);
        holder.time.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/DS-DIGI.TTF"));
        holder.standrdtime.setText(timeZone.getDisplayName());


    }

    @Override
    public int getItemCount() {
        return data_list.size();
    }
    public void removeItem(int position) {
        data_list.remove(position);
        // notify the item removed by position
        // to perform recycler view delete animations
        // NOTE: don't call notifyDataSetChanged()

        notifyItemRemoved(position);
    }

    public class SelectedClockHolder extends RecyclerView.ViewHolder {
        public RelativeLayout layout;
        public TextView city, region, standrdtime;
        public TextClock  time;

        public SelectedClockHolder(View itemView) {
            super(itemView);
            layout = (itemView).findViewById(R.id.layout_world);
            city = (itemView).findViewById(R.id.city);
            region = (itemView).findViewById(R.id.region);
            time = (itemView).findViewById(R.id.time);
            standrdtime = (itemView).findViewById(R.id.standard);

        }
    }
}
