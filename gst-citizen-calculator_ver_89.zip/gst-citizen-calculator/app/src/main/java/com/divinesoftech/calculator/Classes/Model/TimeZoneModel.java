package com.divinesoftech.calculator.Classes.Model;

public class TimeZoneModel {

    String Time_Zone_ID,Checked;

    public String getTime_Zone_ID() {
        return Time_Zone_ID;
    }

    public void setTime_Zone_ID(String time_Zone_ID) {
        Time_Zone_ID = time_Zone_ID;
    }

    public String getChecked() {
        return Checked;
    }

    public void setChecked(String checked) {
        Checked = checked;
    }
}
