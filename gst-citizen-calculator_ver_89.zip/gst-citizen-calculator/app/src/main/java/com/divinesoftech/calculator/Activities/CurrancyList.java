package com.divinesoftech.calculator.Activities;

import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;
import static com.divinesoftech.calculator.Common.Utilty.fontstyle;
import static com.divinesoftech.calculator.database.room.RoomDatabaseGstKt.instances;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.countrylist;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.divinesoftech.calculator.Classes.Model.Country;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DataBase_Constant;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.divinesoftech.calculator.mongodb.CountryFlagSync;
import com.divinesoftech.calculator.mongodb.MongodbUtility;
import com.divinesoftech.calculator.mongodb.OnResponseData;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CurrancyList extends AppCompatActivity {

    RecyclerView dialog_recycle;
    RecyclerView.LayoutManager layoutManager;
    EditText search;
    CountryListAdapter countryListAdapter;
    TextView ActionBarTitle;
    ImageView done;
    public List<Country> selectedlist = new ArrayList<>();
    public List<Country> listCurrancy = new ArrayList<>();
    public List<String> demolist = new ArrayList<>();
    public Map<String, Boolean> map_checked = new HashMap<String, Boolean>();
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    RelativeLayout progess;

    SharedPreferences flagPrefs;
    SharedPreferences.Editor flagEditor;


    DatabaseGst databaseGst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentActivity = this;
        setContentView(R.layout.activity_currancy_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);

        databaseGst = new DatabaseGst(CurrancyList.this);

        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = v.findViewById(R.id.action_bar_title);
        done = v.findViewById(R.id.action_done);
        getSupportActionBar().setCustomView(v);
        ActionBarTitle.setText("Currency List");
        //v.findViewById(R.id.gift_layout).setVisibility(View.GONE);

        progess = findViewById(R.id.reletive_progress);

        flagPrefs = getSharedPreferences("flag_prefrence", MODE_PRIVATE);
        flagEditor = flagPrefs.edit();

        sharedPreferences = getSharedPreferences("currancy_list_prefs", MODE_PRIVATE);
        editor = sharedPreferences.edit();


        dialog_recycle = findViewById(R.id.country_list);
        search = findViewById(R.id.search);
        search.setTypeface(fontstyle(this));


        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        dialog_recycle.setLayoutManager(layoutManager);
       /* countryUtility = new CountryUtility();
        if (!TextUtils.isEmpty(flagPrefs.getString("flag_obj", ""))) {
            Gson gson = new Gson();
            countryUtility = gson.fromJson(flagPrefs.getString("flag_obj", ""), CountryUtility.class);


        } else {
            if (isNetworkAvailable(this)) {
                new ListFlagData().execute();
            }

        }*/
        if (instances != null)
            try {
                String data = instances.roomConnectionDao().getRoomConnection(DataBase_Constant.DATA_COUNTRY_FLAG);
                if (data != null && !data.equals("") && countrylist.size() == 0) {
                    MongodbUtility.countrylist = new Gson().fromJson(data, new TypeToken<ArrayList<Country>>() {
                    }.getType());
                }

            } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                try {
                    if (!s.equals("")) {
                        countryListAdapter.getFilter().filter(s);
                    }
                } catch (NullPointerException | NumberFormatException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        String get_saved_list = sharedPreferences.getString("set_shared", "");
        try {
            JSONArray jsonArray = new JSONArray(get_saved_list);
            for (int i = 0; i < jsonArray.length(); i++) {
                if (countrylist.size() > 0)
                    for (Country name : countrylist) {

                        if (name.getName().equals(jsonArray.getString(i))) {
                            Country model = new Country();
                            model.setFlag(name.getFlag());
                            model.setName(name.getName());
                            model.setIndx(i);
                            selectedlist.add(model);
                        }
                    }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        try {
            if (countrylist.size() > 0) {
                int j = 0;
                for (Country add_data : countrylist) {

                    add_data.setIndx(j);
                    listCurrancy.add(add_data);
                    j++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                for (int i = 0; i < countrylist.size(); i++) {

                    if (map_checked.containsKey(listCurrancy.get(i).getName())
                            && map_checked.get(listCurrancy.get(i).getName()).booleanValue() == true) {
                        demolist.add(listCurrancy.get(i).getName());
                    }
                }


                Gson gson = new Gson();
                String shared_list = gson.toJson(demolist);
                editor.putString("set_shared", shared_list);
                editor.apply();

                finish();

            }
        });

        for (int i = 0; i < listCurrancy.size(); i++) {


        }

        //  new AddCountry(CurrancyList.this,listCurrancy,progess).execute();
        if (listCurrancy.size() > 0) {
            countryListAdapter = new CountryListAdapter(listCurrancy, CurrancyList.this);
            dialog_recycle.setAdapter(countryListAdapter);
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }


    @Override
    protected void onResume() {


        super.onResume();
    }

    public class CountryListAdapter extends RecyclerView.Adapter<CountryListAdapter.CountryListViewHolder> implements Filterable {
        List<Country> datalist, namelist;
        Context context;
        CountryCustomFilter filter;


        public CountryListAdapter(List<Country> datalist, Context context) {
            this.datalist = datalist;
            this.namelist = datalist;
            this.context = context;
            for (int i = 0; i < selectedlist.size(); i++) {
                for (int j = 0; j < datalist.size(); j++) {
                    if (datalist.get(j).getName().equalsIgnoreCase(selectedlist.get(i).getName())) {
                        map_checked.put(datalist.get(j).getName(), true);
                    }
                }
            }


        }


        @NonNull
        @Override
        public CountryListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            view = layoutInflater.inflate(R.layout.listrowitem, null);
            return new CountryListViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final CountryListViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            holder.checkBox.setVisibility(View.VISIBLE);


            if (map_checked.containsKey(datalist.get(position).getName()) && map_checked.get(datalist.get(position).getName()).booleanValue() == true) {


                holder.checkBox.setChecked(true);
                map_checked.put(datalist.get(position).getName(), true);

            } else {

                holder.checkBox.setChecked(false);
                map_checked.put(datalist.get(position).getName(), false);
            }


            Glide.with(context)
                    .load(com.divinesoftech.SocketKt.getFLAG_DOMAIN() + datalist.get(position).getFlag())
                    .into(holder.imageView);
            holder.textView.setText(datalist.get(position).getName());


            holder.select_currancy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    done.setVisibility(View.VISIBLE);

                    if (holder.checkBox.isChecked()) {

                        holder.checkBox.setChecked(false);
                        map_checked.put(datalist.get(position).getName(), false);
                    } else if (!holder.checkBox.isChecked()) {

                        holder.checkBox.setChecked(true);
                        map_checked.put(datalist.get(position).getName(), true);
                        //  selectedlist.get(position).setName(datalist.get(position).getName());


                    }

                }
            });

        }

        @Override
        public int getItemCount() {
            return datalist.size();
        }

        @Override
        public Filter getFilter() {
            if (filter == null) {
                filter = new CountryCustomFilter(CountryListAdapter.this, datalist);
                // return filter;
            }

            return filter;
        }

        class CountryListViewHolder extends RecyclerView.ViewHolder {
            public ImageView imageView;
            public TextView textView;
            public LinearLayout select_currancy;
            public CheckBox checkBox;

            public CountryListViewHolder(View itemView) {
                super(itemView);
                imageView = (ImageView) itemView.findViewById(R.id.flag);
                textView = (TextView) itemView.findViewById(R.id.country_name);
                select_currancy = (LinearLayout) itemView.findViewById(R.id.country_item);
                checkBox = (CheckBox) itemView.findViewById(R.id.checkbox_currancy);

            }
        }


    }

    public class CountryCustomFilter extends Filter {

        CountryListAdapter dailogAdapter;
        List<Country> namelist;


        public CountryCustomFilter(CountryListAdapter dailogAdapter, List<Country> namelist) {
            this.dailogAdapter = dailogAdapter;
            this.namelist = namelist;
        }

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if (constraint != null && constraint.length() > 0) {
                //CHANGE TO UPPER
                constraint = constraint.toString().toUpperCase();
                //STORE OUR FILTERED PLAYERS
                List<Country> filteredPlayers = new ArrayList<>();

                for (int i = 0; i < namelist.size(); i++) {
                    //CHECK
                    if (namelist.get(i).getName().toUpperCase().contains(constraint)) {
                        //ADD PLAYER TO FILTERED PLAYERS
                        filteredPlayers.add(namelist.get(i));
                    }
                }

                results.count = filteredPlayers.size();
                results.values = filteredPlayers;
            } else {
                results.count = namelist.size();
                results.values = namelist;

            }


            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            dailogAdapter.datalist = (List<Country>) results.values;

            //REFRESH
            dailogAdapter.notifyDataSetChanged();
        }
    }

    /*private class ListFlagData extends AsyncTask<String, Integer, String> {
        String RESULT = "";

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                OkHttpClient httpClient = new OkHttpClient.Builder()
                        .connectTimeout(10, TimeUnit.SECONDS)
                        .readTimeout(10, TimeUnit.SECONDS)
                        .build();

                Request request = new Request.Builder()
                        .url(importes + CurrancyWidget.buferrs)
                        .build();

                Response response = httpClient.newCall(request).execute();
                return response.body().string();

            } catch (SocketTimeoutException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;

        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (!s.equals("")) {
                Gson gson = new Gson();
                countryUtility = gson.fromJson(s, CountryUtility.class);


            }


        }
    }*/

    void CountryFlagData() {
        new CountryFlagSync(databaseGst, new OnResponseData() {
            @Override
            public void onResponse() {

            }

            @Override
            public void onFailed() {


            }
        }).execute("");

    }


}
