package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomRecords
@Dao
interface RoomRecordsDao {
    @Query("Select * from RoomRecords")
    fun getRoomRecords(): List<RoomRecords>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomRecords(roomVersion: RoomRecords)

    @Update
    fun updateRoomRecords(roomVersion: RoomRecords)

    @Delete
    fun deleteRoomRecords(roomVersion: RoomRecords)
}