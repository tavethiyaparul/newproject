package com.divinesoftech.calculator.Service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.divinesoftech.calculator.Widgets.CurrancyWidget;
import com.divinesoftech.calculator.Widgets.CurrancyWidgetService;

public class ScreenReciever extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {

            try {

                if (context != null)
                    stopWidgetService(context);

            } catch (NullPointerException | IllegalStateException e) {
                e.printStackTrace();
            } catch (RuntimeException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

           /* if (context != null)
                stopWidgetService(context);

*/
        } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {

            try {

                if (context != null)
                    startWidgetService(context);

            } catch (NullPointerException | IllegalStateException e) {
                e.printStackTrace();
            } catch (RuntimeException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void startWidgetService(Context context) {
        Intent i = new Intent(context, CurrancyWidget.class);

            context.startService(i);


    }

    private void stopWidgetService(Context context) {
        Intent i = new Intent(context, CurrancyWidgetService.class);
        context.stopService(i);
    }
}
