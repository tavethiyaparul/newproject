

package com.divinesoftech.calculator.Adapter;

import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.davemorrissey.labs.subscaleview.ImageSource;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import com.divinesoftech.calculator.R;

class PageController extends RecyclerView.ViewHolder {
  private final SubsamplingScaleImageView iv;
  private Bitmap bitmap;

  PageController(View itemView) {
    super(itemView);

    iv=(SubsamplingScaleImageView)itemView.findViewById(R.id.page);
  }

  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  void setPage(PdfRenderer.Page page) {
    if (bitmap==null) {
      int height=2000;
      int width=height * page.getWidth() / page.getHeight();

      bitmap= Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
    }

    bitmap.eraseColor(0xFFFFFFFF);
    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
    iv.resetScaleAndCenter();
    iv.setImage(ImageSource.cachedBitmap(bitmap));
  }
}
