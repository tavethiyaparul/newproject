package com.divinesoftech.calculator.Fragments;

import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.SocketKt.isPrime;
import static com.divinesoftech.calculator.database.ApiKt.isAdsLibsLoad;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.icu.number.LocalizedNumberFormatter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.divinesoftech.calculator.Activities.HistoryActivity;
import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.Activities.TaxSlabs;
import com.divinesoftech.calculator.Classes.HistoryData;
import com.divinesoftech.calculator.Classes.Model.UpdateData;
import com.divinesoftech.calculator.Common.Utilty;
import com.divinesoftech.calculator.CustomAd.ui.AdsInit;
import com.divinesoftech.calculator.JobSechedual.ConstantKt;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.google.android.gms.ads.AdRequest;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;

public class GSTCalculator extends Fragment implements View.OnClickListener {

    View view;
//    LinearLayout google_layout;

    int isAdlodstate = 0, count = 0, tmpcount = 0;
    int j = 0, i = 0;
    StringBuilder FirstBuff = new StringBuilder();
    StringBuilder secondBuff = new StringBuilder();
    StringBuilder tempBuff = new StringBuilder();

    DecimalFormat df = new DecimalFormat("@############");
    DecimalFormat formater = new DecimalFormat("##,##,##,##,###");
    NumberFormat formatter = new DecimalFormat("###.#####");

    HistoryData historyData;
    DatabaseGst databaseGst;


    public static List<HistoryData> historylog_list = new ArrayList<>();

    ArrayList<String> commomArray;
    ArrayList<Double> operandArray;

    ArrayList<Character> operatorArray;
    ArrayList<Double> resultArray;

    ArrayList<Double> operandFirst_history;
    ArrayList<Character> operator_history;
    ArrayList<Double> operandSecond_history;
    ArrayList<Double> result_history;
    ArrayList<Double> grand_total;
    ArrayList<Double> MemoryArray;


    ArrayList<Double> operandArray1;
    ArrayList<Character> operatorArray1;
    ArrayList<Double> resultArray1;

    ArrayList<String> history_array;

    public static List<HashMap<String, String>> result_array = new ArrayList<HashMap<String, String>>();

    char prevOperator = '=', memoryOpretor = '=';
    char tmpprevOperator = '=', tmpmemoryOpretor = '=';
    char savedOperator = '=';
    char tempSavedOperator = '=';
    //    char tmpPrevOperator = '=';
    double savedOperand = 0;
    double tempsavedOperand = 0;
    double result = 0, result_calculate = 0, result_gst = 0, oprand_one = 0, oprand_two = 0, oprand_result = 0, mu_oprand = 0;
    //    double tmpresult = 0, tmpresult_calculate = 0, tmpresult_gst = 0, tmpoprand_one = 0, tmpoprand_two = 0, tmpoprand_result = 0, tmpmu_oprand = 0;
    char oprator;
    Double gst_val, total_gst, gst_val1;
    String gst_dis = "";
    int demo = 0;
    int is_oprand = 0, is_oprand_renew = 0;
    boolean is_equal = false, is_gst = false, is_mu = false, ans_gst = false, ans_equ_gst = false, isCheckRoot = false;
//    public static boolean isCheckHistoryClick = false;

    String GST = "";

    SharedPreferences mPrefs;
    String one = "", two = "";

    String buttonPressed;
    int checkIndex = -1;

    CountDownTimer autoReply;

    private AppCompatTextView mOperatorDisplay, mStepCountDisplay, mgst_aDisplay, mgst_ans, cmgst_aDisplay, cmgst_ans, mDisplay;
    TextView mCalculatorDisplay;
    private String mCalculatorDisplayString = "", mCalculationString = "";

    private double mCalculatorMemory = 0;
    private Dialog dialog_subscribe;
    private UpdateData updateData;


    String t1 = "", preoprandstring = "", pretempstring = "", mCalculatorDisplay1 = "", mCalculatorDisplay2 = "";
    String display1, appkey;
    SharedPreferences sharedPreferences;
    int intval;
    private AudioManager myAudioManager;
    AdRequest adRequest;

    MediaPlayer mp;
    boolean sound, vibrate, gst_panel;
    ImageView history, gift, btn_settings;
    String round;

    public static int history_ad = 0;
    private FirebaseAnalytics fireBase;

    ConstraintLayout M_panel;
    AppCompatButton button_chnge_gst;
    ConstraintLayout gst_panel_enable;

    Bundle bundle;
    View adDevider;
    FrameLayout ad_frame;
    SharedPreferences preferences, slab_prefr;
    List<String> pref_values;
    final String[] defaul_val = {"+3", "+5", "+12", "+18", "+28", "-3", "-5", "-12", "-18", "-28"};
    final int[] ids = {R.id.buttongst3, R.id.buttongst5, R.id.buttongst12, R.id.buttongst18, R.id.buttongst28, R.id.buttongstsub3, R.id.buttongstsub5, R.id.buttongstsub12, R.id.buttongstsub18, R.id.buttongstsub28};
    AppCompatButton plus_one, plus_two, plus_three, plus_four, plus_five;
    public String key;
    Animation animation;
    ImageView locButton;

    SharedPreferences flagPrefs;
    SharedPreferences.Editor flagEditor;
    AdsInit adsInit;
    TextView txtdigits_Main;
    LinearLayout adsPorgress;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fargment_calculator_gst, container, false);

        requireActivity().getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setHasOptionsMenu(true);

        txtdigits_Main = view.findViewById(R.id.textView1);
        adsPorgress = view.findViewById(R.id.adsPorgress);
        mPrefs = getActivity().getSharedPreferences("myVal", MODE_PRIVATE);

        try {
            databaseGst = ((MainActivity) requireActivity()).databaseGst;
        } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
//        google_layout = view.findViewById(R.id.adsContainer);

        animation = AnimationUtils.loadAnimation(getActivity(), R.anim.alpha);


        flagPrefs = getActivity().getSharedPreferences("flag_prefrence", MODE_PRIVATE);
        flagEditor = flagPrefs.edit();

        updateData = new UpdateData();
        fireBase = FirebaseAnalytics.getInstance(getActivity());

        fireBase.setCurrentScreen(getActivity(), getFragmentManager().getClass().getSimpleName(), "Citizen - calculator - fragment");

        adDevider = view.findViewById(R.id.ad_devider);
        preferences = getActivity().getSharedPreferences("update", MODE_PRIVATE);

        historylog_list.clear();


        Gson gson = new Gson();
        String json = mPrefs.getString("MyObject", "");
//        HistoryData obj = gson.fromJson(json, HistoryData.class);
        if (json != "") {
            Type listOfHistoryType = new TypeToken<List<HistoryData>>() {
            }.getType();
            ArrayList<HistoryData> myhistory = gson.fromJson(json, listOfHistoryType);


            historylog_list.addAll(myhistory);

        } else {
        }


        historyData = new HistoryData();
        gst_panel_enable = view.findViewById(R.id.gst_stab_1);
        M_panel = view.findViewById(R.id.row3);
        button_chnge_gst = view.findViewById(R.id.button_chnge_gst);

        slab_prefr = getActivity().getSharedPreferences("slab_values", MODE_PRIVATE);
        pref_values = new ArrayList<>();


        SharedPreferences prefs = getActivity().getSharedPreferences("MyPref", MODE_PRIVATE);
        sound = prefs.getBoolean("is_sound", true);

        SharedPreferences vibrate_prefs = getActivity().getApplicationContext().getSharedPreferences("MyPref_vibrstion", MODE_PRIVATE);
        vibrate = vibrate_prefs.getBoolean("is_vibrate", true);

        SharedPreferences gst_prefs = getActivity().getApplicationContext().getSharedPreferences("MyPref_gst_panel", MODE_PRIVATE);
        gst_panel = gst_prefs.getBoolean("is_gst_panel", true);
        SharedPreferences change_view = getActivity().getApplicationContext().getSharedPreferences("change_view", MODE_PRIVATE);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        switch (change_view.getInt("view_type", 3)) {
            case 0:
                if (isNetworkAvailable(getActivity()) && isAdsLibsLoad()) {
                    if (!isPrime()) {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.28);
                    } else {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.35);
                    }
                } else {
                    txtdigits_Main.getLayoutParams().height = (int) (height * 0.35);
                }
                txtdigits_Main.invalidate();
                txtdigits_Main.requestFocus();
                button_chnge_gst.setVisibility(View.INVISIBLE);
                gst_panel_enable.setVisibility(View.GONE);
                M_panel.setVisibility(View.GONE);
                break;
            case 1:

                if (isNetworkAvailable(getActivity()) && isAdsLibsLoad()) {
                    if (!isPrime()) {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.22);
                    } else {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.28);
                    }
                } else {
                    txtdigits_Main.getLayoutParams().height = (int) (height * 0.28);
                }
                txtdigits_Main.invalidate();
                txtdigits_Main.requestFocus();
                button_chnge_gst.setVisibility(View.INVISIBLE);
                gst_panel_enable.setVisibility(View.GONE);
                M_panel.setVisibility(View.VISIBLE);
                break;
            case 2:

                if (isNetworkAvailable(getActivity()) && isAdsLibsLoad()) {
                    if (!isPrime()) {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.15);
                    } else {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.22);
                    }
                } else {
                    txtdigits_Main.getLayoutParams().height = (int) (height * 0.22);
                }
                txtdigits_Main.invalidate();
                txtdigits_Main.requestFocus();
                gst_panel_enable.setVisibility(View.VISIBLE);
                M_panel.setVisibility(View.GONE);
                break;
            default:

                if (isNetworkAvailable(getActivity()) && isAdsLibsLoad()) {
                    if (!isPrime()) {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.135);
                    } else {
                        txtdigits_Main.getLayoutParams().height = (int) (height * 0.185);
                    }
                } else {
                    txtdigits_Main.getLayoutParams().height = (int) (height * 0.185);
                }
                txtdigits_Main.invalidate();
                txtdigits_Main.requestFocus();
                gst_panel_enable.setVisibility(View.VISIBLE);
                M_panel.setVisibility(View.VISIBLE);
                break;
        }


        SharedPreferences prefs_round = getActivity().getApplicationContext().getSharedPreferences("MyPref_round", MODE_PRIVATE);
        round = prefs_round.getString("is_round", "");


        if (round.equals("")) {
            round = String.valueOf(3);
        }


        myAudioManager = (AudioManager) getActivity().getSystemService(Context.AUDIO_SERVICE);

        sharedPreferences = getActivity().getSharedPreferences("isvibrate", MODE_PRIVATE);
        intval = sharedPreferences.getInt("Ad_value", isAdlodstate);
        isAdlodstate = intval;


        operandArray = new ArrayList<>();
        operatorArray = new ArrayList<>();
        resultArray = new ArrayList<>();
        history_array = new ArrayList<>();
        MemoryArray = new ArrayList<>();

        operandFirst_history = new ArrayList<>();
        operator_history = new ArrayList<>();
        operandSecond_history = new ArrayList<>();
        result_history = new ArrayList<>();
        grand_total = new ArrayList<>();


        operandArray1 = new ArrayList<>();
        operatorArray1 = new ArrayList<>();
        resultArray1 = new ArrayList<>();

        try {
            mp = MediaPlayer.create(getActivity(), R.raw.click2);
        } catch (NullPointerException | Resources.NotFoundException e) {

        } catch (Exception e) {
            e.printStackTrace();
        }


        mDisplay = view.findViewById(R.id.Msymbol);
        //mDisplay.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/DS-DIGI.TTF"));

        mCalculatorDisplay = view.findViewById(R.id.textView1);
        mCalculatorDisplay.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));

        mOperatorDisplay = view.findViewById(R.id.textView2);
        mOperatorDisplay.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));

        mStepCountDisplay = view.findViewById(R.id.stepCount);
        mStepCountDisplay.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));

        mgst_aDisplay = view.findViewById(R.id.gst_a);
        mgst_aDisplay.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));

        mgst_ans = view.findViewById(R.id.gst_gst);
        mgst_ans.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));

        cmgst_aDisplay = view.findViewById(R.id.cgst_a);
        cmgst_aDisplay.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));

        cmgst_ans = view.findViewById(R.id.cgst_gst);
        cmgst_ans.setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/DS-DIGI.TTF"));


        df.setMinimumFractionDigits(0);
        df.setMaximumFractionDigits(12);
        df.setMinimumIntegerDigits(1);
        df.setMaximumIntegerDigits(12);


        view.findViewById(R.id.button0).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button1).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button2).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button3).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button4).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button5).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button6).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button7).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button8).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button9).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonAdd).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonSubtract).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonMultiply).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonDivide).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonToggleSign).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonDecimalPoint).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonEquals).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonClear).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonAddToMemory).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonSubtractFromMemory).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonRecallMemory).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonModulas).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonCheck).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonCorrect).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonGT).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonRoot).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttonMU).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.button_chnge_gst).setOnClickListener(GSTCalculator.this);
        plus_one = view.findViewById(R.id.buttongst3);
        plus_one.setOnClickListener(GSTCalculator.this);
        plus_two = view.findViewById(R.id.buttongst5);
        plus_two.setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongst12).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongst18).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongst28).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongstsub3).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongstsub5).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongstsub12).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongstsub18).setOnClickListener(GSTCalculator.this);
        view.findViewById(R.id.buttongstsub28).setOnClickListener(GSTCalculator.this);
        setpref(view);
        view.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                requireActivity().getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                return true;
            }
            return false;
        });
        return view;
    }


    private void long_click(final int i, View view) {
        final AppCompatButton button = view.findViewById(i);
        button.setOnLongClickListener(v -> {
            Intent intent = new Intent(getActivity(), TaxSlabs.class);
            getActivity().startActivity(intent);
            return true;
        });
    }

    public boolean verifyAllEqualUsingALoop(List<String> list) {
        for (String s : list) {
            if (!s.equals(list.get(0)))
                return false;
        }
        return true;
    }

    public void history() {

//        isCheckHistoryClick = true;
        try {
            if (vibrate) {
                ((Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE)).vibrate(50);
            }

            if (sound) {
                myAudioManager.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.7F);
            }
        } catch (NullPointerException | Resources.NotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        is_oprand = 0;
        is_oprand_renew = 1;
        count = 0;


        if (!is_equal) {

            if (!is_gst) {

                if (is_mu) {
//                    Log.e("@@@@@@", "onClick is_mu iffff: ");
//                    Log.e("@@@@@@", "onClick is_mu iffff mu_oprand: " + mu_oprand);
//                    Log.e("@@@@@@", "onClick is_mu iffff gst_text(GST): " + gst_text(GST));
//                    Log.e("@@@@@@", "onClick is_mu iffff oprand_two: " + oprand_two);
//                    Log.e("@@@@@@", "onClick is_mu iffff result_calculate: " + result_calculate);
//                    Log.e("@@@@@@", "onClick is_mu iffff tempSavedOperator: " + tempSavedOperator);

                    char c = 0;

//                    try {
                    for (int k = 0; k < operator_history.size(); k++) {
                        c = operator_history.get(k);

                    }
//                    Log.e("======", "history operator_history: " + operator_history);
//                    Log.e("======", "history operatorArray: " + operatorArray);
//                    for (int k = 0; k < operatorArray.size(); k++) {
//
//                        Log.e("STRRRRRR", "onClick is_mu iffff c:operatorArray " + operatorArray.get(k) + ":k:" + k);
//
//                    }
                    Log.e("@@@@@@", "operator_history:onClick is_mu iffff oprand_one: " + oprand_one);
                    Log.e("@@@@@@", "onClick is_mu iffff c: " + c);
                    Log.e("@@@@@@", "onClick is_mu iffff tempSavedOperator: " + tempSavedOperator);
                    Log.e("@@@@@@", "onClick is_mu iffff oprand_two: " + oprand_two);
                    Log.e("@@@@@@", "onClick is_mu iffff gst_text(GST): " + gst_text(GST));
                    Log.e("@@@@@@", "onClick is_mu iffff result_calculate: " + result_calculate);
                    Log.e("@@@@@@", "operator_history:onClick is_mu iffff tempsavedOperand: " + tempsavedOperand);
//                    } catch (Exception e) {
//
//                    }

                    boolean isMUFirst = false;
                    int isMUAdd = 0;
                    int isMUCount = 0;


                    ArrayList<Integer> indexMUSize = new ArrayList<>();
                    ArrayList<String> isMuEqualOrNotArr = new ArrayList<>();

                    boolean isMuEqualOrNot = false;


                    for (i = 0; i < operator_history.size() - 1; i++) {

                        if ('M' == operator_history.get(i)) {
                            try {
                                int indexPrev = i - 1;
                                int indexObj = operator_history.get(indexPrev);
                                if ('=' == indexObj) {
                                    isMuEqualOrNotArr.add("0");
                                } else {
                                    isMuEqualOrNotArr.add("1");
                                }
                            } catch (IndexOutOfBoundsException e) {
                            } catch (Exception e) {
                            }

                        }
                    }

                    isMuEqualOrNot = verifyAllEqualUsingALoop(isMuEqualOrNotArr);
                    Log.e("=====", "history:verifyAllEqualUsingALoop " + isMuEqualOrNot);


                    if (isMuEqualOrNot) {
                        for (i = 0; i <= operator_history.size() - 1; i++) {

                            if ('M' == operator_history.get(i)) {
                                isMUCount++;
                                int indexPrev = i - 1;
                                int indexObj = operator_history.get(indexPrev);


                                if ('=' == indexObj) {
                                    int pos = i + isMUAdd;
                                    indexMUSize.add(pos);
                                    int posNew = pos + 3;
                                    indexMUSize.add(posNew);
                                    Log.e("====", "history:pos::::== pos:" + pos + ":i:" + i + ":isMUAdd:" + isMUAdd + ":posNew:" + posNew + ":isMUCount:" + isMUCount);
                                    isMUAdd = isMUCount + 2;
                                } else {
                                    int pos = i + isMUAdd;
                                    int posNew = pos + 2;
                                    Log.e("====", "history:pos::::!= pos:" + pos + ":i:" + i + ":isMUAdd:" + isMUAdd + ":posNew:" + posNew + ":isMUCount:" + isMUCount);
                                    indexMUSize.add(posNew);
                                    isMUAdd = isMUCount;
                                }

                            } else {
                                Log.e("=====", "history:size:indexMUSize:::::else " + i + ":" + ":" + isMUAdd);
                            }

                        }
                    } else {
                        for (i = 0; i <= operator_history.size() - 1; i++) {


                            if ('M' == operator_history.get(i)) {
                                try {


//                                isMUCount++;
                                    int indexPrev = i - 1;
                                    int indexObj = operator_history.get(indexPrev);


                                    if ('=' == indexObj) {
                                        int pos = i + isMUAdd;
                                        indexMUSize.add(pos);
                                        int posNew = pos + 3;
                                        indexMUSize.add(posNew);
                                        Log.e("====", "history:pos::::== pos:" + pos + ":i:" + i + ":isMUAdd:" + isMUAdd + ":posNew:" + posNew + ":isMUCount:" + isMUCount);
//                                    isMUAdd = isMUCount + 2;
                                    } else {
                                        int pos = i + isMUAdd;
                                        int posNew = pos + 2;
                                        Log.e("====", "history:pos::::!= pos:" + pos + ":i:" + i + ":isMUAdd:" + isMUAdd + ":posNew:" + posNew + ":isMUCount:" + isMUCount);
                                        indexMUSize.add(posNew);
//                                    isMUAdd = isMUCount;
                                    }
                                    Log.e("=====", "history:size:indexMUSize:::::if:bf " + ":" + ":" + isMUAdd + ":" + isMUCount + ":");

                                    isMUAdd = isMUAdd + 2;
                                    Log.e("=====", "history:size:indexMUSize:::::if:af " + ":" + ":" + isMUAdd + ":" + isMUCount + ":");
                                } catch (IndexOutOfBoundsException e) {
                                } catch (Exception e) {

                                }
                            } else {
                            }

                        }

                    }


                    ArrayList<Double> operandArrayTemp = new ArrayList<>();
                    operandArrayTemp.addAll(operandArray);
                    Collections.reverse(indexMUSize);
                    try {

                        indexMUSize.remove(0);
                    } catch (IndexOutOfBoundsException e) {
                    }
                    Log.e("=====", "history:size:indexMUSize " + indexMUSize);
                    Log.e("=====", "history:sizeoperandArrayTemp " + ":" + operandArray + "===:===" + operandArrayTemp);

                    try {

                        for (i = 0; i <= indexMUSize.size() - 1; i++) {
                            Log.e("=====", "history:size:index:remove:before " + "===:===" + operandArrayTemp + ":i:" + indexMUSize.get(i));
                            int index = indexMUSize.get(i);
                            operandArrayTemp.remove(index);
                            Log.e("=====", "history:size:index:remove:after " + "===:===" + operandArrayTemp);
                        }

                        Log.e("=====", "history:size:operandArrayTemp:after " + operandArrayTemp.size() + ":");
                        Log.e("=====", "history:size " + indexMUSize.size() + ":" + operator_history + "===:===" + operandArray + "==:==" + operandArrayTemp);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    ArrayList<String> operandArrayTempNew = new ArrayList<>();
                    ArrayList<String> operandArrayTempNewFinal = new ArrayList<>();

                    for (i = 0; i <= operandArrayTemp.size() - 1; i++) {
                        String str = operandArrayTemp.get(i).toString();
                        operandArrayTempNew.add(str);
                        if (operandArrayTemp.size() - 1 != i) {
                            str = operator_history.get(i).toString();
                            operandArrayTempNew.add(str);
                        }
                    }
                    Log.e("STRRRRRR", "history:operandArrayTempNew:before " + operandArrayTempNew);

                    for (i = 0; i <= operandArrayTempNew.size() - 1; i++) {

                        if (i == 0) {
                            operandArrayTempNewFinal.addAll(operandArrayTempNew);
                        }
                        if ("M".equals(operandArrayTempNew.get(i))) {


                            int indexPrevData = i - 1;
                            String indexObj = operandArrayTempNew.get(indexPrevData);

                            if ("=".equals(indexObj)) {
                                int indexPrev = i - 1;
                                int indexPrevOfPrev = i - 2;
                                String colon = ":";

                                Log.e("STRRRRRR", "history: indexPrev:data" + ":" + indexPrev + ":" + operandArrayTempNew.get(indexPrev) + ":" + i);
                                Log.e("STRRRRRR", "history: indexPrev" + ":" + indexPrevOfPrev + ":" + operandArrayTempNew.get(indexPrevOfPrev) + ":" + i);

                                operandArrayTempNewFinal.add(indexPrevOfPrev + 2, operandArrayTempNew.get(indexPrev));
                                operandArrayTempNewFinal.add(indexPrev + 1, colon);

                                Log.e("STRRRRRR", "history: indexPrev:data:if" + ":" + indexPrevData + ":" + operandArrayTempNew.get(indexPrevData) + ":" + i + ":" + indexObj);
                            } else {


                                int ii = 0;
                                int count1 = 0;
                                int count2 = 4;
                                String valueTemp = "0";
                                String value = "0";
                                Double valueFinal = 0.0;
                                char valueOprand = ' ';
                                boolean ismu = false;
                                int isMUAddNext = 0;
                                int isMUNext = -1;
                                int indexPrev = 0;
                                int indexPrevOfPrev = 0;
                                int isMUNextAdd = 0;


                                for (i = 0; i <= operandArrayTempNew.size() - 1; i++) {
                                    Log.e("=====", "history:operandArrayTempNew:i " + i + ":" + operandArrayTempNew.get(i));

                                    ii = i;

                                    if ("M".equals(operandArrayTempNew.get(ii))) {
                                        Log.e("=====", "history:!!!!!!!:if:bf:M " + ii);
                                        ismu = true;


                                        indexPrev = ii + isMUNextAdd;
                                        indexPrevOfPrev = ii + isMUNextAdd;

                                        String colon = ":";

                                        operandArrayTempNewFinal.add(indexPrevOfPrev, valueFinal.toString());
                                        operandArrayTempNewFinal.add(indexPrev, colon);

                                        isMUAddNext = ii + 3;

                                        count1 = ii + count2;


                                        isMUNextAdd = isMUNextAdd + 2;

                                    } else {


                                        if (!ismu) {

                                            int posOprand = 0;
                                            value = operandArrayTempNew.get(ii);

                                            Log.e("=====", "history:isMUNext:i:value " + isMUNext + ":" + ii + ":" + value + ":" + valueFinal);

                                            if (ii != 0 || ii == isMUNext) {
                                                posOprand = ii - 1;
                                                valueOprand = operandArrayTempNew.get(posOprand).charAt(0);
                                                Log.e("=====ismu", "history:isMUNext:i:value::::::::::::: " + isMUNext + ":" + ii + ":" + value + ":" + valueFinal);

                                                switch (valueOprand) {
                                                    case '+':
                                                        valueFinal = valueFinal + Double.parseDouble(value);
                                                        Log.e("=====ismu", "history:value:valueOprand:if(+) " + valueFinal + ":" + value + ":" + valueFinal + ":" + ii + ":" + operandArrayTempNew.get(ii));
                                                        break;
                                                    case '-':
                                                        valueFinal = valueFinal - Double.parseDouble(value);
                                                        Log.e("=====ismu", "history:value:valueOprand:if(-) " + valueFinal + ":" + value + ":" + valueFinal);
                                                        break;
                                                    case 'x':
                                                        Log.e("=====ismu", "history:value:valueOprand:if(x):bf " + valueFinal + ":" + value + ":" + valueFinal);

                                                        valueFinal = valueFinal * Double.parseDouble(value);
                                                        Log.e("=====ismu", "history:value:valueOprand:if(x):af " + valueFinal + ":" + value + ":" + valueFinal);

                                                        break;
                                                    case '÷':
                                                        Log.e("=====ismu", "history:value:valueOprand:if(/):bf " + valueFinal + ":" + value + ":" + valueFinal);

                                                        valueFinal = valueFinal / Double.parseDouble(value);
                                                        Log.e("=====ismu", "history:value:valueOprand:if(/):af " + valueFinal + ":" + value + ":" + valueFinal);

                                                        break;

                                                    default:
                                                        Log.e("=====", "history:value:valueOprand:else " + ii + ":" + posOprand + ":" + valueFinal);
                                                        break;
                                                }
                                            } else {
                                                valueFinal = Double.parseDouble(operandArrayTempNew.get(ii));
                                                Log.e("=====ismu", "history:isMUNext:i:value:://///:: " + isMUNext + ":" + ii + ":" + value + ":" + valueFinal);
                                                Log.e("=====ismu", "history:value:valueOprand:if@@@@@@@@@@@@@@:else " + isMUNext + ":" + ii + ":" + valueOprand);


                                            }
                                            Log.e("=====", "history:isMUNext:i " + isMUNext + ":" + i + ":" + valueFinal + ":" + value);

                                        } else {
                                            if ("%".equals(operandArrayTempNew.get(ii))) {
                                                valueFinal = Double.parseDouble(operandArrayTempNew.get(isMUAddNext));
                                                Log.e("=====", "history:valueFinal%%%%%%%% " + valueFinal + ":" + isMUAddNext);
                                                if (operandArrayTempNew.size() >= count1) {
                                                    ismu = false;
                                                    isMUNext = ii;
                                                }
                                            }
                                        }

                                    }


                                }

                                Log.e("STRRRRRR", "history: indexPrev:data:else" + ":" + indexPrevData + ":" + operandArrayTempNew.get(indexPrevData) + ":" + i + ":" + indexObj);
                            }


                        }


                    }
                    for (i = 0; i <= operandArrayTempNewFinal.size() - 1; i++) {
                        if (i % 2 == 0) {
                            secondBuff.append(operandArrayTempNewFinal.get(i)).append("\n");

                        } else {
                            secondBuff.append(operandArrayTempNewFinal.get(i)).append("\t");

                        }
                    }

                    Log.e("STRRRRRR", "history:operandArrayTempNew " + operandArrayTempNew);
                    Log.e("STRRRRRR", "history:operandArrayTempNewFinal " + operandArrayTempNewFinal);
                    Log.e("STRRRRRR", "history:operandArrayTempNewFinal:secondBuff" + secondBuff);


                    is_mu = false;

                } else {

                    Log.e("@@@@@@", "onClick is_mu elseee: ");
                    for (int i = 0; i < operator_history.size() && i < operandFirst_history.size(); i++) {

                        if ((buttonPressed.compareTo("=") == 0)) {

                            Log.e("777777777777", "history oprand_one: " + oprand_one);
                            Log.e("777777777777", "history gst_text(GST): " + gst_text(GST));
                            Log.e("777777777777", "history oprand_two: " + oprand_two);
                            Log.e("777777777777", "history oprand_result: " + oprand_result);

//                            secondBuff.append("\n" + oprand_one + "\n"
//                                    + gst_text(GST) + "      " +
//                                    oprand_two + "\n" +
//                                    "---------------------------"
//                                    + "\n" + oprand_result + "\n");

                            secondBuff.append("\n" + oprand_one + "\n"
                                    + tmpprevOperator + "      " +
                                    oprand_two + "\n" +
                                    "---------------------------"
                                    + "\n" + "=" + "      " + result_calculate + "\n");

                            is_gst = false;

                            Log.e("????", "for (is_gst = false; secondBuff: " + secondBuff);
                        } else {

                            Log.e("TAG:::::::", "onClick another click elseeee beloww: ");
                        }


                    }
                }
            } else {

                if ((buttonPressed.compareTo("=") == 0)) {

                    Log.e("777777777777", "history nnnn oprand_one: " + oprand_one);
                    Log.e("777777777777", "history nnnn gst_text(GST): " + gst_text(GST));
                    Log.e("777777777777", "history nnnn oprand_two: " + oprand_two);
                    Log.e("777777777777", "history nnnn oprand_result: " + oprand_result);

                    secondBuff.append("\n" + oprand_one + "\n"
                            + gst_text(GST) + "      " +
                            oprand_two + "\n" +
                            "---------------------------"
                            + "\n" + oprand_result + "\n");

                    is_gst = false;

                    Log.e("????", "for (is_gst = false; secondBuff: " + secondBuff);
                } else {
                    Log.e("TAG:::::::", "onClick another click elseeee beloww: ");
                }


            }
            if (secondBuff.length() != 0) {

                Log.e("######", "secondBuff: " + secondBuff);

                historyData = new HistoryData();
                historyData.setFirst_oprand(secondBuff.toString());

                Log.e("######", "history secondBuff.length(): " + historyData.getFirst_oprand());
                Log.e("######", "history historyData.getOprator(): " + historyData.getOprator());

                historylog_list.add(0, historyData);

                SharedPreferences.Editor prefsEditor = mPrefs.edit();
                Gson gson = new Gson();
                String json = gson.toJson(historylog_list);
                prefsEditor.putString("MyObject", json);
                prefsEditor.apply();

                Log.e("~~~~~~", "json secondBuff: " + json);
                Log.e("~~~~~~", "history size secondBuff: " + historylog_list.size());

                operandFirst_history.clear();
                operator_history.clear();
                operandSecond_history.clear();
                result_history.clear();
                secondBuff.setLength(0);
                secondBuff.trimToSize();

            }

        } else {
            if (operator_history.size() > 2) {

                operator_history.add(0, ' ');

                for (int i = 0; i < operandFirst_history.size() && i < operator_history.size(); i++) {
                    if ((buttonPressed.compareTo("=") == 0)) {

                        FirstBuff.append(gst_text(operator_history.get(i).toString()) + "      " +
                                operandFirst_history.get(i) + "\n");

                    }
                }


            } else {

                if (!isCheckRoot) {

                    char c = 0;
                    try {
                        for (int k = 0; k < operator_history.size(); k++) {
                            c = operator_history.get(i);
                            Log.e("######", "history for FirstBuff  operator_history:c " + c + ":" + result_calculate);

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if ((buttonPressed.compareTo("=") == 0)) {


//                        if (tmpoprand_one != 0.0) {
//                    if (!isCheckHistoryClick) {
//
//                        Log.e("TAG====", "history iff isCheckHistoryClick: " + isCheckHistoryClick);
//
//                        FirstBuff.append("\n" + tmpoprand_one + "\n"
//                                + c + "      " +
//                                tmpoprand_two + "\n" +
//                                "---------------------------"
//                                + "\n" + prevOperator + "      " + tmpresult_calculate + "\n");
//                    } else {
                       /* char c1 = 0;
                        try {
                            for (int k = 0; k < operator_history.size(); k++) {
                                c1 = operator_history.get(i);
                                Log.e("######", "history for FirstBuff  operator_history:c1 " + c1 + ":" + result_calculate);

                            }
                        } catch (Exception e) {

                        }*/
//                        Log.e("TAG====", "history elsee isCheckHistoryClick: " + isCheckHistoryClick);
//                        if (oprand_one != 0.0) {


                        FirstBuff.append("\n" + oprand_one + "\n"
                                + c + "      " +
                                oprand_two + "\n" +
                                "---------------------------"
                                + "\n" + prevOperator + "      " + result_calculate + "\n");
//                        } else {
//                            FirstBuff.append("\n" + tmpoprand_one + "\n"
//                                    + c + "      " +
//                                    tmpoprand_two + "\n" +
//                                    "---------------------------"
//                                    + "\n" + prevOperator + "      " + tmpresult_calculate + "\n");
//                        }

//                    }


                        Log.e("######", "history for FirstBuff  for (int k = 0; k < operator_history.size(): " + FirstBuff);
                    } else {
                        Log.e("TAG:::::::", "onClick another click elseeee beloww: ");
                    }


                } else {
                    isCheckRoot = false;
                    Log.e("######", "history for FirstBuff  for (int k = 0; k < operator_history.size() elseeee: " + FirstBuff);
                }


            }
            if (operator_history.size() > 2) {

                if ((buttonPressed.compareTo("=") == 0)) {
                    FirstBuff.append("---------------------------" + "\n" + "=" + "      " +
                            result_calculate + "\n");
                }


                if (ans_gst && !is_gst) {

                    if ((buttonPressed.compareTo("=") == 0)) {

                        FirstBuff.append("\n" + oprand_one + "\n"
                                + gst_text(GST) + "      " +
                                oprand_two + "\n" +
                                "---------------------------"
                                + "\n" + oprand_result + "\n");
                        ans_gst = false;

                        Log.e("######", "history for FirstBuff ans_gst && !is_gst: " + FirstBuff);
                    } else {
                        Log.e("TAG:::::::", "onClick another click elseeee beloww: ");
                    }

                }
            }

            if (FirstBuff.length() != 0) {
                historyData = new HistoryData();
                Log.e("######", "history FirstBuff: " + FirstBuff);

                historyData.setFirst_oprand(FirstBuff.toString());

                Log.e("######", "history FirstBuff.length(): " + historyData.getFirst_oprand());
                historylog_list.add(0, historyData);

                SharedPreferences.Editor prefsEditor = mPrefs.edit();
                Gson gson = new Gson();
                String json = gson.toJson(historylog_list);
                prefsEditor.putString("MyObject", json);
                prefsEditor.apply();
                Log.e("~~~~~~", "json FirstBuff: " + json);
                Log.e("~~~~~~", "history size FirstBuff: " + historylog_list.size());
//                historylog_list.clear();

                operandFirst_history.clear();
                operator_history.clear();
                operandSecond_history.clear();
                result_history.clear();
                FirstBuff.setLength(0);
                FirstBuff.trimToSize();
            }
            is_equal = false;
        }


        ConstantKt.setDoubleBackToExitPressedOnce(false);
        Intent intent = new Intent(getActivity(), HistoryActivity.class);
        startActivity(intent);


//        isCheckHistoryClick=false;
    }

    public double round_off(String case_id, Double round_val) {
        switch (case_id) {
            case "Round-off":
                round_val = Math.round(round_val * 1d) / 1d;
                break;
            case "1":
                round_val = Math.round(round_val * 10d) / 10d;
                break;
            case "2":
                round_val = Math.round(round_val * 100d) / 100d;
                break;
            case "3":
                round_val = Math.round(round_val * 1000d) / 1000d;
                break;
            case "4":
                round_val = Math.round(round_val * 10000d) / 10000d;
                break;
            case "5":
                round_val = Math.round(round_val * 100000d) / 100000d;
                break;
            default:
                break;
        }
        return round_val;
    }

    public String gst_text(String gst) {
        if (gst.equalsIgnoreCase("A")) {
            if (gst.equals("A")) {
                gst = pref_values.get(0);
            } else {
                gst = pref_values.get(5);
            }
        } else if (gst.equalsIgnoreCase("B")) {
            if (gst.equals("B")) {
                gst = pref_values.get(1);
            } else {
                gst = pref_values.get(6);
            }
        } else if (gst.equalsIgnoreCase("C")) {
            if (gst.equals("C")) {
                gst = pref_values.get(2);
            } else {
                gst = pref_values.get(7);
            }
        } else if (gst.equalsIgnoreCase("D")) {
            if (gst.equals("D")) {
                gst = pref_values.get(3);
            } else {
                gst = pref_values.get(8);
            }
        } else if (gst.equalsIgnoreCase("E")) {
            if (gst.equals("E")) {
                gst = pref_values.get(4);
            } else {
                gst = pref_values.get(9);
            }
        } else if (gst.equalsIgnoreCase("M")) {
            if (gst.equals("M")) {
                gst = "MU";
            } else {
                gst = "MU";
            }
        } else {
            return gst;
        }

        return gst;
    }

    public static Double sum_tot(List<Double> list) {
        Double sum = 0.0;

        for (Double i : list) {
            sum += i;
        }
        return sum;
    }

    public void clearall() {

        operandFirst_history.clear();
        operator_history.clear();
        operandSecond_history.clear();
        result_history.clear();
        MemoryArray.clear();

        FirstBuff.setLength(0);
        FirstBuff.trimToSize();

        secondBuff.setLength(0);
        secondBuff.trimToSize();

        Log.e("######", "clearall oprand_one up:::: " + oprand_one);
        Log.e("######", "clearall oprand_two up:::: " + oprand_two);
        Log.e("######", "clearall mu_oprand up:::: " + mu_oprand);
        Log.e("######", "clearall oprand_result up:::: " + oprand_result);
        Log.e("######", "clearall result_calculate up:::: " + result_calculate);
        Log.e("######", "clearall result_gst up:::: " + result_gst);
        Log.e("######", "clearall count up:::: " + count);

//        if (!isCheckHistoryClick) {
//
//            Log.e("TAG====", "clearall ifff isCheckHistoryClick: " + isCheckHistoryClick);
//
//            tmpoprand_one = oprand_one;
//            tmpoprand_two = oprand_two;
//            tmpmu_oprand = mu_oprand;
//            tmpoprand_result = mu_oprand;
//            tmpresult_calculate = result_calculate;
//            tmpresult_gst = result_gst;
//            tmpcount = count;
//            isCheckHistoryClick = false;

//        } else {
//            Log.e("TAG====", "clearall elsee isCheckHistoryClick: " + isCheckHistoryClick);
////            isCheckHistoryClick = false;
//           /* tmpoprand_one = 0;
//            tmpoprand_two = 0;
//            tmpmu_oprand = 0;
//            tmpoprand_result = 0;
//            tmpresult_calculate = 0;
//            tmpresult_gst = 0;
//            tmpcount = 0;*/
//        }
        oprand_one = 0;
        oprand_two = 0;
        mu_oprand = 0;
        oprand_result = 0;
        result_calculate = 0;
        result_gst = 0;
        count = 0;

    }

    public void menuUpdate() {
        if (requireActivity() == null && requireActivity().isFinishing()) return;
        if (isPrime())
            isGiftVisible = false;
        else isGiftVisible = ((MainActivity) requireActivity()).getListDetailsMain().size() > 0;
        requireActivity().invalidateOptionsMenu();
    }

    boolean isGiftVisible = false;

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        MenuItem giftItem = menu.findItem(R.id.action_gift);
        giftItem.setVisible(isGiftVisible);
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.citizen_calculator_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    public boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE));
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_gift:
                item.setEnabled(false);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        item.setEnabled(true);
                    }
                }, 2000);

                if (isNetworkAvailable(getActivity())) {
                    ((MainActivity) requireActivity()).SubscribeDilog();
                } else {
                    Toast.makeText(getActivity(), "Check Internet Connectivity", Toast.LENGTH_SHORT).show();
                }
                return true;

            case R.id.action_history:
                item.setEnabled(false);
                if (isPrime()) {
                    history();
                } else
                    ((MainActivity) getActivity()).historyClick(() -> {
                        item.setEnabled(true);
                        history();
                        return null;
                    });
                return true;

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        try {
            count++;

            if (mCalculatorDisplayString.length() >= 10) {
                mCalculatorDisplay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 50);
            } else {
                mCalculatorDisplay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 60);
            }

            if (vibrate) {
                ((Vibrator) requireActivity().getSystemService(Context.VIBRATOR_SERVICE)).vibrate(50);
            }

            if (sound) {
                myAudioManager.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.7F);
            }

            buttonPressed = ((Button) v).getText().toString();
            // int buttonpress = v.getId();


            Log.e("buttonPressed:", "onClick: " + buttonPressed);

            if (buttonPressed.compareTo("Check") != 0) {
                if (buttonPressed.compareTo("=") != 0)
                    checkIndex = -1;
                else if (checkIndex >= 0) { //Pressing '=' will show current result while checking
                    mCalculatorDisplay.setText(df.format(resultArray.get(checkIndex)));
                    mOperatorDisplay.setText("=");
                    return;
                }
            }
            if (buttonPressed.compareTo("Auto Replay") == 0) {
                if (autoReply != null)
                    return;
            } else if (autoReply != null) {
                autoReply.cancel();
                autoReply = null;
                mOperatorDisplay.setText((mCalculatorDisplayString.compareTo("") == 0) ?
                        operatorArray.get(operatorArray.size()).toString() : " ");
                mCalculatorDisplay.setText((mCalculatorDisplayString.compareTo("") == 0) ?
                        df.format(resultArray.get(resultArray.size() - 1)) : mCalculatorDisplayString);
                mStepCountDisplay.setText(df.format(resultArray.size() + ((mCalculatorDisplayString.compareTo("") == 0) ? 0 : 1)));
            }
            if (buttonPressed.compareTo(getResources().getString(R.string.button_chnge_gst)) == 0) {

                v.setClickable(false);
                Intent intent = new Intent(getActivity(), TaxSlabs.class);
                getActivity().startActivity(intent);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        v.setClickable(true);
                    }
                }, 2000);


            }


            if (buttonPressed.equals(pref_values.get(0) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");

                result = Double.parseDouble(mCalculatorDisplay1);


                gst_val = (result / 100.0f) * gst_val(0);
                total_gst = result + gst_val;
                gst_val1 = gst_val / 2;


                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);


                operandArray.add(total_gst);
                operatorArray.add('A');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                oprand_one = result;


                GST = "A";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;

                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('A');
                result_history.add(total_gst);


                /*gst_dis = formatter.format(total_gst);
                String gst_valdist = formatter.format(gst_val);
                String cgst_valt = formatter.format(gst_val1);*/


                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdist = String.format("%,.2f", gst_val);
                String cgst_valt = String.format("%,.2f", gst_val1);


                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdist);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_valt);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            } else if (buttonPressed.equals(pref_values.get(1) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.valueOf(mCalculatorDisplay1);
                gst_val = (result / 100.0f) * gst_val(1);
                total_gst = result + gst_val;
                gst_val1 = gst_val / 2;

                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('B');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                oprand_one = result;

                GST = "B";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('B');
                result_history.add(total_gst);


                /*gst_dis = formatter.format(total_gst);
                String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/


                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

               /* String gst_valdist = formatter.format(gst_val);
                    String cgst_valt = formatter.format(gst_val1);*/

                if (gst_dis.length() >= 11) {

                    mCalculatorDisplay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 50);
                } else {
                    mCalculatorDisplay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 60);
                }

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);


            } else if (buttonPressed.equals(pref_values.get(2) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                gst_val = (result / 100.0f) * gst_val(2);
                total_gst = result + gst_val;
                gst_val1 = gst_val / 2;

                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('C');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                oprand_one = result;

                GST = "C";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('C');
                result_history.add(total_gst);

                /*gst_dis = formatter.format(total_gst);

                // gst_dis = total_gst.toString();
                String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/

                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            } else if (buttonPressed.equals(pref_values.get(3) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                gst_val = (result / 100.0f) * gst_val(3); //(1000/100)*18=180
                total_gst = result + gst_val;//1180
                gst_val1 = gst_val / 2;

                    /*gst_val = Math.round(gst_val * 100.0) / 100.0;
                    gst_val1 = Math.round(gst_val1 * 100.0) / 100.0;
                    total_gst = Math.round(total_gst * 100.0) / 100.0;*/

                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);
                MemoryArray.add(total_gst);

                operandArray.add(total_gst);
                operatorArray.add('D');
                resultArray.add(total_gst);

                oprand_one = result;


                GST = "D";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }


                operandFirst_history.add(result);
                operator_history.add('D');
                result_history.add(total_gst);

                /*gst_dis = formatter.format(total_gst);

                // gst_dis = total_gst.toString();
                String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/


                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            } else if (buttonPressed.equals(pref_values.get(4) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                gst_val = (result / 100.0f) * gst_val(4);
                total_gst = result + gst_val;
                gst_val1 = gst_val / 2;


                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('E');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                gst_dis = formatter.format(total_gst);


                oprand_one = result;

                GST = "E";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('E');
                result_history.add(total_gst);

                //  gst_dis = total_gst.toString();
               /* String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/


                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);

            } else if (buttonPressed.equals(pref_values.get(5) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                //gst_val=(screen /100.0f)*5;
                gst_val = result - (result * (100.0d / gst_val(5)));
                total_gst = result - gst_val;
                gst_val1 = gst_val / 2;

                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('a');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                gst_dis = formatter.format(total_gst);

                oprand_one = result;
                GST = "a";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('a');
                result_history.add(total_gst);

                // gst_dis = total_gst.toString().trim();
                /*String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/


                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            } else if (buttonPressed.equals(pref_values.get(6) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                //gst_val=(screen /100.0f)*5;
                gst_val = result - (result * (100.0d / gst_val(6)));
                total_gst = result - gst_val;
                gst_val1 = gst_val / 2;

                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('b');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                gst_dis = formatter.format(total_gst);

                oprand_one = result;
                GST = "b";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('b');
                result_history.add(total_gst);

                // gst_dis = total_gst.toString().trim();
               /* String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/


                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            } else if (buttonPressed.equals(pref_values.get(7) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                //gst_val=(screen /100.0f)*12;
                gst_val = result - (result * (100.0d / gst_val(7)));
                total_gst = result - gst_val;
                gst_val1 = gst_val / 2;

                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('c');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                gst_dis = formatter.format(total_gst);

                oprand_one = result;
                GST = "c";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('c');
                result_history.add(total_gst);

                //  gst_dis = total_gst.toString();
               /* String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/

                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);


                //DecimalFormat dfs = new DecimalFormat("#.##");
                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            } else if (buttonPressed.equals(pref_values.get(8) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                // gst_val=(screen /100.0f)*15.25; //(1000/100)*18=180
                gst_val = result - (result * (100.0d / gst_val(8)));//1000-(1000*(100/118))=
                total_gst = result - gst_val;//84.74
                gst_val1 = gst_val / 2;


                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('d');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);

                gst_dis = formatter.format(total_gst);

                oprand_one = result;
                GST = "d";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('d');
                result_history.add(total_gst);

                // gst_dis = total_gst.toString();
                /*String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/

                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            } else if (buttonPressed.equals(pref_values.get(9) + "%")) {
                mCalculatorDisplay1 = mCalculatorDisplay.getText().toString().replace(",", "");
                result = Double.parseDouble(mCalculatorDisplay1);
                //gst_val=(screen /100.0f)*28;
                gst_val = result - (result * (100.0d / gst_val(9)));
                total_gst = result - gst_val;
                gst_val1 = gst_val / 2;

                result_gst = total_gst;

                gst_val = round_off(round, gst_val);
                gst_val1 = round_off(round, gst_val1);
                total_gst = round_off(round, total_gst);

                operandArray.add(total_gst);
                operatorArray.add('e');
                resultArray.add(total_gst);
                MemoryArray.add(total_gst);


                gst_dis = formatter.format(total_gst);

                oprand_one = result;
                GST = "e";
                oprand_two = gst_val;
                oprand_result = total_gst;

                if (operator_history.size() < 2) {
                    is_gst = true;
                } else {
                    ans_gst = true;
                }

                operandFirst_history.add(result);
                operator_history.add('e');
                result_history.add(total_gst);

                // gst_dis = total_gst.toString();
               /* String gst_valdis = formatter.format(gst_val);
                String cgst_val = formatter.format(gst_val1);*/


                gst_dis = String.format("%,.2f", total_gst);
                String gst_valdis = String.format("%,.2f", gst_val);
                String cgst_val = String.format("%,.2f", gst_val1);

                mCalculatorDisplay.setText(gst_dis);
                mgst_aDisplay.setText("IGST = " + gst_valdis);
                cmgst_aDisplay.setText("CGST/SGST = " + cgst_val);

                mgst_aDisplay.setVisibility(View.VISIBLE);
                mgst_ans.setVisibility(View.VISIBLE);
                cmgst_aDisplay.setVisibility(View.VISIBLE);
                cmgst_ans.setVisibility(View.VISIBLE);
            }


            switch (buttonPressed) {
                case "Auto Replay":
                    if (operandArray.size() == 0)
                        break;
                    int TickTime = 1000;//milliseconds
                    autoReply = new CountDownTimer(TickTime * (operandArray.size() + 2), TickTime) {
                        int m = 0;

                        @Override
                        public void onTick(long millisUntilFinished) {
                            if (m < operandArray.size()) {
                                mOperatorDisplay.setText(operatorArray.get(m).toString());
                                mCalculatorDisplay.setText(df.format(operandArray.get(m)));
                                m++;
                                mStepCountDisplay.setText(df.format(m));
                            } else {
                                cancel();

                                mOperatorDisplay.setText((mCalculatorDisplayString.compareTo("") == 0) ?
                                        operatorArray.get(m - 1).toString() : " ");
                                mCalculatorDisplay.setText((mCalculatorDisplayString.compareTo("") == 0) ?
                                        df.format(operandArray.get(operandArray.size() - 1)) : mCalculatorDisplayString);
                                mStepCountDisplay.setText(df.format(resultArray.size() + ((mCalculatorDisplayString.compareTo("") == 0) ? 0 : 1)));

                                autoReply = null;
                            }
                        }

                        @Override
                        public void onFinish() {
                        }
                    }.start();
                    break;
                case "Check":
                    if (operandArray.size() == 0) break;
                    checkIndex++;
                    checkIndex %= resultArray.size();
                    mOperatorDisplay.setText(operatorArray.get(checkIndex).toString());
                    mCalculatorDisplay.setText(df.format(operandArray.get(checkIndex)));
                    mStepCountDisplay.setText(df.format(checkIndex + 1));
                    break;

                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                    // case "00":
                case "0":


                    if (mCalculatorDisplayString.length() >= df.getMaximumIntegerDigits() +
                            (mCalculatorDisplayString.contains(".") ? 1 : 0) +
                            (mCalculatorDisplayString.contains("-") ? 1 : 0))
                        break;

                    mCalculatorDisplayString += buttonPressed;//Applies for mCalculatorDisplayString="" too.
                    if (!mCalculatorDisplayString.contains(".")) try {
                        mCalculatorDisplayString = df.format(Double.parseDouble(mCalculatorDisplayString));
                    } catch (NumberFormatException e) {
                    } catch (NoSuchMethodError e) {
                    } catch (Exception e) {
                    }
                    //Removes additional zeros.}

                    for (int i = 0; i < mCalculatorDisplayString.length(); i++) {
                        if (mCalculatorDisplayString.contains(".")) {
                            mOperatorDisplay.setText(" ");
                            mCalculatorDisplay.setText(mCalculatorDisplayString);
                            preoprandstring = mCalculatorDisplay.getText().toString();
                        } else {
                            Long longval = Long.parseLong(mCalculatorDisplayString);
                            DecimalFormat formater = new DecimalFormat("##,##,##,##,###");
                            String f1 = formater.format(longval);
                            t1 = f1;
                            mOperatorDisplay.setText(" ");
                            mCalculatorDisplay.setText(t1);
                        }
                    }
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));

                    break;


                case ".":
                    if (!mCalculatorDisplayString.contains("."))
                        mCalculatorDisplayString += (mCalculatorDisplayString.compareTo("") == 0) ? "0." : buttonPressed;

                    mOperatorDisplay.setText(" ");
                    mCalculatorDisplay.setText(mCalculatorDisplayString);
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                    break;


                case "00":

                    if (mCalculatorDisplayString.length() >= df.getMaximumIntegerDigits() +
                            (mCalculatorDisplayString.contains(".") ? 1 : 0) +
                            (mCalculatorDisplayString.contains("-") ? 1 : 0))
                        break;
                    if (mCalculatorDisplayString.compareTo("") == 0 || mCalculatorDisplayString.compareTo("0") == 0)
                        break;
                    String t1 = mCalculatorDisplayString;
                    t1 = t1.concat("00");
                    for (int i = 0; i < t1.length(); i++) {
                        if (i > 9) {
                            t1 = t1.substring(0, t1.length() - 1);
                            break;
                        }
                    }
                    mCalculatorDisplayString = t1;
                    if (mCalculatorDisplayString.contains(".")) {

                        mOperatorDisplay.setText(" ");
                        mCalculatorDisplay.setText(mCalculatorDisplayString);
                        preoprandstring = mCalculatorDisplay.getText().toString();

                    } else {

                        Long longval = Long.parseLong(mCalculatorDisplayString);
                        DecimalFormat formater = new DecimalFormat("##,##,##,##,###");
                        String f1 = formater.format(longval);
                        t1 = f1;
                        // pretempstring =f1;
                        mOperatorDisplay.setText(" ");
                        mCalculatorDisplay.setText(t1);
                    }
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                    break;


                case "Correct":
                    if (savedOperator != '=' && prevOperator == '=' && mCalculatorDisplayString.compareTo("") == 0)
                        mCalculatorDisplayString = df.format(result);

                    Log.e("@@@@@@", "onClick mCalculatorDisplayString savedOperator != '=' && prevOperator ==: " + mCalculatorDisplayString);


                    if (mCalculatorDisplayString.compareTo("") == 0)
                        break;

                    mCalculatorDisplayString = mCalculatorDisplayString.substring(0, mCalculatorDisplayString.length() - 1);
                    Log.e("@@@@@@", "onClick mCalculatorDisplayString mCalculatorDisplayString.substring(0, mCalculatorDisplayString.length() - 1): " + mCalculatorDisplayString);

                    if (mCalculatorDisplayString.compareTo("") == 0 || mCalculatorDisplayString.compareTo("-") == 0)
                        mCalculatorDisplayString = "0";

                    Log.e("@@@@@@", "onClick mCalculatorDisplayString mCalculatorDisplayString.compareTo(\"\") == 0 ||: " + mCalculatorDisplayString);

                    mOperatorDisplay.setText(" ");
                    mCalculatorDisplay.setText(mCalculatorDisplayString);
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                    break;


                case "C":


                    if (autoReply != null) {
                        autoReply.cancel();
                        autoReply = null;
                    }
                    for (int i = 0; i < operandArray.size(); i++) {
                        operandArray1.add(operandArray.get(i));
                        operatorArray1.add(operatorArray.get(i));
                        resultArray1.add(resultArray.get(i));

                    }
                    if (operandArray.size() != 0) {
                        operandArray1.add(null);
                        operatorArray1.add(' ');
                        resultArray1.add(null);
                    }
                    operandArray = new ArrayList<>();
                    operatorArray = new ArrayList<>();
                    resultArray = new ArrayList<>();

                    prevOperator = '=';
//                    tmpprevOperator = '=';
                    savedOperator = '=';
                    memoryOpretor = '=';
                    savedOperand = 0;
                    result = 0;


                    checkIndex = -1;
                    clearall();


                    mCalculatorDisplayString = "";

                    Log.e("@@@@@@", "onClick mCalculatorDisplayString C: " + mCalculatorDisplayString);

                    mCalculatorMemory = 0;

                    mDisplay.setText(" ");
                    mOperatorDisplay.setText(" ");
                    mCalculatorDisplay.setText("0");
                    mStepCountDisplay.setText(df.format(resultArray.size()));//0

                    mgst_aDisplay.setVisibility(View.GONE);
                    mgst_ans.setVisibility(View.GONE);
                    cmgst_aDisplay.setVisibility(View.GONE);
                    cmgst_ans.setVisibility(View.GONE);


                    break;

                case "CE":
                    if (mCalculatorDisplayString.compareTo("") == 0)
                        break;
                    mCalculatorDisplayString = "0";

                    Log.e("@@@@@@", "onClick mCalculatorDisplayString CE: " + mCalculatorDisplayString);

                    mOperatorDisplay.setText(" ");
                    mCalculatorDisplay.setText(mCalculatorDisplayString);
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                    break;


                case "√x":


                    String myval = mCalculatorDisplay.getText().toString();
                    mCalculatorDisplayString = mCalculatorDisplay.getText().toString();

                    Log.e("@@@@@@", "onClick mCalculatorDisplayString mCalculatorDisplay.getText().toString(): " + mCalculatorDisplayString);


                    Log.e("$$$$$", "onClick mCalculatorDisplayString: " + mCalculatorDisplayString);
                    if (mCalculatorDisplayString.contains(","))
                        mCalculatorDisplayString = mCalculatorDisplayString.replace(",", "");
                    Log.e("@@@@@@", "onClick mCalculatorDisplayString mCalculatorDisplayString.contains(\",\")): " + mCalculatorDisplayString);


                    if (mCalculatorDisplayString.compareTo("") == 0) {

                        mCalculatorDisplayString = "0";
                        Log.e("@@@@@@", "onClick mCalculatorDisplayString mCalculatorDisplayString.compareTo(\"\") == 0 if): " + mCalculatorDisplayString);
                    } else {

                        mCalculatorDisplayString = df.format(Math.sqrt(Double.parseDouble(mCalculatorDisplayString)));
                        Log.e("@@@@@@", "onClick mCalculatorDisplayString mCalculatorDisplayString.compareTo(\"\") == 0 else): " + mCalculatorDisplayString);
                    }


                    double cd = Double.parseDouble(mCalculatorDisplayString);
                    cd = round_off(round, cd);
                    String ans = String.valueOf(cd);
                    Log.e("$$$$$", "onClick ans: " + ans);

                    mOperatorDisplay.setText(" ");
                    // mCalculatorDisplay.setText(mCalculatorDisplayString);
                    // operandFirst_history.add(cd);

                    // operandFirst_history.add(Double.valueOf(ans));
                    operator_history.add('√');
                    result_calculate = Double.valueOf(cd);

                    Log.e("$$$$$", "onClick result_calculate: " + result_calculate);

                    mCalculatorDisplay.setText(ans);
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                    is_equal = true;
                    isCheckRoot = true;

                    if ((buttonPressed.compareTo("=") == 0)) {
                        FirstBuff.append("√" + myval + "\n" + " =        " + "\n" + ans);
                    }


                    break;


                case "MC":
                    mCalculatorMemory = 0;
                    break;

                case "M+":
                    if (mCalculatorDisplayString.compareTo("") == 0 && resultArray.size() == 0)
                        break;
                    // mCalculatorMemory += Double.parseDouble((mCalculatorDisplayString.compareTo("") == 0) ? df.format(resultArray.get(resultArray.size() - 1)) : mCalculatorDisplayString);
                    String test1 = "", d = "";
                    for (int i = 0; i < operatorArray.size(); i++) {
                        test1 = operatorArray.get(i).toString();
                    }
                    if (!test1.equals("")) {
                        d = mCalculatorDisplay.getText().toString();
                        d = d.concat(test1);
                        d = d.substring(0, d.length() - 1);
                        mCalculatorDisplayString = d;
                        Log.e("@@@@@@", "onClick mCalculatorDisplayString d if): " + mCalculatorDisplayString);
                    } else {
                        d = mCalculatorDisplay.getText().toString();
                        mCalculatorDisplayString = d;

                        Log.e("@@@@@@", "onClick mCalculatorDisplayString d else): " + mCalculatorDisplayString);

                    }

                    if (!mCalculatorDisplayString.equals("0")) {
                        String a = mCalculatorDisplayString.replace(",", "");
                        Double j2 = Double.parseDouble(a);
                        resultArray.add(j2);
                        mDisplay.setText("M+");
                        MemoryArray.add(j2);
                        mCalculatorDisplayString = "";

                        Log.e("@@@@@@", "onClick mCalculatorDisplayString !mCalculatorDisplayString.equals(\"0\"): " + mCalculatorDisplayString);


                        try {
                            if (mOperatorDisplay.getText().toString().equals(" ") && MemoryArray != null) {

                                if (MemoryArray.size() > 1) {
                                    mCalculatorDisplay.setText(mValue(memoryOpretor, MemoryArray.get(MemoryArray.size() - 2), MemoryArray.get(MemoryArray.size() - 1)));
                                    mCalculatorMemory += Double.valueOf(mCalculatorDisplay.getText().toString());
                                } else {
                                    mCalculatorMemory += Double.parseDouble((mCalculatorDisplayString.compareTo("") == 0) ? df.format(MemoryArray.get(MemoryArray.size() - 1)) : mCalculatorDisplayString);
                                }

                                MemoryArray.add(result);
                                mOperatorDisplay.setText("=");
                                prevOperator = '=';
//                                tmpprevOperator = '=';
                            }
                        } catch (NumberFormatException | NullPointerException |
                                 ArrayIndexOutOfBoundsException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }


                    }


                    break;
                case "M-":
                    if (mCalculatorDisplayString.compareTo("") == 0 && resultArray.size() == 0)
                        break;
                    // mCalculatorMemory -= Double.parseDouble((mCalculatorDisplayString.compareTo("") == 0) ? df.format(resultArray.get(resultArray.size() - 1)) : mCalculatorDisplayString);

                    String test = "", H = "";
                   /* for (int i = 0; i < operatorArray.size(); i++) {
                        test1 = operatorArray.get(i).toString();
                        Log.e("TTTTTT", test);
                    }*/

                    if (!test.equals("")) {
                        H = mCalculatorDisplay.getText().toString();
                        H = H.concat(test);
                        H = H.substring(0, H.length() - 1);
                        mCalculatorDisplayString = H;

                        Log.e("@@@@@@", "onClick mCalculatorDisplayString H if: " + mCalculatorDisplayString);


                    } else {
                        H = mCalculatorDisplay.getText().toString();
                        mCalculatorDisplayString = H;

                        Log.e("@@@@@@", "onClick mCalculatorDisplayString H else: " + mCalculatorDisplayString);


                    }

                    if (!mCalculatorDisplayString.equals("0")) {
                        String a = mCalculatorDisplayString.replace(",", "");
                        Double j2 = Double.parseDouble(a);
                        resultArray.add(j2);
                        MemoryArray.add(j2);
                        mDisplay.setText("M-");
                        mCalculatorDisplayString = "";

                        Log.e("@@@@@@", "onClick mCalculatorDisplayString !mCalculatorDisplayString.equals(\"0\"): " + mCalculatorDisplayString);

                        try {
                            if (mOperatorDisplay.getText().toString().equals(" ") && MemoryArray != null) {

                                if (MemoryArray.size() > 1) {
                                    mCalculatorDisplay.setText(mValue(memoryOpretor, MemoryArray.get(MemoryArray.size() - 2), MemoryArray.get(MemoryArray.size() - 1)));
                                    mCalculatorMemory -= Double.valueOf(mCalculatorDisplay.getText().toString());
                                } else {
                                    mCalculatorMemory -= Double.parseDouble((mCalculatorDisplayString.compareTo("") == 0) ? df.format(MemoryArray.get(MemoryArray.size() - 1)) : mCalculatorDisplayString);
                                }

                                MemoryArray.add(result);
                                mOperatorDisplay.setText("=");
                                prevOperator = '=';
//                                tmpprevOperator = '=';
                            }
                        } catch (NumberFormatException | NullPointerException |
                                 ArrayIndexOutOfBoundsException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    break;
                case "MR":
                    mCalculatorDisplayString = df.format(mCalculatorMemory);
                    Log.e("@@@@@@", "onClick mCalculatorDisplayString MR: " + mCalculatorDisplayString);

                    mOperatorDisplay.setText(" ");
                    mCalculatorDisplay.setText(mCalculatorDisplayString);
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                    break;
                case "GT":


                    double tmp = 0;
                    for (int i = 0; i < operandArray.size() && i < operatorArray.size(); i++) {
                        if (operatorArray.get(i) == ':')
                            tmp += operandArray.get(i);
                    }
                    mCalculatorDisplayString = df.format(tmp);

                    Log.e("@@@@@@", "onClick mCalculatorDisplayString for (int i = 0; i < operandArray.size() && i < operatorArray.size(); i++): " + mCalculatorDisplayString);


                    mOperatorDisplay.setText(" ");
                    mCalculatorDisplay.setText(mCalculatorDisplayString);
                    mStepCountDisplay.setText(df.format(resultArray.size() + 1));


                    for (int i = 0; i < grand_total.size(); i++) {

                        if ((buttonPressed.compareTo("=") == 0)) {

                            FirstBuff.append("+" + "      " +
                                    grand_total.get(i) + "\n");

                        }


                    }

                    if ((buttonPressed.compareTo("=") == 0)) {

                        FirstBuff.append("---------------------------" + "\n" + "GT   =" + "      " +
                                sum_tot(grand_total) + "\n");

                    }


                    historyData = new HistoryData();
                    historyData.setFirst_oprand(FirstBuff.toString());
                    historylog_list.add(j, historyData);

                    Log.e("######", "onClick historyData: " + historyData);


                    j++;
                    grand_total.clear();
                    FirstBuff.setLength(0);
                    FirstBuff.trimToSize();


                    break;
                case "+":
                case "-":
                case "x":
                case "÷":
                case "=":
                    Log.e("||||||", "onClick =: ");
                case "MU":
                case "%":
                    Log.e("======", "% innn buttonPressed: " + buttonPressed);
                    if (buttonPressed.charAt(0) == 'M') {

                        Log.e("======", "buttonPressed.charAt(0): " + buttonPressed.charAt(0));

                        Log.e("@@@@@@", "onClick : " + buttonPressed.charAt(0));

                        is_mu = true;
                        GST = "M";

                        Log.e("@@@@@@", "onClick mCalculatorDisplayString: " + mCalculatorDisplayString);

                        if (!mCalculatorDisplayString.equals("")) {
                            mu_oprand = Double.valueOf(mCalculatorDisplayString);
                            Log.e("@@@@@@", "onClick mu_oprand iff: " + mu_oprand);
                        } else {
                            Log.e("@@@@@@", "onClick mu_oprand elsee: " + mu_oprand);
                        }
                    }
                    Log.e("GSTTTTTT", "onClick prevOperator: " + prevOperator + " -->>> " + (prevOperator == 'M' && buttonPressed.charAt(0) != '%'));
                    Log.e("GSTTTTTT", "onClick buttonPressed.charAt(0): " + buttonPressed.charAt(0));
                    Log.e("GSTTTTTT", "onClick mCalculatorDisplayString.compareTo(\"\"): " + mCalculatorDisplayString.compareTo(""));

                    /*if (buttonPressed.charAt(0) == '=' && prevOperator == '+') {

                        Toast.makeText(getActivity(), "Invalid Format", Toast.LENGTH_LONG).show();

                    }*/

                    if (prevOperator == 'M' && buttonPressed.charAt(0) != '%')
                        break;
                    if (prevOperator == '=' || prevOperator == '%') {

                        Log.e("GSTTTTTT", "onClick ifff innnn: " + buttonPressed.charAt(0));

                        if (buttonPressed.charAt(0) == '%') {

                            Log.e("======", "onClick buttonPressed.charAt(0) == '%': ");

                            break;
                        } else if (buttonPressed.charAt(0) == '=') {
                            Log.e("======", "buttonPressed.charAt(0):::::::::::::::::::::::::::::::: == '=' savedOperator: " + savedOperator);
                            if (savedOperator != '=') {
                                result = (mCalculatorDisplayString.compareTo("") == 0) ? result : Double.parseDouble(mCalculatorDisplayString);//For correct button pressed on result
                                switch (savedOperator) {

                                    case '+':
                                        result += savedOperand;

                                        break;
                                    case '-':
                                        result -= savedOperand;
                                        break;
                                    case 'x':
                                        result *= savedOperand;
                                        break;
                                    case '÷':
                                        result /= savedOperand;
                                        break;
                                    case '%':
                                        char symbol = 0;
                                        for (int k = 0; k < operator_history.size(); k++) {
                                            symbol = operator_history.get(i);

                                            Log.e("$$$$$", "onClick symbol: " + symbol);

                                        }
                                        if (symbol == '+') {
                                            result = oprand_one + result;
                                        } else if (symbol == '-') {
                                            result = oprand_one - result;
                                        } else if (symbol == 'x') {
                                            result = oprand_one * result;
                                        } else if (symbol == '/') {
                                            result = oprand_one / result;
                                        } else {
                                        }


                                }

                                mCalculatorDisplay2 = String.valueOf(result);
                                mCalculatorDisplay2 = mCalculatorDisplay2.replace(".0", "");
                                try {
                                    if (mCalculatorDisplay2.contains(".")) {
                                        mOperatorDisplay.setText(buttonPressed);
                                        mCalculatorDisplay.setText(df.format(result));

                                    } else {
                                        DecimalFormat formater = new DecimalFormat("##,##,##,##,###");
                                        String f1 = formater.format(result);
                                        display1 = f1;
                                        mOperatorDisplay.setText(buttonPressed);
                                        mCalculatorDisplay.setText(display1);


                                    }
                                } catch (Exception e) {

                                    e.printStackTrace();
                                }

                                if (operatorArray.get(operatorArray.size() - 1) != ':')
                                    Log.e("ERROR!", "=== failed!!!");
                                operandArray.set(operandArray.size() - 1, savedOperand);
                                operatorArray.set(operatorArray.size() - 2, savedOperator);
                                operatorArray.set(operatorArray.size() - 1, buttonPressed.charAt(0));
                                resultArray.set(resultArray.size() - 1, result);
                                operandArray.add(result);
                                operatorArray.add(':');
                                resultArray.add(result);
                                MemoryArray.add(result);
                                mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                                mCalculatorDisplayString = "";

                                Log.e("@@@@@@", "onClick mCalculatorDisplayString operatorArray.get(operatorArray.size() - 1: " + mCalculatorDisplayString);

                            }
                        } else {

                            Log.e("======", "else: ");

                            if (result_gst != 0) {
                                mCalculatorDisplayString = String.valueOf(total_gst);
                                mgst_aDisplay.setVisibility(View.GONE);
                                mgst_ans.setVisibility(View.GONE);
                                cmgst_aDisplay.setVisibility(View.GONE);
                                cmgst_ans.setVisibility(View.GONE);

                                Log.e("@@@@@@", "onClick mCalculatorDisplayString result_gst != 0: " + mCalculatorDisplayString);

                            }

                            Log.e("======", "else result toppp mCalculatorDisplay.getText().toString(): " + mCalculatorDisplay.getText().toString());
                            result = (mCalculatorDisplayString.compareTo("") == 0) ? result : Double.parseDouble(mCalculatorDisplay.getText().toString().replace(",", ""));

                            Log.e("======", "else result toppp upppp: " + result);

                            prevOperator = buttonPressed.charAt(0);
                            savedOperator = buttonPressed.charAt(0);
                            memoryOpretor = buttonPressed.charAt(0);

                            tmpprevOperator = prevOperator;

                            Log.e("======", "else prevOperator: " + prevOperator);
                            Log.e("======", "else savedOperator: " + savedOperator);
                            Log.e("======", "else memoryOpretor: " + memoryOpretor);

                            mOperatorDisplay.setText(buttonPressed);
                            mCalculatorDisplay.setText(df.format(result));//Redundant for AutoReply And Check case.
                            mStepCountDisplay.setText(df.format(resultArray.size() + 1));

                            Log.e("======", "else result upppp: " + result);

                            Log.e("======", "else operandArray_before: " + operandArray);
                            Log.e("======", "else operatorArray.add(buttonPressed.charAt(0)_before: " + operatorArray);
                            Log.e("======", "else resultArray_before: " + resultArray);
                            Log.e("======", "else MemoryArray_before: " + MemoryArray);
                            Log.e("======", "else result_before: " + result);

                            operandArray.add(result);
                            operatorArray.add(buttonPressed.charAt(0));
                            resultArray.add(result);
                            MemoryArray.add(result);

                            Log.e("======", "else operandArray: " + operandArray);
                            Log.e("======", "else operatorArray.add(buttonPressed.charAt(0): " + operatorArray);
                            Log.e("======", "else resultArray: " + resultArray);
                            Log.e("======", "else MemoryArray: " + MemoryArray);
                            Log.e("======", "else result: " + result);

                            if (!mCalculatorDisplayString.equals("")) {
                                oprand_one = Double.parseDouble(mCalculatorDisplayString);
                                Log.e("######", "!mCalculatorDisplayString.equals(\"\"): " + oprand_one);
                            }

                            if (is_oprand == 0) {

                                if (is_oprand_renew == 1) {
                                    mCalculatorDisplayString = mCalculatorDisplay.getText().toString();
                                    oprand_one = Double.parseDouble(mCalculatorDisplayString);
                                    Log.e("######", "is_oprand_renew == 1: " + oprand_one);

                                    is_oprand_renew = 0;
                                }

                                if (!mCalculatorDisplayString.equals("")) {
                                    operandFirst_history.add(oprand_one);
                                    is_oprand = 1;
                                }
                            }

                            mCalculatorDisplayString = "";
                        }
                    } else if (mCalculatorDisplayString.compareTo("") == 0) {

                        if (buttonPressed.charAt(0) != '='
                                && prevOperator != 'M'
                                && buttonPressed.charAt(0) != '%') {
                            prevOperator = buttonPressed.charAt(0);
                            savedOperator = buttonPressed.charAt(0);
                            memoryOpretor = buttonPressed.charAt(0);

//                            tmpprevOperator = prevOperator;

                            operatorArray.set(operatorArray.size() - 1, buttonPressed.charAt(0));

                            mOperatorDisplay.setText(buttonPressed);
                            mCalculatorDisplay.setText((mCalculatorDisplayString.compareTo("") == 0) ? //I think mCalculatorDisplayString will always be "" here.
                                    df.format(resultArray.get(resultArray.size() - 1)) : mCalculatorDisplayString);//Redundant for AutoReply And Check case.
                            mStepCountDisplay.setText(df.format(resultArray.size()));//Redundant for AutoReply And Check case.
                        }
                    } else {

                        if ((buttonPressed.compareTo("=") == 0)) {

                            Log.e("TAG:::::::", "onClick = press ifff beloww: ");

//                Toast.makeText(getActivity(), "= press", Toast.LENGTH_LONG).show();
                        } else {
                            Log.e("TAG:::::::", "onClick another click elseeee beloww: ");
//                Toast.makeText(getActivity(), "another click", Toast.LENGTH_LONG).show();
                        }


                        oprand_two = Double.parseDouble(mCalculatorDisplayString);
                        operandSecond_history.add(oprand_two);
                        two = mCalculationString;

                        Log.e("(((((((((TAG)))))))))", "onClick prevOperator: " + prevOperator);

                        operator_history.add(prevOperator);


                        switch (prevOperator) {

                            case '+':
                                if (buttonPressed.charAt(0) == '%') {
                                    result += ((result * Double.parseDouble(mCalculatorDisplayString)) / 100);
                                    result = round_off("5", result);
                                } else {
                                    result += Double.parseDouble(mCalculatorDisplayString);
                                    result = round_off("5", result);
                                }
                                break;
                            case '-':
                                if (buttonPressed.charAt(0) == '%') {
                                    result -= ((result * Double.parseDouble(mCalculatorDisplayString)) / 100);
                                    result = round_off("5", result);
                                } else {
                                    result -= Double.parseDouble(mCalculatorDisplayString);
                                    result = round_off("5", result);
                                }
                                break;
                            case 'x':
                                if (buttonPressed.charAt(0) == '%') {
                                    result = ((result * Double.parseDouble(mCalculatorDisplayString)) / 100);
                                    result = round_off("5", result);
                                } else {
                                    result *= Double.parseDouble(mCalculatorDisplayString);
                                    result = round_off("5", result);
                                }
                                break;
                            case '÷':
                                if (buttonPressed.charAt(0) == '%') {
                                    result = (result * (100 / Double.parseDouble(mCalculatorDisplayString)));
                                    result = round_off("5", result);

                                    Log.e("$$$$$", "onClick result: " + result);

                                } else {
                                    result /= Double.parseDouble(mCalculatorDisplayString);
                                    result = round_off("5", result);

                                    Log.e("$$$$$", "onClick result: " + result);
                                }
                                break;
                            case 'M':
                                result = (result * 100) / (100 - (Double.parseDouble(mCalculatorDisplayString)));
                                result = round_off("5", result);

                                Log.e("$$$$$", "onClick result 'M': " + result);

                                break;

                        }
                        prevOperator = buttonPressed.charAt(0);

//                        tmpprevOperator = prevOperator;

                        if (buttonPressed.charAt(0) != '=') {
                            savedOperator = buttonPressed.charAt(0);
                            memoryOpretor = buttonPressed.charAt(0);

                            tempSavedOperator = savedOperator;
                        }
                        savedOperand = Double.parseDouble(mCalculatorDisplayString);

                        Log.e("<<<<<", "onClick savedOperand: " + savedOperand);

                        tempsavedOperand = savedOperand;

                        Log.e("<<<<<", "onClick tempsavedOperand: " + tempsavedOperand);

                        mOperatorDisplay.setText(buttonPressed);
                        result_calculate = result;

                        if (is_oprand == 1) {
                            operandFirst_history.add(oprand_two);
                        }
                        Log.e("######", "onClick prevOperator: " + prevOperator);
                        Log.e("######", "onClick savedOperator: " + savedOperator);
                        Log.e("######", "onClick memoryOpretor: " + memoryOpretor);
                        Log.e("######", "onClick savedOperand: " + savedOperand);
                        Log.e("######", "onClick result_calculate: " + result_calculate);

                        result_history.add(result_calculate);

                        Log.e("????", "onClick result_history: " + result_history.size());

                        result_calculate = round_off(round, result_calculate);
                        String d1 = String.valueOf(result_calculate);

                        try {
                            if (preoprandstring.contains(".") || mCalculatorDisplayString.contains(".") || d1.contains(".")) {

                                Log.e("!!!!!!!!!", "^^^^^^^^^^--%,d--^^^^^^^^>");
                                mOperatorDisplay.setText(" ");
                                // mCalculatorDisplay.setText(df.format(result_calculate));

                                mCalculatorDisplay.setText(String.format("%,.2f", result_calculate));

                                preoprandstring = "";
                            } else if (preoprandstring.equals("") && !mCalculatorDisplayString.contains(".")) {
                                DecimalFormat formater = new DecimalFormat("##,##,##,##,###");
                                String f1 = formater.format(result_calculate);
                                display1 = f1;
                                mOperatorDisplay.setText(" ");
                                mCalculatorDisplay.setText(display1);

                            }
                        } catch (Exception e) {

                            e.printStackTrace();
                        }

                        mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                        operandArray.add(savedOperand);
                        operatorArray.add(buttonPressed.charAt(0));
                        resultArray.add(result);
                        MemoryArray.add(result);
                        if (buttonPressed.charAt(0) == '=' || buttonPressed.charAt(0) == '%') {
                            operator_history.add(buttonPressed.charAt(0));
                            if (is_mu) {
                                is_equal = false;
                            } else {
                                is_equal = true;
                            }

                            Log.e("######", "onClick result_history result: " + result);

                            result_history.add(result);
                            mStepCountDisplay.setText(df.format(resultArray.size() + 1));
                            operandArray.add(result);
                            operatorArray.add(':');
                            resultArray.add(result);
                            MemoryArray.add(result);
                            grand_total.add(result);

                        }
                        mCalculatorDisplayString = "";

                    }
                    /*try {
                        ((MainActivity) getActivity()).checkInternetConnection();
                    } catch (NullPointerException ignored) {
                    } catch (Exception ignored) {
                    }*/
                    break;
            }
        } catch (Resources.NotFoundException | NumberFormatException | NullPointerException |
                 IndexOutOfBoundsException e) {
            e.printStackTrace();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setpref(View v) {
        for (int i = 0; i < ids.length; i++) {
            long_click(ids[i], v);
            pref_values.add(slab_prefr.getString("slab_" + i, defaul_val[i]));
        }

        for (int k = 0; k < ids.length; k++) {
            setValues(ids[k], v);
        }
    }

    @SuppressLint("SetTextI18n")
    private void setValues(int id, View view) {

        AppCompatButton button = view.findViewById(id);

        if (ids[0] == id) {
            button.setText(pref_values.get(0) + "%");
            if (pref_values.get(0).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[1] == id) {
            button.setText(pref_values.get(1) + "%");
            if (pref_values.get(1).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[2] == id) {
            button.setText(pref_values.get(2) + "%");
            if (pref_values.get(2).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[3] == id) {
            button.setText(pref_values.get(3) + "%");
            if (pref_values.get(3).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[4] == id) {
            button.setText(pref_values.get(4) + "%");
            if (pref_values.get(4).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[5] == id) {
            button.setText(pref_values.get(5) + "%");
            if (pref_values.get(5).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[6] == id) {
            button.setText(pref_values.get(6) + "%");
            if (pref_values.get(6).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[7] == id) {
            button.setText(pref_values.get(7) + "%");
            if (pref_values.get(7).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[8] == id) {
            button.setText(pref_values.get(8) + "%");
            if (pref_values.get(8).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

        if (ids[9] == id) {
            button.setText(pref_values.get(9) + "%");
            if (pref_values.get(9).length() > 6) {
                button.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
            }
        }

    }

    private double gst_val(int i) {
        double val = 0.0;
        if (i <= 4) {
            val = Double.valueOf(pref_values.get(i).substring(1, pref_values.get(i).length()));
        } else {
            val = 100d + Double.valueOf(pref_values.get(i).substring(1, pref_values.get(i).length()));
        }
        return val;
    }


    /* private void SubscribeDilog(String s) {

     */
    /*
      Log.e("GstCalculator", "mRetriveSkuListSize"+QUERY_SKU.mRetriveSkuList(realm).size());*//*

        dialog_subscribe = new Dialog(getActivity());
        dialog_subscribe.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog_subscribe.setContentView(R.layout.dailog_inapp);
        dialog_subscribe.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog_subscribe.setCanceledOnTouchOutside(false);
        dialog_subscribe.setCancelable(false);
        LinearLayout container = dialog_subscribe.findViewById(R.id.container_subscription);
        RelativeLayout close_btn = dialog_subscribe.findViewById(R.id.close_btn);
        int test_id = 555;


        int[] image_back = {R.drawable.bg_one_m, R.drawable.bg_one_y, R.drawable.sub_six, R.drawable.sub_three};
        int[] image_icon = {R.drawable.ic_coins, R.drawable.ic_money, R.drawable.ic_three, R.drawable.cost};

        try {
            Realm realm = Realm.getDefaultInstance();
            List<TB_SKU_N> skuList = QUERY_SKU.mRetriveSkuList(realm);


            if (skuList != null && skuList.size() != 0) {

                container.removeAllViews();

                for (int i = 0; i < skuList.size(); i++) {

                    LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View view = inflater.inflate(R.layout.subscribe_row_item, container, false);
                    TextView one_m_title, one_m_content, one_m_price;
                    ImageView img_icon;
                    RelativeLayout one_month_btn;
                    one_month_btn = (RelativeLayout) view.findViewById(R.id.RL_ONE_MONT);
                    one_m_title = view.findViewById(R.id.one_m_title);
                    one_m_content = view.findViewById(R.id.one_m_content);
                    one_m_price = view.findViewById(R.id.one_m_price);
                    img_icon = view.findViewById(R.id.img_icon);


                    one_month_btn.setBackgroundResource(image_back[i]);
                    img_icon.setBackgroundResource(image_icon[i]);
                    one_m_title.setText(skuList.get(i).getTitle());
                    one_m_content.setText(skuList.get(i).getContent());
                    one_m_price.setText(getString(R.string.ruppee) + " " + skuList.get(i).getDefault_value());

                    final int finalI = i;
                    one_month_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (!TextUtils.isEmpty(skuList.get(finalI).getSku())) {

                                //((MainActivity) getActivity()).inApp.subscribe(getActivity(), skuList.get(finalI).getSku());

                            }
                        }
                    });


                    container.addView(view);

                }


            }
        } catch (NullPointerException | ArrayIndexOutOfBoundsException | JsonSyntaxException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        close_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog_subscribe.dismiss();
            }
        });


        WindowManager wm = (WindowManager) getActivity().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        double width = displayMetrics.widthPixels * .9;
        double hieght = displayMetrics.heightPixels * 1.3;
        Window win = dialog_subscribe.getWindow();
        win.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog_subscribe.show();


    }*/

    String mValue(char s, double op1, double op2) {
        switch (s) {
            case '+':
                return String.valueOf(op1 + op2);
            case '-':
                return String.valueOf(op1 - op2);
            case 'x':
                return String.valueOf(op1 * op2);
            case '÷':
                return String.valueOf(op1 / op2);
            default:
                return String.valueOf(op2);

        }
    }

    String format_value(String str) {
        if (str.contains("."))
            return String.format("%,.2f", str);
        else
            return String.format("%,d", str);
    }


    public Boolean isLoadingAds() {
        return adsPorgress.getVisibility() == View.VISIBLE;
    }

    public void showProgress(int visible) {
        adsPorgress.setVisibility(visible);
    }


}
