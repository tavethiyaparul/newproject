package com.divinesoftech.calculator.Adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.ProductDetails
import com.divinesoftech.calculator.R
import com.divinesoftech.calculator.database.room.RoomSku
import kotlinx.android.synthetic.main.subscribe_row_item.view.*
import java.util.Currency
import kotlin.math.roundToInt

class SkuAdapter(
    listDetailsMain: List<ProductDetails>,
    skuList: List<RoomSku>,
    val callback: (productDetails: ProductDetails) -> Unit
) :
    RecyclerView.Adapter<SkuHolder>() {
    var temSkuList: ArrayList<RoomSku> = ArrayList<RoomSku>()
    var temProductDetails: ArrayList<ProductDetails> = ArrayList<ProductDetails>()
    var hashMap = HashMap<String, Boolean>()
    var pricePerMonth = 8
    var currency = ""

    init {
        Log.e("formattedPrice", "")
        if (listDetailsMain.isNotEmpty()) {
            /*listDetailsMain.forEach {
                it.productId
                it.subscriptionOfferDetails?.forEach { subscriptionOfferDetails ->
                    subscriptionOfferDetails?.pricingPhases?.pricingPhaseList?.forEach { pricingPhases ->
                        Log.e("formattedPrice", pricingPhases?.formattedPrice ?: "")
                    }
                }
            }*/
            skuList.forEach {
                if (it.enable == 1) {
                    temSkuList.add(it)
                    if (!it.title.contains("Month")) {
                        hashMap[it.sku] = true
                    }
                }
            }
            temSkuList.forEach {
                listDetailsMain.forEach { itr ->
                    try {
                        if (itr.productId == it.sku) {
                            itr.subscriptionOfferDetails?.forEach { subscriptionOfferDetails ->
                                subscriptionOfferDetails?.pricingPhases?.pricingPhaseList?.forEach { pricingPhases ->
                                    it.defaultValue = pricingPhases?.formattedPrice ?: ""
                                    temProductDetails.add(itr)
                                    if (!it.title.contains("Month")) {
                                        if (pricingPhases?.formattedPrice != "Free" && itr.productId == "gst_1year") {
                                            pricePerMonth = (((pricingPhases?.priceAmountMicros
                                                ?: 1000000) / 1000000).toDouble() / 12).roundToInt()
                                            currency = Currency.getInstance(
                                                pricingPhases?.priceCurrencyCode ?: ""
                                            ).symbol
                                        }
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SkuHolder {
        val view: View
        val layoutInflater = LayoutInflater.from(parent.context)
        view = layoutInflater.inflate(R.layout.subscribe_row_item, null)
        return SkuHolder(view)
    }

    override fun onBindViewHolder(holder: SkuHolder, position: Int) {
        if (hashMap.containsKey(temSkuList[position].sku) && hashMap[temSkuList[position].sku] == true) {
            holder.checkbox.isChecked = true
            holder.RL_ONE_MONT.setBackgroundResource(R.drawable.sku_selection)
        } else {
            holder.RL_ONE_MONT.setBackgroundResource(0)
            holder.checkbox.isChecked = false
        }

        if (!temSkuList[position].title.contains("Month")) {

        }

//        Glide.with(holder.backgrounds.context)
//            .load(SKU_LINK + temSkuList[position].banner)
//            .into(holder.backgrounds)
        holder.one_m_title.text =
            "${temSkuList[position].defaultValue} ${if (temSkuList[position].title.contains("Month")) "/ Month" else "/ Year"}"
//        holder.perPackPrice.text = "per ${temSkuList[position].title}"
//        holder.one_m_content.text = temSkuList[position].btnText
        if (temSkuList[position].title.contains("Month")) {
            holder.one_m_price.visibility = View.GONE
        } else {
            holder.one_m_price.visibility = View.VISIBLE
            holder.one_m_price.text = "$currency$pricePerMonth per Month"
        }
//        holder.RL_ONE_MONT.setBackgroundColor(Color.parseColor(temSkuList[position].btnColor))
        holder.RL_ONE_MONT.setOnClickListener {
//            onClickSku.onClickSku(temSkuList[position].sku)
            temSkuList.forEach {
                hashMap[it.sku] = false
            }
            hashMap[temSkuList[position].sku] = true
            notifyDataSetChanged()
            if (temProductDetails.size > 0) try {
                callback.invoke(temProductDetails[position])
            } catch (e: IndexOutOfBoundsException) {
            } catch (e: Exception) {

            }
        }

//        Glide.with(holder.imgIcon.context)
//            .load(SKU_LINK + temSkuList[position].image)
//            .into(holder.imgIcon)
    }

    override fun getItemCount(): Int {
        return temSkuList.size
    }
}

class SkuHolder(view: View) : RecyclerView.ViewHolder(view) {
    val one_m_title = view.txtTitle
    val one_m_price = view.txtTitleSub
    val checkbox = view.checkbox
    val RL_ONE_MONT = view.RL_ONE_MONT

}

interface OnClickSku {
    fun onClickSku(sku: String)
}

//enum class IsPrimeGstCal {
//    IS_FREE,IS_PRIME
//}
//@JvmField
//var IsPrimeGstCalIsFree= IsPrimeGstCal.IS_FREE