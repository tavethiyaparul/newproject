package com.divinesoftech.calculator.Classes;

import android.content.Context;

import java.io.File;

public class DetailsUtility {
    String balance,interest,month,principle;

    public static File getCacheDir(Context context) {
        return context.getExternalFilesDir(null) == null ? context.getFilesDir() : context.getExternalFilesDir(null);
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getPrinciple() {
        return principle;
    }

    public void setPrinciple(String principle) {
        this.principle = principle;
    }}
