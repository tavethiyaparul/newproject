package com.divinesoftech.calculator.Service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.divinesoftech.calculator.database.DatabaseGst;

import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.calculator.Common.Utilty.IS_ADFREE;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        SharedPreferences preferences = context.getSharedPreferences("update", MODE_PRIVATE);
        SharedPreferences.Editor editor =  preferences.edit();
        if(intent.hasExtra("requestCode")){
            String code= intent.getStringExtra("requestCode");
             if(code.equalsIgnoreCase("Month")){
                 DatabaseGst databaseGst = new DatabaseGst(context);
                 String isUpdate = databaseGst.getResponse(IS_ADFREE) == null ? "false" : "true";
                 databaseGst.setResponse(IS_ADFREE, "NO", isUpdate);

            }
        }


    }
}
