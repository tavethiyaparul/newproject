package com.divinesoftech.calculator.Adapter;


import android.content.Context;

import androidx.viewpager.widget.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.divinesoftech.calculator.R;

public class ChangeViewAdapter extends PagerAdapter {


    Context context;
    int images[];
    LayoutInflater layoutInflater;


    public ChangeViewAdapter(Context context, int images[]) {
        this.context = context;
        this.images = images;

        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View itemView = layoutInflater.inflate(R.layout.changeview_item, container, false);

        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageView);


        try {
            imageView.setImageResource(images[position]);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }


        container.addView(itemView);

        //listening to image click
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Toast.makeText(context, "" + (position + 1), Toast.LENGTH_LONG).show();*/
            }
        });

        return itemView;
    }



    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }
}
