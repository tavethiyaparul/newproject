package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class RoomGame {
    @PrimaryKey
    var id: String = ""
    var icon: String = ""
    var banner: String = ""
    var link: String = ""
    var enable: Int = 0
}