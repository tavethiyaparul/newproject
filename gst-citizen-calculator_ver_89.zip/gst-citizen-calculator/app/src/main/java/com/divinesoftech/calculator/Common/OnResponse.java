package com.divinesoftech.calculator.Common;

public interface OnResponse {
    void onResponse(String response);
}