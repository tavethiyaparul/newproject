package com.divinesoftech.calculator.Common

interface OnSetTheme {
    fun setTheme(pos:Int)
}