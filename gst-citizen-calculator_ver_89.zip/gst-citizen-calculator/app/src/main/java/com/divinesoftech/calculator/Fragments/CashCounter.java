package com.divinesoftech.calculator.Fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;

public class CashCounter extends Fragment {
    public CashCounter() {

    }

    EditText edtRs1, editRs2, editRs3, editRs4, editRs5, editRs6, editRs7, editRs9, editRs10, editRs11;
    TextView edtResult1, editResult2, editResult3, editResult4, editResult5, editResult6, editResult7, editResult8, editResult9, editResult10;

    int count1 = 0;
    int count2 = 0;
    int count3 = 0;
    int count4 = 0;
    int count5 = 0;
    int count6 = 0;
    int count7 = 0;
    int count8 = 0;
    int count9 = 0;
    int count10 = 0;
    int set1, set2, set3, set4, set5, set6, set7, set8, set9, set10;

    TextView grandTotalCount, notesTotalCount;

    int Total, GTotal;

    RelativeLayout ad_layout;
//    LinearLayout google_layout;
    ConstraintLayout laycoin1, laycoin2, laycoin3, layLess, layMore;
    View view;
    DatabaseGst databaseGst;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.cashcounter_fragment, container, false);

        databaseGst = ((MainActivity) requireActivity()).databaseGst;

        ad_layout = view.findViewById(R.id.ad_layout);
//        google_layout = view.findViewById(R.id.google_layout);
        edtRs1 = view.findViewById(R.id.edtRs1);
        editRs2 = view.findViewById(R.id.edtRs2);
        editRs3 = view.findViewById(R.id.edtRs3);
        editRs4 = view.findViewById(R.id.edtRs4);
        editRs5 = view.findViewById(R.id.edtRs5);
        editRs6 = view.findViewById(R.id.edtRs6);
        editRs7 = view.findViewById(R.id.edtRs7);
        editRs9 = view.findViewById(R.id.coinRs1);
        editRs10 = view.findViewById(R.id.coinRs2);
        editRs11 = view.findViewById(R.id.coinRs3);
        edtResult1 = view.findViewById(R.id.edtResult1);
        editResult2 = view.findViewById(R.id.edtResult2);
        editResult3 = view.findViewById(R.id.edtResult3);
        editResult4 = view.findViewById(R.id.edtResult4);
        editResult5 = view.findViewById(R.id.edtResult5);
        editResult6 = view.findViewById(R.id.edtResult6);
        editResult7 = view.findViewById(R.id.edtResult7);
        editResult8 = view.findViewById(R.id.coinResult1);
        editResult9 = view.findViewById(R.id.coinResult2);
        editResult10 = view.findViewById(R.id.coinResult3);
        notesTotalCount = view.findViewById(R.id.notesTotalCount);
        grandTotalCount = view.findViewById(R.id.grandTotalCount);
        laycoin1 = view.findViewById(R.id.layRs8);
        laycoin2 = view.findViewById(R.id.layRs9);
        laycoin3 = view.findViewById(R.id.layRs10);
        layLess = view.findViewById(R.id.layLess);
        layMore = view.findViewById(R.id.layMore);

        edtRs1.setTransformationMethod(null);
        editRs2.setTransformationMethod(null);
        editRs3.setTransformationMethod(null);
        editRs4.setTransformationMethod(null);
        editRs5.setTransformationMethod(null);
        editRs6.setTransformationMethod(null);
        editRs7.setTransformationMethod(null);
        editRs9.setTransformationMethod(null);
        editRs10.setTransformationMethod(null);
        editRs11.setTransformationMethod(null);


        /*if (isNetworkAvailable(getActivity()) && !isPrime() && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
        }*/

        layLess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layLess.setVisibility(View.GONE);
                layMore.setVisibility(View.VISIBLE);
                laycoin1.setVisibility(View.GONE);
                laycoin2.setVisibility(View.GONE);
                laycoin3.setVisibility(View.GONE);

            }
        });

        layMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layMore.setVisibility(View.GONE);
                layLess.setVisibility(View.VISIBLE);
                laycoin1.setVisibility(View.VISIBLE);
                laycoin2.setVisibility(View.VISIBLE);
                laycoin3.setVisibility(View.VISIBLE);
            }
        });

        ((MainActivity)getActivity()).getReset().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resettext();
            }
        });

        edtRs1.addTextChangedListener(new TextChange(edtRs1));
        editRs2.addTextChangedListener(new TextChange(editRs2));
        editRs3.addTextChangedListener(new TextChange(editRs3));
        editRs4.addTextChangedListener(new TextChange(editRs4));
        editRs5.addTextChangedListener(new TextChange(editRs5));
        editRs6.addTextChangedListener(new TextChange(editRs6));
        editRs7.addTextChangedListener(new TextChange(editRs7));
        editRs9.addTextChangedListener(new TextChange(editRs9));
        editRs10.addTextChangedListener(new TextChange(editRs10));
        editRs11.addTextChangedListener(new TextChange(editRs11));


        /*try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/

        return view;
    }
    private void resettext() {

        edtRs1.requestFocus();

        edtRs1.setText("");
        editRs2.setText("");
        editRs3.setText("");
        editRs4.setText("");
        editRs5.setText("");
        editRs6.setText("");
        editRs7.setText("");
        editRs9.setText("");
        editRs10.setText("");
        editRs11.setText("");

        edtResult1.setText("");
        editResult2.setText("");
        editResult3.setText("");
        editResult4.setText("");
        editResult5.setText("");
        editResult6.setText("");
        editResult7.setText("");
        editResult8.setText("");
        editResult9.setText("");
        editResult10.setText("");

        notesTotalCount.setText("00");
        grandTotalCount.setText("00");

        layLess.setVisibility(View.GONE);
        layMore.setVisibility(View.VISIBLE);
        laycoin1.setVisibility(View.GONE);
        laycoin2.setVisibility(View.GONE);
        laycoin3.setVisibility(View.GONE);
    }

    private void settext(int i) {

        if (i == 1) {
            count1 = 0;
        } else {
            getdata(edtRs1, 1);
        }

        if (i == 2) count2 = 0;
        else getdata(editRs2, 2);

        if (i == 3) count3 = 0;
        else getdata(editRs3, 3);

        if (i == 4) count4 = 0;
        else getdata(editRs4, 4);

        if (i == 5) count5 = 0;
        else getdata(editRs5, 5);

        if (i == 6) count6 = 0;
        else getdata(editRs6, 6);

        if (i == 7) count7 = 0;
        else getdata(editRs7, 7);

        if (i == 8) count8 = 0;
        else getdata(editRs9, 9);

        if (i == 9) count9 = 0;
        else getdata(editRs10, 10);

        if (i == 10) count10 = 0;
        else getdata(editRs11, 11);

        set1 = count1 * 2000;
        set2 = count2 * 500;
        set3 = count3 * 200;
        set4 = count4 * 100;
        set5 = count5 * 50;
        set6 = count6 * 20;
        set7 = count7 * 10;

        set8 = count8 * 5;
        set9 = count9 * 2;
        set10 = count10 * 1;

        edtResult1.setText(String.valueOf(set1));
        editResult2.setText(String.valueOf(set2));
        editResult3.setText(String.valueOf(set3));
        editResult4.setText(String.valueOf(set4));
        editResult5.setText(String.valueOf(set5));
        editResult6.setText(String.valueOf(set6));
        editResult7.setText(String.valueOf(set7));
        editResult8.setText(String.valueOf(set8));
        editResult9.setText(String.valueOf(set9));
        editResult10.setText(String.valueOf(set10));


        Total = count1 + count2 + count3 + count4 + count5 + count6 + count7 + count8 + count9 + count10;
        GTotal = set1 + set2 + set3 + set4 + set5 + set6 + set7 + set8 + set9 + set10;


        notesTotalCount.setText(String.valueOf(Total));
        grandTotalCount.setText(String.valueOf(GTotal));

    }

    private void getdata(EditText edt, int s) {

        if (!edt.getText().toString().isEmpty()) {

            if (s == 1)
                count1 = Integer.parseInt(edtRs1.getText().toString());
            if (s == 2)
                count2 = Integer.parseInt(editRs2.getText().toString());
            if (s == 3)
                count3 = Integer.parseInt(editRs3.getText().toString());
            if (s == 4)
                count4 = Integer.parseInt(editRs4.getText().toString());
            if (s == 5)
                count5 = Integer.parseInt(editRs5.getText().toString());
            if (s == 6)
                count6 = Integer.parseInt(editRs6.getText().toString());
            if (s == 7)
                count7 = Integer.parseInt(editRs7.getText().toString());
            if (s == 9)
                count8 = Integer.parseInt(editRs9.getText().toString());
            if (s == 10)
                count9 = Integer.parseInt(editRs10.getText().toString());
            if (s == 11)
                count10 = Integer.parseInt(editRs11.getText().toString());

        }
    }

    private class TextChange implements TextWatcher {

        View view;

        private TextChange(View v) {
            view = v;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (charSequence.length() > 0 )
                settext(25);
            else{
                switch (view.getId()) {
                    case R.id.edtRs1:
                        edtResult1.setText("0");
                        settext(1);
                        break;
                    case R.id.edtRs2:
                        editResult2.setText("0");
                        settext(2);
                        break;
                    case R.id.edtRs3:
                        settext(3);
                        editResult3.setText("0");
                        break;
                    case R.id.edtRs4:
                        settext(4);
                        editResult4.setText("0");
                        break;
                    case R.id.edtRs5:
                        settext(5);
                        editResult5.setText("0");
                        break;
                    case R.id.edtRs6:
                        settext(6);
                        editResult6.setText("0");
                        break;
                    case R.id.edtRs7:
                        settext(7);
                        editResult7.setText("0");
                        break;
                    case R.id.coinRs1:
                        settext(8);
                        editResult8.setText("0");
                        break;
                    case R.id.coinRs2:
                        settext(9);
                        editResult9.setText("0");
                        break;
                    case R.id.coinRs3:
                        settext(10);
                        editResult10.setText("0");
                        break;

                }
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    }
/*
    void AdsLoadings() {
        ArrayList<String> type = builderAds(requireContext(), COMMON_BANNER);
        if (type.size() > 0) {
            switch (type.get(0)) {
                case GOOGLE_AD:
                    new Utilty().GoogleBannerAdvance(getActivity(), type.get(1), google_layout, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;


                case ADAPTIVE_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().GoogleAdaptiveBanner(getActivity(), type.get(1), google_layout, false, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;
                case SMART_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().mSmartBanner(getActivity(), type.get(1), ad_layout, google_layout);
                    break;

                case CUSTOM_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showCustomBanner(google_layout);
                    break;

                case GAME_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showGameBanner(google_layout);
                    break;
            }
        }
    }
*/
}
