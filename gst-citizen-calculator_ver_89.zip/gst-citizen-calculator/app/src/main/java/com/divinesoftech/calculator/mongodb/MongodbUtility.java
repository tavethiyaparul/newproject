package com.divinesoftech.calculator.mongodb;


import com.divinesoftech.calculator.Classes.Model.Country;
import com.divinesoftech.calculator.Classes.Model.Currency_data;
import com.divinesoftech.calculator.Classes.Model.Data;
import com.divinesoftech.calculator.CustomAd.model.Getversion;

import java.util.ArrayList;

public class MongodbUtility {
//    public static ArrayList<Getversion> mAppLiveAds = new ArrayList<>();

    public static ArrayList<Country> countrylist = new ArrayList<>();
    public static ArrayList<Currency_data> mCurrancyData = new ArrayList<>();
    public static boolean Reload_Currancy = false;


    public static final String MONGODB = "mongodb";
    public static final String DATABASE = "gst_calc";
   // public static final String DATABASE = "a_test_gst_calc";
    public static final String DATABASE_DEVINE = "gst_calc_divine";
    //public static String MONGODB_CONNECTION = "";
//    public static String NODE_CONNECTION = "";
//    public static String NODE_SECRET = "";
    public static String CUSTOM_ADS_ID = "";
//    public static String CUSTOM_DOMAIN = "";
//    public static String FLAG_DOMAIN = "";
//    public static String SKU_LINK = "";
//    public static String SOCKET_CONNECTION = "";
//    public static String SOCKET_HANDSHAKE = "";
//    public static int GAME_ON = 0;
    public static String TABLE_DEVINE_SKU = "sku";
    public static String TABLE_DEVINE_VERSION = "version_table";
    public static String TABLE_DEVINE_CURRANCY = "currancydata";
    public static String TABLE_DEVINE_COUNTRY = "country_flag";
    public static String TABLE_DEVINE_PRIVACY = "privacypolicy";
    public static String TABLE_INSTALL_TRACK = "installtrack";
    public static String TABLE_CUSTOM_ADS = "advertisement_custom";
    public static String TABLE_CUSTOM_ADS_TAG = "advertisement_custom_taglist";
    public static String TABLE_CUSTOM_APP_MASTER = "app_master";
    public static String TABLE_ADS_CUSTOM_COUNT = "app_cad_status";






}
