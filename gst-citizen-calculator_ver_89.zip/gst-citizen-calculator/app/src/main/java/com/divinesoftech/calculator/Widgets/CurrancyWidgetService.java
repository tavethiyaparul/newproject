package com.divinesoftech.calculator.Widgets;

import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

import androidx.annotation.Nullable;

import android.text.TextUtils;
import android.view.View;
import android.widget.RemoteViews;

import com.bumptech.glide.Glide;

import com.bumptech.glide.request.target.AppWidgetTarget;
import com.divinesoftech.calculator.Classes.Model.Currency_data;
import com.divinesoftech.calculator.Classes.Model.WidgetModel;
import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.R;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

import static com.divinesoftech.calculator.Common.Utilty.CURRANCYDATA;
import static com.divinesoftech.calculator.Common.Utilty.PREF_RESPONSE;
import static com.divinesoftech.calculator.Widgets.CurrancyWidget.is_progress;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.mCurrancyData;

public class CurrancyWidgetService extends Service {
    WidgetModel widgetModel = new WidgetModel();


    // private GetLiveCurrancy getCurrencyData = new GetLiveCurrancy();


    AppWidgetTarget appWidgetFrom, appWidgetTargetTo, appWidgetRotate;

    private static final String REFRESH = "refresh";

    /* @Override
     public void onStart(Intent intent, int startId) {
         AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this.getApplicationContext());
         int[] allWidgetIds = intent.getIntArrayExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS);


         SharedPreferences mPrefs = getApplicationContext().getSharedPreferences("widget_prefrence", MODE_PRIVATE);
         Gson gson = new Gson();

         SharedPreferences flagPrefs = getSharedPreferences("flag_prefrence", MODE_PRIVATE);
         SharedPreferences pref_Response = getSharedPreferences(PREF_RESPONSE, MODE_PRIVATE);

        *//* Gson gson1 = new Gson();
        getCurrencyData = gson1.fromJson(flagPrefs.getString("currancy_obj", ""), GetLiveCurrancy.class);*//*

        try {
            if (pref_Response.getString(CURRANCYDATA,null) != null && mCurrancyData.size() == 0) {

                JSONObject object = new JSONObject(pref_Response.getString(CURRANCYDATA,""));
                String data = object.getString("currency_data");
                mCurrancyData = new Gson().fromJson(data, new TypeToken<ArrayList<Currency_data>>() {}.getType());

            }
        } catch (JSONException | NullPointerException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


        for (int widgetId : allWidgetIds) {

            final RemoteViews remoteViews = new RemoteViews(getApplicationContext().getPackageName(), R.layout.currancy_widget_layout);


            String json = mPrefs.getString("MyObject", "");
            if (!TextUtils.isEmpty(json)) {

                widgetModel = gson.fromJson(json, WidgetModel.class);
                String fromLabel = widgetModel.getFrom_shared_label();
                String tolabel = widgetModel.getTo_shared_label();
                String Amount = widgetModel.getFromAmount();
                setFlag(remoteViews, startId);
                caovertation(fromLabel, tolabel, Amount, remoteViews, startId);

                if (is_progress) {
                    remoteViews.setViewVisibility(R.id.reload, View.GONE);
                    remoteViews.setViewVisibility(R.id.reload_loder, View.VISIBLE);
                } else {
                    remoteViews.setViewVisibility(R.id.reload, View.VISIBLE);
                    remoteViews.setViewVisibility(R.id.reload_loder, View.GONE);
                }

            } else {


                String fromLabel = "USD";
                String tolabel = "INR";
                String Amount = "1";
                caovertation(fromLabel, tolabel, Amount, remoteViews, startId);


            }


            Intent click = new Intent("android.intent.action.MAIN");
            click.addCategory("android.intent.category.LAUNCHER");
            click.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            click = new Intent(getApplicationContext(), MainActivity.class);
            click.putExtra("widget", 3);
            click.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, click, PendingIntent.FLAG_UPDATE_CURRENT);


            remoteViews.setOnClickPendingIntent(R.id.refresh, pendingIntent);
            appWidgetManager.updateAppWidget(widgetId, remoteViews);
        }
        stopSelf();

        super.onStart(intent, startId);
    }
*/
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this.getApplicationContext());
        int[] allWidgetIds = intent.getIntArrayExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS);


        SharedPreferences mPrefs = getApplicationContext().getSharedPreferences("widget_prefrence", MODE_PRIVATE);
        Gson gson = new Gson();

        SharedPreferences flagPrefs = getSharedPreferences("flag_prefrence", MODE_PRIVATE);
        SharedPreferences pref_Response = getSharedPreferences(PREF_RESPONSE, MODE_PRIVATE);

       /* Gson gson1 = new Gson();
        getCurrencyData = gson1.fromJson(flagPrefs.getString("currancy_obj", ""), GetLiveCurrancy.class);*/

        try {
            if (pref_Response.getString(CURRANCYDATA, null) != null && mCurrancyData.size() == 0) {

                JSONObject object = new JSONObject(pref_Response.getString(CURRANCYDATA, ""));
                String data = object.getString("currency_data");
                mCurrancyData = new Gson().fromJson(data, new TypeToken<ArrayList<Currency_data>>() {
                }.getType());

            }
        } catch (JSONException | NullPointerException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


        try {
            if (allWidgetIds.length > 0) {
                for (int widgetId : allWidgetIds) {

                    final RemoteViews remoteViews = new RemoteViews(getApplicationContext().getPackageName(), R.layout.currancy_widget_layout);


                    String json = mPrefs.getString("MyObject", "");
                    if (!json.equals("")) {

                        try {
                            widgetModel = gson.fromJson(json, WidgetModel.class);
                            String fromLabel = widgetModel.getFrom_shared_label();
                            String tolabel = widgetModel.getTo_shared_label();
                            String Amount = widgetModel.getFromAmount();
                            setFlag(remoteViews, startId);
                            caovertation(fromLabel, tolabel, Amount, remoteViews, startId);
                        } catch (JsonSyntaxException | NullPointerException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        if (is_progress) {
                            remoteViews.setViewVisibility(R.id.reload, View.GONE);
                            remoteViews.setViewVisibility(R.id.reload_loder, View.VISIBLE);
                        } else {
                            remoteViews.setViewVisibility(R.id.reload, View.VISIBLE);
                            remoteViews.setViewVisibility(R.id.reload_loder, View.GONE);
                        }

                    } else {


                        String fromLabel = "USD";
                        String tolabel = "INR";
                        String Amount = "1";
                        caovertation(fromLabel, tolabel, Amount, remoteViews, startId);


                    }


                    Intent click = new Intent("android.intent.action.MAIN");
                    click.addCategory("android.intent.category.LAUNCHER");
                    click.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    click = new Intent(getApplicationContext(), MainActivity.class);
                    click.putExtra("widget", 3);
                    click.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, click, PendingIntent.FLAG_UPDATE_CURRENT);


                    remoteViews.setOnClickPendingIntent(R.id.refresh, pendingIntent);
                    appWidgetManager.updateAppWidget(widgetId, remoteViews);
                }
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        stopSelf();

        return super.onStartCommand(intent, flags, startId);
    }

    private void caovertation(String fromCNTR, String toCNTR, String amount, RemoteViews views, int start_id) {

        DecimalFormat formater = new DecimalFormat("############.######");

        String match = "";
        SharedPreferences img_url = getApplicationContext().getSharedPreferences("img_prefrence", MODE_PRIVATE);
        Double Amount, dolor_price, first_price = 0.0, second_price = 0.0;

        int from_position = img_url.getInt("from_selecte", 0);
        int to_position = img_url.getInt("to_selecte", 0);

        if (from_position == 0 && to_position == 0) {
            from_position = 149;
            to_position = 66;
        }


        Amount = Double.valueOf(amount);
        views.setTextViewText(R.id.from, amount);
        try {
            if (mCurrancyData.size() > 0) {
                if (!fromCNTR.equals("USD") && !toCNTR.equals("USD")) {
                    String temp = "USD" + fromCNTR;
                    String temp1 = "USD" + toCNTR;

                    if (temp.equals(mCurrancyData.get(from_position).getCountry())) {
                        first_price = Double.valueOf(mCurrancyData.get(from_position).getRate());
                        first_price = first_price * 1;


                    }
                    if (temp1.equals(mCurrancyData.get(to_position).getCountry())) {
                        second_price = Double.valueOf(mCurrancyData.get(to_position).getRate());
                        second_price = second_price * 1;

                    }

                    dolor_price = Amount / first_price;
                    dolor_price = dolor_price * second_price;

                    String result_text = formater.format(dolor_price);
                    views.setTextViewText(R.id.to, result_text);
                    // editText.setText(result_text);


                } else if (!fromCNTR.equals("USD") && toCNTR.equals("USD")) {

                    match = "USD" + fromCNTR;


                    if (match.equals(mCurrancyData.get(from_position).getCountry())) {

                        dolor_price = Double.valueOf(mCurrancyData.get(from_position).getRate());

                        dolor_price = Amount / dolor_price;
                        String result_text = formater.format(dolor_price);
                        views.setTextViewText(R.id.to, result_text);
                        // editText.setText(result_text);


                    }

                } else if (fromCNTR.equals("USD") && !toCNTR.equals("USD")) {
                    match = "USD" + toCNTR;

                    if (match.equals(mCurrancyData.get(to_position).getCountry())) {


                        dolor_price = Double.valueOf(mCurrancyData.get(to_position).getRate());

                        dolor_price = Amount * dolor_price;
                        String result_text = formater.format(dolor_price);

                        if (!TextUtils.isEmpty(result_text))
                            views.setTextViewText(R.id.to, result_text);
                        // editText.setText(result_text);


                    }

                }


            }
        } catch (NumberFormatException | NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setFlag(RemoteViews views, int startId) {
        SharedPreferences imges = getApplicationContext().getSharedPreferences("img_prefrence", MODE_PRIVATE);
        appWidgetFrom = new AppWidgetTarget(getApplicationContext(), R.id.fromImg, views, startId);
        Glide
                .with(getApplicationContext().getApplicationContext()) // safer!
                .asBitmap()
                .load(imges.getString("from_Shared", ""))
                .into(appWidgetFrom);


        appWidgetTargetTo = new AppWidgetTarget(getApplicationContext(), R.id.toImg, views, startId);


        Glide
                .with(getApplicationContext().getApplicationContext()) // safer!
                .asBitmap()
                .load(imges.getString("to_Shared", ""))
                .into(appWidgetTargetTo);
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


}