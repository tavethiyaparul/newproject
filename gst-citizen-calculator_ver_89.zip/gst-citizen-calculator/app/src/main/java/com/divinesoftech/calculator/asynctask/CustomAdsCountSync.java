package com.divinesoftech.calculator.asynctask;

import android.os.AsyncTask;
import android.os.SystemClock;
import android.util.Log;

import com.divinesoftech.calculator.BuildConfig;


import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.concurrent.TimeUnit;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static android.os.Process.THREAD_PRIORITY_BACKGROUND;

public class CustomAdsCountSync extends AsyncTask<String, Void, String> {

    @Override
    protected String doInBackground(String... strings) {
        android.os.Process.setThreadPriority(THREAD_PRIORITY_BACKGROUND);
        SystemClock.sleep(10000);
        try {

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("cad_id", strings[0])
                    .addFormDataPart("package", BuildConfig.APPLICATION_ID)
                    .build();

            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .build();

            Request request = new Request.Builder()
                    .url(strings[1] + strings[2])
                    .post(requestBody)
                    .build();

            Response response = client.newCall(request).execute();
            return response.body().string();

        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

    }
}
