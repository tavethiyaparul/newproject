package com.divinesoftech.calculator.database.room.dao;

import androidx.room.*;
import com.divinesoftech.calculator.database.RoomConnection;
import com.divinesoftech.calculator.database.room.RoomMainAdRecords


@Dao
public interface RoomMainAd {
    @Query("Select data from RoomMainAdRecords where id=:id ")
    fun getRoomMain_Status(id:Int): String

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomMain_Status(roomVersion: RoomMainAdRecords)
}
