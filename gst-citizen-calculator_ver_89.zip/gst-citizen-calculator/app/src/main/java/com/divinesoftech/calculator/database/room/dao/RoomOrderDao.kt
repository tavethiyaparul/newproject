package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomOrder
@Dao
interface RoomOrderDao {
    @Query("Select * from RoomOrder")
    fun getRoomOrder(): List<RoomOrder>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomOrder(roomVersion: RoomOrder)

    @Update
    fun updateRoomOrder(roomVersion: RoomOrder)

    @Delete
    fun deleteRoomOrder(roomVersion: RoomOrder)

    @Query("Delete from RoomOrder")
    fun deleteAllRoomOrder()
}