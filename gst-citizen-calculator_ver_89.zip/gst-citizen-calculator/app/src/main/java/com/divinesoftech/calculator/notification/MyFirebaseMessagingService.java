package com.divinesoftech.calculator.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import android.util.Log;

import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;


import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";
    Bitmap bitmap, picbitmap;
    int type = 1;

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
    // [START receive_message]
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        if (remoteMessage.getData().size() > 0) {


            if (true) {
                scheduleJob();
            } else {
                handleNow();
            }

        }

        //
        if (remoteMessage.getNotification() != null) {

        }

        try {
            type = Integer.parseInt(remoteMessage.getData().get("type"));
        } catch (NumberFormatException e) {
            e.printStackTrace();
            type = 1;
        }
        String message = remoteMessage.getData().get("message");
        String imageUri = remoteMessage.getData().get("image");
        String picUri = remoteMessage.getData().get("picture");

        bitmap = getBitmapfromUrl(imageUri);
        picbitmap = getBitmapfromUrl(picUri);
        sendNotification(message, bitmap, picbitmap);

    }
    // [END receive_message]


    // [START on_new_token]

    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    @Override
    public void onNewToken(String token) {

        sendRegistrationToServer(token);


    }
    // [END on_new_token]

    /**
     * Schedule a job using FirebaseJobDispatcher.
     */
    private void scheduleJob() {

    }

    /**
     * Handle time allotted to BroadcastReceivers.
     */
    private void handleNow() {
    }

    /**
     * Persist token to third-party servers.
     * <p>
     * Modify this method to associate the user's FCM InstanceID token with any server-side account
     * maintained by your application.
     *
     * @param token The new token.
     */
    private void sendRegistrationToServer(String token) {
        storeRegIdInPref(token);
    }

    private void storeRegIdInPref(String token) {


        SharedPreferences pref = getApplicationContext().getSharedPreferences("NotifyTokenGen", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("regId", token);
        editor.apply();

    }

    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param messageBody FCM message body received.
     */
    private void sendNotification(String messageBody, Bitmap image, Bitmap picbitmap) {
        String channelId = getString(R.string.default_notification_channel_id);
        final NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId);
        builder.setSmallIcon(R.drawable.ic_notification);
        builder.setContentTitle(getString(R.string.app_name));
        builder.setContentText(messageBody);
        if (type != 0) {
            builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            builder.setDefaults(NotificationCompat.DEFAULT_LIGHTS);
            builder.setVibrate(new long[]{1000, 1000});
        }
        builder.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(image));/*Notification with Image*/
        builder.setAutoCancel(true);
        builder.setLargeIcon(picbitmap);

        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.putExtra("message", messageBody);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(contentIntent);

        if (Build.VERSION_CODES.O <= Build.VERSION.SDK_INT) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(channelId,
                        "Channel human readable title",
                        NotificationManager.IMPORTANCE_DEFAULT);
                notificationManager.createNotificationChannel(channel);
            }
        }

        Notification notification = builder.build();
        notificationManager.notify(211, notification);

        if (type == 0) {
            Thread thread = new Thread() {
                @Override
                public void run() {
                    try {
                        sleep(500);
                        notificationManager.cancel(211);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };
            thread.start();
        }
    }

    public Bitmap getBitmapfromUrl(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;

        }
    }
}