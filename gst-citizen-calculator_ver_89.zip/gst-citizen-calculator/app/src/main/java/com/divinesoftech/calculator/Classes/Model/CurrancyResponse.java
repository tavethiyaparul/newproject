package com.divinesoftech.calculator.Classes.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class CurrancyResponse implements Serializable
{
    @SerializedName("result")
    private String result;

    @SerializedName("source")
    private String source;

    @SerializedName("currency_data")
    private List <Currency_data> currency_data;

    public List<Currency_data> getCurrency_data() {
        return currency_data;
    }

    public void setCurrency_data(List<Currency_data> currency_data) {
        this.currency_data = currency_data;
    }

    @SerializedName("timestamp")
    private String timestamp;

    @SerializedName("calltime")
    private String calltime;

    public String getResult ()
    {
        return result;
    }

    public void setResult (String result)
    {
        this.result = result;
    }

    public String getSource ()
    {
        return source;
    }

    public void setSource (String source)
    {
        this.source = source;
    }



    public String getTimestamp ()
    {
        return timestamp;
    }

    public void setTimestamp (String timestamp)
    {
        this.timestamp = timestamp;
    }

    public String getCalltime ()
    {
        return calltime;
    }

    public void setCalltime (String calltime)
    {
        this.calltime = calltime;
    }


}