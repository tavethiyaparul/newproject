package com.divinesoftech.calculator.CustomAd.callback;

public interface CustomAdsInit {
    void onSuccess();
    void onFailed();
}
