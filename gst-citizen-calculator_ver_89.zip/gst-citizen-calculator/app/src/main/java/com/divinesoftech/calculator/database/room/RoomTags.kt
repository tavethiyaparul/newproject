package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity
class RoomTags {
    @PrimaryKey
    var id: String = ""
    var attr: String = ""
    var ids: String = ""
    var orderTag: Int = 0
}