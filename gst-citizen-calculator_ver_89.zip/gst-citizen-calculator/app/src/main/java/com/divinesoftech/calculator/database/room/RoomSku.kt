package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class RoomSku{
    @PrimaryKey
    var id: String = ""
    var banner: String = ""
    var image: String = ""
    var title: String = ""
    var title_color: String = ""
    var content1: String = ""
    var content2: String = ""
    var content3: String = ""
    var contentColor: String = ""
    var btnText: String = ""
    var btnColor: String = ""
    var btnTextColor: String = ""
    var sku: String = ""
    var defaultValue: String = ""
    var validity: String = ""
    var enable: Int = 0

}