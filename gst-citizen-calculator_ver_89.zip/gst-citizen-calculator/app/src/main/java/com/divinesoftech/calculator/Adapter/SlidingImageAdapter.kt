package com.divinesoftech.calculator.Adapter

import android.app.Activity
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide

import com.divinesoftech.calculator.Activities.SelectTheme
import com.divinesoftech.calculator.Common.OnSetTheme
import com.divinesoftech.calculator.R
import kotlinx.android.synthetic.main.theme_preview.view.*

class SlidingImageAdapter(var activity: Activity, var themeList: Array<Drawable>, var themeNameList: Array<String>, var setTheme: OnSetTheme): PagerAdapter() {

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val layoutInflater = LayoutInflater.from(activity)
        var view:View = layoutInflater.inflate(R.layout.theme_preview, container, false);
        view.ThemeName

        view.ThemeName.text = themeNameList.get(position)


        Glide.with((activity as SelectTheme))
                .load("")
                .placeholder(themeList.get(position))
                .into(view.theme_img)
        view.theme_img.setOnClickListener(View.OnClickListener {

           // Log.e("==setTheme==> ","XXXXXXXX====adater click=> ")


            setTheme.setTheme(position)
        })

        container.addView(view)

        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view.equals(`object`)
    }

    override fun getCount(): Int {
       return themeList.size
    }
}