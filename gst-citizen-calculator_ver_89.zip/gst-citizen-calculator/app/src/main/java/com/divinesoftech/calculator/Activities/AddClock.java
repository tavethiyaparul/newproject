package com.divinesoftech.calculator.Activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.divinesoftech.calculator.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;

public class AddClock extends AppCompatActivity {
    List<String> clock_list = new ArrayList<>();
    List<String> demolist = new ArrayList<>();
    WorldClockAdapter adapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    EditText search;
    TextView ActionBarTitle;
    ImageView done;
    public Map<String, Boolean> map_checked = new HashMap<String, Boolean>();
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_clock);
        currentActivity=this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_world);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = (TextView) v.findViewById(R.id.action_bar_title);
        done = (ImageView) v.findViewById(R.id.action_done);
        //v.findViewById(R.id.gift_layout).setVisibility(View.GONE);
        getSupportActionBar().setCustomView(v);
        ActionBarTitle.setText("Add Clock");


        sharedPreferences = getSharedPreferences("update", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        recyclerView = findViewById(R.id.recyclview);
        search = findViewById(R.id.search_clock);
        clock_list.clear();
        for (int i = 0; i < TimeZone.getAvailableIDs().length; i++) {
            clock_list.add(TimeZone.getAvailableIDs()[i]);

        }
        demolist.clear();
        Gson gson = new Gson();
        String json = sharedPreferences.getString("clock_shared", "");
        Type type = new TypeToken<List<String>>() {
        }.getType();
        if (!TextUtils.isEmpty(json))
            demolist = gson.fromJson(json, type);



        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

           adapter = new WorldClockAdapter(this, clock_list);
          recyclerView.setAdapter(adapter);

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.equals("")) {
                    adapter.getFilter().filter(s);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                demolist.clear();

                for (int i = 0; i < clock_list.size(); i++) {

                    if (map_checked.containsKey(clock_list.get(i))
                            && map_checked.get(clock_list.get(i)).booleanValue() == true) {
                        demolist.add(clock_list.get(i));
                    }
                }
                Gson gson = new Gson();
                String data_shared = gson.toJson(demolist);
                editor.putString("clock_shared", data_shared);
                editor.apply();
                finish();

            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }

    public class WorldClockAdapter extends RecyclerView.Adapter<WorldClockAdapter.WorldClockHolder> implements Filterable {

        Context context;
        public List<String> dataList;
        String str;
        WorlclockFilter filter;


        public WorldClockAdapter(Context context, List<String> dataList) {
            this.context = context;
            this.dataList = dataList;





            for (int i = 0; i < demolist.size(); i++) {
                for (int j = 0; j < dataList.size(); j++) {
                    if (demolist.get(i).equalsIgnoreCase(dataList.get(j))) {
                        map_checked.put(dataList.get(j), true);
                    }
                }

            }


        }

        @NonNull
        @Override
        public WorldClockHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            view = layoutInflater.inflate(R.layout.world_clock_item, null);
            return new WorldClockHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final WorldClockHolder holder, final int position) {

            TimeZone timeZone = TimeZone.getTimeZone(dataList.get(position));
            Calendar calendar = new GregorianCalendar();
            calendar.setTimeZone(timeZone);

            if (map_checked.containsKey(dataList.get(position)) && map_checked.get(dataList.get(position)).booleanValue() == true) {
                holder.checkBox.setChecked(true);
                map_checked.put(dataList.get(position), true);

            } else {
                holder.checkBox.setChecked(false);
                map_checked.put(dataList.get(position), false);
            }


            if (dataList.get(position).contains("/")) {
                String[] parts = dataList.get(position).split("/");
                String part1 = parts[0];
                String part2 = parts[1];
                holder.city.setText(part2);
                holder.region.setText(part1);
            }


            // holder.time.setText(calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND));
            holder.time.setText(timeZone.getDisplayName(true, TimeZone.SHORT));
            holder.standrdtime.setText(timeZone.getDisplayName());
            holder.layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    done.setVisibility(View.VISIBLE);

                    if (holder.checkBox.isChecked()) {
                        holder.checkBox.setChecked(false);
                        map_checked.put(dataList.get(position), false);
                    } else {
                        holder.checkBox.setChecked(true);
                        map_checked.put(dataList.get(position), true);

                    }

                }
            });


        }


        @Override
        public int getItemCount() {
            return dataList.size();
        }

        @Override
        public Filter getFilter() {
            if (filter == null) {
                filter = new WorlclockFilter(WorldClockAdapter.this, dataList);
                // return filter;
            }

            return filter;
        }

        public class WorldClockHolder extends RecyclerView.ViewHolder {
            public RelativeLayout layout;
            public TextView city, region, time, standrdtime;
            public CheckBox checkBox;

            public WorldClockHolder(View itemView) {
                super(itemView);
                layout = (itemView).findViewById(R.id.layout_world);
                city = (itemView).findViewById(R.id.city);
                region = (itemView).findViewById(R.id.region);
                time = (itemView).findViewById(R.id.time);
                standrdtime = (itemView).findViewById(R.id.standrdtime);
                checkBox = (itemView).findViewById(R.id.checkbox_addclock);

            }
        }
    }

    public class WorlclockFilter extends Filter {
        WorldClockAdapter clockAdapter;
        List<String> datalist;

        public WorlclockFilter(WorldClockAdapter clockAdapter, List<String> datalis) {
            this.clockAdapter = clockAdapter;
            this.datalist = datalis;
        }

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if (constraint != null && constraint.length() > 0) {

                constraint = constraint.toString().toUpperCase();

                List<String> filteredPlayers = new ArrayList<>();

                for (int i = 0; i < datalist.size(); i++) {

                    if (datalist.get(i).toUpperCase().contains(constraint)) {
                        filteredPlayers.add(datalist.get(i));
                    }
                }

                results.count = filteredPlayers.size();
                results.values = filteredPlayers;
            } else {
                results.count = datalist.size();
                results.values = datalist;

            }


            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            clockAdapter.dataList = (List<String>) results.values;
            clockAdapter.notifyDataSetChanged();
        }

    }


}


