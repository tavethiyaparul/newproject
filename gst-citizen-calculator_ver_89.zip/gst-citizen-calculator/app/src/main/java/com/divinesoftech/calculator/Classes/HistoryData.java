package com.divinesoftech.calculator.Classes;

/**
 * Created by jatin android on 3/26/2018.
 */

public class HistoryData {

    String first_oprand,second_oprand,result_total,oprator;

    public String getFirst_oprand() {
        return first_oprand;
    }

    public void setFirst_oprand(String first_oprand) {
        this.first_oprand = first_oprand;
    }

    public String getSecond_oprand() {
        return second_oprand;
    }

    public void setSecond_oprand(String second_oprand) {
        this.second_oprand = second_oprand;
    }

    public String getResult_total() {
        return result_total;
    }

    public void setResult_total(String result_total) {
        this.result_total = result_total;
    }

    public String getOprator() {
        return oprator;
    }

    public void setOprator(String oprator) {
        this.oprator = oprator;
    }
}
