package com.divinesoftech.calculator.Classes.PDF;

import android.app.Activity;

import com.divinesoftech.calculator.R;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import java.io.FileOutputStream;
import java.io.IOException;

public class AddLinkPdf {
    String SRC = "";
    String DEST = "";

    public static void main(String[] args) throws IOException, DocumentException {
        // File file = new File(DEST);
        // file.getParentFile().mkdirs();
        //  new AddLinkPdf().manipulatePdf(SRC, DEST);
    }
    public void manipulatePdf(String src, String dest, Activity activity) throws IOException, DocumentException {
        PdfReader reader = new PdfReader(src);
        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));
        PdfContentByte canvas = stamper.getOverContent(1);
        Font bold = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD);
        bold.setColor(BaseColor.BLUE);
        Phrase pj = new Phrase("Powered By");
        Chunk chunk = new Chunk(activity.getResources().getString(R.string.statementHeader), bold);
        chunk.setUnderline(2.0f,-3.0f);
        chunk.setAnchor(activity.getResources().getString(R.string.url));
        Phrase p = new Phrase();
        p.add(chunk);
        ColumnText ct = new ColumnText(canvas);
        ColumnText ct1 = new ColumnText(canvas);
        ct1.setSimpleColumn(86, 200, 675, 825);
        ct.setSimpleColumn(86, 200, 650, 800);
        ct1.addText(pj);
        ct.addText(p);
        ct1.go();
        ct.go();
        stamper.close();
        reader.close();
    }

}
