package com.divinesoftech.calculator.Activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;
import androidx.appcompat.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.divinesoftech.calculator.Adapter.PageAdapter;
import com.divinesoftech.calculator.R;

import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;

public class ShowPDF extends AppCompatActivity {
    private PageAdapter  adapter;
    private RecyclerView pager;
    private final SnapHelper snapperCarr=new PagerSnapHelper();
    private Uri pickedDocument=null;
    TextView ActionBarTitle;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_pdf);
        currentActivity=this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN ;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);

       /* View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);*/


        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = (TextView) v.findViewById(R.id.action_bar_title);
        getSupportActionBar().setCustomView(v);
      //  ActionBarTitle.setText("Summary");
        //v.findViewById(R.id.gift_layout).setVisibility(View.GONE);

        pager=(RecyclerView)findViewById(R.id.pager);
        pager.setLayoutManager(new LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL, false));
        snapperCarr.attachToRecyclerView(pager);
        if(!TextUtils.isEmpty(getIntent().getStringExtra("URI")))
        {
            pickedDocument = Uri.parse(getIntent().getStringExtra("URI"));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {


                show(pickedDocument);
                ActionBarTitle.setText(pickedDocument.toString().substring(pickedDocument.toString().lastIndexOf("/")+1));
            }
            else
            {
                Intent target = new Intent(Intent.ACTION_VIEW);
                target.setDataAndType(pickedDocument, "application/pdf");
                target.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                Intent intent = Intent.createChooser(target, "Open File");
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    e.printStackTrace();
                }
            }


        }



    }



    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onDestroy() {
        if (adapter!=null) {
            adapter.close();
        }

        super.onDestroy();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    /* @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            if (resultCode== Activity.RESULT_OK) {
                pickedDocument=data.getData();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

                }
                else
                {

                }
            }
        }*/
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void show(Uri uri) {
        try {
            adapter=new PageAdapter(getLayoutInflater(),
                    getContentResolver().openFileDescriptor(uri, "r"));
            pager.setAdapter(adapter);
        }
        catch (java.io.IOException e) {
          e.printStackTrace();
        }
    }


}
