package com.divinesoftech.calculator.Classes.PDF;

import android.app.Activity;

import com.divinesoftech.calculator.Classes.DetailsUtility;
import com.divinesoftech.calculator.R;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseField;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PdfGenrate {
    private Activity activity;
    private PdfWriter pdfWriter;
    String Interest_cal;
    String Loanamount_cal;
    String Monthly_EMI_cal;
    String Period_cal;
    String Total_Interest_cal;
    String Total_Payment_cal;
    String img_path_cal;


    class MyFooter extends PdfPageEventHelper {
        Font font = new Font(Font.FontFamily.COURIER);

        MyFooter() {
        }

        public void onEndPage(PdfWriter writer, Document document) {
            Font font = new Font(Font.FontFamily.UNDEFINED);
            font.setColor(new BaseColor(PdfGenrate.this.activity.getResources().getColor(R.color.tab_background)));
            font.setSize(25.0f);
            PdfContentByte cb = writer.getDirectContent();
            Phrase footer = new Phrase("Page " + writer.getPageNumber(), font);
            try {
                ColumnText.showTextAligned(cb, 0, new Paragraph(new Phrase("", font)), (((document.leftMargin() + 0.0f) + document.topMargin()) + document.bottomMargin()) + 10.0f, document.top(), 0.0f);
            } catch (Exception e) {
            }
            font.setSize(18.0f);
            ColumnText.showTextAligned(cb, 1, footer, ((document.right() - document.left()) / BaseField.BORDER_WIDTH_MEDIUM) + document.leftMargin(), document.bottom() - 10.0f, 0.0f);
        }
    }

    public Boolean write(String Loanamount_cal, String Interest_cal, String Period_cal, String Monthly_EMI_cal, String Total_Interest_cal, String Total_Payment_cal, String fname,String img_path_cal, Activity activity) {
        this.activity = activity;
        this.Loanamount_cal = Loanamount_cal;
        this.Interest_cal = Interest_cal;
        this.Period_cal = Period_cal;
        this.Monthly_EMI_cal = Monthly_EMI_cal;
        this.Total_Interest_cal = Total_Interest_cal;
        this.Total_Payment_cal = Total_Payment_cal;
        this.img_path_cal = img_path_cal;
        try {
            createPdf(fname);
        } catch (IOException e) {
        } catch (DocumentException e2) {
        } catch (Exception e3) {
        }
        return Boolean.valueOf(true);
    }

    public void createPdf(String filename) throws IOException, DocumentException {
        Document document = new Document();
        document.setMargins(0,0,30,30);
        this.pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(filename));
        document.open();
        this.pdfWriter.setPageEvent(new MyFooter());
        document.add(createSpaceTable());
        document.add(createFirstTable());
        document.add(createsecondTable());
        document.close();
    }
    public PdfPTable createSpaceTable()
    {
        Font font = new Font(Font.FontFamily.UNDEFINED);
        font.setColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        font.setSize(25.0f);
        PdfPCell cell = new PdfPCell(new Phrase(""));
        PdfPTable table = new PdfPTable(2);
        try {
            Image img = Image.getInstance(img_path_cal);
            Chunk chunk = new Chunk(img, 10, -15);
            cell.addElement(chunk);

        } catch (BadElementException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        cell.setBorder(2);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        cell.setBorderWidth(BaseField.BORDER_WIDTH_MEDIUM);
        cell.setExtraParagraphSpace(20.0f);
        table.setSpacingAfter(15.0f);
        table.setHorizontalAlignment(0);
        table.setWidthPercentage(100.0f);
        table.addCell(cell);
        Font font_date = new Font(Font.FontFamily.UNDEFINED);
        font_date.setColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        font_date.setSize(15.0f);
        cell = new PdfPCell(new Phrase(new SimpleDateFormat("dd/MM/yyyy").format(new Date(System.currentTimeMillis())), font_date));
        cell.setBorder(2);
        cell.setHorizontalAlignment(2);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        cell.setBorderWidth(BaseField.BORDER_WIDTH_MEDIUM);
        cell.setExtraParagraphSpace(20.0f);
        table.setSpacingAfter(15.0f);
        table.setWidthPercentage(100.0f);
        table.addCell(cell);
        return table;
    }
    public PdfPTable createFirstTable() {
        PdfPTable table = new PdfPTable(2);
        PdfPCell cell = new PdfPCell(new Phrase("Loan Amount"));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase(this.Loanamount_cal));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase("Interest %"));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase(this.Interest_cal));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase("Period"));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase(this.Period_cal));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase("Monthly EMI"));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase(this.Monthly_EMI_cal));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase("Total Interest"));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase(this.Total_Interest_cal));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase("Total Payment"));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        cell = new PdfPCell(new Phrase(this.Total_Payment_cal));
        cell.setPadding(10.0f);
        cell.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        table.addCell(cell);
        table.setSpacingBefore(20.0f);
        return table;
    }

    public PdfPTable createsecondTable() {
        PdfPTable pdfPTable = new PdfPTable(4);
        pdfPTable.setSpacingBefore(15.0f);
        Font font = new Font(Font.FontFamily.TIMES_ROMAN);
        font.setSize(15.0f);
        font.setStyle(Font.BOLD);
        font.setColor(new BaseColor(this.activity.getResources().getColor(R.color.white)));
        PdfPCell cellDetail = new PdfPCell(new Phrase("Month", font));
        cellDetail.setPadding(10.0f);
        cellDetail.setBorder(0);
        cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        pdfPTable.addCell(cellDetail);
        cellDetail = new PdfPCell(new Phrase("Principle", font));
        // cellDetail.setPadding(15.0f);
        cellDetail.setPadding(10.0f);
        cellDetail.setBorder(0);
        cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        pdfPTable.addCell(cellDetail);
        cellDetail = new PdfPCell(new Phrase("Interest", font));
        cellDetail.setPadding(10.0f);
        cellDetail.setBorder(0);
        cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        pdfPTable.addCell(cellDetail);
        cellDetail = new PdfPCell(new Phrase("Balance", font));
        cellDetail.setPadding(10.0f);
        cellDetail.setBorder(0);
        cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
        pdfPTable.addCell(cellDetail);

        Font font_val = new Font(Font.FontFamily.TIMES_ROMAN);
        font_val.setSize(15.0f);
        int Months = Integer.parseInt(this.Period_cal);
        double loanamount =Double.valueOf(this.Loanamount_cal);
        double _loanEMI = Double.valueOf(this.Monthly_EMI_cal);
        double Interest_Rate = (Double.valueOf(this.Interest_cal) / 12.0d) / 100.0d;





        for (int i = 1; i <= Months; i++) {
            DetailsUtility detailData = new DetailsUtility();
            double Interest = loanamount * Interest_Rate;
            double Principal = _loanEMI - Interest;
            double Balance = loanamount - Principal;
            loanamount = Balance;
            if (Balance < 0.0d) {
                Balance = 0.0d;
            }
            detailData.setMonth(String.valueOf(i));
           // detailData.setBalance(String.valueOf(Balance));
           // detailData.setInterest(String.valueOf(Interest));
          //  detailData.setPrinciple(String.valueOf(Principal));

            detailData.setBalance(String.valueOf(Math.round(Balance * 100.0) / 100.0));
            detailData.setInterest(String.valueOf(Math.round(Interest * 100.0) / 100.0));
            detailData.setPrinciple(String.valueOf(Math.round(Principal * 100.0) / 100.0));

            cellDetail = new PdfPCell(new Phrase("" + new Double(detailData.getMonth()).intValue(),font_val));

            cellDetail.setPadding(10.0f);
            cellDetail.setBorder(0);
            if (i % 2 != 0) {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.white)));
            } else {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.light_pdf)));
            }
            pdfPTable.addCell(cellDetail);
            cellDetail = new PdfPCell(new Phrase("" + new Double(detailData.getPrinciple()).intValue(),font_val));
            cellDetail.setPadding(10.0f);
            cellDetail.setBorder(0);
            if (i % 2 != 0) {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.white)));
            } else {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.light_pdf)));
            }
            pdfPTable.addCell(cellDetail);
            cellDetail = new PdfPCell(new Phrase("" + new Double(detailData.getInterest()).intValue(),font_val));
            cellDetail.setPadding(10.0f);
            cellDetail.setBorder(0);
            if (i % 2 != 0) {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.white)));
            } else {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.light_pdf)));
            }
            pdfPTable.addCell(cellDetail);
            cellDetail = new PdfPCell(new Phrase("" +new Double(detailData.getBalance()).intValue() ,font_val));
            cellDetail.setPadding(10.0f);
            cellDetail.setBorder(0);
            if (i % 2 != 0) {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.white)));
            } else {
                cellDetail.setBackgroundColor(new BaseColor(this.activity.getResources().getColor(R.color.light_pdf)));
            }
            pdfPTable.addCell(cellDetail);
        }
        return pdfPTable;
    }

}
