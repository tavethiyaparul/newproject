package com.divinesoftech.calculator.Classes.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Currency_data implements Serializable {


    @SerializedName("rate")
    private String rate;

    @SerializedName("country")
    private String country;

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
