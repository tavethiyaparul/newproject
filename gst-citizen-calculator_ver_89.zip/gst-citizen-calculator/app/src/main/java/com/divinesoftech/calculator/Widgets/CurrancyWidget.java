package com.divinesoftech.calculator.Widgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.AppWidgetTarget;
import com.divinesoftech.calculator.Classes.Model.CountryUtility;
import com.divinesoftech.calculator.Classes.Model.WidgetModel;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.divinesoftech.calculator.mongodb.CountryFlagSync;
import com.divinesoftech.calculator.mongodb.CurrancyDataSync;
import com.divinesoftech.calculator.mongodb.OnConnectionMongoDb;
import com.divinesoftech.calculator.mongodb.OnResponseData;


import java.text.DecimalFormat;

import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.calculator.Common.Utilty.isNetworkAvailable;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.DATABASE;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.DATABASE_DEVINE;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.mCurrancyData;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;


public class CurrancyWidget extends AppWidgetProvider {


  //  private GetLiveCurrancy getCurrencyData = new GetLiveCurrancy();
    public static String buffer = "apikey";
    private CountryUtility countryUtility = new CountryUtility();
    WidgetModel widgetModel = new WidgetModel();
    public static String buffers = "sapiv";
    String fromLabel = "", toLabel = "", amount = "";
    SharedPreferences convert_value;
    public static String bufferrs = "scdr";
    SharedPreferences.Editor convert_Editor;
    DecimalFormat formater = new DecimalFormat("############.000");
    public static boolean is_progress = false;
    public static String buferrs = "country.json";
    public boolean is_default = false;
    public boolean is_refresh = false;
    public static String buuferrs = "skud";
    public static String bufeers = "sadm";
    DatabaseGst databaseGst;
  //  FirebaseRemoteConfig mFirebaseRemoteConfig;



    //  private static final String MyOnClick = "myOnClickTag";
    AppWidgetTarget appWidgetFrom, appWidgetTargetTo;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {

        super.onUpdate(context, appWidgetManager, appWidgetIds);

        ComponentName thisWidget = new ComponentName(context, CurrancyWidget.class);
        int[] allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
        SharedPreferences mPrefs = context.getSharedPreferences("widget_prefrence", MODE_PRIVATE);
        SharedPreferences currancyPrefs = context.getSharedPreferences("currancy_prefrence", MODE_PRIVATE);
        final RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.currancy_widget_layout);
        SharedPreferences img_url = context.getSharedPreferences("img_prefrence", MODE_PRIVATE);

       /* mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setDeveloperModeEnabled(BuildConfig.DEBUG)
                .setMinimumFetchIntervalInSeconds(3600)
                .build();
        mFirebaseRemoteConfig.setConfigSettings(configSettings);*/



        for (int widgetId : allWidgetIds) {

            if (TextUtils.isEmpty(mPrefs.getString("MyObject", ""))) {
                if (isNetworkAvailable(context)) {


                    is_default = true;
                    if(mCurrancyData != null && mCurrancyData.size() > 0)
                    {
                        CurrancyDataTable(context);
                    }





                } else {
                    Toast.makeText(context, "Cheack Connectivity", Toast.LENGTH_SHORT).show();
                }
            } else {

                appWidgetFrom = new AppWidgetTarget(context, R.id.fromImg, remoteViews, widgetId);
                Glide
                        .with(context.getApplicationContext()) // safer!
                        .asBitmap()
                        .load(img_url.getString("from_Shared", ""))
                        .into(appWidgetFrom);
                appWidgetTargetTo = new AppWidgetTarget(context,R.id.toImg, remoteViews,  widgetId);

                Glide
                        .with(context.getApplicationContext()) // safer!
                        .asBitmap()
                        .load(img_url.getString("to_Shared", ""))
                        .into(appWidgetTargetTo);


                try {

                    remoteViews.setViewVisibility(R.id.reload_loder, View.GONE);
                    remoteViews.setViewVisibility(R.id.reload, View.VISIBLE);
                    Intent intent = new Intent(context.getApplicationContext(), CurrancyWidgetService.class);
                    intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, allWidgetIds);
                  /*  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(intent);
                    }else {
                        context.startService(intent);
                    }*/
                    context.startService(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            Intent active = new Intent(context, CurrancyWidget.class);
            active.setAction("Action_refresh");
            PendingIntent actionPendingIntent;
            if (Build.VERSION.SDK_INT >= 31) {
                actionPendingIntent = PendingIntent.getBroadcast(context, 0, active, PendingIntent.FLAG_IMMUTABLE);
            } else {
                actionPendingIntent = PendingIntent.getBroadcast(context, 0, active, PendingIntent.FLAG_MUTABLE);
            }
            remoteViews.setOnClickPendingIntent(R.id.reload, actionPendingIntent);

            appWidgetManager.updateAppWidget(widgetId, remoteViews);
        }


    }


    @Override
    public void onReceive(final Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();


        if (action.equals("Action_refresh")) {
            convert_value = context.getSharedPreferences("convert_prefrence", MODE_PRIVATE);
            convert_Editor = convert_value.edit();
            is_progress = true;
            is_default = false;
            is_refresh = true;


            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.currancy_widget_layout);
            if (isNetworkAvailable(context)) {
                remoteViews.setViewVisibility(R.id.reload, View.GONE);
                remoteViews.setViewVisibility(R.id.reload_loder, View.VISIBLE);
                remoteViews.setProgressBar(R.id.reload_loder, 15, 1, false);

              //  new GetKey(context, remoteViews).execute();
                CurrancyDataTable(context);
                //  new CurrencyData(remoteViews, context).execute();
            } else {
                Toast.makeText(context, "Cheack Connectivity", Toast.LENGTH_SHORT).show();
            }


            AppWidgetManager gm = AppWidgetManager.getInstance(context);
            int[] ids = gm.getAppWidgetIds(new ComponentName(context, CurrancyWidget.class));
            this.onUpdate(context, gm, ids);


            // Log.e("onReceive", "Action_refresh");

        }

        if (action.equals("REFRESH")) {


            AppWidgetManager gm = AppWidgetManager.getInstance(context);
            int[] ids = gm.getAppWidgetIds(new ComponentName(context, CurrancyWidget.class));
            this.onUpdate(context, gm, ids);
        }


    }

  /*  private class GetKey extends AsyncTask<String, Integer, String> {
        String resultUpdate = "", key = " ";
        Context context;
        RemoteViews views;

        public GetKey(Context context) {
            this.context = context;
        }

        public GetKey(Context context, RemoteViews views) {
            this.context = context;
            this.views = views;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                OkHttpClient httpClient = new OkHttpClient.Builder()
                        .connectTimeout(10, TimeUnit.SECONDS)
                        .readTimeout(10, TimeUnit.SECONDS)
                        .build();
                Request request = new Request.Builder()
                        .url(imports + buffer)
                        .build();

                Response response = httpClient.newCall(request).execute();
                return response.body().string();

            } catch (SocketTimeoutException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (!TextUtils.isEmpty(s)) {
                try {
                      Log.e("--------->","----widget---s--curr------->  "+s);
                    JSONObject jsonObject = new JSONObject(s);
                    key = jsonObject.getString("result");
                    KEY_STORE = key;

                    if (!is_default) {
                        new CurrencyData(views, context).execute();
                    } else {
                        new CurrencyData(context).execute();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }


        }
    }

    private class CurrencyData extends AsyncTask<String, Integer, String> {
        String RESULT = "";

        RemoteViews views;
        Context context;

        public CurrencyData(Context context) {
            this.context = context;
        }

        public CurrencyData(RemoteViews views, Context context) {
            this.views = views;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


            if (!is_default) {
                *//*if(is_refresh) {
                    views.setViewVisibility(R.id.reload, View.GONE);
                    views.setProgressBar(R.id.reload_loder, 15, 1, false);
                }*//*
            }
        }


        @Override
        protected String doInBackground(String... strings) {
            try {
                RequestBody requestBody_version = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("data", KEY_STORE)
                        .build();
                OkHttpClient client_version = new OkHttpClient.Builder()
                        .connectTimeout(10, TimeUnit.SECONDS)
                        .readTimeout(10, TimeUnit.SECONDS)
                        .build();
                Request request_version = new Request.Builder()
                        .url(imports + bufferrs)
                        .post(requestBody_version)
                        .build();
                Response response_version = null;

                response_version = client_version.newCall(request_version).execute();

                return response_version.body().string();
            } catch (SocketTimeoutException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;

        }


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            JSONObject jsonObject = null;
            try {
                if (!TextUtils.isEmpty(s)) {
                    jsonObject = new JSONObject(s);
                    String datacount = jsonObject.getString("datacount");

                    if (datacount.equals("1")) {

                        if (!s.equals("")) {
                            Gson gson = new Gson();
                            getCurrencyData = gson.fromJson(s, GetLiveCurrancy.class);

                            SharedPreferences flagPrefs = context.getSharedPreferences("flag_prefrence", MODE_PRIVATE);
                            SharedPreferences.Editor currancyEditor = flagPrefs.edit();
                            String currancy_json = gson.toJson(getCurrencyData);
                            currancyEditor.putString("currancy_obj", currancy_json);
                            currancyEditor.apply();


                            if (!is_default) {

                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {


                                        //  RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.currancy_widget_layout);

                                        is_progress = false;
                                        Intent intent = new Intent(context, CurrancyWidget.class);
                                        intent.setAction("REFRESH");
                                        context.sendBroadcast(intent);
                                        Toast.makeText(context, "Rate Refreshed", Toast.LENGTH_SHORT).show();
                                    }
                                }, 5000);
                                new FlagData(context).execute();

                            } else {

                                if (is_refresh) {
                                    is_progress = false;
                                }
                                new FlagData(context).execute();

                                AppWidgetManager gm = AppWidgetManager.getInstance(context);
                                ComponentName thisWidget = new ComponentName(context, CurrancyWidget.class);
                                int[] allWidgetIds = gm.getAppWidgetIds(thisWidget);
                                Intent intent = new Intent(context.getApplicationContext(), CurrancyWidgetService.class);
                                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, allWidgetIds);
                                context.startService(intent);
                            }


                        }
                    }
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }


    }

    private class FlagData extends AsyncTask<String, Integer, String> {
        String RESULT = "";
        Context context;

        public FlagData(Context context) {
            this.context = context;
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                OkHttpClient httpClient = new OkHttpClient.Builder()
                        .connectTimeout(10, TimeUnit.SECONDS)
                        .readTimeout(10, TimeUnit.SECONDS)
                        .build();
                Request request = new Request.Builder()
                        .url(importes + buferrs)
                        .build();

                Response response = httpClient.newCall(request).execute();
                return response.body().string();

            } catch (SocketTimeoutException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            try {
                if (!s.equals("")) {
                    Gson gson = new Gson();
                    countryUtility = gson.fromJson(s, CountryUtility.class);

                    SharedPreferences flagPrefs = context.getSharedPreferences("flag_prefrence", MODE_PRIVATE);
                    SharedPreferences.Editor flagEditor = flagPrefs.edit();
                    String flag_json = gson.toJson(countryUtility);
                    flagEditor.putString("flag_obj", flag_json);
                    flagEditor.apply();
                }
            } catch (JsonSyntaxException e) {
                e.printStackTrace();
            }
        }
    }*/




    void CurrancyDataTable(Context context) {
        databaseGst = new DatabaseGst(context);
        new CurrancyDataSync(databaseGst, new OnResponseData() {
            @Override
            public void onResponse() {


                if (!is_default) {

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {




                            is_progress = false;
                            Intent intent = new Intent(context, CurrancyWidget.class);
                            intent.setAction("REFRESH");
                            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
                            Toast.makeText(context, "Rate Refreshed", Toast.LENGTH_SHORT).show();
                        }
                    }, 3000);


                } else {

                    if (is_refresh) {
                        is_progress = false;
                    }
                    CountryFlagData();

                    AppWidgetManager gm = AppWidgetManager.getInstance(context);
                    ComponentName thisWidget = new ComponentName(context, CurrancyWidget.class);
                    int[] allWidgetIds = gm.getAppWidgetIds(thisWidget);
                    Intent intent = new Intent(context.getApplicationContext(), CurrancyWidgetService.class);
                    intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, allWidgetIds);
                    context.startService(intent);
                }




            }

            @Override
            public void onFailed() {


            }
        }).execute("");

    }

    void CountryFlagData() {

        new CountryFlagSync(databaseGst, new OnResponseData() {
            @Override
            public void onResponse() {


            }

            @Override
            public void onFailed() {



            }
        }).execute("");

    }


}
