package com.divinesoftech.calculator.Common;

public interface OnCustomAdsClose {
    void onCloseAds();
}
