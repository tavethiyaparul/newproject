package com.divinesoftech.calculator.Service;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.util.Log;

public class ScreenStateService extends Service {

    ScreenReciever screenReciever;

    public void RegisterScreenReciever() {
        screenReciever = new ScreenReciever();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        LocalBroadcastManager.getInstance(this).registerReceiver(screenReciever, filter);


    }

    public void UnRegisterScreenReciever() {
        try {
            if (screenReciever != null) {
                LocalBroadcastManager.getInstance(this).unregisterReceiver(screenReciever);
            }
        } catch (Exception e) {

        }
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();


        RegisterScreenReciever();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        UnRegisterScreenReciever();
    }
}
