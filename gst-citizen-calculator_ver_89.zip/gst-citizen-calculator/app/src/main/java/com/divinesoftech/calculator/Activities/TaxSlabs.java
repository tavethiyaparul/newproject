package com.divinesoftech.calculator.Activities;

import static com.divinesoftech.SocketKt.bannerInlineAdaptiveAds;
import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;
import static com.divinesoftech.calculator.Common.Utilty.ADAPTIVE_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.BACKUP_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.COMMON_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.CUSTOM_AD;
import static com.divinesoftech.calculator.Common.Utilty.FACEBOOK_AD;
import static com.divinesoftech.calculator.Common.Utilty.FACEBOOK_NATIVE_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.GAME_AD;
import static com.divinesoftech.calculator.Common.Utilty.GOOGLE_AD;
import static com.divinesoftech.calculator.Common.Utilty.IS_ADFREE;
import static com.divinesoftech.calculator.Common.Utilty.SMART_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.isNetworkAvailable;
import static com.divinesoftech.calculator.Common.Utilty.is_gst_button;
import static com.divinesoftech.calculator.database.ApiKt.builderAds;
import static com.divinesoftech.calculator.database.ApiKt.isAdsLibsLoad;
import static com.divinesoftech.calculator.database.ApiKt.showCustomBanner;
import static com.divinesoftech.calculator.database.ApiKt.showGameBanner;
import static com.divinesoftech.calculator.database.room.RoomDatabaseGstKt.instances;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.divinesoftech.calculator.Common.Utilty;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.AdsFailToLoad;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.divinesoftech.calculator.database.room.RoomVersion;

import java.util.ArrayList;
import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;

public class TaxSlabs extends AppCompatActivity implements View.OnFocusChangeListener {

    TextView ActionBarTitle;
    ImageView done;
    FrameLayout ad_frame;

    final int[] ids = {R.id.et_plus_one, R.id.et_plus_two, R.id.et_plus_three, R.id.et_plus_four, R.id.et_plus_five, R.id.et_minus_one, R.id.et_minus_two, R.id.et_minus_three, R.id.et_minus_four, R.id.et_minus_five};
    final String[] defaul_val = {"+3", "+5", "+12", "+18", "+28", "-3", "-5", "-12", "-18", "-28"};
    private boolean is_plus = false, is_eror = false;
    SharedPreferences slab_prefr;
    List<String> pref_values;
    int count = 0;
    RelativeLayout ad_tax;
    SharedPreferences preferences;
    DatabaseGst databaseGst;
    RelativeLayout ad_layout;
    LinearLayout google_layout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tax_slab);
        currentActivity = this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_tax_slab);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        View decorView = getWindow().getDecorView();

        databaseGst = new DatabaseGst(TaxSlabs.this);
        preferences = getSharedPreferences("update", MODE_PRIVATE);
        slab_prefr = getSharedPreferences("slab_values", MODE_PRIVATE);
        pref_values = new ArrayList<>();
        ad_layout = findViewById(R.id.ad_layout);
        google_layout = findViewById(R.id.google_layout);
        setpref();
        is_gst_button = false;


        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);

        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = (TextView) v.findViewById(R.id.action_bar_title);
        getSupportActionBar().setCustomView(v);
        ActionBarTitle.setText("Change Tax Slab");
        //v.findViewById(R.id.gift_layout).setVisibility(View.GONE);
        done = (ImageView) v.findViewById(R.id.action_done);
        done.setVisibility(View.VISIBLE);
        ad_tax = findViewById(R.id.ad_tax);
        init();


        if (isNetworkAvailable(TaxSlabs.this)
                && databaseGst.getResponse(IS_ADFREE) != null
                && !databaseGst.getResponse(IS_ADFREE).equals("YES")
                && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
        }

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 0;

                if (!reapet_slab()) {
                    for (int i = 0; i < ids.length; i++) {
                        Check_constarins(ids[i]);
                    }
                }

            }
        });

    }


    public void init() {

        for (int i = 0; i < ids.length; i++) {
            findViewById(ids[i]).setOnFocusChangeListener(this);
            setValues(ids[i], i);
            selection_last(ids[i]);
            ET_TaxtChange(ids[i]);
        }


    }

    private void selection_last(int i) {
        EditText editText = findViewById(i);
        editText.setSelection(editText.getText().length());
    }


    private void ET_TaxtChange(int i) {

        final EditText editText = findViewById(i);


        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                editText.setSelection(editText.getText().length());

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                /**/


                if (s.length() == 0) {

                    if (is_plus) {
                        editText.setText("+");
                        editText.setSelection(editText.getText().length());
                    } else {
                        editText.setText("-");
                        editText.setSelection(editText.getText().length());
                    }

                } else if (s.length() == 2) {
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);

                    if (editText.getText().toString().contains("."))
                        setzero(editText);

                } else if (s.length() == 3) {
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);

                    if (editText.getText().toString().equals("+00") || editText.getText().toString().equals("-00"))
                        setzero(editText);

                } else if (s.length() == 6) {
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
                } else if (s.length() == 7) {
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);

                    if (editText.getText().toString().equals("+0.0000") || editText.getText().toString().equals("-0.0000"))
                        setzero(editText);
                } else {
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
                }

            }


            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }

    private void Check_constarins(int id) {

        EditText editText = findViewById(id);

        if (editText.getText().toString().length() == 1 || Double.valueOf(editText.getText().toString().substring(1, editText.getText().toString().length())) > 999.99) {
            Toast.makeText(this, "Enter Correct value", Toast.LENGTH_SHORT).show();
            is_eror = true;


        } else {
            count++;

            if (ids[0] == id)
                store_shared(0, id);

            if (ids[1] == id)
                store_shared(1, id);


            if (ids[2] == id)
                store_shared(2, id);


            if (ids[3] == id)
                store_shared(3, id);


            if (ids[4] == id)
                store_shared(4, id);

            if (ids[5] == id)
                store_shared(5, id);


            if (ids[6] == id)
                store_shared(6, id);


            if (ids[7] == id)
                store_shared(7, id);


            if (ids[8] == id)
                store_shared(8, id);


            if (ids[9] == id)
                store_shared(9, id);


            if (count == 10) {
                Utilty.is_done = true;
                finish();
            }

        }


    }

    private void setzero(EditText editText) {
        if (is_plus) {
            editText.setText("+0");
            editText.setSelection(editText.getText().length());
        } else {
            editText.setText("-0");
            editText.setSelection(editText.getText().length());
        }
    }

    private void setpref() {
        for (int i = 0; i < ids.length; i++) {

            pref_values.add(slab_prefr.getString("slab_" + i, defaul_val[i]));
        }


    }

    private boolean cheack_reapet() {
        List<String> plus_values_temp = new ArrayList<>();
        List<String> minus_values_temp = new ArrayList<>();
        //  plus_values_temp.clear();
        // minus_values_temp.clear();
        for (int i = 0; i < ids.length; i++) {
            EditText editText = findViewById(ids[i]);
            if (i <= 4) {
                plus_values_temp.add(editText.getText().toString());
            }

            if (i > 4 && i <= 9) {
                minus_values_temp.add(editText.getText().toString());
            }

        }

        for (int i = 0; i < plus_values_temp.size(); i++) {
            EditText editText = findViewById(ids[i]);

            if (plus_values_temp.contains(editText.getText().toString())) {

            }

        }


        for (int i = 0; i < 9; i++) {
            EditText editText = findViewById(ids[i]);

            if (i <= 4) {
                if (plus_values_temp.get(i).equals(editText.getText().toString())) {
                    Toast.makeText(this, "value Already add in + slab", Toast.LENGTH_SHORT).show();
                    return true;

                }
            } else {
                int j = i - 5;

                if (minus_values_temp.get(j).equals(editText.getText().toString())) {
                    Toast.makeText(this, "value Already add in - slab", Toast.LENGTH_SHORT).show();
                    return true;

                }
            }

        }

        return false;
    }


    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        int action_id = v.getId();
        EditText editText = findViewById(action_id);

        if (action_id == ids[0]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[0]);
            }

        } else if (action_id == ids[1]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[1]);
            }

        } else if (action_id == ids[2]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[2]);
            }

        } else if (action_id == ids[3]) {

            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[3]);
            }

        } else if (action_id == ids[4]) {
            if (hasFocus) {
                is_plus = true;
                ET_TaxtChange(ids[4]);
            }

        } else if (action_id == ids[5]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[5]);
            }

        } else if (action_id == ids[6]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[6]);
            }

        } else if (action_id == ids[7]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[7]);
            }
        } else if (action_id == ids[8]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[8]);
            }
        } else if (action_id == ids[9]) {
            if (hasFocus) {
                is_plus = false;
                ET_TaxtChange(ids[9]);
            }
        }
    }

    private void setValues(int id, int i) {

        EditText editText = findViewById(id);

        if (ids[i] == id)
            editText.setText(pref_values.get(i));


    }

    private void store_shared(int i, int id) {
        SharedPreferences.Editor editor_slab = slab_prefr.edit();
        EditText editText = findViewById(id);

        if (editText.getText().toString().substring(editText.getText().toString().length() - 1).equals(".")) {

            editor_slab.putString("slab_" + i, editText.getText().toString().substring(0, editText.getText().toString().length() - 1));
        } else if (i <= 4) {

            if (!editText.getText().toString().contains("+")) {
                editor_slab.putString("slab_" + i, "+" + editText.getText().toString());
            } else {
                editor_slab.putString("slab_" + i, editText.getText().toString());
            }


        } else if (i >= 5) {
            if (!editText.getText().toString().contains("-")) {
                editor_slab.putString("slab_" + i, "-" + editText.getText().toString());
            } else {
                editor_slab.putString("slab_" + i, editText.getText().toString());
            }
        }


        editor_slab.apply();
    }


    void AdsLoadings() {
        RoomVersion roomVersion = instances.versionDao().getAdsAvailable(COMMON_BANNER);
        if (roomVersion == null) {
            bannerInlineAdaptiveAds(this, google_layout, BACKUP_BANNER, () -> {
                showCustomBanner(google_layout);
                return null;
            });
        } else {
            ArrayList<String> type = builderAds(this, COMMON_BANNER);
            if (type.size() > 0) {

                switch (type.get(0)) {
                    case GOOGLE_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        new Utilty().GoogleBannerAdvance(false, TaxSlabs.this, type.get(1), google_layout, () -> showCustomBanner(google_layout));
                        break;

                    case ADAPTIVE_BANNER:
                        bannerInlineAdaptiveAds(this, google_layout, type.get(1), () -> {
                            showCustomBanner(google_layout);
                            return null;
                        });
                        break;
                    case CUSTOM_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        showCustomBanner(google_layout);
                        break;

                    case GAME_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        showGameBanner(google_layout);
                        break;
                }
            }
        }
    }

    private boolean reapet_slab() {
        EditText plus_one, plus_two, plus_three, plus_four, plus_five, minus_one, minus_two, minus_three, minus_four, minus_five;
        plus_one = findViewById(ids[0]);
        String add_one = plus_one.getText().toString();
        plus_two = findViewById(ids[1]);
        plus_three = findViewById(ids[2]);
        plus_four = findViewById(ids[3]);
        plus_five = findViewById(ids[4]);
        minus_one = findViewById(ids[5]);
        minus_two = findViewById(ids[6]);
        minus_three = findViewById(ids[7]);
        minus_four = findViewById(ids[8]);
        minus_five = findViewById(ids[9]);

        if (plus_one.getText().toString().equals(plus_two.getText().toString()) || plus_one.getText().toString().equals(plus_three.getText().toString()) || plus_one.getText().toString().equals(plus_four.getText().toString()) || plus_one.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_two.getText().toString().equals(plus_one.getText().toString()) || plus_two.getText().toString().equals(plus_three.getText().toString()) || plus_two.getText().toString().equals(plus_four.getText().toString()) || plus_two.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_three.getText().toString().equals(plus_two.getText().toString()) || plus_three.getText().toString().equals(plus_one.getText().toString()) || plus_three.getText().toString().equals(plus_four.getText().toString()) || plus_three.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_four.getText().toString().equals(plus_two.getText().toString()) || plus_four.getText().toString().equals(plus_three.getText().toString()) || plus_four.getText().toString().equals(plus_one.getText().toString()) || plus_four.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (plus_five.getText().toString().equals(plus_two.getText().toString()) || plus_five.getText().toString().equals(plus_three.getText().toString()) || plus_five.getText().toString().equals(plus_four.getText().toString()) || plus_five.getText().toString().equals(plus_one.getText().toString())) {
            Toast.makeText(this, "value Already add in + slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_one.getText().toString().equals(minus_two.getText().toString()) || minus_one.getText().toString().equals(minus_three.getText().toString()) || minus_one.getText().toString().equals(minus_four.getText().toString()) || minus_one.getText().toString().equals(minus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_two.getText().toString().equals(minus_one.getText().toString()) || minus_two.getText().toString().equals(minus_three.getText().toString()) || minus_two.getText().toString().equals(plus_four.getText().toString()) || minus_two.getText().toString().equals(plus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_three.getText().toString().equals(minus_two.getText().toString()) || minus_three.getText().toString().equals(minus_one.getText().toString()) || minus_three.getText().toString().equals(minus_four.getText().toString()) || minus_three.getText().toString().equals(minus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_four.getText().toString().equals(minus_two.getText().toString()) || minus_four.getText().toString().equals(minus_three.getText().toString()) || minus_four.getText().toString().equals(minus_one.getText().toString()) || minus_four.getText().toString().equals(minus_five.getText().toString())) {
            Toast.makeText(this, "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        } else if (minus_five.getText().toString().equals(minus_two.getText().toString()) || minus_five.getText().toString().equals(minus_three.getText().toString()) || minus_five.getText().toString().equals(plus_four.getText().toString()) || minus_five.getText().toString().equals(minus_one.getText().toString())) {
            Toast.makeText(this, "value Already add in - slab", Toast.LENGTH_SHORT).show();
            return true;
        }


        return false;
    }


}
