package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class RoomAdsLoaded {
    @PrimaryKey
    var id: String = ""
    var ads_id: String = ""
    var ads_name: String = ""
    var placement_name: String = ""
}