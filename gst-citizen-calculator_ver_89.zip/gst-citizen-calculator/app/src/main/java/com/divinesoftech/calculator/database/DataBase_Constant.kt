package com.divinesoftech.calculator.database

class DataBase_Constant {

    companion object {
        //Todo constant ids
        const val DATA_CONNECTION: Int = 1
        const val DATA_CUSTOM_DOMAIN: Int = 2
        const val DATA_CUSTOM_FLAG: Int = 3
        const val DATA_CURRANCY: Int = 4
        const val DATA_COUNTRY_FLAG: Int = 5
        const val DATA_VERSION: Int = 6
        const val DATA_CUSTOM_ADS: Int = 7
        const val DATA_INSTALL_TRACK: Int = 8
        const val DATA_SKU: Int = 9
        const val DATA_GAME_URL: Int = 10
        const val DATA_GAME_ON: Int = 11
        const val NODE_ID: Int = 12
        const val NODE_SECRET_ID: Int = 13
        const val SKU_LINK_ID: Int = 14
        const val SOCKET_CONNECTION_ID: Int = 15
        const val SOCKET_HANDSHAKE_ID: Int = 16
        const val PRIVACY_POLICY_ID: Int = 17
        const val SUBSCRIPTION_STATE_ID: Int = 18
        const val SUBSCRIPTION_ORDER_ID_ID: Int = 19
        const val RATE_ID: Int = 20
        const val RATE_VALUE_ID: Int = 21
        const val RATE_FIRST_OPEN_ID: Int = 22
        const val RATE_VERSION_ID: Int = 23
        const val HOME_BANNER_NATIVE_ID: Int = 24
        const val HOME_IN_APP_DIALOG_ID: Int = 25
        const val HOME_IN_APP_DIALOG_SHOW_ID: Int = 26
        const val SPLASH_BANNER_ID: Int = 27
        const val ID_TIME_STAMP_FULL_SPLASH: Int = 28
        const val ID_PURCHASE_DIALOG: Int = 29
        const val ID_RATE_APP_FIRST_TIME: Int = 30
        const val ID_TIME_STAMP_RATE_APP_DIALOG: Int = 31

    }

}