package com.divinesoftech.calculator.database.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class RoomAdsChild{
    @PrimaryKey
    var id: String = ""
    var ads_name: String = ""
    var enable: Int = 0
    var ads_id: String = ""
}