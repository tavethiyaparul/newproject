package com.divinesoftech.calculator.ads;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GetAdsIds implements Serializable {
    @SerializedName("result")
    private Result result;

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }


}