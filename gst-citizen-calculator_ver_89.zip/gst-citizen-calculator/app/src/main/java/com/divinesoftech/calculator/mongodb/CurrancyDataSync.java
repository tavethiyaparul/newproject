package com.divinesoftech.calculator.mongodb;

import static com.divinesoftech.calculator.Common.Utilty.Currancy_Response;

import android.os.AsyncTask;

import com.divinesoftech.calculator.Classes.Model.Currency_data;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class CurrancyDataSync extends AsyncTask<String, Integer, String> {


    DatabaseGst databaseGst;
    OnResponseData onResponse;



    public CurrancyDataSync(DatabaseGst databaseGst, OnResponseData onResponse) {

        this.databaseGst = databaseGst;
        this.onResponse = onResponse;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {



     /*   try {

            MongoClientURI mongoClientURI = new MongoClientURI(strings[0]);
            mongoClient = new MongoClient(mongoClientURI);
            MongoDatabase mongoDatabase = mongoClient.getDatabase(DATABASE);



            MongoCollection<Document> collection = mongoDatabase.getCollection(TABLE_DEVINE_CURRANCY);
            Document myDoc = collection.find().first();

            return myDoc.toJson();
        } catch (NullPointerException
                | MongoSocketClosedException
                | MongoExecutionTimeoutException
                | MongoSocketReadException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {

            if (mongoClient != null) {
                mongoClient.close();
            }
        }*/
        return null;
    }

    @Override
    protected void onPostExecute(String s) {


        if (s != null) {

            try {


                JSONObject object = new JSONObject(s);
                String data = object.getString("currency_data");




                if (databaseGst.getResponse(Currancy_Response) != null) {
                    databaseGst.setResponse(Currancy_Response, data.trim(), "true");
                } else {
                    databaseGst.setResponse(Currancy_Response, data.trim(), "false");
                }

                JSONObject object1 = new JSONObject(data);
                String data1 = object1.getString("currency_data");



                MongodbUtility.mCurrancyData = new Gson().fromJson(data1, new TypeToken<ArrayList<Currency_data>>() {}.getType());
                onResponse.onResponse();


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            } catch (java.lang.IllegalStateException e) {
                e.printStackTrace();
            }catch (Exception e) {
                e.printStackTrace();
            }
        }


        super.onPostExecute(s);
    }
}
