package com.divinesoftech.calculator.mongodb;

public interface OnConnectionMongoDb {
    void onConnected();
    void onDevineConnected();
}