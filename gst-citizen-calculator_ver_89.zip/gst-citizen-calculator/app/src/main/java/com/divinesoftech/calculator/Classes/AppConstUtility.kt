package com.divinesoftech.calculator.Classes


var THEME_NUMBER = 0


