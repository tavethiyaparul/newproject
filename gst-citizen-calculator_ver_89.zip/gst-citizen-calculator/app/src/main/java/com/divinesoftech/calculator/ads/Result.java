package com.divinesoftech.calculator.ads;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class Result implements Serializable {
    @SerializedName("datacount")
    private String datacount;

    public ArrayList<Master> getMaster() {
        return master;
    }

    public void setMaster(ArrayList<Master> master) {
        this.master = master;
    }

    @SerializedName("master")
    ArrayList<Master> master;


    public String getDatacount() {
        return datacount;
    }

    public void setDatacount(String datacount) {
        this.datacount = datacount;
    }


    @Override
    public String toString() {
        return "ClassPojo [datacount = " + datacount + ", master = " + master + "]";
    }
}