package com.citizencalc.gstcalculator.Classes.common


import com.divinesoftech.calculator.Common.Utilty.NO_DATA_FOUND

fun setNoDataFound(): Array<String?> {
    val strings = arrayOfNulls<String>(2)
    strings[0] = NO_DATA_FOUND
    strings[1] = NO_DATA_FOUND
    return strings
}