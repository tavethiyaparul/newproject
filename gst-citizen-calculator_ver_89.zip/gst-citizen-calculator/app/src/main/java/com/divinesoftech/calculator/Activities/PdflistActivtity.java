package com.divinesoftech.calculator.Activities;

import android.Manifest;
import android.content.DialogInterface;
import android.os.Environment;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.divinesoftech.calculator.Adapter.PdfListAdapter;
import com.divinesoftech.calculator.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;

public class PdflistActivtity extends AppCompatActivity {
    RecyclerView pdf_recycle;
    PdfListAdapter pdfListAdapter;
    File app_folder = null;
    File[] listfile;
    List<File> pdf_list;
    TextView ActionBarTitle;
    ImageView done;
    int PERMISSION_CODE = 117;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdflist_activtity);
        currentActivity = this;
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);

        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = (TextView) v.findViewById(R.id.action_bar_title);
        done = (ImageView) v.findViewById(R.id.action_done);
        done.setVisibility(View.GONE);
        getSupportActionBar().setCustomView(v);
        ActionBarTitle.setText("PDF");
        //v.findViewById(R.id.gift_layout).setVisibility(View.GONE);

        pdf_recycle = (RecyclerView) findViewById(R.id.pdf_list);
        pdf_list = new ArrayList<File>();
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        pdf_recycle.setLayoutManager(gridLayoutManager);

        pdfLists();

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }

    private void pdfLists() {
        try {
            app_folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), getResources().getString(R.string.app_folder));
            if (!app_folder.exists()) {
                app_folder.mkdirs();
            }

            if (app_folder.isDirectory()) {
                listfile = app_folder.listFiles();
                if (listfile.length > 0) {
                    pdf_list.clear();
                    for (int i = 0; i < listfile.length; i++) {
                        pdf_list.add(listfile[i]);
                    }
                }
            }

            if (pdf_list.size() > 0) {
                Collections.reverse(pdf_list);
                pdfListAdapter = new PdfListAdapter(pdf_list, this);
                pdf_recycle.setAdapter(pdfListAdapter);
            } else {
                findViewById(R.id.layout_nopdf).setVisibility(View.VISIBLE);
            }

        } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


}
