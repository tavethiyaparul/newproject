package com.divinesoftech.calculator.CustomAd.ui;

public interface AdsClick {
    void onClick(String... strings);
}
