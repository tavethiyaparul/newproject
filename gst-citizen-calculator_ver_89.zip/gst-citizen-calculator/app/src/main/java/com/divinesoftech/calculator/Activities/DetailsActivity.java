package com.divinesoftech.calculator.Activities;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import com.divinesoftech.calculator.Classes.DetailsUtility;
import com.divinesoftech.calculator.Classes.PDF.AddLinkPdf;
import com.divinesoftech.calculator.Classes.PDF.ItextMerge;
import com.divinesoftech.calculator.Classes.PDF.PdfGenrate;
import com.divinesoftech.calculator.Common.Utilty;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.AdsFailToLoad;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.divinesoftech.calculator.database.room.RoomVersion;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.google.android.gms.ads.AdLoader;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseField;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.divinesoftech.SocketKt.bannerInlineAdaptiveAds;
import static com.divinesoftech.SocketKt.isPrime;
import static com.divinesoftech.calculator.Classes.GstApp.context;
import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;
import static com.divinesoftech.calculator.Common.Utilty.ADAPTIVE_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.BACKUP_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.COMMON_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.CUSTOM_AD;
import static com.divinesoftech.calculator.Common.Utilty.FACEBOOK_AD;
import static com.divinesoftech.calculator.Common.Utilty.FACEBOOK_NATIVE_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.GAME_AD;
import static com.divinesoftech.calculator.Common.Utilty.GOOGLE_AD;
import static com.divinesoftech.calculator.Common.Utilty.NATIVE_SAVE;
import static com.divinesoftech.calculator.Common.Utilty.SMART_BANNER;
import static com.divinesoftech.calculator.Common.Utilty.isNetworkAvailable;
import static com.divinesoftech.calculator.Fragments.LoanCalculator.iconFile;
import static com.divinesoftech.calculator.database.ApiKt.builderAds;
import static com.divinesoftech.calculator.database.ApiKt.isAdsLibsLoad;
import static com.divinesoftech.calculator.database.ApiKt.showCustomBanner;
import static com.divinesoftech.calculator.database.ApiKt.showGameBanner;
import static com.divinesoftech.calculator.database.room.RoomDatabaseGstKt.instances;
import static com.itextpdf.text.Element.ALIGN_MIDDLE;

public class DetailsActivity extends AppCompatActivity {
    double loanamount = 0.0, _loanEMI = 0.0, Interest_Rate = 0.0, total_intrest = 0.0, total_amount = 0.0;
    int Months = 0;
    private AdLoader adLoader;
    View view;
    TextView text_month, text_principle, text_intrest, text_balance;
    LinearLayout details_linear, menu_item;
    ScrollView scroll;
    PieChart pieChart;
    private String[] xValues = new String[2];
    private int[] yValues = new int[2];
    // private int[] colors_custom = new int[]{getResources().getColor(R.color.chart_light),getResources().getColor(R.color.tab_background)};
    // private String[] names = new String[]{"Principle","Interest"};
    private ArrayList<Integer> colors = new ArrayList();
    DecimalFormat formatter = new DecimalFormat("###,###,##0");
    Boolean is_big_value = false;
    TextView summery_loan, summery_emi, summery_intrest, summery_period, summery_total_intrest, summery_total_payment;
    String pdf_loan = "", pdf_interest = "", pdf_emi = "", pdf_period = "", pdf_total_interest = "", pdf_total_amount = "";
    String loan_details[];
    int PERMISSION_CODE = 117;

    File pdfDir, app_folder, tablesFile, pie_image, pdfFile, finalPdf;
    String sdCard = "";
    Dialog dialog;
    int show_dilog = 0;


    TextView ActionBarTitle;


    private LinearLayout nativeAdContainer;
    private LinearLayout native_adView, ad;

    boolean close_button_flag = false;
    int file_no = 0;
    String file_name = "";
    SharedPreferences preferences;
    ProgressBar progressBar;
    FrameLayout frameLayout;
    DatabaseGst databaseGst;
    RelativeLayout ad_layout;
    LinearLayout google_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentActivity = this;
        setContentView(R.layout.activity_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        View decorView = getWindow().getDecorView();
        databaseGst = new DatabaseGst(DetailsActivity.this);

        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);


        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = v.findViewById(R.id.action_bar_title);
        getSupportActionBar().setCustomView(v);
        ActionBarTitle.setText("Summary");
        //v.findViewById(R.id.gift_layout).setVisibility(View.GONE);
        preferences = getSharedPreferences("update", MODE_PRIVATE);
        // frameLayout =findViewById(R.id.fl_adplaceholder_dtl);
        ad_layout = findViewById(R.id.ad_layout);

        google_layout = findViewById(R.id.google_layout);

        if (isNetworkAvailable(this) && !isPrime() && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
        }


        details_linear = findViewById(R.id.details_linear);
        menu_item = findViewById(R.id.menu_item);
        scroll = findViewById(R.id.scroll);
        scroll.setSmoothScrollingEnabled(true);
        pieChart = findViewById(R.id.piechart);
        pieChart.setUsePercentValues(true);
        pieChart.setRotationEnabled(false);

        summery_loan = findViewById(R.id.dtl_loan_amount);
        summery_emi = findViewById(R.id.dtl_monthley_emi);
        summery_intrest = findViewById(R.id.dtl_interest);
        summery_period = findViewById(R.id.dtl_total_duration);
        summery_total_intrest = findViewById(R.id.dtl_total_interest);
        summery_total_payment = findViewById(R.id.dtl_total_payment);


        loanamount = Double.valueOf(getIntent().getStringExtra("loan_amount"));
        _loanEMI = Double.valueOf(getIntent().getStringExtra("loan_emi"));
        Interest_Rate = Double.valueOf(getIntent().getStringExtra("loan_intrest"));
        Months = Integer.parseInt(getIntent().getStringExtra("loan_period"));
        total_intrest = Double.valueOf(getIntent().getStringExtra("total_intrest"));
        total_amount = Double.valueOf(getIntent().getStringExtra("total_amount"));

        pdf_loan = getIntent().getStringExtra("loan_amount");
        pdf_emi = getIntent().getStringExtra("loan_emi");
        pdf_interest = getIntent().getStringExtra("loan_intrest");
        pdf_period = getIntent().getStringExtra("loan_period");
        pdf_total_interest = getIntent().getStringExtra("total_intrest");
        pdf_total_amount = getIntent().getStringExtra("total_amount");


        Interest_Rate = (Interest_Rate / 12.0d) / 100.0d;
        getpieChart();
        getData();
        summry_table();

    }

    private void folderFile() {
        storeIcon();
        app_folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), getResources().getString(R.string.app_folder));
        if (!app_folder.exists()) {
            app_folder.mkdirs();
        }


        //GeneratePDF();

        sdCard = DetailsUtility.getCacheDir(DetailsActivity.this).getAbsolutePath().toString();
        pdfDir = new File(sdCard, "pdfgenrate");

        if (!pdfDir.exists()) {
            pdfDir.mkdir();
        }

        tablesFile = new File(pdfDir, "table.pdf");
        pie_image = new File(pdfDir, "pieChart.pdf");
        pdfFile = new File(pdfDir, "LoanCalculator.pdf");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.loan_calculator_menu, menu);
        return super.onCreateOptionsMenu(menu);
        // return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_Whatsaap:

                try {
                    folderFile();

                    finalPdf = new File(pdfDir, "statment.pdf");

                    loan_details = new String[]{pdf_loan, pdf_interest, pdf_period, pdf_emi, pdf_total_interest, pdf_total_amount,
                            tablesFile.toString(), pie_image.toString(), pdfFile.toString(), finalPdf.toString(), iconFile.getAbsolutePath().toString()};


                    new PdfDeploy(loan_details, DetailsActivity.this, pieChart).execute();


                    Uri uri = FileProvider.getUriForFile(DetailsActivity.this, DetailsActivity.this.getApplicationContext().getPackageName() + ".my.package.name.provider", finalPdf);

                    Intent share = new Intent();
                    share.setAction(Intent.ACTION_SEND);
                    share.setType("application/pdf");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.setPackage("com.whatsapp");
                    // share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(share);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(this, "Please Install WhatsApp", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }


                break;

            case R.id.action_Share:

                folderFile();
                finalPdf = new File(pdfDir, "statment.pdf");

                loan_details = new String[]{pdf_loan, pdf_interest, pdf_period, pdf_emi, pdf_total_interest, pdf_total_amount,
                        tablesFile.toString(), pie_image.toString(), pdfFile.toString(), finalPdf.toString(), iconFile.getAbsolutePath().toString()};


                new PdfDeploy(loan_details, DetailsActivity.this, pieChart).execute();

                Uri uri_share = FileProvider.getUriForFile(DetailsActivity.this, DetailsActivity.this.getApplicationContext().getPackageName() + ".my.package.name.provider", finalPdf);


                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("application/pdf");
                sharingIntent.putExtra(Intent.EXTRA_STREAM, uri_share);
                startActivity(Intent.createChooser(sharingIntent, "Share With:"));
                break;
            case R.id.action_pdf:
                makepdf();
                break;
            case android.R.id.home:
                finish();
                break;

            default:
                break;
        }

        return true;
    }

    void makepdf() {
        folderFile();
        show_dilog = 1;

        SharedPreferences sp = getSharedPreferences("MyPref", MODE_PRIVATE);
        file_no = sp.getInt("file_count", file_no);
        file_name = "Statment_" + file_no + ".pdf";
        file_no++;
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt("file_count", file_no);
        editor.apply();


        finalPdf = new File(app_folder, file_name);

        loan_details = new String[]{pdf_loan, pdf_interest, pdf_period, pdf_emi, pdf_total_interest, pdf_total_amount,
                tablesFile.toString(), pie_image.toString(), pdfFile.toString(), finalPdf.toString(), iconFile.getAbsolutePath().toString()};
        new PdfDeploy(loan_details, DetailsActivity.this, pieChart).execute();

    }


    void SaveProgressDialog() {
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_save_full_img);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);

        dialog.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        final LinearLayout show_Action, ad_layout_detail;
        RelativeLayout open_pdf, cancle;
        final TextView heading;

        // FrameLayout frameLayout;
        // frameLayout = dialog.findViewById(R.id.fl_adplaceholder_dailog);
        ad_layout_detail = dialog.findViewById(R.id.ad_layout_detail);
        if (isNetworkAvailable(this) && !databaseGst.getResponse("10").equals("YES")) {
            try {

                if (!isPrime()) {
                    if (ad_layout_detail.getVisibility() == View.GONE)
                        ad_layout_detail.setVisibility(View.VISIBLE);
                    if (databaseGst.getResponse(Utilty.IS_ADFREE) != null && !databaseGst.getResponse(Utilty.IS_ADFREE).equals("YES")) {
                        AdsLoadings(ad_layout_detail);
                    }
                } else {
                    ad_layout_detail.setVisibility(View.GONE);
                }


                // showNativeAd(dialog);

               /* if (adLoader == null) {
                    Utilty.GoogleNative(DetailsActivity.this, ad_layout_detail, adLoader);
                }*/
                //  refreshAddailog(frameLayout);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            ad_layout_detail.setVisibility(View.GONE);
        }


        progressBar = dialog.findViewById(R.id.my_progressBar);
        show_Action = dialog.findViewById(R.id.action_pdf_dailog);
        heading = dialog.findViewById(R.id.text_header);
        open_pdf = dialog.findViewById(R.id.open);
        cancle = dialog.findViewById(R.id.cancel);


        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                show_Action.setVisibility(View.VISIBLE);
                heading.setText("Pdf Save Successfully.");
            }
        }, 5000);

        open_pdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (app_folder.isDirectory()) {
                    File[] listFile = app_folder.listFiles();

                    if (listFile.length > 0) {
                        Uri photoURI = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".my.package.name.provider", listFile[listFile.length - 1]);
                        Intent intent = new Intent(DetailsActivity.this, ShowPDF.class);
                        intent.putExtra("URI", photoURI.toString());
                        startActivity(intent);
                        dialog.dismiss();

                    }
                }
            }
        });
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


        progressBar.setVisibility(View.VISIBLE);
        ObjectAnimator progressAnimator = ObjectAnimator.ofInt(progressBar, "progress", 0, 100);
        progressAnimator.setDuration(5000);
        progressAnimator.setInterpolator(new LinearInterpolator());
        progressAnimator.start();


        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        Window win = dialog.getWindow();
        win.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

    }

    void AdsLoadings(LinearLayout layout) {
        ArrayList<String> type = builderAds(this, NATIVE_SAVE);
        if (type.size() > 0) {
            switch (type.get(0)) {
                case GOOGLE_AD:
                    Utilty.GoogleNative(this, type.get(1), layout);
                    break;
            }
        }
    }

    private void getpieChart() {
        if (getIntent().getStringExtra("loan_amount").length() >= 8) {
            yValues[0] = new Double(loanamount / 100.0d).intValue();
            String princi_ple = formatter.format(loanamount);
            xValues[0] = princi_ple;
            colors.add(getResources().getColor(R.color.chart_dark));
            yValues[1] = new Double(total_intrest / 100.0d).intValue();
            String total_intrest_amount = formatter.format(total_intrest);
            xValues[1] = total_intrest_amount;
            colors.add(getResources().getColor(R.color.tab_background));

            is_big_value = true;
        } else {
            yValues[0] = new Double(loanamount / 100.0d).intValue();
            xValues[0] = loanamount + "";
            colors.add(getResources().getColor(R.color.chart_dark));
            yValues[1] = new Double(total_intrest / 100.0d).intValue();
            xValues[1] = total_intrest + "";
            colors.add(getResources().getColor(R.color.tab_background));


        }


        setDataForPieChart();
    }

    public void setDataForPieChart() {
        try {
            int i;
            ArrayList<Entry> yVals1 = new ArrayList();
            for (i = 0; i < this.yValues.length; i++) {
                yVals1.add(new Entry((float) this.yValues[i], i));
            }
            List xVals = new ArrayList();
            for (Object add : this.xValues) {
                xVals.add(add);
            }
            PieDataSet dataSet = new PieDataSet(yVals1, "");
            dataSet.setSliceSpace(2.0f);
            dataSet.setSelectionShift(5.0f);
            dataSet.setColors(this.colors);
            dataSet.setValueTextSize(15.0f);
            PieData data = new PieData(xVals, dataSet);
            data.setValueFormatter(new PercentFormatter());
            data.setValueTextSize(15.0f);
            data.setValueTextColor(-1);
            pieChart.setData(data);
            pieChart.highlightValues(null);
            pieChart.setDescription("");
            pieChart.invalidate();
            pieChart.setUsePercentValues(true);
            pieChart.setHoleRadius(40f);
            pieChart.setTransparentCircleRadius(40f);
            pieChart.setCenterText("Total payable Amount" + "\n" + total_amount + "");
            pieChart.setCenterTextColor(getResources().getColor(R.color.tab_background));


            Legend l = pieChart.getLegend();
            l.setPosition(Legend.LegendPosition.ABOVE_CHART_CENTER);
            l.setCustom(new int[]{getResources().getColor(R.color.chart_dark), getResources().getColor(R.color.tab_background)}, new String[]{"Principle", "Interest"});
            l.setTextSize(12f);
            l.setXEntrySpace(7.0f);
            l.setYEntrySpace(10.0f);


            // l.setXEntrySpace(7.0f);
            //l.setYEntrySpace(5.0f);
            l.setForm(Legend.LegendForm.CIRCLE);


        } catch (Exception e) {
        }
    }

    private void getData() {
        try {

            for (int i = 1; i <= Months; i++) {
                DetailsUtility detailData = new DetailsUtility();
                double Interest = loanamount * Interest_Rate;
                double Principal = _loanEMI - ((double) ((int) Interest));
                if (Interest <= 1) {
                    Interest = 0.0d;
                    Principal = _loanEMI;
                }
                double Balance = loanamount - Principal;
                loanamount = Balance;
                if (Balance < 0.0d) {
                    Balance = 0.0d;
                }
                detailData.setMonth(String.valueOf(i));
                detailData.setBalance(String.valueOf(Math.round(Balance * 100.0) / 100.0));
                detailData.setInterest(String.valueOf(Math.round(Interest * 100.0) / 100.0));
                detailData.setPrinciple(String.valueOf(Math.round(Principal * 100.0) / 100.0));

                view = View.inflate(this, R.layout.detail_row_item, null);
                text_month = (TextView) view.findViewById(R.id.month);
                text_principle = (TextView) view.findViewById(R.id.principle);
                text_intrest = (TextView) view.findViewById(R.id.intrest);
                text_balance = (TextView) view.findViewById(R.id.Balance);

                text_month.setText("" + new Double(detailData.getMonth()).intValue());
                text_principle.setText("" + new Double(detailData.getPrinciple()).intValue());
                text_intrest.setText("" + new Double(detailData.getInterest()).intValue());
                text_balance.setText("" + new Double(detailData.getBalance()).intValue());


                if (i % 2 == 0) {
                    view.setBackgroundColor(Color.parseColor("#B2BABB"));
                } else {
                    view.setBackgroundColor(getResources().getColor(R.color.layout_background));
                }

                details_linear.addView(view);


            }
        } catch (Exception e) {
        }
    }

    public void summry_table() {
        summery_loan.setText(getIntent().getStringExtra("loan_amount"));
        summery_emi.setText(getIntent().getStringExtra("loan_emi"));
        summery_intrest.setText(getIntent().getStringExtra("loan_intrest"));
        summery_period.setText(getIntent().getStringExtra("loan_period"));
        summery_total_intrest.setText(getIntent().getStringExtra("total_intrest"));
        summery_total_payment.setText(getIntent().getStringExtra("total_amount"));


    }


    public class PdfDeploy extends AsyncTask<String[], String, Activity> {
        String genrate_pdf[];
        Activity activity;
        PieChart chart;
        int i = 0;

        //  public static final String IMG = "/storage/emulated/0/Android/data/com.example.jatinandroid.loancalculator/files/resule/icon.png";

        public PdfDeploy(String[] genrate_pdf, Activity activity, PieChart chart) {
            this.genrate_pdf = genrate_pdf;

            this.activity = activity;

            this.chart = chart;


        }

        @Override
        protected void onPreExecute() {
            if (show_dilog == 1) {
                close_button_flag = false;
                SaveProgressDialog();
                //dialog.show();


            }

            super.onPreExecute();
        }

        @Override
        protected Activity doInBackground(String[]... strings) {
            genrate_tables(); //step 1
            piePdf();         //step 2
            mergPdf();        // step 3
            finalPdf();       //step 4     note: do not change steps


            return null;
        }


        public Boolean genrate_tables() {
            if (new PdfGenrate().write(genrate_pdf[0], genrate_pdf[1], genrate_pdf[2], genrate_pdf[3], genrate_pdf[4], genrate_pdf[5], genrate_pdf[6], genrate_pdf[10], activity).booleanValue()) {

                return true;
            }

            return true;
        }

        public Boolean mergPdf() {
            if (new ItextMerge().merging(genrate_pdf[6], genrate_pdf[7], genrate_pdf[8]).booleanValue()) {

                return true;
            }
            return true;
        }

        public void finalPdf() {
            try {
                new AddLinkPdf().manipulatePdf(genrate_pdf[8], genrate_pdf[9], activity);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (DocumentException e) {
                e.printStackTrace();
            }
        }

        public void piePdf() {
            Bitmap bitmap;
            chart.setDrawingCacheEnabled(true);
            chart.buildDrawingCache();
            bitmap = chart.getDrawingCache();

            try {

                Image image = null;
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                image = Image.getInstance(stream.toByteArray());

                image.setAlignment(ALIGN_MIDDLE);

                //image.scaleAbsolute();


                image.scaleAbsolute(bitmap.getWidth() / 1.5f, bitmap.getHeight() / 1.5f);
                Document document = new Document(image);
                document.setPageSize(PageSize.A4);
                PdfWriter.getInstance(document, new FileOutputStream(genrate_pdf[7]));
                document.open();
                document.addHeader(getApplicationContext().getResources().getString(R.string.app_name), "");


                Font font = new Font(Font.FontFamily.TIMES_ROMAN);
                font.setColor(new BaseColor(getApplicationContext().getResources().getColor(R.color.tab_background)));
                font.setSize(25.0f);
                font.setStyle(Font.BOLD);
                PdfPCell cell = new PdfPCell(new Phrase(""));
                PdfPTable table = new PdfPTable(2);
                cell = new PdfPCell(new Phrase("Pie chart", font));
                cell.setBorder(2);
                cell.setBorderColor(new BaseColor(getApplicationContext().getResources().getColor(R.color.tab_background)));
                cell.setBorderWidth(BaseField.BORDER_WIDTH_MEDIUM);
                cell.setExtraParagraphSpace(20.0f);
                table.setSpacingAfter(15.0f);
                table.setHorizontalAlignment(0);
                table.setWidthPercentage(100.0f);
                table.addCell(cell);
                cell = new PdfPCell(new Phrase(new SimpleDateFormat("dd/MM/yyyy").format(new Date(System.currentTimeMillis())), font));
                cell.setBorder(2);
                cell.setHorizontalAlignment(2);
                cell.setBorderColor(new BaseColor(getApplicationContext().getResources().getColor(R.color.tab_background)));
                cell.setBorderWidth(BaseField.BORDER_WIDTH_MEDIUM);
                cell.setExtraParagraphSpace(20.0f);
                table.setSpacingAfter(25.0f);
                table.setWidthPercentage(100.0f);
                table.addCell(cell);


                Font font_fotter = new Font(Font.FontFamily.UNDEFINED);
                font_fotter.setColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
                font_fotter.setSize(25.0f);
                PdfPCell cell_footer = new PdfPCell(new Phrase(""));
                PdfPTable table_fotter = new PdfPTable(2);
                table_fotter.setTotalWidth(100);
                table_fotter.setWidths(new float[]{10, 90});


               /* try {
                    Image img = Image.getInstance(genrate_pdf[10]);
                    Chunk chunk = new Chunk(img, 10, -15);
                    cell_footer.addElement(chunk);

                } catch (BadElementException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }*/
                // cell_footer = new PdfPCell(new Phrase(this.activity.getResources().getString(R.string.statementHeader),font_fotter));
                cell_footer.setBorder(2);
                cell_footer.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
                cell_footer.setBorderWidth(BaseField.BORDER_WIDTH_MEDIUM);
                cell_footer.setExtraParagraphSpace(20.0f);
                table_fotter.setSpacingAfter(15.0f);
                table_fotter.setHorizontalAlignment(0);
                table_fotter.setWidthPercentage(100);
                table_fotter.addCell(cell_footer);
                Font font_date = new Font(Font.FontFamily.UNDEFINED);
                font_date.setColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
                font_date.setSize(25.0f);
                cell_footer = new PdfPCell(new Phrase(new Phrase(this.activity.getResources().getString(R.string.statementHeader), font_date)));
                cell_footer.setBorder(2);
                cell_footer.setHorizontalAlignment(0);
                cell_footer.setPaddingLeft(70.0f);
                cell_footer.setBorderColor(new BaseColor(this.activity.getResources().getColor(R.color.tab_background)));
                cell_footer.setBorderWidth(BaseField.BORDER_WIDTH_MEDIUM);
                cell_footer.setExtraParagraphSpace(20.0f);
                table_fotter.setSpacingBefore(50.0f);
                table_fotter.setWidthPercentage(100);
                table_fotter.addCell(cell_footer);


                document.add(table);
                document.add(image);
                document.add(table_fotter);


                document.close();

            } catch (Exception e) {
                e.printStackTrace();
            }


        }


        @Override
        protected void onPostExecute(Activity activity) {
            if (show_dilog == 1) {
                close_button_flag = true;
            }
            show_dilog = 0;

            super.onPostExecute(activity);
        }


    }

   /* private void showNativeAd(final Dialog dialog) {
        showNativeAdNew(dialog);
    }*/


    public void storeIcon() {
        Drawable icon = getResources().getDrawable(R.drawable.icon);
        Bitmap icon_bitmap = ((BitmapDrawable) icon).getBitmap();
        File pdfDir;
        String sdCard = DetailsUtility.getCacheDir(this).getAbsolutePath().toString();
        pdfDir = new File(sdCard, "pdfgenrate");
        if (!pdfDir.exists()) {
            pdfDir.mkdir();
        }
        iconFile = new File(pdfDir, "" +
                "icon.png");
        if (!iconFile.exists()) {
            iconFile = new File(pdfDir, "icon.png");
        }


        try {
            FileOutputStream out = new FileOutputStream(iconFile);
            icon_bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }


    }







   /* private void refreshAddailog(final FrameLayout view) {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_unified_intrest));

        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            // OnUnifiedNativeAdLoadedListener implementation.
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                try {
                    //  FrameLayout frameLayout = getActivity().findViewById(R.id.fl_adplaceholder);
                    UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                            .inflate(R.layout.native_ad_pdf, null);
                    populateUnifiedNativeAdViewdailog(unifiedNativeAd, adView);
                    view.removeAllViews();
                    view.addView(adView);
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            }

        });


        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(true)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                //   frameLayout.setVisibility(View.GONE);

            }
        }).build();



        adLoader.loadAd(new AdRequest.Builder().addTestDevice(getString(R.string.test_device)).build());


    }
    private void populateUnifiedNativeAdViewdailog(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {
        VideoController vc = nativeAd.getVideoController();
        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
            public void onVideoEnd() {
                super.onVideoEnd();
            }
        });


        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));

        com.google.android.gms.ads.formats.MediaView mediaView = (com.google.android.gms.ads.formats.MediaView) adView.findViewById(R.id.ad_media);
        ImageView mainImageView = adView.findViewById(R.id.ad_image);
        //adView.setMediaView(mediaView);

        // Apps can check the VideoController's hasVideoContent property to determine if the
        // NativeAppInstallAd has a video asset.
        if (vc.hasVideoContent()) {
            adView.setMediaView(mediaView);
            mainImageView.setVisibility(View.GONE);
        } else {
            adView.setImageView(mainImageView);
            mediaView.setVisibility(View.GONE);
            // At least one image is guaranteed.
            try {
                List<com.google.android.gms.ads.formats.NativeAd.Image> images = nativeAd.getImages();
                mainImageView.setImageDrawable(images.get(0).getDrawable());
            } catch (java.lang.IndexOutOfBoundsException e) {
                adView.setVisibility(View.GONE);
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
                adView.setVisibility(View.GONE);
            }
        }


        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }
          *//* if (adView.getMediaView() == null) {
                adView.getMediaView().setVisibility(View.GONE);
            } else {
                adView.getMediaView().setVisibility(View.VISIBLE);
            }*//*

        adView.setNativeAd(nativeAd);
    }*/


    void AdsLoadings() {

        RoomVersion roomVersion = instances.versionDao().getAdsAvailable(COMMON_BANNER);
        if (roomVersion == null) {
            bannerInlineAdaptiveAds(this, google_layout, BACKUP_BANNER, () -> {
                showCustomBanner(google_layout);
                return null;
            });
        } else {
            ArrayList<String> type = builderAds(this, COMMON_BANNER);
            if (type.size() > 0) {

                switch (type.get(0)) {
                    case GOOGLE_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        new Utilty().GoogleBannerAdvance(false, DetailsActivity.this, type.get(1), google_layout, new AdsFailToLoad() {
                            @Override
                            public void onFailed() {
                                showCustomBanner(google_layout);
                            }
                        });
                        break;
                    case ADAPTIVE_BANNER:
                        bannerInlineAdaptiveAds(this, google_layout, type.get(1), () -> {
                            showCustomBanner(google_layout);
                            return null;
                        });
                        break;
                    case SMART_BANNER:
                        google_layout.setVisibility(View.GONE);
                        new Utilty().mSmartBanner(this, type.get(1), ad_layout, google_layout);
                        break;

                    case CUSTOM_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        showCustomBanner(google_layout);
                        break;

                    case GAME_AD:
                        google_layout.setVisibility(View.VISIBLE);
                        showGameBanner(google_layout);
                        break;
                }
            }
        }
    }

}





