package com.divinesoftech.calculator.database.room

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Converters {

    @TypeConverter
    fun fromString(value: String): ArrayList<RoomAdsChild> {
        val listType = object : TypeToken<ArrayList<RoomAdsChild>>() {

        }.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromArrayList(list: ArrayList<RoomAdsChild>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}