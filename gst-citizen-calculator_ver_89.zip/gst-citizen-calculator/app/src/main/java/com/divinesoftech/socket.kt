package com.divinesoftech

import android.app.Activity
import android.content.Context
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import com.divinesoftech.calculator.BuildConfig
import com.divinesoftech.calculator.Classes.GstApp
import com.divinesoftech.calculator.Classes.Model.Country
import com.divinesoftech.calculator.Classes.Model.Currency_data
import com.divinesoftech.calculator.Common.Utilty
import com.divinesoftech.calculator.JobSechedual.getRestService
import com.divinesoftech.calculator.NoInternetDialog
import com.divinesoftech.calculator.R
import com.divinesoftech.calculator.database.DataBase_Constant
import com.divinesoftech.calculator.database.Helper
import com.divinesoftech.calculator.database.RoomConnection
import com.divinesoftech.calculator.database.initialize
import com.divinesoftech.calculator.database.isAdsLibsLoad
import com.divinesoftech.calculator.database.room.RoomAdsChild
import com.divinesoftech.calculator.database.room.RoomAdvertisement
import com.divinesoftech.calculator.database.room.RoomGame
import com.divinesoftech.calculator.database.room.RoomMainAdRecords
import com.divinesoftech.calculator.database.room.RoomSku
import com.divinesoftech.calculator.database.room.RoomTags
import com.divinesoftech.calculator.database.room.RoomVersion
import com.divinesoftech.calculator.database.room.instances
import com.divinesoftech.calculator.mongodb.MongodbUtility
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonSyntaxException
import com.google.gson.reflect.TypeToken
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL


fun AppCompatActivity.noInternetDialog(callback: () -> Unit) {
    if (!this.isFinishing) {
        CoroutineScope(Dispatchers.Main).launch {
            val fragmentManager = supportFragmentManager
            if (!fragmentManager.isDestroyed) {
                try {
                    val fragmentTransaction = fragmentManager.beginTransaction()
                    fragmentManager.findFragmentByTag("NoInternetDialog")?.let {
                        fragmentTransaction.remove(it)
                    }
                    fragmentTransaction.commitAllowingStateLoss()
                    val dialog = NoInternetDialog()
                    dialog.callback = {
                        callback.invoke()
                    }
                    dialog.setStyle(DialogFragment.STYLE_NO_FRAME, 0)
                    dialog.show(fragmentManager, "NoInternetDialog")
                } catch (_: IllegalStateException) {
                } catch (_: Exception) {
                }
            }
        }
    }
}


suspend fun testInternetConnection(): Boolean {
    return if (isPrime()) {
        true
    } else withContext(Dispatchers.IO) {
        try {
            val url = URL("https://www.google.com/")
            val urlConnection = url.openConnection() as HttpURLConnection
            urlConnection.connectTimeout = 5000
            urlConnection.readTimeout = 5000
            val statusCode = urlConnection.responseCode
            statusCode in (200..299)
        } catch (e: IOException) {
            false
        }
    }
}


const val VERSION = "version"
const val SKU = "sku_dtl_new"
const val PRIVACY_POLICY = "privacypolicy"
const val CURRENCY_DATA = "currancydata"
const val COUNTRY_FLAG = "country_flag"
const val INSTALL_TRACK = "installtrack"
const val CUSTOM_ADS_TAG_LIST = "customAdsTaglist"
const val CUSTOM_ADS = "customAds"
const val VERIFY_USER = "verify_user"

const val EVENT_VERSION_DATA = "versionData"
const val EVENT_SKU_DATA = "sku_dtl_newData"
const val EVENT_PRIVACY_POLICY = "privacypolicyData"
const val EVENT_CURRENCY_DATA = "currancydataData"
const val EVENT_COUNTRY_FLAG = "country_flagData"
const val EVENT_INSTALL_TRACK = "installtrackData"
const val EVENT_CUSTOM_ADS_TAG_LIST = "customAdsTaglistData"
const val EVENT_CUSTOM_ADS = "customAdsData"
const val EVENT_VERIFY_USER = "verify_userData"

private var socket: Socket? = null

var socketListenerKo: SocketListener? = null

interface SocketListener {
    fun call(state: String, data: String)
}

fun insertIntoTable(id: Int, data: String) {
    val settings = RoomConnection()
    settings.id = id
    settings.data = data
    instances?.roomConnectionDao()
        ?.insertRoomConnection(settings)
}

inline var idHomeInAppDialogShow: String
    get() = instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.HOME_IN_APP_DIALOG_SHOW_ID)
        ?: "false"
    set(string) = insertIntoTable(DataBase_Constant.HOME_IN_APP_DIALOG_SHOW_ID, string)

inline var idHomeInAppDialogId: String
    get() = instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.HOME_IN_APP_DIALOG_ID)
        ?: "false"
    set(string) = insertIntoTable(DataBase_Constant.HOME_IN_APP_DIALOG_ID, string)

inline var idRateVersion: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.RATE_VERSION_ID)
        ?: ""
    set(string) = insertIntoTable(DataBase_Constant.RATE_VERSION_ID, string)

inline var idRateFirstOpen: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.RATE_FIRST_OPEN_ID)
        ?: "false"
    set(string) = insertIntoTable(DataBase_Constant.RATE_FIRST_OPEN_ID, string)

inline var idInAppRated: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.RATE_ID) ?: "false"
    set(string) = insertIntoTable(DataBase_Constant.RATE_ID, string)

inline var idInAppValueRated: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.RATE_VALUE_ID)
        ?: "0.0"
    set(string) = insertIntoTable(DataBase_Constant.RATE_VALUE_ID, string)

inline var CUSTOM_DOMAIN: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.DATA_CUSTOM_DOMAIN)
        ?: ""
    set(string) = insertIntoTable(DataBase_Constant.DATA_CUSTOM_DOMAIN, string)

inline var FLAG_DOMAIN: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.DATA_CUSTOM_FLAG)
        ?: ""
    set(string) = insertIntoTable(DataBase_Constant.DATA_CUSTOM_FLAG, string)

inline var GAME_PAGE_URL: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.DATA_GAME_URL) ?: ""
    set(string) = insertIntoTable(DataBase_Constant.DATA_GAME_URL, string)

inline var GAME_ON: Int
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.DATA_GAME_ON)
        ?.toInt() ?: 0
    set(string) = insertIntoTable(DataBase_Constant.DATA_GAME_ON, string.toString())

inline var NODE_CONNECTION: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.NODE_ID) ?: ""
    set(string) = insertIntoTable(DataBase_Constant.NODE_ID, string)

inline var NODE_SECRET: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.NODE_SECRET_ID)
        ?: ""
    set(string) = insertIntoTable(DataBase_Constant.NODE_SECRET_ID, string)

inline var SKU_LINK: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.SKU_LINK_ID) ?: ""
    set(string) = insertIntoTable(DataBase_Constant.SKU_LINK_ID, string)

inline var SOCKET_CONNECTION: String
    get() = instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.SOCKET_CONNECTION_ID) ?: ""
    set(string) = insertIntoTable(DataBase_Constant.SOCKET_CONNECTION_ID, string)

inline var SOCKET_HANDSHAKE: String
    get() = instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.SOCKET_HANDSHAKE_ID)
        ?: ""
    set(string) = insertIntoTable(DataBase_Constant.SOCKET_HANDSHAKE_ID, string)

inline var SUBSCRIPTION_STATE: String
    get() = instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.SUBSCRIPTION_STATE_ID)
        ?: ""
    set(string) = insertIntoTable(DataBase_Constant.SUBSCRIPTION_STATE_ID, string)


inline var AB_HOME_BANNER_NATIVE: Boolean
    get() = (instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.HOME_BANNER_NATIVE_ID) ?: "false").toBoolean()
    set(string) = insertIntoTable(DataBase_Constant.HOME_BANNER_NATIVE_ID, string.toString())

inline var TIME_STAMP_FULL_SPLASH: Long
    get() = instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.ID_TIME_STAMP_FULL_SPLASH)?.toLong() ?: 0L
    set(string) = insertIntoTable(DataBase_Constant.ID_TIME_STAMP_FULL_SPLASH, string.toString())

inline var TIME_STAMP_ID_PURCHASE_DIALOG: Long
    get() = instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.ID_PURCHASE_DIALOG)?.toLong() ?: 0L
    set(string) = insertIntoTable(DataBase_Constant.ID_PURCHASE_DIALOG, string.toString())


inline var RATE_APP_FIRST_TIME: Boolean
    get() = (instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.ID_RATE_APP_FIRST_TIME) ?: "false").toBoolean()
    set(string) = insertIntoTable(DataBase_Constant.ID_RATE_APP_FIRST_TIME, string.toString())

inline var TIME_STAMP_RATE_APP_DIALOG: Long
    get() = instances?.roomConnectionDao()
        ?.getRoomConnection(DataBase_Constant.ID_TIME_STAMP_RATE_APP_DIALOG)?.toLong() ?: 0L
    set(string) = insertIntoTable(DataBase_Constant.ID_TIME_STAMP_RATE_APP_DIALOG, string.toString())

const val AB_SPLASH_BANNER = "ca-app-pub-8980115782895213/3065575015"


fun remoteData(callback: () -> Unit) {
    try {
        val mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        val configSettings = FirebaseRemoteConfigSettings.Builder()
            .setMinimumFetchIntervalInSeconds(3600)
            .build()
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings)
        mFirebaseRemoteConfig.fetchAndActivate()
            .addOnCompleteListener {
                try {
                    val data = JSONObject(mFirebaseRemoteConfig.getString(Utilty.CONFIG_TAG))
                        .getJSONArray(if (BuildConfig.DEBUG) "live" else "live")
                        .getJSONObject(0)

                    if (BuildConfig.DEBUG)
                        Log.e("remoteData", data.toString())

                    CUSTOM_DOMAIN = data.getString(Utilty.CUSTOM_AD_TAG)
                    FLAG_DOMAIN = data.getString(Utilty.COUNTRY_FLAG_TAG)
                    GAME_PAGE_URL = data.getString(Utilty.GAME_URL)
                    GAME_ON = data.getString(Utilty.GAME_ON_TAG).toInt()
                    NODE_CONNECTION = data.getString(Utilty.NODE_TAG)
                    NODE_SECRET = data.getString("node_secret")
                    SKU_LINK = data.getString("sku_link")
                    SOCKET_CONNECTION = data.getString("socket")
                    SOCKET_HANDSHAKE = data.getString("socket_secret")
                    if (data.has("ab_test")) {
                        val abTest = data.getJSONArray("ab_test")
                        AB_HOME_BANNER_NATIVE =
                            abTest.getJSONObject(0).getBoolean("home_banner_native")
                    }

                    callback.invoke()
                } catch (_: JSONException) {
                }
            }
    } catch (_: JSONException) {
    } catch (_: Exception) {
    }
}


fun Socket.initSocket() {
    on(Socket.EVENT_DISCONNECT) {
        Log.e(
            "EVENT_DISCONNECT", "_________________________"
        )
    }
    on(Socket.EVENT_CONNECT) {
        Log.e(
            "EVENT_CONNECT", "_________________________"
        )
    }
    on(Socket.EVENT_CONNECT_ERROR) {
        /*it.forEach { item ->
            val exception = item as EngineIOException
            Log.e(
                "EVENT_CONNECT_ERROR",
                "EVENT_CONNECT_ERROR ${exception.message + " " + exception.code + " " + exception.cause}"
            )
        }*/
        Log.e(
            "EVENT_CONNECT_ERROR", "_________________________"
        )
    }
    on(EVENT_PRIVACY_POLICY) { args ->
        if (args.isNotEmpty()) {
            try {
                val data = JSONArray(args[0].toString())
                if (data.length() > 0) {
                    try {
                        val settings = RoomConnection()
                        settings.id = DataBase_Constant.PRIVACY_POLICY_ID
                        settings.data = data.getJSONObject(0).getString("content")
                        instances?.roomConnectionDao()
                            ?.insertRoomConnection(settings)
                    } catch (_: JSONException) {
                    }
                }
            } catch (_: JSONException) {
            } finally {
                installTrack()
            }

        }
    }
    on(EVENT_CURRENCY_DATA) { args ->
        if (args.isNotEmpty()) {
            val data = JSONArray(args[0].toString())
            if (data.length() > 0) {
                try {
                    val currency_data =
                        data.getJSONObject(0).getString("currency_data")
                    val data1 = JSONObject(currency_data)
                    MongodbUtility.mCurrancyData =
                        Gson().fromJson<ArrayList<Currency_data>>(
                            data1.getString("currency_data"),
                            object : TypeToken<ArrayList<Currency_data>>() {}.type
                        )

                    val settings = RoomConnection()
                    settings.id = DataBase_Constant.DATA_CURRANCY
                    settings.data = data1.getString("currency_data").trim()

                    instances?.roomConnectionDao()
                        ?.insertRoomConnection(settings)
                } catch (_: JSONException) {
                } finally {
                    socketEmit(CUSTOM_ADS_TAG_LIST, "")
                }

            }
        }
    }
    on(EVENT_COUNTRY_FLAG) { args ->
        if (args.isNotEmpty()) {
            val data = JSONArray(args[0].toString())
            if (data.length() > 0) {
                try {
                    MongodbUtility.countrylist =
                        Gson().fromJson<ArrayList<Country>>(
                            data.getJSONObject(0).getString("country"),
                            object : TypeToken<ArrayList<Country>>() {}.type
                        )

                    val settings = RoomConnection()
                    settings.id = DataBase_Constant.DATA_COUNTRY_FLAG
                    settings.data = data.getJSONObject(0).getString("country").trim()
                    instances?.roomConnectionDao()?.insertRoomConnection(settings)
                } catch (_: JSONException) {
                } finally {
                    socketEmit(CURRENCY_DATA, "")
                }
            }
        }
    }
    on(EVENT_INSTALL_TRACK) { args ->
        if (args.isNotEmpty()) {
            try {
                if (args[0] == "done") {
                    val settings = RoomConnection()
                    settings.id = DataBase_Constant.DATA_INSTALL_TRACK
                    settings.data = BuildConfig.VERSION_CODE.toString()
                    instances?.roomConnectionDao()
                        ?.insertRoomConnection(settings)
                }
            } catch (_: Exception) {
            } finally {
                gameData()
            }
        }
    }
    on(EVENT_CUSTOM_ADS_TAG_LIST) { args ->
        if (args.isNotEmpty()) {
            try {
                val data = JSONArray(args[0].toString())
                if (data.length() > 0)
                    for (i in 0 until data.length()) {
                        try {
                            val dataObject = data.getJSONObject(i)
                            val tbTags = RoomTags()
                            tbTags.id = dataObject.getString("_id")
                            tbTags.attr = dataObject.getString("attr")
                            tbTags.ids = dataObject.getString("ids")
                            tbTags.orderTag = dataObject.getInt("order")
                            instances?.roomTagsDao()?.insertRoomAdsLoaded(tbTags)
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        } catch (e: NullPointerException) {
                            e.printStackTrace()
                        } catch (e: IndexOutOfBoundsException) {
                            e.printStackTrace()
                        }
                    }
            } catch (_: JSONException) {
            } finally {
                socketEmit(CUSTOM_ADS, "")
            }
        }
    }
    on(EVENT_CUSTOM_ADS) { args ->
        if (args.isNotEmpty()) {
            try {
                val data = JSONArray((args[0].toString()))
                if (data.length() > 0)
                    for (i in 0 until data.length()) {
                        val dataObject = data.getJSONObject(i)
                        try {
                            val advertisement = RoomAdvertisement()
                            advertisement.ID = dataObject.getString("_id")
                            advertisement.ADDTITLE = dataObject.getString("add_title")
                            advertisement.ADDDESCD = dataObject.getString("add_desc")
                            advertisement.ICON = dataObject.getString("icon")
                            advertisement.BANNER = dataObject.getString("banner")
                            advertisement.INSTALL = dataObject.getString("install")
                            advertisement.COLOR = dataObject.getString("color")
                            advertisement.RATING = dataObject.getString("rating")
                            advertisement.DOWNLOAD = dataObject.getString("download")
                            advertisement.REVIEW = dataObject.getString("review")
                            if (dataObject.has("design_page"))
                                advertisement.DESIGNPAGE =
                                    dataObject.getString("design_page")
                            advertisement.CUSTOMMULTI =
                                dataObject.getString("advertisement_custom_multi")
                            advertisement.ENABLE = dataObject.getInt("enable")
                            advertisement.DATE = dataObject.getString("date")
                            instances?.roomAdvertisementDao()
                                ?.insertRoomAdvertisement(advertisement)
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        } catch (e: NullPointerException) {
                            e.printStackTrace()
                        } catch (e: IndexOutOfBoundsException) {
                            e.printStackTrace()
                        }
                    }
            } catch (_: JSONException) {
            } finally {
                socketEmit(PRIVACY_POLICY, "")
            }
        }
    }
    on(EVENT_VERIFY_USER) { args ->
        if (args.isNotEmpty()) {
            try {
                val jsonObject = JsonParser.parseString(args[0].toString()).asJsonObject
                if (jsonObject.has("subscriptionState")) {
                    if (SUBSCRIPTION_STATE != jsonObject.get("subscriptionState").asString)
                        socketListenerKo?.call(
                            EVENT_VERIFY_USER,
                            jsonObject.get("subscriptionState").asString
                        )
                    SUBSCRIPTION_STATE = jsonObject.get("subscriptionState").asString

                }
            } catch (_: JsonSyntaxException) {
            } catch (_: Exception) {
            }
        }
    }
    on(EVENT_SKU_DATA) { args ->
        if (args.isNotEmpty()) {
            try {
                val data = JSONArray((args[0].toString()))
                Log.e(EVENT_SKU_DATA, data.toString())
                if (data.length() > 0) {
                    for (i in 0 until data.length()) {
                        val skudata = RoomSku()
                        val skuObject = data.getJSONObject(i)
                        skudata.id = skuObject.getString("_id")
                        skudata.banner = skuObject.getString("banner")
                        skudata.image = skuObject.getString("image")
                        skudata.title = skuObject.getString("title")
                        skudata.title_color = skuObject.getString("title_color")
                        skudata.content1 = skuObject.getString("content1")
                        skudata.content2 = skuObject.getString("content2")
                        skudata.content3 = skuObject.getString("content3")
                        skudata.contentColor = skuObject.getString("content_color")
                        skudata.btnText = skuObject.getString("btn_text")
                        skudata.btnColor = skuObject.getString("btn_color")
                        skudata.btnTextColor = skuObject.getString("btn_text_color")
                        skudata.sku = skuObject.getString("sku")
                        skudata.defaultValue = skuObject.getString("default_value")
                        skudata.validity = skuObject.getString("validity")
                        skudata.enable = skuObject.getInt("enable")
                        instances?.skuDao()?.insertRoomSku(skudata)
                    }

                }
            } catch (_: JSONException) {
            } finally {
                CoroutineScope(Dispatchers.Main).launch {
                    socketListenerKo?.call(EVENT_SKU_DATA, "")
                }
                socketEmit(COUNTRY_FLAG, "")
            }

        }
    }
    on(EVENT_VERSION_DATA) { args ->
        if (args.isNotEmpty()) {
            try {
//                Log.e("EVENT_VERSION_DATA", args[0].toString())
                val ads = JSONObject((args[0].toString()))
                try {
                    val adMaster_mainadstatus: String =
                        ads.getString("enabled").toString()
                    val settings = RoomMainAdRecords()
                    settings.id = Helper.ID_MAIN_STATUS
                    settings.data = adMaster_mainadstatus
                    instances?.roomRoomMainAd()?.insertRoomMain_Status(settings)


                    val adMaster_isForcefullyStatus: String =
                        ads.getString("is_force").toString()
                    val settings2 = RoomMainAdRecords()
                    settings2.id = Helper.ID_FORCEFULLY
                    settings2.data = adMaster_isForcefullyStatus
                    instances?.roomRoomMainAd()?.insertRoomMain_Status(settings2)

                    if (isAdsLibsLoad()) {
                        GstApp.context.initialize()
                    }
                    val adMaster_mainGameStatus: String =
                        ads.getString("is_game").toString()
                    val settings3 = RoomMainAdRecords()
                    settings3.id = Helper.ID_GAME
                    settings3.data = adMaster_mainGameStatus
                    instances?.roomRoomMainAd()?.insertRoomMain_Status(settings3)

                    val adMaster = JSONArray(ads.getString("ad_master"))
                    if (adMaster.length() > 0) {
                        for (i in 0 until adMaster.length()) {
                            val adsObject = adMaster.getJSONObject(i)
                            val appAds = RoomVersion()
                            appAds.placement_name = adsObject.getString("adm_name")
                            Log.e(
                                "EVENT_VERSION_DATA",
                                "EVENT_VERSION_DATA ${appAds.placement_name}"
                            )
                            try {
                                appAds.count =
                                    if (adsObject.getString("count") == "0") 0 else adsObject.getString(
                                        "count"
                                    ).toInt()
                            } catch (e: NumberFormatException) {
                                appAds.count = 0
                            }
                            appAds.enable = adsObject.getInt("enable")
                            val adChild = adsObject.getJSONArray("ad_chield")
                            for (j in 0 until adChild.length()) {
                                val adChildObject = adChild.getJSONObject(j)
                                val adChildModel = RoomAdsChild()
                                adChildModel.id =
                                    "${adsObject.getString("adm_name")}_$j"
                                adChildModel.ads_id =
                                    adChildObject.getString("ad_token")
                                adChildModel.ads_name =
                                    adChildObject.getString("ad_keyword")
                                adChildModel.enable = adChildObject.getInt("enable")
                                appAds.adsChild.add(adChildModel)
                                instances?.versionDao()?.insertVersionData(appAds)
                            }

                        }

                        socketListenerKo?.call(EVENT_VERSION_DATA, "")
                    }

                } catch (e: JSONException) {
                    Log.e("JSONException", "EVENT_VERSION_DATA", e)
                } finally {
                    socketEmit(SKU, "")
                }

            } catch (e: Exception) {
                Log.e("Exception", "EVENT_VERSION_DATA", e)
            }
        }
    }
}

var isSocketConnected = false
fun socketEmit(eventName: String, messages: String) {
    if (BuildConfig.DEBUG)
        Log.e("TAG", "$eventName socketEmit ********************* $messages")
    if (socket == null) {
        try {
            val opts = IO.Options()
            opts.path = SOCKET_HANDSHAKE
            socket = IO.socket(SOCKET_CONNECTION, opts)
            socket?.let {
                it.io()
                    .reconnection(true)
                    .reconnectionAttempts(5)
                    .reconnectionDelay(5000)
                if (!it.connected()) {
                    it.connect()
                    if (!isSocketConnected)
                        it.initSocket()
                    isSocketConnected = true
                    try {
                        if (eventName == VERIFY_USER || eventName == INSTALL_TRACK)
                            it.emit(eventName, JSONObject(messages))
                        else it.emit(eventName, messages)
                    } catch (e: OutOfMemoryError) {
                        Log.e("OutOfMemoryError ", "OutOfMemoryError", e)
                    } catch (e: Exception) {
                        Log.e("Exception ", "Exception", e)
                    }
                } else {
                    try {
                        if (eventName == VERIFY_USER || eventName == INSTALL_TRACK)
                            it.emit(eventName, JSONObject(messages))
                        else it.emit(eventName, messages)
                    } catch (e: OutOfMemoryError) {
                        Log.e("OutOfMemoryError ", "OutOfMemoryError", e)
                    } catch (e: Exception) {
                        Log.e("Exception ", "Exception", e)
                    }
                }
            }
        } catch (e: IOException) {
            Log.e("IOException ", "IOException", e)
        } catch (e: RuntimeException) {
            Log.e("RuntimeException ", "RuntimeException", e)
        } catch (e: Exception) {
            Log.e("Exception ", "Exception", e)
        }
    } else {
        socket?.let {
            if (!it.connected()) {
                it.connect()
                if (!isSocketConnected)
                    it.initSocket()
                isSocketConnected = true
                try {
                    if (eventName == VERIFY_USER || eventName == INSTALL_TRACK)
                        it.emit(eventName, JSONObject(messages))
                    else it.emit(eventName, messages)
                } catch (e: OutOfMemoryError) {
                    Log.e("socketEmit ", "OutOfMemoryError", e)
                } catch (e: Exception) {
                    Log.e("socketEmit ", "Exception", e)
                }
            } else {
                try {
                    if (eventName == VERIFY_USER || eventName == INSTALL_TRACK)
                        it.emit(eventName, JSONObject(messages))
                    else it.emit(eventName, messages)
                } catch (e: OutOfMemoryError) {
                    Log.e("socketEmit ", "OutOfMemoryError", e)
                } catch (e: Exception) {
                    Log.e("socketEmit ", "Exception", e)
                }
            }
        }
    }

}

fun installTrack() {
    var oldVersion =
        instances?.roomConnectionDao()?.getRoomConnection(DataBase_Constant.DATA_INSTALL_TRACK)
    if (oldVersion == null) {
        oldVersion = "null"
    }
    if (BuildConfig.VERSION_CODE.toString() != oldVersion) {
        val jsonObject = JsonObject()
        jsonObject.addProperty("app_old_version", if (oldVersion == "null") "" else oldVersion)
        jsonObject.addProperty("app_version", BuildConfig.VERSION_CODE.toString())
        socketEmit(INSTALL_TRACK, jsonObject.toString())
    } else gameData()
}

fun verificationPurchase(sku: String, token: String) {
    val jsonObject = JsonObject()
    jsonObject.addProperty("packageName", BuildConfig.APPLICATION_ID)
    jsonObject.addProperty("sku", sku)
    jsonObject.addProperty("token", token)
    socketEmit(VERIFY_USER, jsonObject.toString())
}

fun isPrime(): Boolean {
    return SUBSCRIPTION_STATE == "SUBSCRIPTION_STATE_ACTIVE"
}

fun gameData() {
    CoroutineScope(Dispatchers.IO).launch {
        val jsonObject = JsonObject()
        jsonObject.addProperty("event_name", "game")
        val api = getRestService()
        if (api != null) {
            val call = api.body(jsonObject)
            call.enqueue(object : Callback<JsonObject> {
                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    if (response.isSuccessful) {
                        val jsonObjectMain = JSONObject(response.body().toString())
                        val code = jsonObjectMain.getInt("code")
                        if (code == 200) {
                            try {
                                val data = jsonObjectMain.getJSONArray("data")
                                if (data.length() > 0)
                                    for (i in 0 until data.length()) {
                                        try {
                                            val dataObject = data.getJSONObject(i)
                                            val tbTags = RoomGame()
                                            tbTags.id = dataObject.getString("_id")
                                            tbTags.icon = dataObject.getString("icon")
                                            tbTags.banner = dataObject.getString("banner")
                                            tbTags.link = dataObject.getString("link")
                                            tbTags.enable = dataObject.getInt("enable")

                                            instances?.roomGamesDao()?.insertRoomGameLoaded(tbTags)
                                        } catch (e: JSONException) {
                                            e.printStackTrace()
                                        } catch (e: NullPointerException) {
                                            e.printStackTrace()
                                        } catch (e: IndexOutOfBoundsException) {
                                            e.printStackTrace()
                                        }
                                    }
                            } catch (e: JSONException) {
                                Log.e("CustomAdsStoreJob", "JSONException")
                            }
                        }
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    Log.e("TAG", "--------game job-----${t.message}")
                }
            })
        }

    }
}

val Activity.maxHeightBanner: Int
    get() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density = outMetrics.density
        val adWidthPixels = resources.getDimension(R.dimen._55sdp)
        return (adWidthPixels / density).toInt()
    }


fun Activity.bannerInlineAdaptiveAds(layout: LinearLayout, id: String, callback: () -> Unit) {
    val adView = AdView(this)
    adView.setAdSize(
        AdSize.getInlineAdaptiveBannerAdSize(
            WindowManager.LayoutParams.MATCH_PARENT,
            maxHeightBanner
        )
    )
    adView.adUnitId =
        if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/9214589741" else id
    adView.loadAd(AdRequest.Builder().build())
    adView.adListener = object : AdListener() {
        override fun onAdFailedToLoad(adError: LoadAdError) {
            super.onAdFailedToLoad(adError)
            layout.removeAllViews()
            callback.invoke()
        }

        override fun onAdLoaded() {
            super.onAdLoaded()
            layout.removeAllViews()
            layout.addView(adView)
        }
    }
}

fun Activity.splashBannerInlineAdaptiveAds(
    layout: LinearLayout,
    id: String,
    callback: (isAdsFail: Boolean) -> Unit
) {
    val adView = AdView(this)
    adView.setAdSize(
        AdSize.getInlineAdaptiveBannerAdSize(
            WindowManager.LayoutParams.MATCH_PARENT,
            maxHeightBanner
        )
    )
    adView.adUnitId =
        if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/9214589741" else id
    adView.loadAd(AdRequest.Builder().build())
    adView.adListener = object : AdListener() {
        override fun onAdFailedToLoad(adError: LoadAdError) {
            super.onAdFailedToLoad(adError)
            layout.removeAllViews()
            callback.invoke(true)
        }

        override fun onAdLoaded() {
            super.onAdLoaded()
            layout.removeAllViews()
            layout.addView(adView)
            callback.invoke(false)
        }
    }
}


fun Activity.nativeBannerInlineAdaptiveAds(id: String, callback: (adView: AdView?) -> Unit) {
    val adView = AdView(this)
    adView.setAdSize(
        AdSize.getInlineAdaptiveBannerAdSize(
            WindowManager.LayoutParams.MATCH_PARENT,
            maxHeightNative
        )
    )
    adView.adUnitId =
        if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/9214589741" else id
    adView.loadAd(AdRequest.Builder().build())
    adView.adListener = object : AdListener() {
        override fun onAdFailedToLoad(adError: LoadAdError) {
            super.onAdFailedToLoad(adError)
            callback.invoke(null)
        }

        override fun onAdLoaded() {
            super.onAdLoaded()
            callback.invoke(adView)
        }
    }
}

val Activity.maxHeightNative: Int
    get() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density = outMetrics.density
        val adWidthPixels = resources.getDimension(R.dimen._180sdp)
        return (adWidthPixels / density).toInt()
    }