package com.divinesoftech.calculator.JobSechedual

import android.app.Activity
import android.content.Context
import android.os.Build
import com.divinesoftech.NODE_CONNECTION
import com.divinesoftech.NODE_SECRET
import com.divinesoftech.calculator.BuildConfig
import com.divinesoftech.calculator.BuildConfig.*
import com.divinesoftech.calculator.Common.AppOpenManager
import com.divinesoftech.calculator.database.*
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.gson.JsonObject
import com.ihsanbal.logging.Level
import com.ihsanbal.logging.LoggingInterceptor
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.internal.platform.Platform
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader


@JvmField
var appOpenManager: AppOpenManager? = null


var GOOGLE = "Google"
var GOOGLE_INLINE_ADAPTIVE_BANNER = "google_inline_adaptive_banner"
var EXIT_NATIVE = "Exit_Native"
var FULL_HISTORY = "full_history"
var ALTERNATIVE = "ALTERNATIVE"
var NO_ADS_FOUND = "no ads found"
var CUSTOM = "CUSTOM"

var doubleBackToExitPressedOnce = false


fun isDeviceRootedOrEmulator(): Boolean {
    return checkRootMethod1() || checkRootMethod2() || checkRootMethod3() || Build.FINGERPRINT.startsWith(
        "generic"
    ) || Build.FINGERPRINT.startsWith("unknown") || Build.MODEL.contains("google_sdk") || Build.MODEL.contains(
        "Emulator"
    ) || Build.MODEL.contains("Android SDK built for x86")
}

private fun checkRootMethod1(): Boolean {
    val buildTags = Build.TAGS
    return buildTags != null && buildTags.contains("test-keys")
}

private fun checkRootMethod2(): Boolean {
    val paths = arrayOf(
        "/system/app/Superuser.apk",
        "/sbin/su",
        "/system/bin/su",
        "/system/xbin/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/su"
    )
    for (path in paths) {
        if (File(path).exists()) return true
    }
    return false
}

private fun checkRootMethod3(): Boolean {
    var process: Process? = null
    return try {
        process = Runtime.getRuntime().exec(
            arrayOf(
                "/system/xbin/which", "su"
            )
        )
        val abc = BufferedReader(InputStreamReader(process.inputStream))
        abc.readLine() != null
    } catch (t: Throwable) {
        false
    } finally {
        process?.destroy()
    }
}


fun getRestService(): Service? {
    return if (getRestClient(NODE_CONNECTION) != null) try {
        getRestClient(NODE_CONNECTION)?.create(Service::class.java)
    } catch (e: NullPointerException) {
        e.printStackTrace()
        null
    } else null
}

fun getRestClient(baseUrl: String): Retrofit? {
    return if (baseUrl.contains("http")) {
        try {
            val interceptor = Interceptor { chain ->
                val original = chain.request()
                val builder = original.newBuilder()
                builder.header("app_secret", NODE_SECRET)
                builder.method(original.method, original.body)
                val request = builder.build()
                chain.proceed(request)
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(
                    LoggingInterceptor.Builder()
                        .setLevel(if (DEBUG) Level.BASIC else Level.NONE)
                        .log(Platform.INFO)
                        .log(1)
                        .request("Request")
                        .response("ResponseCategory")
                        .build()
                )
                .addInterceptor(interceptor)
                .build()

            Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(baseUrl)
                .client(client)
                .build()
        } catch (e: SecurityException) {
            null
        }
    } else null
}

interface Service {
    @POST(".")
    fun body(@Body jsonObject: JsonObject): Call<JsonObject>

    @GET(".")
    fun check(): Call<JsonObject>
}
