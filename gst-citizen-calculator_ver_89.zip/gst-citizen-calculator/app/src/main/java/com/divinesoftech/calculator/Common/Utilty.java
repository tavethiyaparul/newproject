package com.divinesoftech.calculator.Common;


import static com.google.android.gms.ads.AdSize.LARGE_BANNER;
import static com.google.android.gms.ads.nativead.NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_LANDSCAPE;
import static com.google.android.gms.ads.nativead.NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_SQUARE;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.divinesoftech.calculator.BuildConfig;
import com.divinesoftech.calculator.CustomAd.callback.AdsLoaded;
import com.divinesoftech.calculator.CustomAd.model.Data;
import com.divinesoftech.calculator.CustomAd.ui.AdsClick;
import com.divinesoftech.calculator.CustomAd.ui.AdsInit;
import com.divinesoftech.calculator.CustomAd.ui.BannerAds;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.database.AdsFailToLoad;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;


public class Utilty {
    public static boolean is_done = false;

    public static String BACKUP_BANNER = "ca-app-pub-8980115782895213/4991822247";
    public static String CONFIG_TAG = "conn_gst_calc";
    public static String CONNECTION_TAG = "calc_conn_test";
    public static String CUSTOM_AD_TAG = "custom_adcalc";
    public static String COUNTRY_FLAG_TAG = "gst_mongo_flags";
    public static String GAME_URL = "game_url";
    public static String GAME_ON_TAG = "game_on";
    public static String NODE_TAG = "node";

    public static String SHARED_PERF = "GstCaculator";


    public static boolean isSplashScreen = false;
    public static boolean isClickGames = false;


    public static int mAdsAnswer = 0;
    public static int mAdsAnswernew = 0;
    public static int mAdsMax = 0;


    public static int Count = 0;
    public static int mCountAdsLoadings = 0;
    public static String prv = "";

    public static final String KEY_DATA_VALUE = "TOKEN";
    public static String KEY_DATA = "";

    public static boolean is_gst_button = false;
    public static boolean is_history_button = false;

    public static ArrayList<Data> mAdsData = new ArrayList<>();

    public static final String Install_Track = "sapiinastall";
    public static final String LIVE_ADS = "sadmnw";
    public static final String CUSTOM_ADS = "apicad";
    public static final String CUSTOM_ADS_COUNT = "apicadc";


    public static final String GOOGLE_AD = "Google";

    public static final String ADAPTIVE_BANNER = "adaptive_banner";
    public static final String SMART_BANNER = "smart_banner";
    public static final String GOOGLE_BANNER_AD = "G_Banner";
    public static final String START_APP_AD = "StartApp";
    public static final String FACEBOOK_AD = "Facebook";
    public static final String FACEBOOK_NATIVE_BANNER = "Facebook_Native_Banner";
    public static final String CUSTOM_AD = "CUSTOM";
    public static final String GAME_AD = "GAME";
    public static final String ALTERNATIVE = "ALTERNATIVE";
    public static final String DEFAULT = "DEFAULT";
    public static final String APP_OPEN = "App_Open";
    public static final String NO_DATA_FOUND = "NO_DATA_FOUND";

    public static final String Native_Banner = "Native_Banner";
    public static final String Mode_Interstial = "interstial";
    public static final String Mode_Banner = "banner";
    public static final String Mode_Native = "native";

    //Ad Prefreances----

    public static final String AD_GST_PREF = "AD_GST_PREF";
    public static final String AD_LOAN_PREF = "AD_LOAN_PREF";
    public static final String AD_INTREST_PREF = "AD_INTREST_PREF";
    public static final String AD_AGE_PREF = "AD_AGE_PREF";
    public static final String AD_CURRANCY_PREF = "AD_CURRANCY_PREF";
    public static final String AD_MAIN_PREF = "AD_MAIN_PREF";


    public static final String FULL_SPLASH = "full_splash";
    public static final String HOME_BANNER = "Home_banner";
    public static final String HOME_BANNER_VARIANT_B = "Home_banner_variant_b";
    public static final String NATIVE_SAVE = "Native_Save";
    public static final String COMMON_BANNER = "Common Banner";
    public static final String Main_Activity = "Main_Activity";


    public static final String Rate_First_Time = "Rate_First_Time";
    public static final String Rate_Date = "Rate_Date";
    public static final String Rate_Dialog_show = "Rate_Dialog_show";
    public static final String RATE_US_COM = "COMPLETE";

    public static final String Date_format = "MM/dd/yyyy";


    public static String SKU_REPONSE = "7";
    public static String IS_ADFREE = "10";
    public static String Live_Ads = "1";
    public static String Custom_Ads = "2";
    public static String Currancy_Response = "3";
    public static String Cuontry_Flag_Response = "4";
    public static final String PREF_RESPONSE = "PREF_RRESPONSE";
    public static final String CURRANCYDATA = "currancy_response";
    public static final String COUNTRYDATA = "flag_response";
    public static AdsInit adsInit;
    public static ArrayList<Data> arrayListAds = new ArrayList();


    public static void appOpen() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                isSplashScreen = false;
            }
        }, 4000);
        isSplashScreen = true;
    }

    public static void preventTwoClick(final View view) {
        view.setEnabled(false);
        view.postDelayed(
                () -> view.setEnabled(true),
                500
        );
    }

    /*public static String[] mGetAdsIdMangoDb(ArrayList<Getversion> mAppLiveAds, String AdsType, SharedPreferences preferences, String mPerfName) {

        if (mAppLiveAds.size() > 0)
            try {
                @SuppressLint("CommitPrefEdits") SharedPreferences.Editor editor = preferences.edit();
                String[] strings = new String[2];
                ArrayList<String> stringArrayList = new ArrayList<>();
                for (Getversion version : mAppLiveAds) {


                    if (version.getAdm_name().equals(AdsType) && version.getEnable().equals("1")) {

                        for (Ad_chield adChield : version.getAd_chield()) {
                            String keyWord = adChield.getAd_keyword();
                            if (!keyWord.equals(ALTERNATIVE) && !keyWord.equals(CUSTOM_AD))
                                stringArrayList.add(keyWord);

                        }


                    }
                }

                if (stringArrayList.size() > 0) {

                    for (Getversion version : mAppLiveAds) {

                        if (version.getAdm_name().equals(AdsType) && version.getEnable().equals("1")) {

                            for (Ad_chield adChield : version.getAd_chield()) {


                                if (adChield.getEnable().equals("1")) {
                                    strings[0] = adChield.getAd_keyword();

                                    Log.e("====strings[0]=====> ","XXXXXXX====> "+strings[0]);

                                    if (strings[0].equals(CUSTOM_AD)) {
                                        strings[0] = CUSTOM_AD;
                                        strings[1] = CUSTOM_AD;
                                        return strings;
                                    } else if (strings[0].equals(ALTERNATIVE)) {
                                        Log.e("====ALTERNATIVE=====> ","XXXXXXX====> "+strings[0]);

                                        int MODE = preferences.getInt(mPerfName, 1);
                                        Log.e("====MODE=====> ","XXXXXXX====> "+MODE);
                                        switch (MODE) {
                                            case 1:
                                                if (stringArrayList.size() == 1) {
                                                    editor.putInt(mPerfName, 1);
                                                    editor.apply();
                                                    Log.e("=========> ","XXXXXXX==get(0)==> "+stringArrayList.get(0));
                                                    strings[0] = stringArrayList.get(0);
                                                } else {
                                                    editor.putInt(mPerfName, 2);
                                                    editor.apply();
                                                    strings[0] = stringArrayList.get(0);
                                                }
                                                break;
                                            case 2:
                                                if (stringArrayList.size() == 2) {
                                                    editor.putInt(mPerfName, 1);
                                                    editor.apply();
                                                    strings[0] = stringArrayList.get(1);
                                                } else {
                                                    editor.putInt(mPerfName, 3);
                                                    editor.apply();
                                                    strings[0] = stringArrayList.get(1);
                                                }
                                                break;
                                            case 3:
                                                if (stringArrayList.size() == 3) {
                                                    editor.putInt(mPerfName, 1);
                                                    editor.apply();
                                                    strings[0] = stringArrayList.get(2);
                                                } else {
                                                    editor.putInt(mPerfName, 4);
                                                    editor.apply();
                                                    strings[0] = stringArrayList.get(2);
                                                }
                                                break;
                                            case 4:
                                                if (stringArrayList.size() == 4) {
                                                    editor.putInt(mPerfName, 1);
                                                    editor.apply();
                                                    strings[0] = stringArrayList.get(3);
                                                } else {
                                                    editor.putInt(mPerfName, 5);
                                                    editor.apply();
                                                    strings[0] = stringArrayList.get(3);
                                                }
                                                break;
                                            case 5:
                                                editor.putInt(mPerfName, 1);
                                                editor.apply();
                                                strings[0] = stringArrayList.get(4);
                                                break;
                                        }

                                    }
                                    Log.e("=========> ","XXXXXXX==getAd_keyword==> "+adChield.getAd_keyword());
                                    if (strings[0].equals(adChield.getAd_keyword())) {

                                        Log.e("=========> ","XXXXXXX==getAd_token==> "+adChield.getAd_token());
                                        strings[1] = adChield.getAd_token();
                                        return strings;
                                    }

                                    break;
                                }
                            }
                            break;
                        }
                    }


                } else return null;

            } catch (JsonSyntaxException e) {

                e.printStackTrace();
                return null;
            } catch (NumberFormatException e) {

                e.printStackTrace();
                return null;
            } catch (IndexOutOfBoundsException e) {

                return null;
            } catch (NullPointerException e) {

                return null;
            } catch (Exception e) {

                e.printStackTrace();
                return null;
            }

        return null;
    }*/


    public static boolean isNetworkAvailable(Context context) {
        return isNetworkConnected(context);
    }


    public static boolean isNetworkConnected(final Context context) {
        if (context != null) {
            final ConnectivityManager connectivityManager = (ConnectivityManager) context.
                    getSystemService(Context.CONNECTIVITY_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network network = connectivityManager.getActiveNetwork();
                final NetworkCapabilities capabilities = connectivityManager
                        .getNetworkCapabilities(network);

                return capabilities != null
                        && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            } else {
                NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
                return netInfo != null && netInfo.isConnectedOrConnecting();
            }
        } else {
            return false;
        }
    }

    public static void hideSoftKeyboard(View view) {
        if (view == null) {
            return;
        }
        View mFocusView = view;

        Context context = view.getContext();
        if (context != null && context instanceof Activity) {
            Activity activity = ((Activity) context);
            mFocusView = activity.getCurrentFocus();
        }
        if (mFocusView == null) {
            return;
        }
        mFocusView.clearFocus();
        InputMethodManager manager = (InputMethodManager) mFocusView.getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        manager.hideSoftInputFromWindow(mFocusView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    public static Typeface fontstyle(Context context) {
        Typeface font;
        font = Typeface.createFromAsset(context.getAssets(), "fonts/Sansation_Bold.ttf");
        return font;
    }

    public static boolean isLeapYear(int year) {
        if (year % 4 != 0) {
            return false;
        } else if (year % 400 == 0) {
            return true;
        } else if (year % 100 == 0) {
            return false;
        } else {
            return true;
        }
    }

    public static void hideSystemUI(Activity activity) {

        View decorView = activity.getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }


    public void GoogleBannerAdvance(Boolean isBlackScreen, Activity activity, String id, LinearLayout ads_container, AdsFailToLoad adsFailToLoad) {


        new AdLoader.Builder(activity, /*BuildConfig.DEBUG ? "ca-app-pub-3940256099942544/2247696110" :*/ id)
                .forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                        int layout;
                        if (isBlackScreen) {
                            layout = R.layout.ad_unified;
                        } else layout = R.layout.ad_unified_white;
                        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(layout, null);

                        BannerUnifiedNativeAdView(nativeAd, adView);
                        ads_container.setVisibility(View.VISIBLE);
                        ads_container.removeAllViews();
                        ads_container.addView(adView);
                        adView.bringToFront();
                        ads_container.invalidate();

                    }

                })
                .withNativeAdOptions(
                        new NativeAdOptions.Builder()
                                .setMediaAspectRatio(NATIVE_MEDIA_ASPECT_RATIO_SQUARE)
                                .build()
                )
                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        adsFailToLoad.onFailed();
                    }
                })
                .build()
                .loadAd(new AdRequest.Builder().build());


    }

    public void GoogleBannerAdvanceLarge(Activity activity, String id, LinearLayout ads_container, AdsFailToLoad adsFailToLoad) {


        new AdLoader.Builder(activity, BuildConfig.DEBUG ? "ca-app-pub-3940256099942544/2247696110" : id)
                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.ad_unified_large, null);

                        BannerUnifiedNativeAdView(nativeAd, adView);
                        ads_container.setVisibility(View.VISIBLE);
                        ads_container.removeAllViews();
                        ads_container.addView(adView);
                        adView.bringToFront();
                        ads_container.invalidate();

                    }

                })
                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        adsFailToLoad.onFailed();
                    }
                })
                .build()
                .loadAd(new AdRequest.Builder().build());


    }

    private void BannerUnifiedNativeAdView(com.google.android.gms.ads.nativead.NativeAd nativeAd, NativeAdView adView) {

//        com.google.android.gms.ads.nativead.MediaView mediaView = adView.findViewById(R.id.ad_media);
//        adView.setMediaView(mediaView);

        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
//        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
//        adView.setPriceView(adView.findViewById(R.id.ad_price));
//        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
//        ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());

        if (nativeAd.getIcon() != null)
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());

        /*if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.GONE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }*/

        /*if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.GONE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }*/

        adView.setNativeAd(nativeAd);
    }


    public void GoogleAdaptiveBanner(Activity activity, String id, LinearLayout Custom_ad_Container, Boolean isLarge, AdsFailToLoad adsFailToLoad) {
        try {

            if (activity != null && !activity.isFinishing()) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(activity);
                com.google.android.gms.ads.AdSize adSize = isLarge ? LARGE_BANNER : getAdSize(activity);

                adView.setAdSize(adSize);
                adView.setAdUnitId(BuildConfig.DEBUG ? "ca-app-pub-3940256099942544/6300978111" : id);
                AdRequest adRequest = new AdRequest
                        .Builder()
                        .build();
                adView.loadAd(adRequest);
                adView.setAdListener(new com.google.android.gms.ads.AdListener() {
                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        Custom_ad_Container.removeAllViews();
                        Custom_ad_Container.setVisibility(View.VISIBLE);
                        Custom_ad_Container.addView(adView);


                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
//                        Log.e("onAdFailedToLoad", "XXXXX=========> " + loadAdError.getCode());
                        adsFailToLoad.onFailed();
                    }


                });
            }
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public com.google.android.gms.ads.AdSize getAdSize(Activity activity) {
        // Determine the screen width (less decorations) to use for the ad width.
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    public void mSmartBanner(Activity activity, String id, RelativeLayout ad_container, LinearLayout Custom_ad_Container) {
        com.google.android.gms.ads.AdView mAdView = new com.google.android.gms.ads.AdView(activity);
        mAdView.setAdSize(AdSize.SMART_BANNER);
        mAdView.setAdUnitId(id);
        AdRequest adRequest = new AdRequest
                .Builder()
                .build();
        mAdView.loadAd(adRequest);
        mAdView.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                ad_container.removeAllViews();
                ad_container.setVisibility(View.VISIBLE);
                ad_container.addView(mAdView);
            }

            @Override
            public void onAdFailedToLoad(@NonNull @NotNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                if (Custom_ad_Container.getVisibility() == View.GONE) {
                    Custom_ad_Container.setVisibility(View.VISIBLE);
                    CustomAds(activity, Custom_ad_Container);
                }
            }

        });

    }


    public static void GoogleNative(Activity activity, String id, LinearLayout ads_container) {

        new AdLoader.Builder(activity, id)
                .forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.ads_native_google, null);

                        populateUnifiedNativeAdView(nativeAd, adView);

                        ads_container.setVisibility(View.VISIBLE);
                        ads_container.removeAllViews();
                        ads_container.addView(adView);
                        adView.bringToFront();
                        ads_container.invalidate();
                    }

                })
                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);

                    }
                })
                .build()
                .loadAd(new AdRequest.Builder().build());


    }

    public static void populateUnifiedNativeAdView(com.google.android.gms.ads.nativead.NativeAd nativeAd, NativeAdView adView) {

        MediaContent vc = nativeAd.getMediaContent();
        vc.getVideoController().setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
            public void onVideoEnd() {
                super.onVideoEnd();
            }
        });

        com.google.android.gms.ads.nativead.MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        // Some assets are guaranteed to be in every UnifiedNativeAd.
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());

        // These assets aren't guaranteed to be in every UnifiedNativeAd, so it's important to
        // check before trying to display them.
        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.GONE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.GONE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.GONE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
    }


    public void CustomAds(Activity activity, LinearLayout linearLayout) {
        adsInit = new AdsInit();
        adsInit.AdsRequest(activity, true, arrayListAds, new AdsLoaded() {
            @Override
            public void onLoaded(ArrayList<String> arrayList, int pos) {

                try {
                    if (arrayList != null) {
                        BannerAds bannerAds = new BannerAds(activity);
                        Data data = arrayListAds.get(pos);
                        bannerAds.adLoad(data);
                        linearLayout.addView(bannerAds);
                        linearLayout.setVisibility(View.VISIBLE);
                        linearLayout.setBackgroundColor(Color.WHITE);
                        bannerAds.onListner(new AdsClick() {
                            @Override
                            public void onClick(String... strings) {
                            }
                        });
                    }
                } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailed() {

                linearLayout.removeAllViews();
                linearLayout.setVisibility(View.GONE);


            }
        });
    }

}
