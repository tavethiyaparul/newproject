package com.divinesoftech.calculator.CustomAd.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

@Keep
public class GetAdsData implements Serializable {
    @SerializedName("data")
    private ArrayList<Data> data;
    @SerializedName("splash")
    private ArrayList<Data> splash;

    public ArrayList<Data> getData() {
        return data;
    }

    public void setData(ArrayList<Data> data) {
        this.data = data;
    }

    public ArrayList<Data> getSplash() {
        return splash;
    }

    public void setSplash(ArrayList<Data> splash) {
        this.splash = splash;
    }
}