package com.divinesoftech.calculator.asynctask;

import android.os.AsyncTask;

import com.divinesoftech.calculator.Common.OnResponse;


import java.io.IOException;
import java.net.SocketTimeoutException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY;

public class CustomAdsSync extends AsyncTask<String, Void, String> {
    OnResponse onResponse;


    public CustomAdsSync(OnResponse onResponse) {
        this.onResponse = onResponse;
    }

    @Override
    protected String doInBackground(String... strings) {
        android.os.Process.setThreadPriority(THREAD_PRIORITY_URGENT_DISPLAY);

        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(strings[0] + strings[1])
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            return response.body().string();
        } catch (SocketTimeoutException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);


            onResponse.onResponse(s);

    }
}