package com.divinesoftech.calculator.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.divinesoftech.calculator.Activities.ShowPDF;
import com.divinesoftech.calculator.R;

import java.io.File;
import java.util.List;

public class PdfListAdapter extends RecyclerView.Adapter<PdfListAdapter.PdfListHolder> {

    List<File> data_list;
    Context context;



    public PdfListAdapter(List<File> data_list,Context context) {
        this.data_list = data_list;
        this.context = context;
    }

    @NonNull
    @Override
    public PdfListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.pdf_list_item, null);
        return new PdfListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PdfListHolder holder, final int position) {

        String file_name = data_list.get(position).toString();
        file_name = file_name.substring(file_name.lastIndexOf("/")+1);
        holder.textView.setText(file_name);
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri photoURI = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".my.package.name.provider", data_list.get(position));
                Intent intent = new Intent(context, ShowPDF.class);
                intent.putExtra("URI",photoURI.toString());
                context.startActivity(intent);



            }
        });

    }

    @Override
    public int getItemCount() {
        return data_list.size();
    }

    public class PdfListHolder extends RecyclerView.ViewHolder {
        TextView textView;
        LinearLayout layout;
        public PdfListHolder(View itemView) {
            super(itemView);
            textView = (TextView)itemView.findViewById(R.id.pdf_name);
            layout = (LinearLayout)itemView.findViewById(R.id.layout_back);
        }
    }
}
