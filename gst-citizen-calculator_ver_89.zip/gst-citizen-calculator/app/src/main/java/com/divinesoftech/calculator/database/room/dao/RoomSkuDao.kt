package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomSku
import com.divinesoftech.calculator.database.room.RoomVersion

@Dao
interface RoomSkuDao {
    @Query("Select * from RoomSku where enable=1")
    fun getRoomSku(): List<RoomSku>?


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomSku(roomVersion: RoomSku)

    @Update
    fun updateRoomSku(roomVersion: RoomSku)

    @Delete
    fun deleteRoomSku(roomVersion: RoomSku)
}