package com.divinesoftech.calculator.database.room.dao

import androidx.room.*
import com.divinesoftech.calculator.database.room.RoomAdvertisement
@Dao
interface RoomAdvertisementDao {
    @Query("Select * from RoomAdvertisement")
    fun getRoomAdvertisement(): List<RoomAdvertisement>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoomAdvertisement(roomVersion: RoomAdvertisement)

    @Update
    fun updateRoomAdvertisement(roomVersion: RoomAdvertisement)

    @Delete
    fun deleteRoomAdvertisement(roomVersion: RoomAdvertisement)
}