package com.divinesoftech.calculator.Activities

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Dialog
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.IntentSender.SendIntentException
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableString
import android.util.DisplayMetrics
import android.util.Log
import android.view.*
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.*
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.divinesoftech.AB_HOME_BANNER_NATIVE
import com.divinesoftech.CUSTOM_DOMAIN
import com.divinesoftech.EVENT_SKU_DATA
import com.divinesoftech.EVENT_VERIFY_USER
import com.divinesoftech.EVENT_VERSION_DATA
import com.divinesoftech.GAME_ON
import com.divinesoftech.GAME_PAGE_URL
import com.divinesoftech.SOCKET_CONNECTION
import com.divinesoftech.SUBSCRIPTION_STATE
import com.divinesoftech.SocketListener
import com.divinesoftech.TIME_STAMP_ID_PURCHASE_DIALOG
import com.divinesoftech.TIME_STAMP_RATE_APP_DIALOG
import com.divinesoftech.VERSION
import com.divinesoftech.bannerInlineAdaptiveAds
import com.divinesoftech.calculator.Adapter.SkuAdapter
import com.divinesoftech.calculator.BuildConfig
import com.divinesoftech.calculator.Classes.GstApp
import com.divinesoftech.calculator.Classes.Model.CountryUtility
import com.divinesoftech.calculator.Classes.Model.CustomAd
import com.divinesoftech.calculator.Classes.Model.UpdateData
import com.divinesoftech.calculator.Common.AppOpenManager
import com.divinesoftech.calculator.Common.CustomTypefaceSpan
import com.divinesoftech.calculator.Common.Utilty
import com.divinesoftech.calculator.Common.Utilty.BACKUP_BANNER
import com.divinesoftech.calculator.Common.Utilty.isNetworkAvailable
import com.divinesoftech.calculator.CustomAd.CustomAdsUtil
import com.divinesoftech.calculator.CustomAd.callback.AdsLoaded
import com.divinesoftech.calculator.CustomAd.callback.DownloadedWebPage
import com.divinesoftech.calculator.CustomAd.callback.InterstitialCustom
import com.divinesoftech.calculator.CustomAd.model.Data
import com.divinesoftech.calculator.CustomAd.sync.DownloadingWebPage
import com.divinesoftech.calculator.CustomAd.ui.AdsInit
import com.divinesoftech.calculator.Fragments.*
import com.divinesoftech.calculator.JobSechedual.*
import com.divinesoftech.calculator.R
import com.divinesoftech.calculator.Service.AlarmReceiver
import com.divinesoftech.calculator.database.*
import com.divinesoftech.calculator.database.room.RoomAdvertisement
import com.divinesoftech.calculator.database.room.RoomDatabaseGst
import com.divinesoftech.calculator.database.room.instances
import com.divinesoftech.idInAppRated
import com.divinesoftech.isPrime
import com.divinesoftech.nativeBannerInlineAdaptiveAds
import com.divinesoftech.remoteData
import com.divinesoftech.socketEmit
import com.divinesoftech.socketListenerKo
import com.divinesoftech.verificationPurchase
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallState
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.JsonSyntaxException
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.content_main.adsContainer
import kotlinx.android.synthetic.main.custom_actionbar.view.*
import kotlinx.android.synthetic.main.dailog_inapp.close_btn
import kotlinx.android.synthetic.main.dailog_inapp_dynamic.*
import kotlinx.android.synthetic.main.tax_slab.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess


class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener,
    PurchasesUpdatedListener {
    var adapter: SkuAdapter? = null
    var fragment: Fragment? = null
    private var fireBase: FirebaseAnalytics? = null
    lateinit var fragments_settings: Any
    lateinit var flag: Any
    private val flag_Ad_fail = false
    var is_custom_ad_exit = false
    var countryUtility: CountryUtility? = null
    private var updateData: UpdateData? = null
    private var customAd: CustomAd? = null
    var doubleBack = false
    var is_widget = false
    var dilog: Dialog? = null

    //    var dialog_subscribe: Dialog? = null
    var preferences: SharedPreferences? = null
    var preferences_Install: SharedPreferences? = null
    var pref_Response: SharedPreferences? = null
    var editor: SharedPreferences.Editor? = null
    var pref_Response_Editor: SharedPreferences.Editor? = null
    private val is_Ad_once = false
    private var is_count = false
    private var ad_not_load = false
    var adRequest: AdRequest? = null
    var getAdsData: ArrayList<Data>? = null
    var handler = Handler()
    var runnable = Runnable { doubleBack = false }
    var key = ""
    var formattedDate = ""
    var KEY_STORE = ""
    var flagPrefs: SharedPreferences? = null
    var flagEditor: SharedPreferences.Editor? = null
    var Ckey = ""
    var is_subscribe = false
    var inApp: BillingClient? = null

    var days: Int? = null


    var expireSevenDialogs: Dialog? = null
    var subscriptionDetectedDialogs: Dialog? = null

    /* var skuMT: TransactionDetails? = null
     var skuYT: TransactionDetails? = null
     var skuThree: TransactionDetails? = null
     var skuSix: TransactionDetails? = null*/
    var PERMISSION_CODE = 120


    var imports: String? = null
    var importes: String? = null
    var imporrts: String? = null
    private val Ad_flag_once = false
    private val load_ads = false
    var handler_back = Handler()
    var AD_ID = ""
    var AD_Flag: String? = "0"
    var ActionBarTitle: TextView? = null
    var reset: AppCompatImageView? = null
    var removeAll: AppCompatImageView? = null
    private val Ad_set = false


    var runnable_back = Runnable { doubleBack = false }

    override fun onResume() {
        super.onResume()
        socketListenerKo = object : SocketListener {
            override fun call(state: String, data: String) {
                when (state) {
                    EVENT_VERSION_DATA -> {
                        CoroutineScope(Dispatchers.Main).launch {
                            if (isFirstTimeLoads) {
                                exitAdsLoads()
                            }
                        }
                    }

                    EVENT_VERIFY_USER -> {
                        CoroutineScope(Dispatchers.Main).launch {
                            if (data == "SUBSCRIPTION_STATE_ACTIVE") {
                                v?.AdText?.visibility = View.GONE
                                nav_view.menu.getItem(7).subMenu?.getItem(1)?.isVisible = false
                                nav_view.menu.getItem(7).subMenu?.getItem(2)?.isVisible = false
                                nav_view.menu.getItem(7).subMenu?.getItem(3)?.isVisible = false
                                purchaseSuccessDialog()
                            }
                        }
                    }

                    EVENT_SKU_DATA -> {
                        CoroutineScope(Dispatchers.Main).launch {
                            inAppDetail()
                        }
                    }
                }
            }
        }

        if (Utilty.is_done) {
            GotoFragment(0)
            Utilty.is_done = false
        }
        updateMenuItem()

//        checkInternetConnection()

    }

    /*private var isShow = false
    fun checkInternetConnection() {
        CoroutineScope(Dispatchers.Main).launch {
            if (!testInternetConnection()) {
                if (!isShow) {
                    isShow = true
                    *//*noInternetDialog {
                        isShow = false
                        checkInternetConnection()
                    }*//*
                }
            }
        }
    }*/

    var appUpdateManager: AppUpdateManager? = null
    var listener: InstallStateUpdatedListener? = null

    private val MY_REQUEST_CODE = 111

    var CurrentDate = ""
    var CurrentDatenew: String? = ""
    private val specialformat = SimpleDateFormat(Utilty.Date_format)
    private val mRateValue = 0f

    lateinit var databaseGst: DatabaseGst

    private var count = 1
    private val handlerGame = Handler()
    var runnableGame: Runnable = object : Runnable {
        override fun run() {
            if (CheackGameUrl()) {
                if (GAME_ON == 1) {
                    val nav_Menu = nav_view!!.menu
                    nav_Menu.findItem(R.id.nav_Play_game).isVisible = false
                }
            } else {
                if (count < 10) {
                    handlerGame.postDelayed(this, 500)
                }
            }
            count++
        }
    }


    private fun bannerLoading() {
        val bannerAds = if (AB_HOME_BANNER_NATIVE) {
            instances?.versionDao()?.getAdsAvailable(Utilty.HOME_BANNER_VARIANT_B)
        } else {
            instances?.versionDao()?.getAdsAvailable(Utilty.HOME_BANNER)
        }

        if (bannerAds == null) {
            bannerInlineAdaptiveAds(adsContainer, BACKUP_BANNER) {}
        } else if (isAdsLibsLoad()) {
            if (!isPrime()) {
                try {
                    try {
                        if (AB_HOME_BANNER_NATIVE) {
                            deleteRecord(Utilty.HOME_BANNER_VARIANT_B)
                            callBanner(builderAds(Utilty.HOME_BANNER_VARIANT_B))
                        } else {
                            deleteRecord(Utilty.HOME_BANNER)
                            callBanner(builderAds(Utilty.HOME_BANNER))
                        }
                    } catch (ignored: IllegalStateException) {
                    }
                } catch (ignored: java.lang.Exception) {
                }
            } else {
                adsContainer.visibility = View.GONE
            }
        } else {
            if (isPrime()) {
                adsContainer.visibility = View.GONE
            }
        }
    }


    private fun callBanner(type: ArrayList<String>) {
        if (type.size > 0) {
            when (type[0]) {
                Utilty.NO_DATA_FOUND -> {}
                Utilty.GOOGLE_AD -> try {
                    Utilty().GoogleBannerAdvance(
                        true,
                        this,
                        type[1],
                        adsContainer,
                        object : AdsFailToLoad {
                            override fun onFailed() {
                                showCustomBanner(adsContainer)
                            }
                        })
                } catch (e: java.lang.IllegalStateException) {
                } catch (e: RuntimeException) {
                }

                Utilty.ADAPTIVE_BANNER -> {
                    bannerInlineAdaptiveAds(adsContainer, type[1]) {
                        showCustomBanner(adsContainer)
                    }
                }

                Utilty.CUSTOM_AD -> try {
                    showCustomBanner(adsContainer)
                } catch (e: java.lang.IllegalStateException) {
                    Log.e("IllegalStateException", "IllegalStateException", e)
                } catch (e: RuntimeException) {
                    Log.e("RuntimeException", "RuntimeException", e)
                }

                Utilty.GAME_AD -> try {
                    showGameBanner(adsContainer)
                } catch (e: java.lang.IllegalStateException) {
                    Log.e("IllegalStateException", "IllegalStateException", e)
                } catch (e: RuntimeException) {
                    Log.e("RuntimeException", "RuntimeException", e)
                }
            }
        }
        exitAdsLoads()
    }


    var v: View? = null


    /* override fun onWindowFocusChanged(hasFocus: Boolean) {
         super.onWindowFocusChanged(hasFocus)
         if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
             window.attributes.layoutInDisplayCutoutMode =
                 WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
         }
         try {
             window.decorView.systemUiVisibility =
                 (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                         View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                         View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                         View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                         View.SYSTEM_UI_FLAG_FULLSCREEN or
                         View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
         } catch (e: NullPointerException) {
             e.printStackTrace()
         }
     }*/

    @SuppressLint("InvalidWakeLockTag", "CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /*if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            window.decorView.systemUiVisibility =
                (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        } catch (e: NullPointerException) {
            e.printStackTrace()
        }*/
        setContentView(R.layout.activity_main)
        CoroutineScope(Dispatchers.Main).launch {
            Log.e("splashBanner","show main activity")
            delay(100)
            GstApp.currentActivity = this@MainActivity
            fragments_settings = 0
            flag = 0

            if (!SOCKET_CONNECTION.contains("http")) {
                isFirstTimeLoads = true
                remoteData {
                    socketEmit(VERSION, BuildConfig.VERSION_CODE.toString())
                }
            } else {
                socketEmit(VERSION, BuildConfig.VERSION_CODE.toString())
                remoteData {}
                inAppDetail()
            }

            /*val decorView = window.decorView
            val uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN
            decorView.systemUiVisibility = uiOptions
            window.addFlags(1024)*/
            setSupportActionBar(toolbar)
            supportActionBar!!.setDisplayShowCustomEnabled(true)
            supportActionBar!!.setDisplayShowTitleEnabled(false)
            databaseGst = DatabaseGst(this@MainActivity)
            Utilty.adsInit = AdsInit()

            // initDatabase()

//        getSkuData()

            preferences = getSharedPreferences("update", MODE_PRIVATE)
            pref_Response = getSharedPreferences(Utilty.PREF_RESPONSE, MODE_PRIVATE)
            editor = preferences?.edit()
            pref_Response_Editor = pref_Response?.edit()
            val inflator = LayoutInflater.from(this@MainActivity)
            v = inflator.inflate(R.layout.custom_actionbar, null)
            ActionBarTitle = v?.action_bar_title
            reset = v?.reset
            removeAll = v?.removeAll
            if (databaseGst.getResponse(Utilty.IS_ADFREE) == null) {
                val isUpdatestr =
                    if (databaseGst.getResponse(Utilty.IS_ADFREE) == null) "false" else "true"
                databaseGst.setResponse(Utilty.IS_ADFREE, "NO", isUpdatestr)
            }
            val date = Calendar.getInstance().time
            bannerLoading()
            GotoFragment(0)
            updateMenuItem()
            CurrentDate = specialformat.format(date)/*if (preferences?.getString(Utilty.Rate_Date, "26/01/1990") != CurrentDate) {
            if (preferences?.getBoolean(Utilty.Rate_Dialog_show, false) != true) {
                if (preferences?.getBoolean(Utilty.Rate_First_Time, false) == true) {
                    mRateUseDialog(false)
                    editor?.putBoolean(Utilty.Rate_First_Time, false)
                    editor?.putString(Utilty.Rate_Date, CurrentDate)
                    editor?.apply()
                } else {
                    editor?.putBoolean(Utilty.Rate_First_Time, true)
                    editor?.apply()
                }
            }
        }*/

            val sharedPreferences = getSharedPreferences("StoreData", MODE_PRIVATE)
            editor = sharedPreferences.edit()
            @SuppressLint("SimpleDateFormat") val spf = SimpleDateFormat("MM/dd/yyyy")
            val date1 = Calendar.getInstance().time
            CurrentDatenew = spf.format(date1)
            if (CurrentDate != sharedPreferences.getString("update", "")) {
                UpdateDialog()
            }/*  if (Utilty.isNetworkAvailable(this@MainActivity) && databaseGst.getResponse(Utilty.IS_ADFREE) != "YES") {
              //v?.gift_layout?.visibility = View.VISIBLE

              if (IsPrimeGstCalIsFree == IsPrimeGstCal.IS_FREE) {
                  v?.img_app?.setImageDrawable(resources.getDrawable(R.drawable.ic_gift_box))
                  v?.img_app?.visibility = View.VISIBLE
                  v?.btn_playgame?.visibility = View.VISIBLE
                  v?.txt_game?.visibility = View.VISIBLE
              }
              else{
                  v?.img_app?.visibility = View.GONE
                  v?.btn_playgame?.visibility = View.GONE
                  v?.txt_game?.visibility = View.GONE
              }

          *//*    try {

                val handler = Handler(Looper.getMainLooper())
                val runnable: Runnable = object : Runnable {
                    override fun run() {
                        val ads = instances?.versionDao()?.getVersionData(Utilty.FULL_EXIT, 1)
                        if (ads != null) {
                            deleteRecord(Utilty.FULL_EXIT)
                            AdsLoadingInterStialExit(builderAds(Utilty.FULL_EXIT))
                            try {
//                                AppOpenManager()
                            } catch (e: RuntimeException) {
                            }
                        } else {
                            handler.postDelayed(this, 250)
                        }
                    }
                }
                handler.postDelayed(runnable, 250)
            } catch (e: Exception) {
                e.printStackTrace()
            }
*//*

                }
                else {
                    //v?.gift_layout?.visibility = View.GONE
                    v?.btn_playgame?.visibility = View.GONE
                    v?.txt_game?.visibility = View.GONE
                    v?.AdText?.visibility = View.GONE
                }*/




            supportActionBar!!.customView = v
            flagPrefs = getSharedPreferences("flag_prefrence", MODE_PRIVATE)
            flagEditor = flagPrefs?.edit()
            countryUtility = CountryUtility()
            updateData = UpdateData()
            customAd = CustomAd()
            FirebaseMessaging.getInstance().isAutoInitEnabled = true/* FirebaseInstanceId.getInstance().instanceId
             .addOnCompleteListener { task: Task<InstanceIdResult> ->
                 if (!task.isSuccessful) {
                     return@addOnCompleteListener
                 }
                 storeRegIdInPref(task.result.token)
             }*/
            v?.gift_layout?.setOnClickListener(View.OnClickListener { v1: View? -> GiftDialog() })
//        v?.btn_playgame?.setOnClickListener(View.OnClickListener { view: View? ->
//            try {
//                if (GAME_PAGE_URL != "") RedirectToPage(this@MainActivity)
//            } catch (e: ActivityNotFoundException) {
//                e.printStackTrace()
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        })
            val m = nav_view.menu
            for (i in 0 until m.size()) {
                val mi = m.getItem(i)
                val subMenu = mi.subMenu
                if (subMenu != null && subMenu.size() > 0) {
                    for (j in 0 until subMenu.size()) {
                        val subMenuItem = subMenu.getItem(j)
                        applyFontToMenuItem(subMenuItem)
                    }
                }
                applyFontToMenuItem(mi)
            }


            if (preferences?.all?.size == 0) {
                editor?.putString("date", "31-May-1990")
                editor?.putString("date1", "31-May-1990")
                editor?.apply()
            }
            val currunt_date = Calendar.getInstance().time
            val df = SimpleDateFormat("dd-MMM-yyyy")
            formattedDate = df.format(currunt_date)
//        exitdilog()
            fireBase = FirebaseAnalytics.getInstance(this@MainActivity)
            fireBase!!.setCurrentScreen(this@MainActivity, this.javaClass.simpleName, "load - mainActivity")
            nav_view.setNavigationItemSelectedListener(this@MainActivity)
            nav_view.setCheckedItem(R.id.citizen_calculator)
            val toggle: ActionBarDrawerToggle = object : ActionBarDrawerToggle(
                this@MainActivity,
                drawer_layout,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
            ) {

                override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                    super.onDrawerSlide(drawerView, slideOffset)
                    Utilty.hideSoftKeyboard(nav_view)
                }
            }
            drawer_layout.addDrawerListener(toggle)
            toggle.syncState()
            handlerGame.postDelayed(runnableGame, 1000)

            fragments_settings = 1
            val extras = intent.extras
            if (extras != null) {
                val value = extras.getInt("widget")
                is_widget = true
                if (value == 3) {
                    GotoFragment(value)
                }
            }

            lay_premium.setOnClickListener {
                SubscribeDilog()
            }

            lay_exit.setOnClickListener {
                exitProcess(0)
            }
        }
    }

    fun exitAdsLoads() {
        if (!isPrime() && isAdsLibsLoad()) {
            val ads = instances?.versionDao()?.getVersionData(EXIT_NATIVE, 1)
            if (ads != null) {
                val arraylist: ArrayList<String> = GstApp.context.builderAds(EXIT_NATIVE)
                nativeLoadingOnly(arraylist)
            }
            if (appOpenManager == null) appOpenManager = AppOpenManager()
        }
    }

    @JvmField
    var isFirstTimeLoads = false

    var listDetailsMain: ArrayList<ProductDetails> = ArrayList()

    fun isSkuAvailable(): Boolean {
        val skuListData = instances?.skuDao()?.getRoomSku()
        return !skuListData.isNullOrEmpty()
    }

    var isCalledMenu = true

    //todo inapp
    fun inAppDetail() {
        try {
            inApp =
                BillingClient.newBuilder(this).setListener(this).enablePendingPurchases().build()
            val skuListData = instances?.skuDao()?.getRoomSku()
            if (!skuListData.isNullOrEmpty()) {
                inApp?.startConnection(object : BillingClientStateListener {
                    override fun onBillingSetupFinished(billingResult: BillingResult) {
                        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                            listDetailsMain = ArrayList()
                            skuListData.forEach {
                                val productList = listOf(
                                    QueryProductDetailsParams.Product.newBuilder()
                                        .setProductId(it.sku)
                                        .setProductType(BillingClient.ProductType.SUBS).build()
                                )


                                val params = QueryProductDetailsParams.newBuilder()
                                    .setProductList(productList)

                                inApp?.queryProductDetailsAsync(params.build()) { billingResult1, productDetailsList ->
                                    if (billingResult1.responseCode == BillingClient.BillingResponseCode.OK) if (productDetailsList.size > 0) {
                                        listDetailsMain.addAll(productDetailsList)
                                        if (isCalledMenu && listDetailsMain.size > 1) {
                                            isCalledMenu = false
                                            CoroutineScope(Dispatchers.Main).launch {
                                                checkPurchaseDialog()
                                                if (fragment is GSTCalculator) (fragment as GSTCalculator).menuUpdate()
                                            }
                                        }
                                    }
                                }
                            }
                            inApp?.queryPurchaseHistoryAsync(
                                QueryPurchaseHistoryParams.newBuilder()
                                    .setProductType(BillingClient.ProductType.SUBS).build()
                            ) { billingResult1, purchaseHistoryRecord ->
                                if (billingResult1.responseCode == BillingClient.BillingResponseCode.OK) {
                                    purchaseHistoryRecord?.let { list ->
                                        if (list.size > 0) {
                                            list.sortByDescending { it.purchaseTime }
                                            verificationPurchase(
                                                JSONObject(list[0].originalJson).getString("productId"),
                                                list[0].purchaseToken
                                            )
                                        }
                                    }
                                }
                            }
                            /*CoroutineScope(Dispatchers.Main).launch {
                                if (!isPrime()) {
                                    if (idHomeInAppDialogId == "false") {
                                        idHomeInAppDialogId = "true"
                                    } else if (idHomeInAppDialogShow == "false" && idHomeInAppDialogId == "true") {
                                        idHomeInAppDialogShow = "true"
                                        SubscribeDilog()
                                    }
                                }
                            }*/

                        } else Log.e(
                            EVENT_SKU_DATA,
                            "***************************************** inAppDetail if else"
                        )
                    }

                    override fun onBillingServiceDisconnected() {

                    }
                })
            } else Log.e(
                EVENT_SKU_DATA, "***************************************** inAppDetail esle"
            )
        } catch (e: NullPointerException) {
            e.printStackTrace()
            Log.e("inAppDetail", "***************************************** ", e)
        } catch (e: ArrayIndexOutOfBoundsException) {

            e.printStackTrace()
            Log.e("inAppDetail", "***************************************** ", e)
        } catch (e: JsonSyntaxException) {

            e.printStackTrace()
            Log.e("inAppDetail", "***************************************** ", e)
        } catch (e: Exception) {

            e.printStackTrace()
            Log.e("inAppDetail", "***************************************** ", e)
        }
    }

    fun expireSeven() {
        expireSevenDialogs = Dialog(this)
        expireSevenDialogs!!.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs!!.window!!.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = expireSevenDialogs!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireSix() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs!!.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs!!.window!!.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = expireSevenDialogs!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_6)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireFive() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs!!.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs!!.window!!.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = expireSevenDialogs!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_5)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireFour() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs!!.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs!!.window!!.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = expireSevenDialogs!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_4)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireThree() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs!!.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs!!.window!!.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = expireSevenDialogs!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_3)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireTwo() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs!!.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs!!.window!!.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = expireSevenDialogs!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_2)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    fun expireOne() {

        expireSevenDialogs = Dialog(this)
        expireSevenDialogs!!.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        expireSevenDialogs!!.window!!.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = expireSevenDialogs!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )

        expireSevenDialogs!!.setCanceledOnTouchOutside(false)
        expireSevenDialogs!!.setCancelable(false)
        expireSevenDialogs!!.setContentView(R.layout.dialog_expire_seven)

        val layClose = expireSevenDialogs!!.findViewById<AppCompatButton>(R.id.layClose)
        val txtDesc = expireSevenDialogs!!.findViewById<AppCompatTextView>(R.id.txtDesc)

        txtDesc.text = getString(R.string.expire_desc_1)


        layClose.setOnClickListener {

            expireSevenDialogs?.dismiss()
        }

        expireSevenDialogs?.show()
    }

    protected fun UpdateDialog() {
        appUpdateManager = AppUpdateManagerFactory.create(this@MainActivity)
        val appUpdateInfoTask = appUpdateManager!!.appUpdateInfo
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo: AppUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(
                    AppUpdateType.FLEXIBLE
                )
            ) {
                try {
                    appUpdateManager!!.startUpdateFlowForResult(
                        appUpdateInfo, AppUpdateType.FLEXIBLE, this@MainActivity, MY_REQUEST_CODE
                    )
                } catch (e: SendIntentException) {
                    e.printStackTrace()
                }
            } else {
            }
        }
        listener = InstallStateUpdatedListener { installState: InstallState ->
            if (installState.installStatus() == InstallStatus.DOWNLOADED) {
                // After the update is downloaded, show a notification
                // and request user confirmation to restart the app.
                popupSnackbarForCompleteUpdate()
            }
        }
        appUpdateManager!!.registerListener(listener!!)
        editor!!.putString("update", CurrentDate)
        editor!!.putInt("updateVer", BuildConfig.VERSION_CODE)
        editor!!.commit()
    }

    private fun popupSnackbarForCompleteUpdate() {
        val snackbar = Snackbar.make(
            findViewById(R.id.layout_main),
            "An update has just been downloaded.",
            Snackbar.LENGTH_INDEFINITE
        )
        snackbar.setAction(
            "RESTART"
        ) { view: View? -> appUpdateManager!!.completeUpdate() }
        snackbar.setActionTextColor(
            resources.getColor(R.color.colorPrimary)
        )
        snackbar.show()
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MY_REQUEST_CODE) {
            if (resultCode != RESULT_OK) {
            }
        }
    }

    private fun setAlaramDuration(days: Long, Req_code: Int, period: Int) {
        val intent = Intent(this@MainActivity, AlarmReceiver::class.java)
        intent.putExtra("requestCode", "Month")
        val sender = PendingIntent.getBroadcast(
            this, Req_code, intent, PendingIntent.FLAG_UPDATE_CURRENT
        )
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (TimeUnit.DAYS.toMillis(days) - period == 0L) {
            am.set(AlarmManager.RTC_WAKEUP, 1000, sender)
        }
        v?.img_app?.visibility = View.GONE
        v?.gift_layout?.visibility = View.GONE
        v?.AdText?.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return if (keyCode == KeyEvent.KEYCODE_BACK) {
            if ((fragment is GSTCalculator) && (fragment as GSTCalculator).isLoadingAds) {
                return true
            } else if (exitFullLoading.visibility == View.VISIBLE) {
                return true
            } else if (drawer_layout!!.isDrawerOpen(GravityCompat.START)) {
                drawer_layout!!.closeDrawer(GravityCompat.START)
            } else if (isNetworkAvailable(this@MainActivity) && isAdsLibsLoad()) {
                if (!isPrime()) {
                    if (fragments_settings != 1) {
                        doubleBackToExitPressedOnce = false
                        fragment = GSTCalculator()
                        GotoFragment(0)
                        nav_view.menu.getItem(0).isChecked = true
                        updateMenuItem()
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.frame_layout, fragment!!).commit()
                        fragments_settings = 1
//                        return
                    } else {
                        if (exitnative != null || exitAdView != null) {
                            showExitDialog()
                        } else {
                            if (doubleBackToExitPressedOnce) {
                                exitProcess(0)
                            }
                            if (!doubleBackToExitPressedOnce) {
                                doubleBackToExitPressedOnce = true
                                Toast.makeText(
                                    this@MainActivity, "Tap Again To Exit App.", Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                } else {
                    if (fragments_settings != 1) {
                        doubleBackToExitPressedOnce = false
                        fragment = GSTCalculator()
                        GotoFragment(0)
                        nav_view.menu.getItem(0).isChecked = true
                        updateMenuItem()
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.frame_layout, fragment!!).commit()
                        fragments_settings = 1
//                        return
                    } else if (fragments_settings == 1) {
                        if (doubleBackToExitPressedOnce) {
                            exitProcess(0)
                        }
                        if (!doubleBackToExitPressedOnce) {
                            doubleBackToExitPressedOnce = true
                            Toast.makeText(
                                this@MainActivity, "Tap Again To Exit App.", Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } else {
                if (fragments_settings != 1) {
                    doubleBackToExitPressedOnce = false
                    fragment = GSTCalculator()
                    GotoFragment(0)
                    nav_view.menu.getItem(0).isChecked = true
                    updateMenuItem()
                    supportFragmentManager.beginTransaction().replace(R.id.frame_layout, fragment!!)
                        .commit()
                    fragments_settings = 1
//                    return
                } else {
                    if (doubleBackToExitPressedOnce) {
                        exitProcess(0)
                    }
                    if (!doubleBackToExitPressedOnce) {
                        doubleBackToExitPressedOnce = true
                        Toast.makeText(
                            this@MainActivity, "Tap Again To Exit App", Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }

            true
        } else super.onKeyDown(keyCode, event)
    }


    /*override fun onBackPressed() {

        if (drawer_layout!!.isDrawerOpen(GravityCompat.START)) {
            drawer_layout!!.closeDrawer(GravityCompat.START)
            return
        }


    }*/

    private fun updateMenuItem() {

        if (isNetworkAvailable(this@MainActivity) && isAdsLibsLoad()) {
            if (isPrime()) {
                hideItem()
//                v?.btn_playgame?.visibility = View.GONE
//                v?.txt_game?.visibility = View.GONE
                v?.AdText?.visibility = View.GONE

            } else {

                showItem()
                if (isGameLoad()) {
//                    v?.btn_playgame?.visibility = View.VISIBLE
//                    v?.txt_game?.visibility = View.VISIBLE
                    v?.AdText?.visibility = View.VISIBLE

                } else {

//                    v?.btn_playgame?.visibility = View.GONE
//                    v?.txt_game?.visibility = View.GONE
                    v?.AdText?.visibility = View.GONE
                    nav_view.menu.getItem(7).subMenu?.getItem(3)?.isVisible = false

                }
            }
        } else {

//            v?.btn_playgame?.visibility = View.GONE
//            v?.txt_game?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE

        }
    }


    private fun DoubleBackExit() {
        if (doubleBack) {
            finish()
        } else {
            doubleBack = true
            Toast.makeText(this@MainActivity, "Press Back Again To Exit", Toast.LENGTH_SHORT).show()
            handler_back.postDelayed(runnable_back, 2000)
        }
    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val bundle = Bundle()
        val id = item.itemId
        bundle.putInt("Navigation_Id", id)
        var name = "test"
        Utilty.hideSoftKeyboard(nav_view)
        if (id == R.id.citizen_calculator) {
            name = "Citigen_Fragment"
            fragments_settings = 1
            flag = 0
            GotoFragment(0)
            updateMenuItem()
        } else if (id == R.id.loan_calculator) {
            name = "Loan_Fragment"
            fragments_settings = 2
            flag = 1
            GotoFragment(1)
        } else if (id == R.id.nav_manage) {
            name = "Settings_Fragment"
            fragments_settings = 3
            GotoFragment(2)
        } else if (id == R.id.currency_calculator) {
            fragments_settings = 4
            GotoFragment(3)
        } else if (id == R.id.nav_Play_game) {
            try {
                if (GAME_PAGE_URL != "") RedirectToPage(this@MainActivity)
            } catch (e: ActivityNotFoundException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else if (id == R.id.nav_share) {
            val s1 = ("http://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}")
            //dialog1.dismiss();
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(Intent.EXTRA_TEXT, s1)
            sendIntent.type = "text/plain"
            startActivity(sendIntent)
        } else if (id == R.id.nav_rate) {
            showRateIn()
        } else if (id == R.id.intrest_calculator) {
            fragments_settings = 5
            GotoFragment(4)
        } else if (id == R.id.ad_count_down) {
            val intent = Intent(this, ChangeViewActivity::class.java)
            startActivity(intent)
        } else if (id == R.id.Sub_Scription) {
            if (isNetworkAvailable(this)) {
                SubscribeDilog()
            } else Toast.makeText(this, "Check Internet Connection", Toast.LENGTH_SHORT).show()
        } else if (id == R.id.age_calculator) {
            fragments_settings = 6
            GotoFragment(5)
        } else if (id == R.id.world_clock) {
            fragments_settings = 7
            GotoFragment(6)
        } else if (id == R.id.cash_counter) {
            fragments_settings = 8
            GotoFragment(7)
        } else if (id == R.id.manage_Subscription) {
            val intent = Intent(this, ManageSubscriptionActivity::class.java)
            startActivity(intent)
        }
        fireBase!!.logEvent(name, bundle)
        drawer_layout!!.closeDrawer(GravityCompat.START)
        return true
    }


    fun GotoFragment(position: Int) {


        if (!isNetworkAvailable(this@MainActivity)) {
//            v?.btn_playgame?.visibility = View.GONE
//            v?.txt_game?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE

            nav_view.menu.getItem(7).subMenu?.getItem(1)?.isVisible = false
            nav_view.menu.getItem(7).subMenu?.getItem(2)?.isVisible = false
            nav_view.menu.getItem(7).subMenu?.getItem(3)?.isVisible = false
        } else {

            if (isAdsLibsLoad()) {
                if (isPrime()) {
//                    v?.btn_playgame?.visibility = View.GONE
//                    v?.txt_game?.visibility = View.GONE
                    v?.AdText?.visibility = View.GONE
                    nav_view.menu.getItem(7).subMenu?.getItem(1)?.isVisible = false
                    nav_view.menu.getItem(7).subMenu?.getItem(2)?.isVisible = false
                    nav_view.menu.getItem(7).subMenu?.getItem(3)?.isVisible = false
                } else {

//                    v?.btn_playgame?.visibility = View.VISIBLE
//                    v?.txt_game?.visibility = View.VISIBLE
                    v?.AdText?.visibility = View.VISIBLE
                    nav_view.menu.getItem(7).subMenu?.getItem(1)?.isVisible = true
                    nav_view.menu.getItem(7).subMenu?.getItem(2)?.isVisible = true
                    nav_view.menu.getItem(7).subMenu?.getItem(3)?.isVisible = true
                }
            } else {

//                v?.btn_playgame?.visibility = View.GONE
//                v?.txt_game?.visibility = View.GONE
                v?.AdText?.visibility = View.GONE

                nav_view.menu.getItem(7).subMenu?.getItem(1)?.isVisible = false
                nav_view.menu.getItem(7).subMenu?.getItem(2)?.isVisible = false
                nav_view.menu.getItem(7).subMenu?.getItem(3)?.isVisible = false
            }
        }

        fragment = null
        var fc: Class<*>? = null
        //String title = "";
        if (position == 0) {
            ActionBarTitle!!.text = "Calculator"

            if (isNetworkAvailable(this@MainActivity) && isAdsLibsLoad()) {
                Log.e("TAG", "GotoFragment: -------1")
                if (!isPrime()) {
                    Log.e("TAG", "GotoFragment: -------2")

                    v?.img_app?.visibility = View.VISIBLE
                    v?.AdText?.visibility = View.VISIBLE
                } else {
                    Log.e("TAG", "GotoFragment: -------3")

                    v?.img_app?.visibility = View.GONE
                    v?.AdText?.visibility = View.GONE
                }
            } else {
                Log.e("TAG", "GotoFragment: -------4")

                //v?.gift_layout?.visibility = View.GONE
                v?.img_app?.visibility = View.GONE
                v?.AdText?.visibility = View.GONE
            }
            reset?.visibility = View.GONE
            removeAll?.visibility = View.GONE
            fc = GSTCalculator::class.java
            fragment = GSTCalculator()


            /*  if (Utilty.isNetworkAvailable(this@MainActivity)) {
                  if (isGameLoad()) v?.btn_playgame?.visibility =
                      View.VISIBLE else v?.btn_playgame?.visibility = View.GONE
                  if (isGameLoad()) v?.txt_game?.visibility =
                      View.VISIBLE else v?.txt_game?.visibility = View.GONE
              }*/


            // title = "Citizen Calculator";
        } else if (position == 1) {
            ActionBarTitle!!.text = "Loan Calculator"
            //v?.gift_layout?.visibility = View.GONE
            v?.img_app?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
            reset?.visibility = View.GONE
            removeAll?.visibility = View.GONE
            fc = LoanCalculator::class.java
            fragment = GSTCalculator()/*if (Utilty.isNetworkAvailable(this@MainActivity)) {
                if (isGameLoad()) v?.btn_playgame?.visibility =
                    View.VISIBLE else v?.btn_playgame?.visibility = View.GONE
                if (isGameLoad()) v?.txt_game?.visibility =
                    View.VISIBLE else v?.txt_game?.visibility = View.GONE
            }*/
            //  title = "Loan Calculator";
        } else if (position == 2) {
            //v?.gift_layout?.visibility = View.GONE
            v?.img_app?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
            reset?.visibility = View.GONE
            removeAll?.visibility = View.GONE
            ActionBarTitle!!.text = "Settings"
            fc = Settings::class.java
            fragment = Settings()/*if (Utilty.isNetworkAvailable(this@MainActivity)) {
                if (isGameLoad()) v?.btn_playgame?.visibility =
                    View.VISIBLE else v?.btn_playgame?.visibility = View.GONE
                if (isGameLoad()) v?.txt_game?.visibility =
                    View.VISIBLE else v?.txt_game?.visibility = View.GONE
            }*/
            // title = "Settings";
        } else if (position == 3) {
            // v?.gift_layout?.visibility = View.GONE
            v?.img_app?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
            reset?.visibility = View.GONE
            removeAll?.visibility = View.GONE
            ActionBarTitle!!.text = "Currency Converter"
            fc = CurrencyConverter::class.java
            fragment = CurrencyConverter()/*if (Utilty.isNetworkAvailable(this@MainActivity)) {
                if (isGameLoad()) v?.btn_playgame?.visibility =
                    View.VISIBLE else v?.btn_playgame?.visibility = View.GONE
                if (isGameLoad()) v?.txt_game?.visibility =
                    View.VISIBLE else v?.txt_game?.visibility = View.GONE
            }*/
        } else if (position == 4) {
            // v?.gift_layout?.visibility = View.GONE
            v?.img_app?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
            reset?.visibility = View.GONE
            removeAll?.visibility = View.GONE
            ActionBarTitle!!.text = "Interest Calculator"
            fc = IntrestCalculator::class.java
            fragment = IntrestCalculator()/*if (Utilty.isNetworkAvailable(this@MainActivity)) {
                if (isGameLoad()) v?.btn_playgame?.visibility =
                    View.VISIBLE else v?.btn_playgame?.visibility = View.GONE
                if (isGameLoad()) v?.txt_game?.visibility =
                    View.VISIBLE else v?.txt_game?.visibility = View.GONE
            }*/
        } else if (position == 5) {
            //v?.gift_layout?.visibility = View.GONE
            v?.img_app?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
            reset?.visibility = View.GONE
            removeAll?.visibility = View.GONE
            ActionBarTitle!!.text = "Age Calculator"
            fc = AgeCalculator::class.java
            fragment = AgeCalculator()/*if (Utilty.isNetworkAvailable(this@MainActivity)) {
                if (isGameLoad()) v?.btn_playgame?.visibility =
                    View.VISIBLE else v?.btn_playgame?.visibility = View.GONE
                if (isGameLoad()) v?.txt_game?.visibility =
                    View.VISIBLE else v?.txt_game?.visibility = View.GONE
            }*/
        } else if (position == 6) {
            //v?.gift_layout?.visibility = View.GONE
            v?.img_app?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
            reset?.visibility = View.GONE
            removeAll?.visibility = View.GONE
            ActionBarTitle!!.text = "World Clock"
            fc = WorldClock::class.java
            fragment = WorldClock()
        } else if (position == 7) {
            //v?.gift_layout?.visibility = View.GONE
            v?.img_app?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
//            v?.btn_playgame?.visibility = View.GONE
//            v?.txt_game?.visibility = View.GONE
            reset?.visibility = View.VISIBLE
            removeAll?.visibility = View.GONE
            ActionBarTitle!!.text = "Money Cash Counter"
            fc = CashCounter::class.java
            fragment = CashCounter()
        }
        try {
            fragment = fc!!.newInstance() as Fragment
            if (fragment != null) {
                supportFragmentManager.beginTransaction().setCustomAnimations(
                    R.anim.enter_from_left,
                    R.anim.exit_to_right,
                    R.anim.enter_from_right,
                    R.anim.exit_to_left
                ).replace(R.id.frame_layout, fragment!!).addToBackStack(null).commit()
            }
            //   }
        } catch (e: InstantiationException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    //todo inapp
    @SuppressLint("SetTextI18n")
    fun SubscribeDilog() {
        if (this.isFinishing) return
        val dialog_subscribe = Dialog(this)
        dialog_subscribe.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog_subscribe.setContentView(R.layout.dailog_inapp_dynamic)
        dialog_subscribe.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog_subscribe.setCanceledOnTouchOutside(false)
//        dialog_subscribe.setCancelable(false)

        dialog_subscribe.btnPurchase?.setOnClickListener {
            productDetailsMain?.let { ip ->
                val productDetails: ProductDetails = ip
                val offerToken = productDetails.subscriptionOfferDetails?.get(0)?.offerToken
                val productDetailsParamsList = listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(productDetails).setOfferToken(offerToken ?: "").build()
                )

                val billingFlowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(productDetailsParamsList).build()

                inApp?.launchBillingFlow(this, billingFlowParams)
            }
        }

        val skuListData = instances?.skuDao()?.getRoomSku()
        if (skuListData != null) {
//            getSkuPrice(dialog_subscribe)
            dialog_subscribe.skuRecv?.layoutManager =
                LinearLayoutManager(this, RecyclerView.VERTICAL, false)
            if (listDetailsMain.size > 0) {
                dialog_subscribe.btnPurchase?.visibility = View.VISIBLE
                adapter = SkuAdapter(listDetailsMain, skuListData) { ip ->
                    updateButton(ip, dialog_subscribe)
                }
                dialog_subscribe.skuRecv?.adapter = adapter
                adapter?.let { itAdapter ->
                    listDetailsMain.forEach { ip ->
                        try {
                            if (itAdapter.hashMap.containsKey(ip.productId) && itAdapter.hashMap[ip.productId] == true) {
                                updateButton(ip, dialog_subscribe)
                            }
                        } catch (e: NullPointerException) {
                        }

                    }
                }
            }
        }
        dialog_subscribe.close_btn?.setOnClickListener { v: View? ->
            dialog_subscribe.dismiss()
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val displayMetrics = DisplayMetrics()
        display.getMetrics(displayMetrics)
        val win: Window = dialog_subscribe.window!!
        win.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog_subscribe.show()
    }

//    var listProductDetails: ArrayList<ProductDetails> = ArrayList()
//    private fun getSkuPrice(dialog_subscribe:Dialog) {
//        fetchPrice(sku) {
//            it?.let { productDetails ->
//                listProductDetails.add(productDetails)
//                if (count == listProductDetails.size) {
//
//                } else {
//                    count++
//                    getSkuPrice()
//                }
//            }
//        }
//    }

    var skuCount = 0
    var productDetailsMain: ProductDetails? = null
    private fun updateButton(productDetails: ProductDetails, dialog_subscribe: Dialog) {
        productDetailsMain = productDetails/*
                adapter?.let { itAdapter ->
                    itAdapter.temSkuList.forEach {
                        if (itAdapter.hashMap.containsKey(it.sku) && itAdapter.hashMap[it.sku] == true) {
                            try {
                                listDetailsMain.forEach { ip ->
                                    if (ip.productId == it.sku) {
                                        Log.e("temSkuList","******************************************* ${it.sku} ")
                                        if (ip.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.get(
                                                0
                                            )?.formattedPrice == "Free"
                                        ) {
                                            dialog_subscribe?.freeTrialData?.text = "${
                                                ip.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.get(
                                                    0
                                                )?.billingPeriod?.substring(
                                                    1,
                                                    2
                                                )
                                            } Days Free Trial Then ${
                                                ip.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.get(
                                                    1
                                                )
                                                    ?.formattedPrice
                                            } ${if (it.title.contains("Month")) "/ Month" else "/ Year"}"
                                            dialog_subscribe?.freeTrialData?.visibility =
                                                View.VISIBLE
                                            dialog_subscribe?.btnPurchase?.text =
                                                "Try Free Trial"
                                        } else {
                                            dialog_subscribe?.freeTrialData?.text = ""
                                            dialog_subscribe?.btnPurchase?.text =
                                                "Start Subscription"
                                        }

                                        ip.subscriptionOfferDetails?.forEach { subscriptionOfferDetails ->
        //                                    subscriptionOfferDetails?.pricingPhases?.pricingPhaseList?.forEach { pricingPhases ->
        //                                    }
                                        }
                                    }
                                }

                            } catch (_: Exception) {
                            }
                        }
                    }

                }
        */


        if (productDetails.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.get(
                0
            )?.formattedPrice == "Free"
        ) {
            dialog_subscribe?.freeTrialData?.text = "${
                productDetails.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.get(
                    0
                )?.billingPeriod?.substring(
                    1, 2
                )
            } Days Free Trial Then ${
                productDetails.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.get(
                    1
                )?.formattedPrice
            } ${if (productDetails.title.contains("Month")) "/ Month" else "/ Year"}"
            dialog_subscribe?.freeTrialData?.visibility = View.VISIBLE
            dialog_subscribe?.btnPurchase?.text = "Try Free Trial"
        } else {
            dialog_subscribe?.freeTrialData?.visibility = View.INVISIBLE
            dialog_subscribe?.btnPurchase?.text = "Start Subscription"
        }


    }


    fun exitdilog() {
        dilog = Dialog(this)
        dilog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dilog?.setContentView(R.layout.dialog_select)
        dilog?.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dilog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        //  dilog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        dilog!!.setCanceledOnTouchOutside(false)
        dilog!!.setCancelable(false)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val displayMetrics = DisplayMetrics()
        display.getMetrics(displayMetrics)
        val width = displayMetrics.widthPixels * .9
        val hieght = displayMetrics.heightPixels * 1.3
        val win = dilog!!.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        // dilog.show();
    }

    var exitnative: NativeAd? = null
    var exitAdView: AdView? = null


    private fun nativeLoadingOnly(ads: ArrayList<String>) {
        when (ads[0]) {
            GOOGLE_INLINE_ADAPTIVE_BANNER -> {
                nativeBannerInlineAdaptiveAds(ads[1]) {
                    exitAdView = it
                }
            }

            GOOGLE -> {
                AdLoader.Builder(
                    this, ads[1]
                ).forNativeAd { nativeAd ->
                    if (!this.isFinishing) {
                        this.exitnative = nativeAd
                    }
                }.withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        super.onAdFailedToLoad(loadAdError)
                        nativeLoadingOnly(GstApp.context.adsFailToLoads(EXIT_NATIVE))
                    }

                }).build().loadAd(AdRequest.Builder().build())
            }

            CUSTOM -> {}
        }
    }

    var bottomSheetDialog: BottomSheetDialog? = null

    private fun showExitDialog() {

        if (bottomSheetDialog == null) {
            bottomSheetDialog = BottomSheetDialog(this@MainActivity)
        }


        if (bottomSheetDialog?.isShowing == false) {
            bottomSheetDialog?.setCanceledOnTouchOutside(true)
            val parentView: View =
                LayoutInflater.from(this@MainActivity).inflate(R.layout.ly_exit, null)
            bottomSheetDialog?.setContentView(parentView)
            val nativeAds = parentView.findViewById<LinearLayout>(R.id.nativeAd)
//            val btnCancel = parentView.findViewById<AppCompatImageView>(R.id.closeAds)
            ShowExitNative(nativeAds)


//            btnCancel.setOnClickListener {
//                bottomSheetDialog?.dismiss()
//            }

            bottomSheetDialog?.setOnCancelListener {
                bottomSheetDialog?.dismiss()
            }

            bottomSheetDialog?.setOnKeyListener { _, keyCode, _ ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    bottomSheetDialog?.dismiss()
                    exitProcess(0)
                    true
                } else false
            }
            (parentView.findViewById(R.id.actionTapToExit) as AppCompatButton).setOnClickListener {
                bottomSheetDialog?.dismiss()
                exitProcess(0)
            }
            if (isGameLoad()) {
                (parentView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.VISIBLE
                (parentView.findViewById(R.id.ivGame) as RelativeLayout).setOnClickListener {
                    if (GAME_PAGE_URL != "") RedirectToPage(this@MainActivity)
                }
                setAlphaAnimation(parentView.findViewById(R.id.ivGame))
            } else {
                (parentView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.GONE
            }

            bottomSheetDialog?.show()
        }
    }

    fun setAlphaAnimation(v: View) {
        val scaleDownX = ObjectAnimator.ofFloat(v, "scaleX", 0.8f)
        val scaleDownY = ObjectAnimator.ofFloat(v, "scaleY", 0.8f)
        scaleDownX.duration = 1000
        scaleDownY.duration = 1000

        val scaleUpX = ObjectAnimator.ofFloat(v, "scaleX", 1f)
        val scaleUpY = ObjectAnimator.ofFloat(v, "scaleY", 1f)
        scaleUpX.duration = 1000
        scaleUpY.duration = 1000

        /*val fadeIn = ObjectAnimator.ofFloat(v, "alpha", 0.3f, 1f)
        fadeIn.duration = 500

        val fadeOut = ObjectAnimator.ofFloat(v, "alpha", 1f, 0.3f)
        fadeOut.duration = 500*/

        val zoomInZoomOut = AnimatorSet()

        zoomInZoomOut.play(scaleUpX).with(scaleUpY).after(scaleDownX).after(scaleDownY)
        zoomInZoomOut.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                super.onAnimationEnd(animation)
                zoomInZoomOut.start()
            }
        })
        zoomInZoomOut.start()
    }


    private fun ShowExitNative(layout: LinearLayout) {
        if (exitnative != null) {
            setexitNativeAdView(exitnative!!, layout)
            nativeLoadingOnly(GstApp.context.builderAds(EXIT_NATIVE))

        } else if (exitAdView != null) {
            val adViewParent = exitAdView?.parent as? ViewGroup
            adViewParent?.removeView(exitAdView)
            layout.removeAllViews()
            layout.addView(exitAdView)
        } else {
            setCustomExitNativeAdView(layout)
        }
    }

    private fun setexitNativeAdView(nativeAd: NativeAd, layout: LinearLayout) {

        val adView = layoutInflater.inflate(R.layout.ads_native, null) as NativeAdView
        val vc = nativeAd.mediaContent
        vc?.videoController?.videoLifecycleCallbacks =
            object : VideoController.VideoLifecycleCallbacks() {}
        val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
        adView.mediaView = mediaView
        try {
            adView.bodyView = adView.findViewById(R.id.ad_body)
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_app_icon)
            (adView.headlineView as TextView).text = nativeAd.headline
            (adView.bodyView as TextView).text = nativeAd.body
            (adView.callToActionView as AppCompatButton).text = nativeAd.callToAction

            if (nativeAd.icon == null) {
                adView.iconView?.visibility = View.GONE
            } else {
                (adView.iconView as ImageView).setImageDrawable(nativeAd.icon?.drawable)
                adView.iconView?.visibility = View.VISIBLE
            }
            adView.setNativeAd(nativeAd)
            layout.removeAllViews()
            layout.addView(adView)
        } catch (e: Exception) {
        }
    }

    private fun setCustomExitNativeAdView(layout: LinearLayout) {


        if (instances == null) {
            instances = RoomDatabaseGst.getInstance(this)
        }

        mLoadingData(this@MainActivity)?.let {

            val dataone: RoomAdvertisement = it

            val inflater =
                layout.context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val adView = inflater.inflate(R.layout.ads_custom_native, null)

            /*if (isGameLoad()) {
                (adView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.VISIBLE
                (adView.findViewById(R.id.ivGame) as RelativeLayout).setOnClickListener {
                    if (GAME_PAGE_URL != "") RedirectToPage(this@MainActivity)
                }
            } else {
                (adView.findViewById(R.id.ivGame) as RelativeLayout).visibility = View.GONE

            }*/

            (adView.findViewById<View>(R.id.ad_headline) as TextView).text = dataone.ADDTITLE
            (adView.findViewById<View>(R.id.ad_headline) as TextView).setTextColor(
                Color.parseColor(
                    "#000000"
                )
            )
            (adView.findViewById<View>(R.id.ad_headline) as TextView).isSelected = true
            (adView.findViewById<View>(R.id.ad_body) as TextView).text = dataone.ADDDESCD
            (adView.findViewById<View>(R.id.ad_body) as TextView).setTextColor(
                Color.parseColor("#000000")
            )
            val calltoAction = adView.findViewById<AppCompatButton>(R.id.ad_call_to_action)
            calltoAction.text = "INSTALL"

            calltoAction.setOnClickListener { view: View? ->
                startActivity(
                    Intent(
                        "android.intent.action.VIEW", Uri.parse(dataone.INSTALL)
                    )
                )
            }

            /*val btnExit = adView.findViewById<AppCompatTextView>(R.id.ad_btn_exit)
            btnExit.setOnClickListener {
                exitProcess(0)
                finishAffinity()
            }*/

            if (dataone.ICON == null) {
                (adView.findViewById<View>(R.id.ad_app_icon) as AppCompatImageView).visibility =
                    View.GONE
            } else {
                Glide.with(this@MainActivity).load(CUSTOM_DOMAIN + dataone.ICON)
                    .into(adView.findViewById<View>(R.id.ad_app_icon) as AppCompatImageView)
            }


            if (dataone.BANNER == null) {
                (adView.findViewById<View>(R.id.ad_media) as ImageView).visibility = View.GONE
            } else {
                Glide.with(this@MainActivity).load(CUSTOM_DOMAIN + dataone.BANNER)
                    .into(adView.findViewById<View>(R.id.ad_media) as ImageView)

            }

            layout.removeAllViews()
            layout.background = null
            layout.addView(adView)
            layout.bringToFront()
            layout.invalidate()
        }

    }


    private fun setfragment_sub() {
        if (isNetworkAvailable(this@MainActivity) && databaseGst.getResponse(Utilty.IS_ADFREE) != "YES") {
            v?.img_app?.visibility = View.VISIBLE
            //v?.gift_layout?.visibility = View.VISIBLE
            v?.AdText?.visibility = View.VISIBLE
        } else {
            v?.img_app?.visibility = View.GONE
            //v?.gift_layout?.visibility = View.GONE
            v?.AdText?.visibility = View.GONE
//            v?.btn_playgame?.visibility = View.GONE
//            v?.txt_game?.visibility = View.GONE
        }
        if (fragments_settings == 1) {
            GotoFragment(0)
            updateMenuItem()

        } else if (fragments_settings == 2) {
            GotoFragment(1)
        } else if (fragments_settings == 3) {
            GotoFragment(2)
        } else if (fragments_settings == 4) {
            GotoFragment(3)
        } else {
            GotoFragment(0)
            updateMenuItem()

        }
    }

    private fun hideItem() {
        val nav_Menu = nav_view!!.menu
        nav_Menu.findItem(R.id.ad_count_down).isVisible = false
    }

    private fun showItem() {
        val nav_Menu = nav_view!!.menu
        if (!nav_Menu.findItem(R.id.ad_count_down).isVisible) nav_Menu.findItem(R.id.ad_count_down).isVisible =
            true
    }


    private fun applyFontToMenuItem(mi: MenuItem) {
        val font = Typeface.createFromAsset(assets, "fonts/Sansation_Bold.ttf")
        val mNewTitle = SpannableString(mi.title)
        mNewTitle.setSpan(
            CustomTypefaceSpan("", font), 0, mNewTitle.length, Spannable.SPAN_INCLUSIVE_INCLUSIVE
        )
        mi.title = mNewTitle
    }


    fun GiftDialog() {
        val dialog = Dialog(this@MainActivity)
        dialog.setContentView(R.layout.dialog_gift)
        dialog.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.window!!.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(true)
        val myImageView = dialog.findViewById<ImageView>(R.id.close)
        val mClose = dialog.findViewById<RelativeLayout>(R.id.close_ad)
        mClose.setOnClickListener { view: View? ->
            myImageView.clearAnimation()
            dialog.dismiss()
        }
        val rotate = RotateAnimation(
            0F, 360F, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
        )
        rotate.duration = 2000
        rotate.repeatCount = Animation.INFINITE
        myImageView.setOnClickListener { v: View? ->
            myImageView.startAnimation(rotate)
            Handler().postDelayed({ DialogValidation(dialog, myImageView) }, 1000)
        }
        DialogValidation(dialog, myImageView)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = dialog.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        // dialog.show();
    }

    var isShuffle = false

    fun DialogValidation(dialog: Dialog, imageViewRe: ImageView) {
        if (isNetworkAvailable(this@MainActivity)) {
            try {
                //val s = QUERY_CONNECTION.mRetriveSettings(realm, DataBase_Constant.DATA_CUSTOM_ADS)
                val s = instances?.roomConnectionDao()
                    ?.getRoomConnection(DataBase_Constant.DATA_CUSTOM_ADS)
                if (s != null && !s.equals("")) {
                    if (Utilty.arrayListAds.size > 0 && Utilty.arrayListAds != null) {
                        Collections.shuffle(Utilty.arrayListAds)
                        val pos = AdsInit.getApk(this@MainActivity, Utilty.arrayListAds)
                        val data = Utilty.arrayListAds[pos]
                        if (pos != -1) {
                            val imageView = dialog.findViewById<ImageView>(R.id.ads_img)
                            val icon = dialog.findViewById<ImageView>(R.id.icon)
                            val textView = dialog.findViewById<TextView>(R.id.txt_title)
                            val txt_content = dialog.findViewById<TextView>(R.id.txt_content)
                            textView.text = data.title
                            txt_content.text = data.desc
                            val button = dialog.findViewById<Button>(R.id.btn_ads_install)
                            val mDrawable = ContextCompat.getDrawable(this, R.drawable.btn_ad)
                            mDrawable!!.colorFilter = PorterDuffColorFilter(
                                Color.parseColor(if (data.color == "null") "#444bb6" else data.color),
                                PorterDuff.Mode.MULTIPLY
                            )
                            button.background = mDrawable
                            Glide.with(this@MainActivity).load(data.banner).apply(
                                RequestOptions().placeholder(R.drawable.ic_launcher_foreground)
                                    .diskCacheStrategy(DiskCacheStrategy.ALL).skipMemoryCache(true)
                            ).listener(object : RequestListener<Drawable?> {
                                override fun onLoadFailed(
                                    e: GlideException?,
                                    model: Any,
                                    target: Target<Drawable?>,
                                    isFirstResource: Boolean
                                ): Boolean {
                                    return false
                                }

                                override fun onResourceReady(
                                    resource: Drawable?,
                                    model: Any,
                                    target: Target<Drawable?>,
                                    dataSource: DataSource,
                                    isFirstResource: Boolean
                                ): Boolean {
                                    imageViewRe.clearAnimation()
                                    return false
                                }
                            }).into(imageView)
                            Glide.with(this@MainActivity).load(data.icon).apply(
                                RequestOptions().placeholder(R.drawable.ic_launcher_foreground)
                                    .diskCacheStrategy(DiskCacheStrategy.ALL).skipMemoryCache(true)
                            ).into(icon)
                            button.setOnClickListener { v: View? ->

                                //  GstApp.appInstance.getJobManager().addJobInBackground();
                                /*GstApp.appInstance.jobManager
                                    .addJobInBackground(CustomAdCountJob(data.cadid))*/
                                // new CustomAdsCountSync().execute(data.getCadid());
                                val intent = Intent("android.intent.action.VIEW")
                                intent.data = Uri.parse(data.install)
                                startActivity(intent)
                                dialog.dismiss()
                            }
                            dialog.findViewById<View>(R.id.txt_title)
                                .setOnClickListener { v: View? ->
                                    val intent = Intent("android.intent.action.VIEW")
                                    intent.data = Uri.parse(data.install)
                                    startActivity(intent)
                                    dialog.dismiss()
                                }
                            dialog.findViewById<View>(R.id.ads_img).setOnClickListener { v: View? ->
                                val intent = Intent("android.intent.action.VIEW")
                                intent.data = Uri.parse(data.install)
                                startActivity(intent)
                                dialog.dismiss()
                            }
                            dialog.show()
                        } else {
                            Toast.makeText(
                                this@MainActivity, "No Gift Data Found", Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } catch (e: NullPointerException) {
                e.printStackTrace()
            } catch (e: ArrayIndexOutOfBoundsException) {
                e.printStackTrace()
            } catch (e: JsonSyntaxException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


    fun AdCloseExitIntent() {
        exitFullLoading.visibility = View.GONE
        drawer_layout!!.visibility = View.INVISIBLE
        exit_layout!!.visibility = View.VISIBLE
        doubleBackToExitPressedOnce = true
    }


    fun mRateUseDialog() {
        val dialog = Dialog(this@MainActivity)
        dialog.setContentView(R.layout.dialog_rate_us)
        dialog.window!!.setBackgroundDrawableResource(R.color.dialogbg)
        dialog.window!!.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)
        dialog.findViewById<View>(R.id.btn_no_thanks).setOnClickListener { view: View? ->
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.btn_yes).setOnClickListener { view: View? ->
            idInAppRated = "true"
            showRateIn()
            dialog.dismiss()
        }

        /*  AppCompatRatingBar rating = dialog.findViewById(R.id.rating);
           rating.setOnRatingBarChangeListener((ratingBar, v, b) -> mRateValue = ratingBar.getRating());*/
        val wm = getSystemService(
            WINDOW_SERVICE
        ) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val win = dialog.window
        win!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.show()
    }


    var dialogCustomShowSelection: Dialog? = null

    fun CustomAdsIntertesial() {
        try {
            if (Utilty.arrayListAds != null && Utilty.arrayListAds.size > 0) {
                Utilty.adsInit.AdsRequest(this, true, Utilty.arrayListAds, object : AdsLoaded {
                    override fun onLoaded(arrayList: ArrayList<String>, i: Int) {
                        val data = Utilty.arrayListAds[i]
                        val url = data.design_page
                        if (url != null) {
                            val sdCard = filesDir.toString()
                            val mLocationDir = File(sdCard, CustomAdsUtil.ASSERT_LOCATION)
                            val fileName = mLocationDir.toString() + File.separator + url.substring(
                                url.lastIndexOf('/') + 1
                            )
                            if (File(fileName).exists()) {
                                Utilty.adsInit.InterstitialCustomAds(this@MainActivity,
                                    data,
                                    object : InterstitialCustom {
                                        override fun onInterstitialCustomClose() {
                                            AdCloseExitIntent()
                                        }

                                        override fun onInterstitialCustomLoaded(dialog: Dialog) {
                                            dialogCustomShowSelection = dialog
                                        }

                                        override fun onInterstitialCustomFailed() {}
                                        override fun onAdsClick(cadid: String) {/*if (Utilty.isNetworkConnected(this@MainActivity)) GstApp.appInstance.jobManager.addJobInBackground(
                                                CustomAdCountJob(data.cadid)
                                            )*/
                                        }
                                    })
                            } else {
                                DownloadingWebPage(this@MainActivity, object : DownloadedWebPage {
                                    override fun onSuccess() {
                                        Utilty.adsInit.InterstitialCustomAds(this@MainActivity,
                                            data,
                                            object : InterstitialCustom {
                                                override fun onInterstitialCustomClose() {
                                                    AdCloseExitIntent()
                                                }

                                                override fun onInterstitialCustomLoaded(dialog: Dialog) {
                                                    dialogCustomShowSelection = dialog
                                                }

                                                override fun onInterstitialCustomFailed() {}
                                                override fun onAdsClick(cadid: String) {/*if (Utilty.isNetworkConnected(this@MainActivity)) GstApp.appInstance.jobManager.addJobInBackground(
                                                        CustomAdCountJob(data.cadid)
                                                    )*/
                                                }
                                            })
                                    }

                                    override fun onFailed() {}
                                }).execute(url)
                            }
                        }
                    }

                    override fun onFailed() {
                    }
                })
            }
        } catch (e: NullPointerException) {
            e.printStackTrace()
        } catch (e: IndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private var adprogress: Dialog? = null

    fun adsDialogProgress() {
        adprogress = Dialog(this, R.style.dialogTheme)
        adprogress?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        adprogress?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        adprogress?.setCancelable(false)
        adprogress?.setContentView(R.layout.dialog_loading_layout)
        adprogress?.show()
    }

    private fun CheackGameUrl(): Boolean {
        return GAME_PAGE_URL != ""
    }

    override fun onPurchasesUpdated(
        billingResult: BillingResult, purchases: MutableList<Purchase>?
    ) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            val skuListData = instances?.skuDao()?.getRoomSku()
            if (!skuListData.isNullOrEmpty()) for (purchase in purchases) {
                val originalJson = JSONObject(purchase.originalJson)
                val productId = originalJson.getString("productId")
                verificationPurchase(productId, purchase.purchaseToken)

                val settings = RoomConnection()
                settings.id = DataBase_Constant.SUBSCRIPTION_ORDER_ID_ID
                settings.data = purchase.orderId ?: purchase.purchaseToken

                instances?.roomConnectionDao()?.insertRoomConnection(settings)
            }
        }
    }

    private fun purchaseSuccessDialog() {
        val parentView: View = LayoutInflater.from(this).inflate(R.layout.dialog_restore, null)
        val dialog = Dialog(this)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setContentView(parentView)
        val okay: AppCompatTextView = parentView.findViewById(R.id.okay)
        okay.setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        dialog.show()
    }


    fun checkPurchaseDialog() {
        val currentTimeMillis = System.currentTimeMillis()
        if ((TIME_STAMP_ID_PURCHASE_DIALOG == 0L)
            || (currentTimeMillis - TIME_STAMP_ID_PURCHASE_DIALOG >= TimeUnit.DAYS.toMillis(1))
        ) {
            val skuListData = instances?.skuDao()?.getRoomSku()
            if (SUBSCRIPTION_STATE != "SUBSCRIPTION_STATE_ACTIVE" && skuListData != null && isNetworkAvailable(
                    this@MainActivity
                )
            ) {
                TIME_STAMP_ID_PURCHASE_DIALOG = currentTimeMillis
                SubscribeDilog()
            }
        } else if (idInAppRated != "true"
            && currentTimeMillis - TIME_STAMP_RATE_APP_DIALOG >= TimeUnit.DAYS.toMillis(1)
        ) {
            TIME_STAMP_RATE_APP_DIALOG = currentTimeMillis
            mRateUseDialog()
        }
    }


    var countHistory = 0
    val handlerHistory = Handler(Looper.getMainLooper())
    val runnableHistory = object : Runnable {
        override fun run() {
            if (adsAdHistoryFail) {
                if (fragment is GSTCalculator) {
                    (fragment as GSTCalculator).showProgress(8)
                }
                handlerHistory.removeCallbacks(this)
                callbackAdHistory?.invoke()
            } else if (interstitialAdHistory != null) {
                interstitialAdHistory?.show(this@MainActivity)
                interstitialAdHistory?.fullScreenContentCallback =
                    object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            if (fragment is GSTCalculator) {
                                (fragment as GSTCalculator).showProgress(8)
                            }
                            callbackAdHistory?.invoke()
                            interstitialAdHistory = null
                        }
                    }
            } else if (20 < countHistory) {
                if (fragment is GSTCalculator) {
                    (fragment as GSTCalculator).showProgress(8)
                }
                handlerHistory.removeCallbacks(this)
                callbackAdHistory?.invoke()
            } else {
                countHistory += 1
                handlerHistory.postDelayed(this, 250)
            }
        }
    }

    var adsAdHistoryFail = false
    var interstitialAdHistory: InterstitialAd? = null
    var callbackAdHistory: (() -> Unit)? = null
    fun historyClick(callback: () -> Unit) {
        if (interstitialAdHistory != null) {
            interstitialAdHistory?.show(this@MainActivity)
            interstitialAdHistory?.fullScreenContentCallback =
                object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        if (fragment is GSTCalculator) {
                            (fragment as GSTCalculator).showProgress(8)
                        }
                        handlerHistory.removeCallbacks(runnableHistory)
                        callbackAdHistory?.invoke()
                        interstitialAdHistory = null
                    }

                    override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                        super.onAdFailedToShowFullScreenContent(p0)
                        if (fragment is GSTCalculator) {
                            (fragment as GSTCalculator).showProgress(8)
                        }
                        handlerHistory.removeCallbacks(runnableHistory)
                        callbackAdHistory?.invoke()
                        interstitialAdHistory = null
                    }
                }
        } else {
            callbackAdHistory = callback
            countHistory = 0
            adsAdHistoryFail = false
            handlerHistory.postDelayed(runnableHistory, 250)
            if (fragment is GSTCalculator) {
                (fragment as GSTCalculator).showProgress(0)
            }
            val ads = builderAds(FULL_HISTORY)
            when (ads[0]) {
                GOOGLE -> {
                    InterstitialAd.load(this,
                        if (BuildConfig.DEBUG) "/6499/example/interstitial" else ads[1],
                        AdRequest.Builder().build(),
                        object : InterstitialAdLoadCallback() {
                            override fun onAdLoaded(ads: InterstitialAd) {
                                interstitialAdHistory = ads
                            }

                            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                                adsAdHistoryFail = true
                            }
                        })
                }

                else -> {
                    if (fragment is GSTCalculator) {
                        (fragment as GSTCalculator).showProgress(8)
                    }
                    handlerHistory.removeCallbacks(runnableHistory)
                    callbackAdHistory?.invoke()
                }
            }
        }
    }


    private fun showRateIn() {
        val manager: ReviewManager = ReviewManagerFactory.create(this)
        val request: com.google.android.play.core.tasks.Task<ReviewInfo> =
            manager.requestReviewFlow()
        request.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val reviewInfo: ReviewInfo = task.result
                val flow: com.google.android.play.core.tasks.Task<Void> =
                    manager.launchReviewFlow(this, reviewInfo)
                flow.addOnCompleteListener { it ->
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)
                        )
                    )
                }
                flow.addOnFailureListener { it -> }
            } else {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)
                    )
                )
            }
        }
    }

}
