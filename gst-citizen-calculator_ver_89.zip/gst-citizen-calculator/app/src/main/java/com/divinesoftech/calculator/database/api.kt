package com.divinesoftech.calculator.database

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.net.Uri
import android.os.AsyncTask
import android.os.Process
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.annotation.Keep
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.divinesoftech.CUSTOM_DOMAIN
import com.divinesoftech.SKU_LINK
import com.divinesoftech.TIME_STAMP_FULL_SPLASH
import com.divinesoftech.TIME_STAMP_ID_PURCHASE_DIALOG
import com.divinesoftech.calculator.Activities.bitmapFromDrawable
import com.divinesoftech.calculator.Common.Utilty.*
import com.divinesoftech.calculator.CustomAd.CustomAdsUtil.ASSERT_LOCATION
import com.divinesoftech.calculator.R
import com.divinesoftech.calculator.database.Helper.*
import com.divinesoftech.calculator.database.room.*
import com.divinesoftech.isPrime
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.gst_custom_banner_ads.view.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit


interface AdsFailToLoad {
    fun onFailed()
}

class HistroyDataAs {
    var data = ""
    var operator = ""
}

@Keep
class GSTLIVE_ADS {
    var ID = ""
    var ADS_ID = ""
    var ADS_KEYWORD = ""
    var ENABLE = 0
}


fun splashBuilderAds(): String {
    var id = ""
    val currentTimeMillis = System.currentTimeMillis()
    if (isPrime() || !isAdsLibsLoad()) return id
    instances?.versionDao()?.getVersionData(FULL_SPLASH, 1)?.let {
        if (currentTimeMillis - TIME_STAMP_ID_PURCHASE_DIALOG >= TimeUnit.DAYS.toMillis(1)) {
            id = ""
        } else if ((TIME_STAMP_FULL_SPLASH == 0L)
            || (currentTimeMillis - TIME_STAMP_FULL_SPLASH >= TimeUnit.MINUTES.toMillis(it.count.toLong()))
        ) {
            it.adsChild.forEach { ads ->
                if (ads.ads_name == GOOGLE_AD && it.enable == 1) {
                    TIME_STAMP_FULL_SPLASH = System.currentTimeMillis()
                    id = ads.ads_id
                }
            }
        }
    }
    return id
}

fun Context.builderAds(name: String): ArrayList<String> {
    if (isPrime() || !isAdsLibsLoad()) return setNoDataFound()

    val preferences = getSharedPreferences("ADS_ALTERNATIVE", Context.MODE_PRIVATE)
    val ads = instances?.versionDao()?.getVersionData(name, 1)
    if (ads != null) {

        if (ads.count != 0) {
            var count = preferences.getInt("${name}_count", 0)
            @SuppressLint("CommitPrefEdits") val editor = preferences.edit()
            if (ads.count <= count) {
                editor.putInt("${name}_count", 0)
                editor.apply()
            } else {
                count += 1
                editor.putInt("${name}_count", count)
                editor.apply()
                return setNoDataFound()
            }
        }

        val listAds = ArrayList<GSTLIVE_ADS>()
        ads.adsChild.forEach { itAdsTemp ->

            if (itAdsTemp.ads_name != CUSTOM_AD && itAdsTemp.ads_name != ALTERNATIVE && itAdsTemp.enable != -1) {
                val liveAds = GSTLIVE_ADS()
                liveAds.ID = itAdsTemp.id
                liveAds.ADS_ID = itAdsTemp.ads_id
                liveAds.ADS_KEYWORD = itAdsTemp.ads_name
                liveAds.ENABLE = itAdsTemp.enable
                listAds.add(liveAds)
            }
        }

        val strings = ArrayList<String>()
        ads.adsChild.forEach { itAds ->
            if (itAds.enable == 1 && listAds.size > 0) {
                when (itAds.ads_name) {
                    CUSTOM_AD -> {
                        strings.add(0, CUSTOM_AD)
                        strings.add(1, CUSTOM_AD)
                        strings.add(2, CUSTOM_AD)
                        return strings
                    }

                    ALTERNATIVE -> {
                        @SuppressLint("CommitPrefEdits") val editor = preferences.edit()
                        when (preferences.getInt(name, 1)) {
                            1 -> {
                                return if (listAds.size == 1) {
                                    editor.putInt(name, 1)
                                    editor.apply()
                                    strings.add(0, listAds[0].ADS_KEYWORD)
                                    strings.add(1, listAds[0].ADS_ID)
                                    strings.add(2, listAds[0].ID)
                                    strings
                                } else {
                                    editor.putInt(name, 2)
                                    editor.apply()

                                    strings.add(0, listAds[0].ADS_KEYWORD)
                                    strings.add(1, listAds[0].ADS_ID)
                                    strings.add(2, listAds[0].ID)
                                    strings
                                }
                            }

                            2 -> {
                                return if (listAds.size == 2) {
                                    editor.putInt(name, 1)
                                    editor.apply()

                                    strings.add(0, listAds[1].ADS_KEYWORD)
                                    strings.add(1, listAds[1].ADS_ID)
                                    strings.add(2, listAds[1].ID)
                                    strings
                                } else {
                                    editor.putInt(name, 3)
                                    editor.apply()

                                    strings.add(0, listAds[1].ADS_KEYWORD)
                                    strings.add(1, listAds[1].ADS_ID)
                                    strings.add(2, listAds[1].ID)
                                    strings
                                }
                            }

                            3 -> {
                                return if (listAds.size == 3) {
                                    editor.putInt(name, 1)
                                    editor.apply()

                                    strings.add(0, listAds[2].ADS_KEYWORD)
                                    strings.add(1, listAds[2].ADS_ID)
                                    strings.add(2, listAds[2].ID)
                                    strings
                                } else {
                                    editor.putInt(name, 4)
                                    editor.apply()

                                    strings.add(0, listAds[2].ADS_KEYWORD)
                                    strings.add(1, listAds[2].ADS_ID)
                                    strings.add(2, listAds[2].ID)
                                    strings
                                }
                            }

                            4 -> {
                                return if (listAds.size == 4) {
                                    editor.putInt(name, 1)
                                    editor.apply()

                                    strings.add(0, listAds[3].ADS_KEYWORD)
                                    strings.add(1, listAds[3].ADS_ID)
                                    strings.add(2, listAds[3].ID)
                                    strings
                                } else {
                                    editor.putInt(name, 5)
                                    editor.apply()

                                    strings.add(0, listAds[3].ADS_KEYWORD)
                                    strings.add(1, listAds[3].ADS_ID)
                                    strings.add(2, listAds[3].ID)
                                    strings
                                }
                            }

                            5 -> {
                                editor.putInt(name, 1)
                                editor.apply()

                                strings.add(0, listAds[4].ADS_KEYWORD)
                                strings.add(1, listAds[4].ADS_ID)
                                strings.add(2, listAds[4].ID)
                                return strings
                            }
                        }
                    }

                    else -> {
                        strings.add(0, itAds.ads_name)
                        strings.add(1, itAds.ads_id)
                        strings.add(2, itAds.id)
                        return strings
                    }
                }
            }
        }
    } else Log.e("builderAds ", "ads != null")

    return setNoDataFound()
}

fun setDefaultData(): ArrayList<String> {
    val strings = ArrayList<String>()
    strings.add(0, DEFAULT)
    strings.add(1, DEFAULT)
    strings.add(2, DEFAULT)
    return strings
}

fun setCustomData(): ArrayList<String> {
    val strings = ArrayList<String>()
    strings.add(0, CUSTOM_AD)
    strings.add(1, CUSTOM_AD)
    strings.add(2, CUSTOM_AD)
    return strings
}

fun getCustomData(name: String): Int {
    var customStatus = -1
    val ads = instances?.versionDao()?.getVersionData(name, 1)

    ads?.adsChild?.forEach { itAdsTemp ->
        if (itAdsTemp.ads_name == CUSTOM_AD) {
            customStatus = itAdsTemp.enable
        }
    }

    return customStatus
}

fun setNoDataFound(): ArrayList<String> {
    val strings = ArrayList<String>()
    strings.add(0, NO_DATA_FOUND)
    strings.add(1, NO_DATA_FOUND)
    strings.add(2, NO_DATA_FOUND)
    return strings
}

fun checkAdsIsFailed(placementName: String, id: String): Boolean {
    var isAvailable = false
    val data = instances?.roomAdsLoadedDao()?.getRoomAdsLoaded(id, placementName)
    if (data != null) {
        isAvailable = true
    }
    return isAvailable
}

fun deleteRecord(placementName: String) {
    instances?.roomAdsLoadedDao()?.deleteRoomAdsLoaded(placementName)
}

fun isAdsEnable(name: String): Boolean {
    return instances?.versionDao()?.adsEnable(name) == 1
}

fun isAdsLibsLoad(): Boolean {
    return instances?.roomRoomMainAd()?.getRoomMain_Status(ID_MAIN_STATUS) == "1"
}

fun isGameLoad(): Boolean {
    return instances?.roomRoomMainAd()?.getRoomMain_Status(ID_GAME) == "1"
}

fun isLoadForcefully(): Boolean {
    return instances?.roomRoomMainAd()?.getRoomMain_Status(ID_FORCEFULLY) == "1"
}


fun Context.initialize() {
    MobileAds.initialize(this)
    MobileAds.setRequestConfiguration(
        RequestConfiguration.Builder()
            .setTestDeviceIds(
                listOf(
                    "B1A57D07DF3E1C38022CB3EBED42B25F",
                    "3020BC5A0BF203A48377783FDFC65CC5",
                    "95906B95A152802BDBC88E85B956E8E0",
                    "211D2161E1A99FAA626B73D7B58DAD66",
                    "1F2B0C5D25D38284AD59DD01FD670754",
                    "80697C32BB1872BA2E38FA60E17BC4D8",
                    "7899DF65AC07249894D67E1916E024E0",
                    "B329C2CEE6D5882C674D7B1431FEEBF8",
                    "3368FFB4CE8D4A153E6A429CC9F34695",
                    "2D2AB2D3711DE48A6F631D44E148508E",
                    "F4C1CA5BDA884479811402A4525FCBBF"
                )
            ).build()
    )
}

fun Context.adsFailToLoads(
    placementName: String
): java.util.ArrayList<String> {
    val strings = java.util.ArrayList<String>()
    if (!isNetworkConnected(this)) return setCustomData()

    val ads = instances?.versionDao()?.getVersionData(placementName, 1)
    if (ads != null) {
        val data = ads.adsChild

        if (data != null && data.size > 0) {
            data.forEach {
                if (!checkAdsIsFailed(
                        placementName,
                        it.id
                    ) && it.enable == 0 && it.ads_name != ALTERNATIVE
                ) {
                    strings.add(0, it.ads_name)
                    strings.add(1, it.ads_id)
                    strings.add(2, it.id)

                    val liveAdsLoadedId = RoomAdsLoaded()
                    liveAdsLoadedId.ads_name = it.ads_name
                    liveAdsLoadedId.ads_id = it.ads_id
                    liveAdsLoadedId.id = it.id
                    liveAdsLoadedId.placement_name = placementName
                    instances?.roomAdsLoadedDao()?.insertRoomAdsLoaded(liveAdsLoadedId)
                    return strings
                }
            }
        }
    }
    return setNoDataFound()
}

fun showCustomBanner(layout_banner_view: LinearLayout) {
    try {
        layout_banner_view.visibility = View.VISIBLE
        if (layout_banner_view.childCount > 0) {
            layout_banner_view.removeAllViews()
        }

        val bannerAds = BannerAds(layout_banner_view.context)
        mLoadingData(layout_banner_view.context)?.let {
            bannerAds.builder(it)
        }

        //Todo Show Banner Ads
        layout_banner_view.addView(bannerAds)
        //Todo listener. it's optional
        bannerAds.setOnBannerAdsListener(object :
            AdsLoadingListener {
            override fun onLoaded() {

            }

            override fun onFailedAds() {

            }

            override fun onClick() {

            }
        })
    } catch (e: Exception) {
        e.printStackTrace()
    }

}

fun showGameBanner(layout_banner_view: LinearLayout) {
    try {
        val inflater = layout_banner_view.context
            .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

        val view: View = inflater.inflate(R.layout.game_banner, layout_banner_view, false)

        val rawObj: RoomGame? = mLoadingGameData()
        if (rawObj != null) {
            Picasso.get().load(SKU_LINK.replace("SKU", "AD") + rawObj?.banner)
                .into(view.findViewById<ImageView>(R.id.banner_img))
            view.findViewById<ImageView>(R.id.banner_img).visibility = View.VISIBLE

            view.findViewById<ImageView>(R.id.banner_img).setOnClickListener {
                try {
                    val builder = CustomTabsIntent.Builder()
                    builder.setToolbarColor(
                        ContextCompat.getColor(
                            layout_banner_view.context,
                            R.color.App_dark
                        )
                    )
                    builder.setCloseButtonIcon(
                        bitmapFromDrawable(
                            layout_banner_view.context,
                            R.drawable.ic_back_white
                        )
                    )

                    val customTabsIntent = builder.build()
                    customTabsIntent.intent.setPackage("com.android.chrome")
                    customTabsIntent.launchUrl(
                        layout_banner_view.context,
                        Uri.parse(rawObj.link)
                    )
                } catch (_: ActivityNotFoundException) {
                } catch (_: Exception) {
                }
            }
        } else {
            view.findViewById<ImageView>(R.id.banner_img).visibility = View.GONE
        }


        if (layout_banner_view.childCount > 0) {
            layout_banner_view.removeAllViews()
        }
        layout_banner_view.addView(view)
        layout_banner_view.invalidate()
        layout_banner_view.bringToFront()


    } catch (e: Exception) {
        e.printStackTrace()
    }

}

class BannerAds(context: Context) : FrameLayout(context) {

    private lateinit var adsLoadingListener: AdsLoadingListener

    fun builder(tbAdvertisement: RoomAdvertisement) {
        if (tbAdvertisement != null) {
            val executor: ExecutorService =
                ThreadPoolExecutor(
                    3,
                    3,
                    0L,
                    TimeUnit.MILLISECONDS,
                    ArrayBlockingQueue(15)
                )
            val stringArrayList = java.util.ArrayList<String>()
            val sdCard = context.filesDir.toString()
            val mLocationDir = File(sdCard, ASSERT_LOCATION)
            if (!mLocationDir.exists()) {
                mLocationDir.mkdir()
            }

            val icon: String = tbAdvertisement.ICON
//            stringArrayList.add(icon)
//            val iconFile = File(mLocationDir, icon)

            setAdsData(tbAdvertisement)
            /*   if (iconFile.exists()) {
                   setAdsData(tbAdvertisement)
               } else if (isNetworkAvailable(context)) {
                   val assertDownloading = AssertDownloading(context, stringArrayList, object :
                       AdsDataListener {
                       override fun onLoaded() {
                           executor.shutdown()
                           setAdsData(tbAdvertisement)
                       }

                       override fun onFailedAssert() {
                           executor.shutdown()
                           if (::adsLoadingListener.isInitialized) {
                               adsLoadingListener.onFailedAds()
                           }
                       }
                   })
                   assertDownloading.executeOnExecutor(executor)
               }*/
        }
    }

    private fun setAdsData(tbAdvertisement: RoomAdvertisement) {
        LayoutInflater.from(context).inflate(R.layout.gst_custom_banner_ads, this)
        native_ad_title_ads_network.text = tbAdvertisement.ADDTITLE
        native_ad_title_ads_network.isSelected = true
        native_ad_social_context_ads_network.text = tbAdvertisement.ADDDESCD
        native_ad_social_context_ads_network.isSelected = true
        ratingbar_ads_network.rating = tbAdvertisement.RATING.toFloat()
        val mDrawable =
            ContextCompat.getDrawable(context, R.drawable.gst_banner_network_btn_app)
        mDrawable?.colorFilter = PorterDuffColorFilter(
            Color.parseColor(if (tbAdvertisement.COLOR == "null") "#444bb6" else tbAdvertisement.COLOR),
            PorterDuff.Mode.MULTIPLY
        )
        native_ad_call_to_action_ads_network.background = mDrawable

        Glide.with(context)
            .load(CUSTOM_DOMAIN + tbAdvertisement.ICON)
            .apply(
                RequestOptions().diskCacheStrategy(DiskCacheStrategy.ALL).skipMemoryCache(true)
            )
            .into(native_icon_view_ads_network)

        native_ad_call_to_action_ads_network.setOnClickListener {
            try {
                val intent = Intent("android.intent.action.VIEW")
                intent.data = Uri.parse(tbAdvertisement.INSTALL)
                context.startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }



        if (::adsLoadingListener.isInitialized) {
            adsLoadingListener.onLoaded()
        }
    }

    fun setOnBannerAdsListener(adsLoadingListener: AdsLoadingListener) {
        this.adsLoadingListener = adsLoadingListener
    }

}

interface AdsLoadingListener {
    fun onLoaded()
    fun onFailedAds()
    fun onClick()
}

interface AdsDataListener {
    fun onLoaded()
    fun onFailedAssert()
}

class AssertDownloading(
    val context: Context,
    private val paths: ArrayList<String>,
    private val adsListener: AdsDataListener
) :
    AsyncTask<String, Int, String>() {
    override fun doInBackground(vararg params: String?): String {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
        val arrayList = java.util.ArrayList<String>()
        for (i in paths.indices) {
            if (download(CUSTOM_DOMAIN + paths[i], paths[i])) {
                arrayList.add(paths[i])
            }
        }
        return if (arrayList.size == paths.size) {
            "done"
        } else {
            "failed"
        }
    }


    override fun onPostExecute(result: String?) {
        super.onPostExecute(result)
        if (result.equals("done")) {
            adsListener.onLoaded()
        } else {
            adsListener.onFailedAssert()
        }
    }


    private fun download(
        downloadUrl: String,
        imageName: String
    ): Boolean {
        return try {
            val url = URL(downloadUrl)

            var mLocationDir: File? = null
            val sdCard = context.filesDir.toString()
            mLocationDir = File(sdCard, ASSERT_LOCATION)
            if (!mLocationDir.exists()) {
                mLocationDir.mkdir()
            }
            val file = File(mLocationDir, imageName)
            if (file.exists() && file.length() > 0) {
                return true
            }
            val ucon = url.openConnection()
            var inputStream: InputStream? = null
            val httpConn = ucon as HttpURLConnection
            httpConn.requestMethod = "GET"
            httpConn.connect()
            if (httpConn.responseCode == HttpURLConnection.HTTP_OK) {
                inputStream = httpConn.inputStream
            }
            val fos = FileOutputStream(file)
            val buffer = ByteArray(64000)
            var bufferLength = 0
            if (inputStream != null) {
                while (inputStream.read(buffer).also { bufferLength = it } > 0) {
                    fos.write(buffer, 0, bufferLength)
                }
            }
            fos.close()
            file.exists() && file.length() > 0
        } catch (io: IOException) {
            io.printStackTrace()
            false
        } catch (e: NullPointerException) {
            e.printStackTrace()
            false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}

var tags: List<RoomTags> = ArrayList()
var games: List<RoomGame> = ArrayList()
var mAdsMax: Int = 0
var getApkCount: Int = 0
var customDataResult: List<RoomAdvertisement> = ArrayList()
lateinit var indices: ArrayList<Int>
fun mLoadingData(context: Context): RoomAdvertisement? {

    customDataResult = instances?.roomAdvertisementDao()?.getRoomAdvertisement()!!

    tags = instances?.roomTagsDao()?.getRoomAdsLoaded()!!


    if (customDataResult != null && customDataResult.size > 0) {
        if (!::indices.isInitialized) {
            indices = ArrayList(customDataResult.size)

            for (i in 0 until customDataResult.size) {
                indices.add(i)
            }

            indices.shuffle()
        }

        val int = mGetApk(context)
        return if (int == -1) {
            null
        } else {
            customDataResult[indices[int]]
        }
    } else {
        return null
    }
}

fun mLoadingGameData(): RoomGame? {
    games = instances?.roomGamesDao()?.getRoomGameLoaded()!!
    if (games != null && games.size > 0) {
        Collections.shuffle(games)
        return games[0]
    } else if (games != null && games.size == 1) {
        return games[0]
    } else {
        return null
    }
}

private fun mGetApk(context: Context): Int {


    if (customDataResult != null && customDataResult.isNotEmpty()) {
        if (customDataResult.size == 0) {
            return -1
        } else if (mAdsMax == customDataResult.size) {
            mAdsMax = 0
        }
        val mAdsAnswer: Int = mAdsMax++

        try {

            val packageName = customDataResult[indices[mAdsAnswer]].INSTALL
            if (packageName == context.packageName
                || getLaunchIntent(
                    context,
                    packageName
                ) != null
            ) {
                getApkCount++
                if (getApkCount == customDataResult.size) {
                    getApkCount = 0
                    return -1
                }
                return mGetApk(context)
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }

        getApkCount = 0
        return mAdsAnswer
    } else return -1

}


private fun getLaunchIntent(
    context: Context,
    packageName: String?
): Intent? {
    return context.packageManager.getLaunchIntentForPackage(packageName!!)
}