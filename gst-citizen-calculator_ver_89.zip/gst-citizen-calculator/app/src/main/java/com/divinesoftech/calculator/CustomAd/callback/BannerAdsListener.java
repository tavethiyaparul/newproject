package com.divinesoftech.calculator.CustomAd.callback;

public interface BannerAdsListener {
    void onBannerLoad();
    void onBannerFailed();
}
