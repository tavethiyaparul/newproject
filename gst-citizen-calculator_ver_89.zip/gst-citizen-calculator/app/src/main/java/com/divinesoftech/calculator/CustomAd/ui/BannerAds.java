package com.divinesoftech.calculator.CustomAd.ui;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.divinesoftech.calculator.CustomAd.callback.BannerAdsListener;
import com.divinesoftech.calculator.CustomAd.model.Data;
import com.divinesoftech.calculator.R;


import java.io.File;

import static com.divinesoftech.calculator.CustomAd.CustomAdsUtil.ASSERT_LOCATION;


public class BannerAds extends FrameLayout {
    Context context;
    ImageView native_icon_view;
    AppCompatTextView native_ad_title, native_ad_social_context;
    AppCompatRatingBar ratingbar;
    AppCompatButton native_ad_call_to_action;
    BannerAdsListener bannerAdsListener;
    AdsClick adsClick;

    public BannerAds(Context context) {
        super(context);
        this.context = context;
    }

    public void onListner(AdsClick adsClick) {
        this.adsClick = adsClick;
    }

    public void adLoad(Data data) {
        try {
            LayoutInflater.from(context).inflate(R.layout.ads_network_custom_banner, this);
            native_icon_view = findViewById(R.id.native_icon_view_ads_network);
            native_ad_title = findViewById(R.id.native_ad_title_ads_network);
            ratingbar = findViewById(R.id.ratingbar_ads_network);
            native_ad_social_context = findViewById(R.id.native_ad_social_context_ads_network);
            native_ad_call_to_action = findViewById(R.id.native_ad_call_to_action_ads_network);

            native_ad_title.setText(data.getTitle());
            native_ad_social_context.setText(data.getDesc());
            ratingbar.setRating(Float.parseFloat(data.getRating()));


            Drawable mDrawable = ContextCompat.getDrawable(context, R.drawable.ads_network_btn_app);
            mDrawable.setColorFilter(new PorterDuffColorFilter(Color.parseColor(data.getColor().equals("null") ? "#444bb6"
                    : data.getColor()), PorterDuff.Mode.MULTIPLY));
            native_ad_call_to_action.setBackground(mDrawable);

            Glide.with(context)
                    .load(context.getFilesDir() + File.separator + ASSERT_LOCATION + File.separator + data.getIcon().substring(data.getIcon().lastIndexOf('/') + 1))
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .skipMemoryCache(true))
                    .into(native_icon_view);



            native_ad_call_to_action.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        adsClick.onClick(data.getCadid());
                        /*if (isNetworkConnected(context)) {
                            ExecutorService executor = new ThreadPoolExecutor(3, 3,
                                    0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(15));
                            new CustomAdsCountSync()
                                    .executeOnExecutor(executor,
                                            data.getCadid(),
                                            PACKAGE_NAME,
                                            "Banner");
                            executor.shutdown();
                        }*/
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setData(Uri.parse(data.getInstall()));
                        context.startActivity(intent);
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            native_icon_view.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        adsClick.onClick(data.getCadid());
                        /*if (isNetworkConnected(context)) {
                            ExecutorService executor = new ThreadPoolExecutor(3, 3, 0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(15));
                            new CustomAdsCountSync()
                                    .executeOnExecutor(executor,
                                            data.getCadid(),
                                            PACKAGE_NAME,
                                            "Banner");
                            executor.shutdown();
                        }*/
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setData(Uri.parse(data.getInstall()));
                        context.startActivity(intent);

                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            if (bannerAdsListener != null)
                bannerAdsListener.onBannerLoad();
        } catch (IndexOutOfBoundsException | NullPointerException e) {
            e.printStackTrace();
            if (bannerAdsListener != null)
                bannerAdsListener.onBannerFailed();
        } catch (Exception e) {
            e.printStackTrace();
            if (bannerAdsListener != null)
                bannerAdsListener.onBannerFailed();
        }
    }

    public void setListener(BannerAdsListener bannerAdsListener) {
        this.bannerAdsListener = bannerAdsListener;
    }

}
