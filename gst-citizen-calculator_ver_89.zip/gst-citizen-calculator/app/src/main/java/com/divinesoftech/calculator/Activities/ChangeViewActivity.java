package com.divinesoftech.calculator.Activities;

import android.content.SharedPreferences;

import com.google.android.material.tabs.TabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.divinesoftech.calculator.Adapter.ChangeViewAdapter;
import com.divinesoftech.calculator.R;

import static com.divinesoftech.calculator.Classes.GstApp.currentActivity;
import static com.divinesoftech.calculator.Common.Utilty.is_done;

public class ChangeViewActivity extends AppCompatActivity {
    ViewPager viewPager;
    int images[] = {R.drawable.simple_calculator, R.drawable.citizen_calculator, R.drawable.gst_calculator, R.drawable.gst_citizen_calculator};
    ChangeViewAdapter myCustomPagerAdapter;
    TextView ActionBarTitle;
    ImageView done;

    SharedPreferences change_view;
    SharedPreferences.Editor change_editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_view);
        currentActivity=this;
        change_view = getApplicationContext().getSharedPreferences("change_view", MODE_PRIVATE);
        change_editor = change_view.edit();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_changeview);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().addFlags(1024);
        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_actionbar, null);
        ActionBarTitle = (TextView) v.findViewById(R.id.action_bar_title);
        done = (ImageView) v.findViewById(R.id.action_done);
        done.setVisibility(View.VISIBLE);
       // v.findViewById(R.id.gift_layout).setVisibility(View.GONE);
        getSupportActionBar().setCustomView(v);
        // ActionBarTitle.setText("Select Theme");
        ActionBarTitle.setText("Simple Calculator");


        viewPager = (ViewPager) findViewById(R.id.viewPager);
        myCustomPagerAdapter = new ChangeViewAdapter(ChangeViewActivity.this, images);
        viewPager.setAdapter(myCustomPagerAdapter);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                if (position == 0)
                    ActionBarTitle.setText("Simple Calculator");

                if (position == 1)
                    ActionBarTitle.setText("Citizen Calculator");

                if (position == 2)
                    ActionBarTitle.setText("GST Calculator");

                if (position == 3)
                    ActionBarTitle.setText("GST & Citizen Calculator");

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                is_done = true;
                change_editor.putInt("view_type", viewPager.getCurrentItem());
                change_editor.apply();
                Toast.makeText(ChangeViewActivity.this, "View Changed", Toast.LENGTH_SHORT).show();
                finish();

            }
        });


        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager, true);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


}
