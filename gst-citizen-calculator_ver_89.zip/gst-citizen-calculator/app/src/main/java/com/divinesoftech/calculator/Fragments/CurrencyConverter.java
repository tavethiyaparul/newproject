package com.divinesoftech.calculator.Fragments;

import static android.content.Context.MODE_PRIVATE;
import static com.divinesoftech.calculator.Common.Utilty.isNetworkAvailable;
import static com.divinesoftech.calculator.database.room.RoomDatabaseGstKt.instances;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.Reload_Currancy;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.countrylist;
import static com.divinesoftech.calculator.mongodb.MongodbUtility.mCurrancyData;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.divinesoftech.calculator.Activities.CurrancyList;
import com.divinesoftech.calculator.Activities.MainActivity;
import com.divinesoftech.calculator.Classes.Model.Country;
import com.divinesoftech.calculator.Classes.Model.CurrancyResponse;
import com.divinesoftech.calculator.Classes.Model.Currency_data;
import com.divinesoftech.calculator.Classes.Model.WidgetModel;
import com.divinesoftech.calculator.R;
import com.divinesoftech.calculator.Widgets.CurrancyWidget;
import com.divinesoftech.calculator.database.DataBase_Constant;
import com.divinesoftech.calculator.database.DatabaseGst;
import com.divinesoftech.calculator.mongodb.MongodbUtility;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CurrencyConverter extends Fragment implements RecyclerItemTouchHelper.RecyclerItemTouchHelperListener {
    View view;

    LinearLayout layout;
    AppCompatEditText Amount_edit, answer;
    AppCompatImageView switch_country, from_image, to_image;
    AppCompatTextView from_currancy_label, to_currancy_label, editTextFrom, editTextTo, last_update;
    RelativeLayout layout_from, layout_to;
    Animation animation;
    Dialog dialog;
    DailogAdapter dilog_adapter;
    int is_count = 0;
    List<String> saved_currancy = new ArrayList<>();
    List<Country> country_data = new ArrayList<>();
    List<Country> dilog_country_data = new ArrayList<>();
    String selected_from_str = "", selected_to_str = "", from_img_uri = "", to_img_uri = "";
    SharedPreferences shared_saved;
    SharedPreferences.Editor editor_saved;
    WidgetModel widgetModel;
    RecyclerView selected_recycle;
    RecyclerView.LayoutManager layoutManager;
    SelectedAdepter selectedAdepter;
    RefreshListReceiver refreshListReceiver;
    Boolean flag_label = false;
    DecimalFormat formater = new DecimalFormat("############.######");
    RelativeLayout progress;
    SharedPreferences img_url;
    SharedPreferences.Editor imgEditor;
    SharedPreferences flagPrefs;
    SharedPreferences.Editor flagEditor;
    SharedPreferences imges;
    SharedPreferences.Editor editor;
    FrameLayout frameLayout;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor save_editor;
    WidgetModel model;
    SharedPreferences preferences;
    RelativeLayout ad_layout;
//    LinearLayout google_layout;
    CurrancyResponse currancyResponse;
    DatabaseGst databaseGst;


    public CurrencyConverter() {
    }


    @Override
    public void onDestroy() {
        try {
            getActivity().unregisterReceiver(refreshListReceiver);

        } catch (NullPointerException | IllegalStateException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    public void onResume() {

        try {
            IntentFilter intentFilter = new IntentFilter("listreceiver");
            getActivity().registerReceiver(refreshListReceiver, intentFilter);

            if (TextUtils.isEmpty(Amount_edit.getText())) {
                Amount_edit.setText("1");
                Amount_edit.setSelection(Amount_edit.length());
            } else {
                Amount_edit.setSelection(Amount_edit.length());
            }

            String get_saved_list = shared_saved.getString("set_shared", "");
            if (!TextUtils.isEmpty(get_saved_list)) {

                saved_currancy.clear();
                country_data.clear();
                JSONArray jsonArray = new JSONArray(get_saved_list);
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (dilog_country_data != null) {
                        for (Country name : dilog_country_data) {
                            if (name.getName().equals(jsonArray.getString(i))) {
                                saved_currancy.add(name.getName());
                                Country model = new Country();
                                model.setFlag(name.getFlag());
                                model.setName(name.getName());
                                model.setIndx(name.getIndx());
                                country_data.add(model);
                            }
                        }
                    }
                }


                if (country_data != null && country_data.size() > 0) {
                    selectedAdepter = new SelectedAdepter(country_data, getActivity());
                    selected_recycle.setAdapter(selectedAdepter);

                }


            }
        } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onResume();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.currencyfragment_layout, container, false);
        setHasOptionsMenu(true);
        databaseGst = ((MainActivity) requireActivity()).databaseGst;
        currancyResponse = new CurrancyResponse();

        if (instances!=null) {
            try {
                if (countrylist.size() == 0) {
                    String countryFlag = instances.roomConnectionDao().getRoomConnection(DataBase_Constant.DATA_COUNTRY_FLAG);
                    if (countryFlag != null && !countryFlag.equals(""))
                        MongodbUtility.countrylist = new Gson().fromJson(countryFlag, new TypeToken<ArrayList<Country>>() {
                        }.getType());
                }
                if (instances != null)
                    if (mCurrancyData.size() == 0) {
                        String currancy = instances.roomConnectionDao().getRoomConnection(DataBase_Constant.DATA_CURRANCY);
                        if (currancy != null && !currancy.equals(""))
                            MongodbUtility.mCurrancyData = new Gson().fromJson(currancy, new TypeToken<ArrayList<Currency_data>>() {
                            }.getType());
                    }


            } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ad_layout = view.findViewById(R.id.ad_layout);
        widgetModel = new WidgetModel();

        flagPrefs = getActivity().getSharedPreferences("flag_prefrence", MODE_PRIVATE);
        flagEditor = flagPrefs.edit();
        refreshListReceiver = new RefreshListReceiver();
        model = new WidgetModel();
        progress = view.findViewById(R.id.progress_layout);
        editTextFrom = view.findViewById(R.id.country_from);
        editTextTo = view.findViewById(R.id.country_to);
        last_update = view.findViewById(R.id.time);

        from_currancy_label = view.findViewById(R.id.from_currancy_label);
        to_currancy_label = view.findViewById(R.id.to_currancy_label);
        Amount_edit = view.findViewById(R.id.amount);
        answer = view.findViewById(R.id.answer);
        switch_country = view.findViewById(R.id.switch_btn);
        switch_country.setEnabled(false);
        switch_country.setClickable(false);
        animation = AnimationUtils.loadAnimation(getActivity(), R.anim.rotation);
        from_image = view.findViewById(R.id.from_image);
        to_image = view.findViewById(R.id.to_image);
        layout_from = view.findViewById(R.id.relative_country_from);
        layout_to = view.findViewById(R.id.relative_country_to);
        selected_recycle = view.findViewById(R.id.country_selected_list);
        layoutManager = new LinearLayoutManager(getActivity());
        selected_recycle.setLayoutManager(layoutManager);
        frameLayout = view.findViewById(R.id.frame_home);


        ad_layout = view.findViewById(R.id.ad_layout);
//        google_layout = view.findViewById(R.id.google_layout);


        img_url = getActivity().getSharedPreferences("img_prefrence", MODE_PRIVATE);
        imgEditor = img_url.edit();
        shared_saved = getActivity().getSharedPreferences("currancy_list_prefs", MODE_PRIVATE);
        editor_saved = shared_saved.edit();
        imges = getActivity().getSharedPreferences("img_prefrence", MODE_PRIVATE);
        editor = imges.edit();
        sharedPreferences = getActivity().getSharedPreferences("currancy_list_prefs", MODE_PRIVATE);
        save_editor = sharedPreferences.edit();
        preferences = getActivity().getSharedPreferences("update", MODE_PRIVATE);


        try {
            if (countrylist.size() == 0 || mCurrancyData.size() == 0) {
                if (isNetworkAvailable(getActivity())) {

                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("No Internet Found !");
                    builder.setMessage("Check your Internet Connectivity \n and Tryagain");
                    builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            if (isNetworkAvailable(getActivity())) {
                                dialog.dismiss();
                                progress.setVisibility(View.VISIBLE);

                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        progress.setVisibility(View.GONE);
                                    }
                                }, 3000);

                            } else {
                                Toast.makeText(getActivity(), "No Internet Found", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.create();
                    builder.show();


                }

            } else {
                if (countrylist.size() != 0) {
                    dilog_country_data.clear();
                    for (int i = 0; i < countrylist.size(); i++) {
                        Country model = new Country();
                        model.setFlag(countrylist.get(i).getFlag());
                        model.setName(countrylist.get(i).getName());
                        model.setIndx(i);
                        dilog_country_data.add(model);
                    }
                }

                setFields();
            }
        } catch (JsonSyntaxException | NullPointerException | IndexOutOfBoundsException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


        /*if (isNetworkAvailable(getActivity()) && !isPrime() && isAdsLibsLoad()) {
            AdsLoadings();
        } else {
            ad_layout.setVisibility(View.GONE);
            //((MainActivity)getActivity()).Game_btn.setVisibility(View.GONE);
        }*/


        selected_recycle.setItemAnimator(new DefaultItemAnimator());
        selected_recycle.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(selected_recycle);


        Amount_edit.setOnClickListener(v -> {
            String test = Amount_edit.getText().toString();
            if (test.contains(" ")) {
                Amount_edit.setSelection(Amount_edit.getText().toString().length() - 1);
                Amount_edit.setFocusable(true);
            }
        });

        Amount_edit.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {


            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (getActivity().getCurrentFocus() == Amount_edit) {


                    if (!s.toString().equals("")) {

                        if (s.toString().length() == 1 && s.toString().equals(".")) {

                            Amount_edit.setText("0.");
                            Amount_edit.setSelection(Amount_edit.length());
                            s = "0.";
                        }


                        caovertation(from_currancy_label.getText().toString(), to_currancy_label.getText().toString(), s.toString(), answer, 201);
                    } else {
                    }


                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        layout_from.setOnClickListener(v -> {
            if (isNetworkAvailable(getActivity())) {
                is_count = 1;
                openCountryList();
            } else {
                Toast.makeText(getActivity(), "Internet Not Available", Toast.LENGTH_SHORT).show();
            }

        });
        layout_to.setOnClickListener(v -> {
            if (isNetworkAvailable(getActivity())) {
                is_count = 2;
                openCountryList();
            } else {
                Toast.makeText(getActivity(), "Internet not avilable", Toast.LENGTH_SHORT).show();
            }
        });


        /*try {
            ((MainActivity) getActivity()).checkInternetConnection();
        } catch (NullPointerException ignored) {
        } catch (Exception ignored) {
        }*/

        return view;
    }

    private void setFields() {
        try {


            if (TextUtils.isEmpty(img_url.getString("from_Shared", "")) && TextUtils.isEmpty(img_url.getString("to_Shared", ""))) {


                String country_lable_from = "", country_lable_to = "", selected_from_str = "", selected_to_str = "", from_url = "", to_url = "", from_name = "", to_name = "";
                from_url = com.divinesoftech.SocketKt.getFLAG_DOMAIN() + countrylist.get(149).getFlag();
                to_url = com.divinesoftech.SocketKt.getFLAG_DOMAIN() + countrylist.get(66).getFlag();
                from_name = countrylist.get(149).getName();
                to_name = countrylist.get(66).getName();

                selected_from_str = from_name.substring(0, Math.min(from_name.length(), 3));
                selected_to_str = to_name.substring(0, Math.min(to_name.length(), 3));
                country_lable_from = from_name.substring(from_name.lastIndexOf("-") + 2);
                country_lable_to = to_name.substring(to_name.lastIndexOf("-") + 2);

                imgEditor.putInt("from_selecte", 149);
                imgEditor.putInt("to_selecte", 66);
                imgEditor.apply();
                setModels(from_url, to_url, selected_from_str, selected_to_str, country_lable_from, country_lable_to);

            } else if (TextUtils.isEmpty(img_url.getString("from_Shared", "")) && !TextUtils.isEmpty(img_url.getString("to_Shared", ""))) {

                String country_lable_from = "", country_lable_to = "", selected_from_str = "", selected_to_str = "", from_url = "", to_url = "", from_name = "", to_name = "";
                from_url = com.divinesoftech.SocketKt.getFLAG_DOMAIN() + countrylist.get(149).getFlag();
                to_url = img_url.getString("to_Shared", "");
                from_name = countrylist.get(149).getName();
                to_name = img_url.getString("to_name", "");

                selected_from_str = from_name.substring(0, Math.min(from_name.length(), 3));
                selected_to_str = to_name.substring(0, Math.min(to_name.length(), 3));
                country_lable_from = from_name.substring(from_name.lastIndexOf("-") + 2);
                country_lable_to = to_name.substring(to_name.lastIndexOf("-") + 2);
                setModels(from_url, to_url, selected_from_str, selected_to_str, country_lable_from, country_lable_to);


            } else if (!TextUtils.isEmpty(img_url.getString("from_Shared", "")) && TextUtils.isEmpty(img_url.getString("to_Shared", ""))) {

                String country_lable_from = "", country_lable_to = "", selected_from_str = "", selected_to_str = "", from_url = "", to_url = "", from_name = "", to_name = "";

                from_url = img_url.getString("from_Shared", "");
                to_url = com.divinesoftech.SocketKt.getFLAG_DOMAIN() + countrylist.get(66).getFlag();

                from_name = img_url.getString("from_name", "");
                to_name = countrylist.get(149).getName();

                selected_from_str = from_name.substring(0, Math.min(from_name.length(), 3));
                selected_to_str = to_name.substring(0, Math.min(to_name.length(), 3));
                country_lable_from = from_name.substring(from_name.lastIndexOf("-") + 2);
                country_lable_to = to_name.substring(to_name.lastIndexOf("-") + 2);

                setModels(from_url, to_url, selected_from_str, selected_to_str, country_lable_from, country_lable_to);


            } else if (!TextUtils.isEmpty(img_url.getString("from_Shared", "")) && !TextUtils.isEmpty(img_url.getString("to_Shared", ""))) {

                String country_lable_from = "", country_lable_to = "", selected_from_str = "", selected_to_str = "", from_url = "", to_url = "", from_name = "", to_name = "";
                from_url = img_url.getString("from_Shared", "");
                to_url = img_url.getString("to_Shared", "");
                from_name = img_url.getString("from_name", "");
                to_name = img_url.getString("to_name", "");

                selected_from_str = from_name.substring(0, Math.min(from_name.length(), 3));
                selected_to_str = to_name.substring(0, Math.min(to_name.length(), 3));
                country_lable_from = from_name.substring(from_name.lastIndexOf("-") + 2);
                country_lable_to = to_name.substring(to_name.lastIndexOf("-") + 2);

                setModels(from_url, to_url, selected_from_str, selected_to_str, country_lable_from, country_lable_to);

            } else {

            }
        } catch (NullPointerException | IndexOutOfBoundsException | NumberFormatException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setModels(String... strings) {
        try {
            model.setFromCountry(strings[0]); //fromurl
            model.setToCountry(strings[1]);  //tourl
            model.setFrom_shared_label(strings[2]);  //lable USD
            model.setTo_shared_label(strings[3]);      //lable INR
            model.setFrom_country_name(strings[4]);  // from country name
            model.setTo_country_name(strings[5]);       // to Country name

            editTextTo.setText(model.getTo_country_name());
            editTextFrom.setText(model.getFrom_country_name());
            from_currancy_label.setText(model.getFrom_shared_label());
            to_currancy_label.setText(model.getTo_shared_label());

            Glide.with(getActivity()).load(model.getFromCountry()).into(from_image);
            Glide.with(getActivity()).load(model.getToCountry()).into(to_image);


            caovertation(from_currancy_label.getText().toString(), to_currancy_label.getText().toString(), Amount_edit.getText().toString(), answer, 201);
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    @Override
    public void onCreateOptionsMenu(final Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.currancy_menu, menu);

        ImageView locButton = new ImageView(getActivity());
        locButton.setImageResource(R.drawable.ic_refresh);

        menu.getItem(0).setActionView(locButton);
        locButton.setOnClickListener(v -> {
            menu.getItem(0).getActionView().startAnimation(animation);
            if (TextUtils.isEmpty(Amount_edit.getText())) {
                Amount_edit.setText("1");
            }
            try {
                if (isNetworkAvailable(getActivity())) {
                    Reload_Currancy = true;
                    // new RefreshAppData(progress, getActivity()).execute();
                    if (country_data != null && country_data.size() > 0) {
                        selectedAdepter.notifyDataSetChanged();
                    }
                } else {
                    Toast.makeText(getActivity(), "Internet not avilable", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_refresh:


                return true;
            case R.id.action_add:
                if (isNetworkAvailable(getActivity())) {
                    Intent intent = new Intent(getActivity(), CurrancyList.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getActivity(), "Internet not avilable", Toast.LENGTH_SHORT).show();
                }

                return true;
        }


        return super.onOptionsItemSelected(item);
    }


    void openCountryList() {
        dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.country_list_view_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCanceledOnTouchOutside(true);
        dialog.setCancelable(true);
        RecyclerView dialog_recycle;
        RecyclerView.LayoutManager layoutManager;
        EditText search;

        dialog_recycle = dialog.findViewById(R.id.country_list);
        search = dialog.findViewById(R.id.search);


        layoutManager = new LinearLayoutManager(getActivity());
        dialog_recycle.setLayoutManager(layoutManager);


        if (dilog_country_data.size() != 0) {
            dilog_adapter = new DailogAdapter(dilog_country_data, getActivity());
            dialog_recycle.setAdapter(dilog_adapter);
        }


        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                try {
                    if (!s.equals(""))
                        dilog_adapter.getFilter().filter(s);
                } catch (NullPointerException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        WindowManager wm = (WindowManager) getActivity().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        Window win = dialog.getWindow();
        win.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.show();

    }


    private void caovertation(String fromCNTR, String toCNTR, String amount, EditText editText, int code) {

        String match = "";
        Double Amount, dolor_price, first_price = 0.0, second_price = 0.0;
        int from_position = 0, to_position = 0;

        if (code == 201) {
            from_position = img_url.getInt("from_selecte", 0);
            to_position = img_url.getInt("to_selecte", 0);

        } else {
            from_position = img_url.getInt("from_selecte", 0);
            to_position = img_url.getInt("to_shared_ind", 0);
        }


        if (!flag_label) {
            from_currancy_label.setText(fromCNTR);
            to_currancy_label.setText(toCNTR);

        }

        if (!TextUtils.isEmpty(amount)) {

            if (amount.length() == 1 && amount.equals(".")) {
                amount = "1";
            }
            Amount = Double.valueOf(amount);
            int i = 0;

            try {


                if (mCurrancyData != null) {
                    if (mCurrancyData.size() != 0) {
                        if (!fromCNTR.equals("USD") && !toCNTR.equals("USD")) {
                            String temp = "USD" + fromCNTR;
                            String temp1 = "USD" + toCNTR;

                            if (temp.equals(mCurrancyData.get(from_position).getCountry())) {
                                first_price = Double.valueOf(mCurrancyData.get(from_position).getRate());
                                first_price = first_price * 1;


                            }
                            if (temp1.equals(mCurrancyData.get(to_position).getCountry())) {
                                second_price = Double.valueOf(mCurrancyData.get(to_position).getRate());
                                second_price = second_price * 1;

                            }

                            dolor_price = Amount / first_price;
                            dolor_price = dolor_price * second_price;
                            dolor_price = Math.round(dolor_price * 100d) / 100d;
                            String result_text = formater.format(dolor_price);
                            last_update.setText("Last Update: " + DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()));
                            editText.setText(result_text);


                        } else if (!fromCNTR.equals("USD") && toCNTR.equals("USD")) {

                            match = "USD" + fromCNTR;


                            if (match.equals(mCurrancyData.get(from_position).getCountry())) {

                                dolor_price = Double.valueOf(mCurrancyData.get(from_position).getRate());

                                dolor_price = Amount / dolor_price;
                                dolor_price = Math.round(dolor_price * 100d) / 100d;
                                String result_text = formater.format(dolor_price);

                                editText.setText(result_text);

                                last_update.setText("Last Update: " + DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()));

                            }

                        } else if (fromCNTR.equals("USD") && !toCNTR.equals("USD")) {
                            match = "USD" + toCNTR;

                            if (match.equals(mCurrancyData.get(to_position).getCountry())) {

                                dolor_price = Double.valueOf(mCurrancyData.get(to_position).getRate());

                                dolor_price = Amount * dolor_price;
                                dolor_price = Math.round(dolor_price * 100d) / 100d;
                                String result_text = formater.format(dolor_price);

                                if (!android.text.TextUtils.isEmpty(result_text))
                                    editText.setText(result_text);
                                last_update.setText("Last Update: " + DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()));

                            }

                        }


                    }

                }


                widgetModel.setFromCountry(img_url.getString("from_Shared", ""));
                widgetModel.setToCountry(img_url.getString("to_Shared", ""));
                widgetModel.setFrom_shared_label(from_currancy_label.getText().toString());
                widgetModel.setTo_shared_label(to_currancy_label.getText().toString());
                widgetModel.setFromAmount(Amount_edit.getText().toString());
                widgetModel.setToAmount(answer.getText().toString());
                widgetModel.setFrom_country_name(editTextFrom.getText().toString());
                widgetModel.setTo_country_name(editTextTo.getText().toString());

                widgetdata(widgetModel);

                Intent intent = new Intent(getActivity(), CurrancyWidget.class);
                intent.setAction("REFRESH");
                LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);


            } catch (NullPointerException | NumberFormatException | IndexOutOfBoundsException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Amount_edit.setError("Enter value");
        }


    }


    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position) {

        if (viewHolder instanceof SelectedAdepter.SelectedViewHolder) {
            // get the removed item name to display it in snack bar
            String name = country_data.get(viewHolder.getAdapterPosition()).getName();
            final Country deletedItem = country_data.get(viewHolder.getAdapterPosition());
            final int deletedIndex = viewHolder.getAdapterPosition();


            // remove the item from recycler view
            selectedAdepter.removeItem(viewHolder.getAdapterPosition());
            saved_currancy.remove(deletedIndex);
            Gson gson = new Gson();
            String shared_list = gson.toJson(saved_currancy);
            save_editor.putString("set_shared", shared_list);
            save_editor.apply();


        }

    }


    public class DailogAdapter extends RecyclerView.Adapter<DailogAdapter.DilogViewHolder> implements Filterable {
        List<Country> datalist, namelist;
        Context context;
        CustomFilter filter;

        public DailogAdapter(List<Country> datalist, Context context) {
            this.datalist = datalist;
            this.namelist = datalist;
            this.context = context;

        }


        @Override
        public DilogViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view;
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            view = layoutInflater.inflate(R.layout.listrowitem, null);
            return new DilogViewHolder(view);
        }


        @Override
        public void onBindViewHolder(final DilogViewHolder holder, @SuppressLint("RecyclerView") final int position) {


            Glide.with(context)
                    .load(com.divinesoftech.SocketKt.getFLAG_DOMAIN() + datalist.get(position).getFlag())
                    .into(holder.imageView);
            holder.textView.setText(datalist.get(position).getName());

            holder.select_currancy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    if (is_count == 1) {

                        if (country_data.size() != 0) {
                            selectedAdepter.notifyDataSetChanged();
                        }

                        selected_from_str = holder.textView.getText().toString();
                        from_currancy_label.setText(selected_from_str.substring(0, Math.min(selected_from_str.length(), 3)));


                        from_img_uri = com.divinesoftech.SocketKt.getFLAG_DOMAIN() + datalist.get(position).getFlag();


                        imgEditor.putString("from_Shared", from_img_uri);
                        imgEditor.putString("from_name", datalist.get(position).getName());
                        imgEditor.putInt("from_selecte", datalist.get(position).getIndx());
                        imgEditor.apply();
                        editTextFrom.setText(holder.textView.getText().toString().substring(holder.textView.getText().toString().lastIndexOf("-") + 2));
                        Glide.with(context)
                                .load(com.divinesoftech.SocketKt.getFLAG_DOMAIN() + datalist.get(position).getFlag())
                                .into(from_image);
                        caovertation(from_currancy_label.getText().toString(), to_currancy_label.getText().toString(), Amount_edit.getText().toString(), answer, 201);
                        // is_count = 0;
                        dialog.dismiss();
                    } else if (is_count == 2) {

                        selected_to_str = holder.textView.getText().toString();
                        to_currancy_label.setText(selected_to_str.substring(0, Math.min(selected_to_str.length(), 3)));

                        to_img_uri = com.divinesoftech.SocketKt.getFLAG_DOMAIN() + datalist.get(position).getFlag();
                        imgEditor.putString("to_Shared", to_img_uri);
                        imgEditor.putString("to_name", datalist.get(position).getName());
                        imgEditor.putInt("to_selecte", datalist.get(position).getIndx());
                        imgEditor.apply();
                        // widgetModel.setToCountry(to_img_uri);
                        // widgetdata(widgetModel);
                        editTextTo.setText(holder.textView.getText().toString().substring(holder.textView.getText().toString().lastIndexOf("-") + 2));
                        Glide.with(context)
                                .load(com.divinesoftech.SocketKt.getFLAG_DOMAIN() + datalist.get(position).getFlag())
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .into(to_image);

                        caovertation(from_currancy_label.getText().toString(), to_currancy_label.getText().toString(), Amount_edit.getText().toString(), answer, 201);
                        // is_count = 0;
                        dialog.dismiss();
                    }

                }
            });


        }

        @Override
        public int getItemCount() {
            return datalist.size();
        }

        @Override
        public Filter getFilter() {
            if (filter == null) {
                filter = new CustomFilter(this, namelist);
                // return filter;
            }

            return filter;
        }

        class DilogViewHolder extends RecyclerView.ViewHolder {
            public ImageView imageView;
            public TextView textView;
            public LinearLayout select_currancy;

            public DilogViewHolder(View itemView) {
                super(itemView);
                imageView = (ImageView) itemView.findViewById(R.id.flag);
                textView = (TextView) itemView.findViewById(R.id.country_name);
                select_currancy = (LinearLayout) itemView.findViewById(R.id.country_item);
            }
        }


    }

    public class CustomFilter extends Filter {

        DailogAdapter dailogAdapter;
        List<Country> namelist;


        public CustomFilter(DailogAdapter dailogAdapter, List<Country> namelist) {
            this.dailogAdapter = dailogAdapter;
            this.namelist = namelist;
        }

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if (constraint != null && constraint.length() > 0) {
                //CHANGE TO UPPER
                constraint = constraint.toString().toUpperCase();
                //STORE OUR FILTERED PLAYERS
                List<Country> filteredPlayers = new ArrayList<>();

                for (int i = 0; i < namelist.size(); i++) {
                    //CHECK
                    if (namelist.get(i).getName().toUpperCase().contains(constraint)) {
                        //ADD PLAYER TO FILTERED PLAYERS
                        filteredPlayers.add(namelist.get(i));
                    }
                }

                results.count = filteredPlayers.size();
                results.values = filteredPlayers;
            } else {
                results.count = namelist.size();
                results.values = namelist;

            }


            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            dailogAdapter.datalist = (List<Country>) results.values;

            //REFRESH
            dailogAdapter.notifyDataSetChanged();
        }
    }

    public class SelectedAdepter extends RecyclerView.Adapter<SelectedAdepter.SelectedViewHolder> {
        List<Country> selected_list;
        Context context;
        boolean delete_flag = false;

        public SelectedAdepter(List<Country> selected_list, Context context) {
            this.selected_list = selected_list;
            this.context = context;

        }


        @NonNull
        @Override
        public SelectedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            view = layoutInflater.inflate(R.layout.selected_row_item, null);
            return new SelectedViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final SelectedViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            // holder.delete.setVisibility(View.VISIBLE);


            flag_label = true;

            final Country country = selected_list.get(position);
            String text_label = "";
            text_label = selected_list.get(position).getName();
            text_label = text_label.substring(0, Math.min(text_label.length(), 3));


            Glide.with(context)
                    .load(com.divinesoftech.SocketKt.getFLAG_DOMAIN() + selected_list.get(position).getFlag())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.selected_imageView);

            holder.selected_textView.setText(selected_list.get(position).getName().substring(selected_list.get(position).getName().toString().lastIndexOf("-") + 2));

            final String finalText_label = text_label;


            if (selected_list.size() != 0) {
                imgEditor.putInt("to_shared_ind", selected_list.get(position).getIndx());
                imgEditor.apply();
                caovertation(from_currancy_label.getText().toString(), finalText_label, Amount_edit.getText().toString(), holder.currancy_answer, 200);
            }

            // }


            Amount_edit.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (getActivity().getCurrentFocus() == Amount_edit) {
                        try {
                            if (!s.toString().equals("")) {
                                if (selected_list.size() != 0) {
                                    imgEditor.putInt("to_shared_ind", selected_list.get(position).getIndx());
                                    imgEditor.apply();
                                    caovertation(from_currancy_label.getText().toString(), finalText_label, s.toString(), holder.currancy_answer, 200);
                                }
                            }
                        } catch (NullPointerException | IndexOutOfBoundsException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });


        }

        @Override
        public int getItemCount() {
            return selected_list.size();
        }

        public void removeItem(int position) {
            selected_list.remove(position);
            // notify the item removed by position
            // to perform recycler view delete animations
            // NOTE: don't call notifyDataSetChanged()

            notifyItemRemoved(position);
        }

        public void restoreItem(Country item, int position) {
            selected_list.add(position, item);
            // notify item added by position
            notifyItemInserted(position);
        }

        class SelectedViewHolder extends RecyclerView.ViewHolder {
            public ImageView selected_imageView;
            public TextView selected_textView;
            public LinearLayout selected_currancy;
            public EditText currancy_answer;
            public RelativeLayout layout;
            //  CheckBox fav_img;

            public SelectedViewHolder(View itemView) {
                super(itemView);
                selected_imageView = (ImageView) itemView.findViewById(R.id.flag);
                // delete = (ImageView) itemView.findViewById(R.id.delete);
                //   fav_img = (CheckBox) itemView.findViewById(R.id.favourite);
                selected_textView = (TextView) itemView.findViewById(R.id.country_name);
                currancy_answer = (EditText) itemView.findViewById(R.id.currancy_amount);
                selected_currancy = (LinearLayout) itemView.findViewById(R.id.country_item);
                layout = (RelativeLayout) itemView.findViewById(R.id.fornt_view);
            }
        }


    }


    private class RefreshListReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            ArrayList<Country> selectedDataList = new ArrayList<>();
            ArrayList<Country> unSelectedDataList = new ArrayList<>();
            ArrayList<Country> mergedList = new ArrayList<>();
            if (!TextUtils.isEmpty(action)) {


                if (action.equalsIgnoreCase("listreceiver")) {
                    ArrayList<Country> countryArrayList = (ArrayList<Country>) intent.getExtras().getSerializable("updatedList");
                    // String delete_item = intent.getStringExtra("deleteItem");
                    if (countryArrayList != null && countryArrayList.size() > 0) {
                        for (int i = 0; i < countryArrayList.size(); i++) {
                            Country country = countryArrayList.get(i);
                            String favSelected = country.getChecked();
                            if (!TextUtils.isEmpty(favSelected)) {
                                if (favSelected.equalsIgnoreCase("true")) {
                                    selectedDataList.add(country);
                                } else {
                                    unSelectedDataList.add(country);
                                }
                            }

                        }
                        mergedList.addAll(selectedDataList);
                        mergedList.addAll(unSelectedDataList);

                        selectedAdepter = new SelectedAdepter(mergedList, getActivity());
                        selected_recycle.setAdapter(selectedAdepter);

                    }
                }
            }

        }
    }


    private void widgetdata(WidgetModel model) {
        SharedPreferences mPrefs = getActivity().getSharedPreferences("widget_prefrence", MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = mPrefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(model);
        prefsEditor.putString("MyObject", json);
        prefsEditor.apply();

    }


/*
    void AdsLoadings() {
        ArrayList<String> type = builderAds(requireContext(), COMMON_BANNER);
        if (type.size() > 0) {
            switch (type.get(0)) {
                case GOOGLE_AD:
                    new Utilty().GoogleBannerAdvance(requireActivity(), type.get(1), google_layout, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;


                case ADAPTIVE_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().GoogleAdaptiveBanner(requireActivity(), type.get(1), google_layout, false, new AdsFailToLoad() {
                        @Override
                        public void onFailed() {
                            showCustomBanner(google_layout);
                        }
                    });
                    break;
                case SMART_BANNER:
                    google_layout.setVisibility(View.GONE);
                    new Utilty().mSmartBanner(requireActivity(), type.get(1), ad_layout, google_layout);
                    break;

                case CUSTOM_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showCustomBanner(google_layout);
                    break;

                case GAME_AD:
                    google_layout.setVisibility(View.VISIBLE);
                    showGameBanner(google_layout);
                    break;
            }
        }
    }
*/


   /* void CurrancyDataTable() {
        new CurrancyDataSync(databaseGst, new OnResponseData() {
            @Override
            public void onResponse() {

                CountryFlagData();
            }

            @Override
            public void onFailed() {

                progress.setVisibility(View.GONE);
            }
        }).execute(MONGODB_CONNECTION);

    }

    void CountryFlagData() {

        new CountryFlagSync(databaseGst, new OnResponseData() {
            @Override
            public void onResponse() {

                if (countrylist.size() != 0) {
                    dilog_country_data.clear();
                    for (int i = 0; i < countrylist.size(); i++) {
                        Country model = new Country();
                        model.setFlag(countrylist.get(i).getFlag());
                        model.setName(countrylist.get(i).getName());
                        model.setIndx(i);
                        dilog_country_data.add(model);
                    }
                }

                setFields();
                progress.setVisibility(View.GONE);
            }

            @Override
            public void onFailed() {


                progress.setVisibility(View.GONE);
            }
        }).execute(MONGODB_CONNECTION);

    }
*/

}


